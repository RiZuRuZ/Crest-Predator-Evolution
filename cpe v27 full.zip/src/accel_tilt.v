// accel_tilt: tilt the board to move (ADXL362 accelerometer over SPI, Nexys A7)
//
// SPI mode 0 at about 1 MHz (SCLK = clk / (2 * HALF)). After reset: write POWER_CTL (0x2D)
// = 0x02 (measurement mode). Then every GAP clocks (~10 ms): read XDATA (0x08) and YDATA (0x09), the 8-bit
// values (1 g = about 64 at the default +-2 g range).
// Each axis is the average of the last 4 readings. Tilt beyond DEAD (about 15 degrees)
// on an axis gives a direction like a held button; it is released only below REL
// (hysteresis, so it does not flicker at the edge).
// INV_X / INV_Y / SWAP_XY turn the sensor axes into screen directions (set in top.v
// from a test on the board).
// ax_out / ay_out (after swap / invert) go to the HUD test line (SW14) to check it.
// PLACEHOLDERS: DEAD, REL.
module accel_tilt #(
    parameter DEAD    = 16,
    parameter REL     = 10,
    parameter INV_X   = 0,
    parameter INV_Y   = 0,
    parameter SWAP_XY = 0,
    // clock-rate dependent (defaults for 100 MHz; top.v runs at 25 MHz)
    parameter HALF    = 50,        // clocks per half SCLK period
    parameter START   = 100000,    // clocks before the first command (1 ms)
    parameter GAP     = 1000000    // clocks between readings (10 ms)
)(
    input  wire clk,
    input  wire rst,
    output reg  sclk,
    output reg  mosi,
    input  wire miso,
    output reg  csn,
    output reg  tilt_l,
    output reg  tilt_r,
    output reg  tilt_u,
    output reg  tilt_d,
    output wire signed [7:0] ax_out,
    output wire signed [7:0] ay_out
);
    // ---- ~1 MHz bit clock: half period = HALF clocks ------------------------------------
    reg [5:0]  hc;
    wire       half = (hc == HALF - 1);
    always @(posedge clk) hc <= (rst || half) ? 6'd0 : hc + 6'd1;

    localparam S_WAIT = 2'd0, S_XFER = 2'd1, S_GAP = 2'd2;
    reg [1:0]  st;
    reg [19:0] wait_t;
    reg        inited;
    reg [31:0] tx;              // bytes to send, MSB first
    reg [31:0] rx;
    reg [5:0]  nbits, bitc;
    reg signed [7:0] ax, ay;
    reg signed [9:0] ax1, ax2, ax3, ay1, ay2, ay3;   // last readings (sign-extended)

    always @(posedge clk) begin
        if (rst) begin
            st <= S_WAIT; wait_t <= START; inited <= 1'b0;
            sclk <= 1'b0; csn <= 1'b1; mosi <= 1'b0;
            ax <= 8'sd0; ay <= 8'sd0; bitc <= 6'd0; nbits <= 6'd0;
            ax1 <= 10'sd0; ax2 <= 10'sd0; ax3 <= 10'sd0;
            ay1 <= 10'sd0; ay2 <= 10'sd0; ay3 <= 10'sd0;
        end else case (st)
            S_WAIT: if (wait_t == 20'd0) begin
                        csn  <= 1'b0;
                        sclk <= 1'b0;
                        if (!inited) begin tx <= {8'h0A, 8'h2D, 8'h02, 8'h00}; nbits <= 6'd24; mosi <= 1'b0; end
                        else         begin tx <= {8'h0B, 8'h08, 8'h00, 8'h00}; nbits <= 6'd32; mosi <= 1'b0; end
                        bitc <= 6'd0;
                        st   <= S_XFER;          // first bit of both commands is 0
                    end else wait_t <= wait_t - 20'd1;
            S_XFER: if (half) begin
                        if (!sclk) begin
                            if (bitc == nbits) begin st <= S_GAP; csn <= 1'b1; end
                            else sclk <= 1'b1;           // MOSI was set half a bit ago
                        end else begin
                            rx   <= {rx[30:0], miso};    // sample on the rising edge
                            tx   <= {tx[30:0], 1'b0};
                            mosi <= tx[30];              // next bit while SCLK is low
                            sclk <= 1'b0;
                            bitc <= bitc + 6'd1;
                        end
                    end
            S_GAP:  begin
                        if (inited) begin
                            // 4-reading average: sum of the last 3 + the new one
                            ax3 <= ax2; ax2 <= ax1; ax1 <= $signed(rx[15:8]);
                            ay3 <= ay2; ay2 <= ay1; ay1 <= $signed(rx[7:0]);
                            ax  <= ($signed(rx[15:8]) + ax1 + ax2 + ax3) >>> 2;
                            ay  <= ($signed(rx[7:0])  + ay1 + ay2 + ay3) >>> 2;
                        end
                        inited <= 1'b1;
                        wait_t <= GAP;                  // ~10 ms
                        st     <= S_WAIT;
                    end
            default: st <= S_WAIT;
        endcase
    end

    wire signed [7:0] vx = SWAP_XY ? ay : ax;
    wire signed [7:0] vy = SWAP_XY ? ax : ay;
    wire signed [7:0] hx = INV_X ? -vx : vx;
    wire signed [7:0] hy = INV_Y ? -vy : vy;
    assign ax_out = hx;
    assign ay_out = hy;
    always @(posedge clk) begin
        if (rst) begin tilt_l <= 1'b0; tilt_r <= 1'b0; tilt_u <= 1'b0; tilt_d <= 1'b0; end
        else begin
            tilt_r <= tilt_r ? (hx >  REL) : (hx >  DEAD);
            tilt_l <= tilt_l ? (hx < -REL) : (hx < -DEAD);
            tilt_d <= tilt_d ? (hy >  REL) : (hy >  DEAD);
            tilt_u <= tilt_u ? (hy < -REL) : (hy < -DEAD);
        end
    end
endmodule
