// camera: keeps the player in the middle of the screen in a wrapping 1920 x 640 world
// - cam_x / cam_y = world position of the screen's top-left pixel
// - x follows the player all the time and wraps around the world (the map is the loop)
// - y follows the player but stops at the world top and bottom, so nothing outside
//   the map is ever shown
// - the camera is updated once per frame on `update` (during vertical blanking),
//   one clock after the game tick so it already sees the new player position
// - world_x / world_y = world position of the current screen pixel, registered
//   (1 clock late, safe: the pixel changes every 4 clocks). Game renderers use these.
module camera #(
    parameter WORLD_W = 1920,
    parameter WORLD_H = 640,
    parameter VIEW_W  = 640,
    parameter VIEW_H  = 480
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        update,
    input  wire [10:0] player_x,
    input  wire [9:0]  player_y,
    input  wire [7:0]  player_w,       // box to keep in the middle (the sprite)
    input  wire [7:0]  player_h,
    input  wire [4:0]  zoom,           // world px per screen px x16: 16 = 1.0, 20 = 1.25
                                       // (Fever zooms out; the view becomes 20*zoom wide)
    input  wire [9:0]  pixel_x,
    input  wire [9:0]  pixel_y,
    // v14 screen shake: added to world_x / world_y only (drawing), cam_x / cam_y and all
    // game logic stay put; 0 = no shake
    input  wire signed [3:0] shake_x,
    input  wire signed [3:0] shake_y,
    output reg  [10:0] cam_x,
    output reg  [9:0]  cam_y,
    output reg  [10:0] world_x,
    output reg  [9:0]  world_y
);
    wire [6:0] half_w = player_w[7:1];
    wire [6:0] half_h = player_h[7:1];

    // x: player center minus half a screen, modulo the world width
    wire [9:0]  vhw  = zoom * 5'd20;                   // half view width  (320 at 1.0)
    wire [9:0]  vhh  = zoom * 4'd15;                   // half view height (240 at 1.0)
    wire [12:0] tx   = {2'b00, player_x} + half_w + WORLD_W - vhw;
    wire [12:0] tx_m = (tx >= WORLD_W) ? tx - WORLD_W : tx;

    // y: player center minus half a screen, clamped to 0 .. WORLD_H - VIEW_H
    wire signed [12:0] ty = $signed({3'b000, player_y}) + $signed({6'b0, half_h}) - $signed({3'b000, vhh});
    wire signed [12:0] ty_max = WORLD_H - $signed({2'b00, vhh, 1'b0});
    wire        [9:0]  ty_c = (ty < 0)      ? 10'd0 :
                              (ty > ty_max) ? ty_max[9:0] : ty[9:0];

    always @(posedge clk) begin
        if (rst) begin
            cam_x <= 11'd0;
            cam_y <= 10'd0;
        end else if (update) begin
            cam_x <= tx_m[10:0];
            cam_y <= ty_c;
        end
    end

    // world position of the pixel being drawn
    // (pixel * zoom / 16; at zoom 16 this is the pixel itself)
    wire [14:0] zx = pixel_x * zoom;
    wire [14:0] zy = pixel_y * zoom;
    // x: + WORLD_W keeps the sum positive for a negative shake, then one or two wraps
    wire [12:0] wx = {2'b00, zx[14:4]} + cam_x + WORLD_W + {{9{shake_x[3]}}, shake_x};
    wire [12:0] wx1 = (wx >= 2 * WORLD_W) ? wx - 2 * WORLD_W :
                      (wx >= WORLD_W)     ? wx - WORLD_W : wx;
    // y: clamp to the world (the top / bottom row repeats for a few pixels while shaking)
    wire signed [12:0] wy = $signed({3'b000, zy[13:4]}) + $signed({3'b000, cam_y})
                            + $signed({{9{shake_y[3]}}, shake_y});
    always @(posedge clk) begin
        world_x <= wx1[10:0];
        world_y <= (wy < 0) ? 10'd0 : (wy > WORLD_H - 1) ? WORLD_H - 1 : wy[9:0];
    end
endmodule
