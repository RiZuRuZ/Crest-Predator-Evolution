// fish_anim_counter
// Shared swim-frame counter for all fish. The frame advances every SWIM_TICKS game ticks.
// Give each fish slot a different phase so they do not flap in sync:
//     frame_i = frame_base + i   (2-bit add wraps 0..3)
module fish_anim_counter #(
    parameter SWIM_TICKS = 8          // 60 Hz / 8 = 7.5 frames per second
)(
    input  wire       clk,
    input  wire       rst,            // active-high synchronous
    input  wire       tick_60hz,      // 1-clk game tick
    output reg  [1:0] frame_base
);
    reg [7:0] cnt;
    always @(posedge clk) begin
        if (rst) begin
            cnt        <= 8'd0;
            frame_base <= 2'd0;
        end else if (tick_60hz) begin
            if (cnt == SWIM_TICKS - 1) begin
                cnt        <= 8'd0;
                frame_base <= frame_base + 2'd1;
            end else begin
                cnt <= cnt + 8'd1;
            end
        end
    end
endmodule
