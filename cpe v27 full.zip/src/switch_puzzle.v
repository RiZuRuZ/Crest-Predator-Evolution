// switch_puzzle: the hiding mini game - flip the switches whose LEDs blink
//
// On `start` a random set of 1..5 switches out of SW2..SW13 (12 switches) is chosen;
// the target is "each chosen switch flipped from where it is now". The LED above every
// switch that is not yet at its target blinks; a switch flipped to its target goes dark,
// flipping it back makes it blink again. `solved` = every switch at its target.
// `active` from shark_event clears the puzzle when the shark event ends.
module switch_puzzle (
    input  wire        clk,
    input  wire        rst,
    input  wire        start,          // 1-clk pulse
    input  wire        active,
    input  wire [11:0] sw,             // SW[13:2]
    input  wire [15:0] rand,
    input  wire        blink,          // slow blink phase
    output wire [11:0] led,            // LED[13:2]
    output wire        solved,
    output reg         running
);
    function [11:0] onehot(input [3:0] v);
        onehot = 12'd1 << ((v >= 4'd12) ? v - 4'd12 : v);
    endfunction

    wire [1:0]  extra = rand[13:12];                    // 0..3 more switches after the first
    wire [11:0] m0 = onehot(rand[3:0]);
    wire [11:0] m1 = (extra >= 2'd1) ? onehot(rand[7:4])  : 12'd0;
    wire [11:0] m2 = (extra >= 2'd2) ? onehot(rand[11:8]) : 12'd0;
    wire [11:0] m3 = (extra >= 2'd3) ? onehot(rand[15:12] ^ rand[3:0]) : 12'd0;
    wire [11:0] m4 = rand[14] ? onehot(rand[9:6]) : 12'd0;
    wire [11:0] mask_new = m0 | m1 | m2 | m3 | m4;

    reg [11:0] target;
    always @(posedge clk) begin
        if (rst || !active) begin
            running <= 1'b0;
            target  <= 12'd0;
        end else if (start) begin
            running <= 1'b1;
            target  <= sw ^ mask_new;
        end
    end

    wire [11:0] todo = running ? (sw ^ target) : 12'd0;
    assign solved = running && (todo == 12'd0);
    assign led    = blink ? todo : 12'd0;
endmodule
