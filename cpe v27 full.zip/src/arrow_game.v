// arrow_game: press the arrows in time (Audition style) - boss FINISH and event mini game
//
// A lane at the bottom of the screen (x 90..629, y 380..435) with a target box at
// x 128..171 (v25: 121..179). NA notes slide in from the right; press the matching button
// when a note is in the box:  |x - 150| <= 8 PERFECT, <= 20 GOOD, wrong button or <= 44 MISS
// (v25: <= 12 PERFECT, <= 28 GOOD, wrong button in the box = MISS);
// a note that passes the box is a MISS. After all NA notes: done, ok = misses < MISS_MAX.
// rating / rate_t tell boss_hud which word to show.
// v20: base speed by difficulty: easy 3, normal 4, hard 5 px per tick.
// v23: faster: easy 4, normal 5, hard 6 px per tick (slow = base - 1, fast = base + 2).
// v25: more notes and closer in normal / hard, faster, a wider box (the same on both sides):
//      base speed easy 6, normal 7, hard 8 px per tick (v23 +2); notes 16 / 24 / 28,
//      one every 26 / 20 / 16 ticks; box |x - 150| <= 28 (GOOD), <= 12 PERFECT; a press
//      outside the box does nothing, a note that leaves the box on the left is a MISS;
//      FAIL (ok = 0) at 5 / 6 / 7 misses.
// v21: 16 notes (was 10); every note has its own speed: slow (base - 1), normal, fast
//      (base + 2); a 5th note type, a yellow circle = the centre button (BTNC / Space);
//      a faster note waits until the one before it is past x 280, so notes never overtake.
//      `misses` is the miss count (event rating).
// Every number is a PLACEHOLDER.
module arrow_game (
    input  wire        clk,
    input  wire        rst,
    input  wire        tick,
    input  wire [15:0] rand,
    input  wire        start,
    input  wire [1:0]  diff,                  // v20: 0 easy, 1 normal, 2 hard
    input  wire        p_u, p_d, p_l, p_r,    // 1-clk button / key pulses
    input  wire        p_c,                   // v21: centre button / Space
    input  wire [9:0]  px,                    // screen x / y, 3 clocks late
    input  wire [9:0]  py,
    output reg         active,
    output reg         done,                  // 1-clk pulse
    output reg         ok,                    // valid with done
    output reg  [1:0]  rating,                // last judgement: 1 PERFECT, 2 GOOD, 3 MISS
    output reg  [5:0]  rate_t,                // ticks left to show it
    output reg  [3:0]  combo,                 // hits in a row
    output reg         hit,                   // 1-clk: PERFECT / GOOD (bite + sound)
    output reg  [4:0]  misses,                // v21
    output wire        pixel_on,
    output wire [11:0] rgb
);
    localparam TGT = 150, NS = 8;
    localparam [9:0] W_GOOD = 10'd28, W_PERF = 10'd12;   // v25 box (v23: 20 / 8, press <= 44)
    localparam [2:0] D_U = 0, D_D = 1, D_L = 2, D_R = 3, D_C = 4;
    // v25 by difficulty (v23: 4 / 5 / 6 px, 16 notes every 26 ticks, FAIL at 5 misses)
    wire [3:0] base     = (diff == 2'd0) ? 4'd6  : (diff == 2'd2) ? 4'd8  : 4'd7;
    wire [4:0] NA       = (diff == 2'd0) ? 5'd16 : (diff == 2'd2) ? 5'd28 : 5'd24;
    wire [4:0] GAP      = (diff == 2'd0) ? 5'd26 : (diff == 2'd2) ? 5'd16 : 5'd20;
    wire [4:0] MISS_MAX = (diff == 2'd0) ? 5'd5  : (diff == 2'd2) ? 5'd7  : 5'd6;

    reg        a_on  [0:NS-1];
    reg [2:0]  a_dir [0:NS-1];
    reg [9:0]  a_x   [0:NS-1];
    reg [3:0]  a_v   [0:NS-1];                // v21 own speed
    reg [4:0]  gap_t;
    reg [4:0]  spawned, judged;
    reg [2:0]  last_s;                        // slot of the last note
    reg        last_ok;                       // a note was spawned before

    integer k, k1, k2;
    // free slot, front note (smallest x)
    reg [2:0] fs, fr;
    reg       ff, fv;
    reg [9:0] fx;
    always @* begin
        ff = 1'b0; fs = 3'd0; fv = 1'b0; fr = 3'd0; fx = 10'h3FF;
        for (k1 = NS - 1; k1 >= 0; k1 = k1 - 1) begin
            if (!a_on[k1]) begin ff = 1'b1; fs = k1[2:0]; end
        end
        for (k1 = 0; k1 < NS; k1 = k1 + 1) begin
            if (a_on[k1] && a_x[k1] < fx) begin fv = 1'b1; fr = k1[2:0]; fx = a_x[k1]; end
        end
    end
    wire [9:0] fd   = (fx > TGT) ? fx - TGT : TGT - fx;
    wire       press = p_u | p_d | p_l | p_r | p_c;
    wire [2:0] pdir = p_c ? D_C : p_u ? D_U : p_d ? D_D : p_l ? D_L : D_R;

    // the next note: kind (rand[3:2]: 0 slow, 1..2 normal, 3 fast) and button
    // (rand[6:4]: 0..4, 5..7 fold back to an arrow)
    wire [3:0] v_new = (rand[3:2] == 2'd0) ? base - 4'd1 : (rand[3:2] == 2'd3) ? base + 4'd2 : base;
    wire [2:0] d_new = (rand[6:4] > 3'd4) ? {1'b0, rand[5:4]} : rand[6:4];
    wire       wait_ = last_ok && a_on[last_s] && (v_new > a_v[last_s]) && (a_x[last_s] >= 10'd280);

    always @(posedge clk) begin
        done <= 1'b0; hit <= 1'b0;
        if (rst) begin
            active <= 1'b0; ok <= 1'b0; rating <= 2'd0; rate_t <= 6'd0; combo <= 4'd0;
            gap_t <= 5'd0; spawned <= 5'd0; judged <= 5'd0; misses <= 5'd0;
            last_s <= 3'd0; last_ok <= 1'b0;
            for (k = 0; k < NS; k = k + 1) begin
                a_on[k] <= 1'b0; a_dir[k] <= 3'd0; a_x[k] <= 10'd0; a_v[k] <= 4'd4;
            end
        end else if (start) begin
            active <= 1'b1; ok <= 1'b0; rating <= 2'd0; rate_t <= 6'd0; combo <= 4'd0;
            gap_t <= 5'd0; spawned <= 5'd0; judged <= 5'd0; misses <= 5'd0; last_ok <= 1'b0;
            for (k = 0; k < NS; k = k + 1) a_on[k] <= 1'b0;
        end else if (active) begin
            if (tick) begin
                if (rate_t != 6'd0) rate_t <= rate_t - 6'd1;
                // move; a note past the box is a miss
                for (k = 0; k < NS; k = k + 1) if (a_on[k]) begin
                    a_x[k] <= a_x[k] - {6'd0, a_v[k]};
                    if (a_x[k] < TGT - W_GOOD) begin          // v25: left the box
                        a_on[k] <= 1'b0;
                        rating <= 2'd3; rate_t <= 6'd30; combo <= 4'd0;
                        misses <= misses + 5'd1; judged <= judged + 5'd1;
                    end
                end
                // a new note GAP ticks after the last one (later if it would overtake)
                if (gap_t < GAP) gap_t <= gap_t + 5'd1;
                else if (spawned < NA && ff && !wait_) begin
                    a_on[fs] <= 1'b1; a_dir[fs] <= d_new; a_x[fs] <= 10'd660; a_v[fs] <= v_new;
                    spawned <= spawned + 5'd1; gap_t <= 5'd0; last_s <= fs; last_ok <= 1'b1;
                end
                if (judged >= NA) begin
                    active <= 1'b0; done <= 1'b1; ok <= (misses < MISS_MAX);
                end
            end else if (press && fv && fd <= W_GOOD) begin   // v25: only inside the box
                a_on[fr] <= 1'b0;
                judged   <= judged + 5'd1;
                rate_t   <= 6'd30;
                if (pdir == a_dir[fr] && fd <= W_PERF) begin
                    rating <= 2'd1; combo <= combo + 4'd1; hit <= 1'b1;
                end else if (pdir == a_dir[fr]) begin
                    rating <= 2'd2; combo <= combo + 4'd1; hit <= 1'b1;
                end else begin
                    rating <= 2'd3; combo <= 4'd0; misses <= misses + 5'd1;
                end
            end
        end
    end

    // ---------------- drawing ----------------
    wire lane   = (px >= 10'd90) && (px < 10'd630) && (py >= 10'd380) && (py < 10'd436);
    wire lane_i = (px >= 10'd92) && (px < 10'd628) && (py >= 10'd382) && (py < 10'd434);
    // v25: box x 121..179 (+-28 around 150), PERFECT band x 138..161 (+-12)
    wire tbox   = (px >= 10'd121) && (px < 10'd180) && (py >= 10'd386) && (py < 10'd430);
    wire tbox_i = (px >= 10'd124) && (px < 10'd177) && (py >= 10'd389) && (py < 10'd427);
    wire pband  = (px >= 10'd138) && (px < 10'd162) && (py >= 10'd389) && (py < 10'd427);

    // note 28 x 28 around (a_x, 408): arrow, or a ring for the centre button
    reg       ar_on, ar_dot;
    reg [2:0] ar_dir;
    reg [9:0] u, v, al, cr, crd, cdx, cdy;
    reg [10:0] cd2;
    always @* begin
        ar_on = 1'b0; ar_dot = 1'b0; ar_dir = 3'd0;
        for (k2 = 0; k2 < NS; k2 = k2 + 1) begin
            u = px + 10'd14 - a_x[k2];            // 0..27 inside
            v = py - 10'd394;
            if (a_on[k2] && u < 10'd28 && v < 10'd28) begin
                if (a_dir[k2] == D_C) begin
                    cdx = (u > 10'd13) ? u - 10'd13 : 10'd13 - u;
                    cdy = (v > 10'd13) ? v - 10'd13 : 10'd13 - v;
                    cd2 = cdx[4:0] * cdx[4:0] + cdy[4:0] * cdy[4:0];
                    if (cd2 <= 11'd169) begin                       // radius 13
                        ar_on = 1'b1; ar_dir = D_C; ar_dot = (cd2 <= 11'd25);
                    end
                end else begin
                    // al = distance from the back (3) to the tip (26), cr = across
                    case (a_dir[k2])
                        D_R: begin al = u;           cr = v; end
                        D_L: begin al = 10'd27 - u;  cr = v; end
                        D_D: begin al = v;           cr = u; end
                        default: begin al = 10'd27 - v; cr = u; end
                    endcase
                    crd = (cr > 10'd14) ? cr - 10'd14 : 10'd14 - cr;
                    if (al >= 10'd3 && al <= 10'd26 && {crd, 1'b0} <= 10'd26 - al) begin
                        ar_on = 1'b1; ar_dir = a_dir[k2];
                    end
                end
            end
        end
    end

    assign pixel_on = active && lane;
    assign rgb = ar_on ? ((ar_dir == D_U) ? 12'hF55 : (ar_dir == D_D) ? 12'h5CF :
                          (ar_dir == D_L) ? 12'h7F7 : (ar_dir == D_R) ? 12'hFC3 :
                          (ar_dot ? 12'hFFF : 12'hFE3)) :
                 (tbox && !tbox_i) ? 12'hFE5 :
                 !lane_i ? 12'hFFF : pband ? 12'h652 : 12'h013;
endmodule
