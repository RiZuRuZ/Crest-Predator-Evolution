// powerup_ctrl: one power-up item at a time somewhere in the camera view
//
// Kinds (sprite frame in powerup.mem, 24 x 24):
//   0 heart  (+ in a blue orb)  one heart back (player_health.heart_up, at most 3)
//   1 shield                    blocks the next hit (pshield until used)
//   2 speed  (lightning)        faster for BOOST_TICKS (form_skills.boost)
// A new item appears FIRST_TICKS after the start, then every 20..30 s, inside the view
// (40 px from its edges) but not inside the safe box around the player (like the
// sea mines: the spot is tried again on the next tick). The kind is random; the
// heart is replaced by the shield while the player has all 3 hearts.
// v20: no shield while the player already has one (`has_shield`: power-up shield or Tough
// Scales): the shield / heart picks become speed. A shield item that is out when the
// player gets a shield goes away and another (not a shield) appears somewhere else on
// the next tick.
// It stays LIFE ticks, blinks in its last BLINK ticks, and bobs up and down 2 px.
// Touching it (player hitbox) takes it: `got` pulse with `got_kind`.
// Position: x world, y world + 128 (slot_sprite convention), top-left of the sprite.
// PLACEHOLDERS: all timings.
module powerup_ctrl #(
    parameter WORLD_W     = 1920,
    parameter FIRST_TICKS = 1200,    // 20 s
    parameter LIFE        = 720,     // 12 s
    parameter BLINK       = 180      // last 3 s
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        tick_60hz,
    input  wire [1:0]  diff,           // v18: first 10 / 12 / 20 s, then 10-15 / 15-20 / 25-34 s
    input  wire [15:0] rand,
    input  wire [10:0] cam_x,
    input  wire [9:0]  cam_y,
    input  wire [10:0] player_cx,
    input  wire [9:0]  player_cy,
    input  wire [8:0]  safe_x,
    input  wire [8:0]  safe_y,
    input  wire [10:0] player_x,     // hitbox
    input  wire [9:0]  player_y,
    input  wire [7:0]  player_w,
    input  wire [7:0]  player_h,
    input  wire [1:0]  hearts,
    input  wire        has_shield,   // v20
    input  wire [5:0]  anim,         // frame counter bits for bob / blink
    output wire        on,           // visible this frame (blinking included)
    output reg  [1:0]  kind,
    output wire [10:0] x,
    output wire [10:0] y,            // world y + 128
    output wire [10:0] cx,           // centre (world), for the aura
    output wire [9:0]  cy,
    output reg         got,          // 1-clk pulse
    output reg  [1:0]  got_kind
);
    reg        live;
    reg [10:0] px;
    reg [9:0]  py;
    reg [10:0] t;                    // life left / time to the next one
    assign on = live && (t > BLINK || anim[3]);

    // bob: 0,1,2,1 px every 8 frames
    wire [1:0] bob = (anim[5:4] == 2'd2) ? 2'd2 : (anim[5:4] == 2'd0) ? 2'd0 : 2'd1;
    assign x  = px;
    assign y  = {1'b0, py} + 11'd128 + bob;
    wire [11:0] cx_r = {1'b0, px} + 12'd12;
    assign cx = (cx_r >= WORLD_W) ? cx_r - WORLD_W : cx_r[10:0];
    assign cy = py + 10'd12 + bob;

    // candidate spot inside the view, and its distance to the player centre
    // v18 (more often than v17: 20 s, then 20..30 s)
    wire [10:0] first_t = (diff == 2'd0) ? 11'd600 : (diff == 2'd2) ? 11'd1200 : 11'd720;
    wire [10:0] next_t  = (diff == 2'd0) ? 11'd600  + {1'b0, rand[9:0] % 10'd300} :
                          (diff == 2'd2) ? 11'd1500 + {1'b0, rand[9:0] % 10'd540} :
                                           11'd900  + {1'b0, rand[9:0] % 10'd300};
    wire [9:0]  rxv  = rand[9:0] % 10'd536;            // 640 - 24 - 80
    wire [8:0]  ryv  = rand[15:7] % 9'd376;            // 480 - 24 - 80
    wire [11:0] sx_r = {1'b0, cam_x} + 12'd40 + rxv;
    wire [10:0] sx_w = (sx_r >= WORLD_W) ? sx_r - WORLD_W : sx_r[10:0];
    wire [9:0]  sy_w = cam_y + 10'd40 + ryv;
    wire [11:0] ncx_r = {1'b0, sx_w} + 12'd12;
    wire [10:0] ncx   = (ncx_r >= WORLD_W) ? ncx_r - WORLD_W : ncx_r[10:0];
    wire [10:0] sdx_a = (ncx >= player_cx) ? ncx - player_cx : player_cx - ncx;
    wire [10:0] sdx   = (sdx_a > WORLD_W / 2) ? WORLD_W - sdx_a : sdx_a;
    wire [9:0]  ncy   = sy_w + 10'd12;
    wire [9:0]  sdy   = (ncy >= player_cy) ? ncy - player_cy : player_cy - ncy;
    wire        too_close = (sdx < {2'd0, safe_x}) && (sdy < {1'b0, safe_y});
    wire [1:0]  rk   = (rand[12:11] == 2'd3) ? rand[13] : rand[12:11];   // 0..2
    wire [1:0]  pk0  = (rk == 2'd0 && hearts >= 2'd3) ? 2'd1 : rk;
    wire [1:0]  pick = (pk0 == 2'd1 && has_shield) ? 2'd2 : pk0;

    // contact
    wire touch_c;
    aabb_collision #(.SCREEN_W(WORLD_W), .CW(11)) u_c (
        .ax(px), .ay({1'b0, py} + 11'd2), .aw(8'd24), .ah(8'd22),
        .bx(player_x), .by({1'b0, player_y}), .bw(player_w), .bh(player_h),
        .hit(touch_c)
    );
    reg touch_r;
    always @(posedge clk) touch_r <= touch_c & live;

    always @(posedge clk) begin
        got <= 1'b0;
        if (rst) begin
            live <= 1'b0; t <= first_t; px <= 11'd0; py <= 10'd0; kind <= 2'd0; got_kind <= 2'd0;
        end else begin
            if (live && kind == 2'd1 && has_shield && !touch_r) begin
                live <= 1'b0; t <= 11'd0;                           // v20: respawn at once
            end else if (live && touch_r) begin
                live <= 1'b0; got <= 1'b1; got_kind <= kind;
                t <= next_t;                                        // v18 (was 20..30 s)
            end else if (tick_60hz) begin
                if (live) begin
                    if (t == 11'd0) begin
                        live <= 1'b0;
                        t    <= next_t;
                    end else t <= t - 11'd1;
                end else if (t != 11'd0) t <= t - 11'd1;
                else if (!too_close) begin
                    live <= 1'b1; t <= LIFE; px <= sx_w; py <= sy_w; kind <= pick;
                end
            end
        end
    end
endmodule
