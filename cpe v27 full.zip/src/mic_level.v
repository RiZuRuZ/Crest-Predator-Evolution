// mic_level: loudness of the on-board PDM microphone (Nexys A7, ADMP421)
//
// M_CLK = clk / (2 * DIV) = 2.5 MHz (100 MHz / 40 or 25 MHz / 10), M_LRSEL = 0, M_DATA sampled on the M_CLK rising edge.
// Every 64 PDM bits the number of ones (0..64) is one sound sample (39 kHz); silence is
// about 32. amp = |ones - 32|. `level` is a peak envelope of amp (rises at once, falls
// by 1 every 2^DECAY_BITS clocks, ~10 ms); `loud` = level >= THRESH while `enable` (SW15) is on.
// PLACEHOLDER: THRESH - check the HUD mic bar on the board and adjust.
module mic_level #(
    parameter THRESH     = 10,
    // clock-rate dependent (defaults for 100 MHz; top.v runs at 25 MHz)
    parameter DIV        = 20,     // clocks per half M_CLK period
    parameter DECAY_BITS = 20      // level falls by 1 every 2^DECAY_BITS clocks
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       enable,
    input  wire       m_data,
    output reg        m_clk,
    output wire       m_lrsel,
    output reg  [4:0] level,          // 0..31
    output wire       loud
);
    assign m_lrsel = 1'b0;

    reg [4:0] div;
    reg       rise;
    always @(posedge clk) begin
        rise <= 1'b0;
        if (rst) begin div <= 5'd0; m_clk <= 1'b0; end
        else if (div == DIV - 1) begin
            div   <= 5'd0;
            m_clk <= ~m_clk;
            rise  <= ~m_clk;              // m_clk goes high now
        end else div <= div + 5'd1;
    end

    reg       d_s1, d_s2;
    always @(posedge clk) begin d_s1 <= m_data; d_s2 <= d_s1; end

    reg [5:0] nbits;
    reg [6:0] ones;
    reg [5:0] amp;
    reg       amp_v;
    always @(posedge clk) begin
        amp_v <= 1'b0;
        if (rst) begin nbits <= 6'd0; ones <= 7'd0; amp <= 6'd0; end
        else if (rise) begin
            if (nbits == 6'd63) begin
                amp   <= (ones + d_s2 >= 7'd32) ? (ones + d_s2 - 7'd32) : (7'd32 - ones - d_s2);
                amp_v <= 1'b1;
                ones  <= 7'd0;
                nbits <= 6'd0;
            end else begin
                ones  <= ones + d_s2;
                nbits <= nbits + 6'd1;
            end
        end
    end

    reg [19:0] decay;
    always @(posedge clk) begin
        if (rst || !enable) begin level <= 5'd0; decay <= 20'd0; end
        else begin
            decay <= decay + 20'd1;
            if (amp_v && amp > {1'b0, level}) level <= (amp[5] ? 5'd31 : amp[4:0]);
            else if (decay[DECAY_BITS-1:0] == 0 && level != 5'd0) level <= level - 5'd1;   // ~10 ms
        end
    end
    assign loud = enable && (level >= THRESH);
endmodule
