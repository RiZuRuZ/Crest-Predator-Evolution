// fish_renderer: draws the fish sprites of all fish_pool slots (replaces fish_rect_renderer)
//
// Works in world coordinates (world_x / world_y from camera); x wraps around the world.
// Sprites (fish-sprites.md), art faces right, 4 swim frames each:
//   type 0 small 31x27, 1 medium 52x42, 2 large 93x52, 3 golden 44x35
// A fish swimming left (dir = 1) is drawn mirrored.
// Frame of slot k = frame_base + k (fish_anim_counter), so the fish do not flap in step.
//
// ROMs: one per type, fish0..fish3.mem, address = frame*W*H + y*W + x, 4-bit index into
// the type's 16 colors in fish_pal.mem (entry type*16 + index), index 0 transparent.
//
// Overlapping fish: every type ROM has two read ports, so for each type the two lowest
// slots of that type covering the pixel are read (candidates A and B). Of all visible
// candidates the lowest slot is drawn, so a fish behind shows through the transparent
// parts of the fish in front - also when both are the same type. (Three fish of one
// type on the same pixel would show only two of them.)
//
// Timing: same as player_renderer (position registered, ROM read, then combinational
// select and palette), ready before pixel_mixer samples.
module fish_renderer #(
    parameter N       = 4,
    parameter WORLD_W = 1920
)(
    input  wire            clk,
    input  wire [10:0]     world_x,
    input  wire [9:0]      world_y,
    input  wire [N-1:0]    active_vec,
    input  wire [2*N-1:0]  type_vec,
    input  wire [11*N-1:0] x_vec,
    input  wire [10*N-1:0] y_vec,
    input  wire [N-1:0]    dir_vec,
    input  wire [1:0]      frame_base,
    // red shark (red_shark.v): the large-fish sprite drawn 1.5x bigger (139 x 78) with its
    // own red palette (red_shark_pal.mem). It reads the large-fish ROM like a type-2 fish,
    // so no extra block RAM; it is in front of every fish.
    input  wire            rs_on,
    input  wire [10:0]     rs_x,
    input  wire [9:0]      rs_y,
    input  wire            rs_dir,         // 1 = swims left (mirrored)
    input  wire [1:0]      rs_frame,
    // v15 boss: the same slot draws the boss instead (rs_big = 1): the large-fish sprite
    // 3x bigger (279 x 156), palette rs_pal of boss_pal.mem (0 normal, 1 red warning,
    // 2 phase 2, 3 phase 3, 4 white flash), rs_flipy = upside down (defeated)
    input  wire            rs_big,
    input  wire [2:0]      rs_pal,
    input  wire            rs_flipy,
    output wire            pixel_on,
    output wire [11:0]     rgb_out
);
    function [7:0] fw(input [1:0] t);
        case (t)
            2'd0: fw = 8'd31;  2'd1: fw = 8'd52;  2'd2: fw = 8'd93;  default: fw = 8'd44;
        endcase
    endfunction
    function [7:0] fh(input [1:0] t);
        case (t)
            2'd0: fh = 8'd27;  2'd1: fh = 8'd42;  2'd2: fh = 8'd52;  default: fh = 8'd35;
        endcase
    endfunction

    // ---- stage 1: for each type, the two lowest slots of that type on this pixel ----
    // candidate index c = 2*type + (0 = lowest slot A, 1 = second lowest B)
    reg        v_c   [0:7];
    reg [7:0]  sx_c  [0:7];
    reg [7:0]  sy_c  [0:7];
    reg [1:0]  fr_c  [0:7];
    reg [3:0]  pri_c [0:7];           // 0 = red shark, k + 1 = fish slot k
    reg        red_c [0:7];

    integer k, c;
    reg [1:0]  ty;
    reg [10:0] fx;
    reg [9:0]  fy;
    reg [11:0] rx;
    reg [9:0]  ry;
    reg [7:0]  w, h;
    reg        ins;
    reg [11:0] rrx;
    reg [9:0]  rry;
    reg [8:0]  rsx;
    reg [7:0]  rsy;
    reg [8:0]  rs_w1;                 // sprite width - 1 / height on screen
    reg [7:0]  rs_h;
    always @* begin
        for (c = 0; c < 8; c = c + 1) begin
            v_c[c] = 1'b0; sx_c[c] = 8'd0; sy_c[c] = 8'd0; fr_c[c] = 2'd0; pri_c[c] = 4'd15; red_c[c] = 1'b0;
        end
        // highest slot first: each new hit pushes the previous A down to B,
        // so after the loop A = lowest slot, B = second lowest
        for (k = N - 1; k >= 0; k = k - 1) begin
            ty  = type_vec[2*k +: 2];
            fx  = x_vec[11*k +: 11];
            fy  = y_vec[10*k +: 10];
            w   = fw(ty);
            h   = fh(ty);
            rx  = (world_x >= fx) ? (world_x - fx) : ({1'b0, world_x} + WORLD_W - fx);
            ry  = world_y - fy;
            ins = active_vec[k] && (rx < {4'd0, w}) && (world_y >= fy) && (ry < {2'd0, h});
            if (ins) begin
                v_c[2*ty+1]   = v_c[2*ty];
                sx_c[2*ty+1]  = sx_c[2*ty];
                sy_c[2*ty+1]  = sy_c[2*ty];
                fr_c[2*ty+1]  = fr_c[2*ty];
                pri_c[2*ty+1] = pri_c[2*ty];
                red_c[2*ty+1] = red_c[2*ty];
                v_c[2*ty]     = 1'b1;
                red_c[2*ty]   = 1'b0;
                sx_c[2*ty]    = dir_vec[k] ? (w - 8'd1 - rx[7:0]) : rx[7:0];
                sy_c[2*ty]    = ry[7:0];
                fr_c[2*ty]    = frame_base + k[1:0];
                pri_c[2*ty]   = k[3:0] + 4'd1;              // slots 0..11 -> 1..12 (15 = none)
            end
        end
        // red shark last, so it becomes candidate A of type 2 (pushes a large fish to B)
        rrx = (world_x >= rs_x) ? (world_x - rs_x) : ({1'b0, world_x} + WORLD_W - rs_x);
        rry = world_y - rs_y;
        rs_w1 = rs_big ? 9'd278 : 9'd138;
        rs_h  = rs_big ? 8'd156 : 8'd78;
        rsx   = 9'd0;
        rsy   = 8'd0;
        if (rs_on && (rrx <= {3'd0, rs_w1}) && (world_y >= rs_y) && (rry < {2'd0, rs_h})) begin
            rsx = rs_dir ? (rs_w1 - rrx[8:0]) : rrx[8:0];
            rsy = rs_flipy ? (rs_h - 8'd1 - rry[7:0]) : rry[7:0];
            v_c[5] = v_c[4]; sx_c[5] = sx_c[4]; sy_c[5] = sy_c[4]; fr_c[5] = fr_c[4];
            pri_c[5] = pri_c[4]; red_c[5] = red_c[4];
            v_c[4]   = 1'b1;
            // back to the 93 x 52 sprite: x 2/3 (red shark) or x 1/3 (boss, 85/256)
            sx_c[4]  = rs_big ? (rsx * 17'd85) >> 8 : (rsx * 17'd171) >> 8;
            sy_c[4]  = rs_big ? (rsy * 16'd85) >> 8 : (rsy * 16'd171) >> 8;
            fr_c[4]  = rs_frame;
            pri_c[4] = 4'd0;
            red_c[4] = 1'b1;
        end
    end

    reg        v_r   [0:7];
    reg [7:0]  sx_r  [0:7];
    reg [7:0]  sy_r  [0:7];
    reg [1:0]  fr_r  [0:7];
    reg [3:0]  pri_r [0:7];
    reg        red_r [0:7];
    integer j;
    always @(posedge clk)
        for (j = 0; j < 8; j = j + 1) begin
            v_r[j]   <= v_c[j];
            sx_r[j]  <= sx_c[j];
            sy_r[j]  <= sy_c[j];
            fr_r[j]  <= fr_c[j];
            pri_r[j] <= pri_c[j];
            red_r[j] <= red_c[j];
        end

    // ---- stage 2: one dual-port ROM per type ---------------------------------------
    function [14:0] faddr(input [1:0] t, input [1:0] f, input [7:0] y, input [7:0] x);
        case (t)
            2'd0:    faddr = f * 15'd837  + y * 15'd31 + x;   // 31 x 27
            2'd1:    faddr = f * 15'd2184 + y * 15'd52 + x;   // 52 x 42
            2'd2:    faddr = f * 15'd4836 + y * 15'd93 + x;   // 93 x 52
            default: faddr = f * 15'd1540 + y * 15'd44 + x;   // 44 x 35
        endcase
    endfunction

    wire [3:0] q [0:7];
    sprite_bank2 #(.DEPTH(3348),  .FILE("fish0.mem")) u_f0 (.clk(clk),
        .addr_a(faddr(2'd0, fr_r[0], sy_r[0], sx_r[0])), .addr_b(faddr(2'd0, fr_r[1], sy_r[1], sx_r[1])),
        .idx_a(q[0]), .idx_b(q[1]));
    sprite_bank2 #(.DEPTH(8736),  .FILE("fish1.mem")) u_f1 (.clk(clk),
        .addr_a(faddr(2'd1, fr_r[2], sy_r[2], sx_r[2])), .addr_b(faddr(2'd1, fr_r[3], sy_r[3], sx_r[3])),
        .idx_a(q[2]), .idx_b(q[3]));
    sprite_bank2 #(.DEPTH(19344), .FILE("fish2.mem")) u_f2 (.clk(clk),
        .addr_a(faddr(2'd2, fr_r[4], sy_r[4], sx_r[4])), .addr_b(faddr(2'd2, fr_r[5], sy_r[5], sx_r[5])),
        .idx_a(q[4]), .idx_b(q[5]));
    sprite_bank2 #(.DEPTH(6160),  .FILE("fish3.mem")) u_f3 (.clk(clk),
        .addr_a(faddr(2'd3, fr_r[6], sy_r[6], sx_r[6])), .addr_b(faddr(2'd3, fr_r[7], sy_r[7], sx_r[7])),
        .idx_a(q[6]), .idx_b(q[7]));

    reg       v_d   [0:7];
    reg [3:0] pri_d [0:7];
    reg       red_d [0:7];
    always @(posedge clk)
        for (j = 0; j < 8; j = j + 1) begin
            v_d[j]   <= v_r[j];
            pri_d[j] <= pri_r[j];
            red_d[j] <= red_r[j];
        end

    // ---- stage 3: visible candidate with the lowest slot, palette (combinational) ----
    reg [11:0] pal [0:63];
    initial $readmemh("fish_pal.mem", pal);
    reg [11:0] rpal [0:15];
    initial $readmemh("red_shark_pal.mem", rpal);
    reg [11:0] bpal [0:127];
    initial $readmemh("boss_pal.mem", bpal);

    reg        on;
    reg [2:0]  sel;
    reg [3:0]  best;
    integer    m;
    always @* begin
        on   = 1'b0;
        sel  = 3'd0;
        best = 4'd15;
        for (m = 0; m < 8; m = m + 1)
            if (v_d[m] && q[m] != 4'd0 && (!on || pri_d[m] < best)) begin
                on   = 1'b1;
                sel  = m[2:0];
                best = pri_d[m];
            end
    end

    assign pixel_on = on;
    assign rgb_out  = red_d[sel] ? (rs_big ? bpal[{rs_pal, q[sel]}] : rpal[q[sel]])
                                 : pal[{sel[2:1], q[sel]}];
endmodule
