// stun_fx: three little stars circling above the dragon's head while it is stunned
//
// The stars move round an ellipse (radius rx across, 5 px up / down) centred on
// (cx, cy), one third of a turn apart; one turn takes 64 frames (about 1 s).
// A star in the front half of the ellipse (lower half on screen) is drawn big
// (7x7 four-point sparkle, yellow with a white centre); in the back half it is small and
// dim (5x5 plus), so the ring looks round.
// Star positions are worked out once per clock from anim_t and the centre (they only
// change once per frame), then the pixel test runs in two register stages from
// world_x / world_y, like the other renderers (ready 2 clocks after world_x).
module stun_fx #(
    parameter WORLD_W = 1920
)(
    input  wire        clk,
    input  wire        en,
    input  wire [10:0] world_x,
    input  wire [9:0]  world_y,
    input  wire [10:0] cx,             // centre of the ellipse (world)
    input  wire [9:0]  cy,
    input  wire [5:0]  rx,             // ellipse radius across
    input  wire [9:0]  anim_t,
    output reg         pixel_on,
    output reg  [11:0] rgb_out
);
    // 16 * cos(2 pi i / 32)
    function signed [5:0] cos32(input [4:0] i);
        case (i)
            5'd0:  cos32 =  6'sd16;  5'd1:  cos32 =  6'sd16;  5'd2:  cos32 =  6'sd15;  5'd3:  cos32 =  6'sd13;
            5'd4:  cos32 =  6'sd11;  5'd5:  cos32 =  6'sd9;   5'd6:  cos32 =  6'sd6;   5'd7:  cos32 =  6'sd3;
            5'd8:  cos32 =  6'sd0;   5'd9:  cos32 = -6'sd3;   5'd10: cos32 = -6'sd6;   5'd11: cos32 = -6'sd9;
            5'd12: cos32 = -6'sd11;  5'd13: cos32 = -6'sd13;  5'd14: cos32 = -6'sd15;  5'd15: cos32 = -6'sd16;
            5'd16: cos32 = -6'sd16;  5'd17: cos32 = -6'sd16;  5'd18: cos32 = -6'sd15;  5'd19: cos32 = -6'sd13;
            5'd20: cos32 = -6'sd11;  5'd21: cos32 = -6'sd9;   5'd22: cos32 = -6'sd6;   5'd23: cos32 = -6'sd3;
            5'd24: cos32 =  6'sd0;   5'd25: cos32 =  6'sd3;   5'd26: cos32 =  6'sd6;   5'd27: cos32 =  6'sd9;
            5'd28: cos32 =  6'sd11;  5'd29: cos32 =  6'sd13;  5'd30: cos32 =  6'sd15;  default: cos32 = 6'sd16;
        endcase
    endfunction

    localparam [11:0] W12 = WORLD_W;

    // ---- star positions (top-left of a 7x7 box) ----
    reg [10:0] bx [0:2];
    reg [9:0]  by [0:2];
    reg        front [0:2];
    integer k;
    reg [4:0]  ang;
    reg signed [11:0] ox, oy;
    reg [11:0] xr;
    always @(posedge clk) begin
        for (k = 0; k < 3; k = k + 1) begin
            ang = anim_t[5:1] + k * 11;
            ox  = ($signed({6'd0, rx}) * cos32(ang)) >>> 4;           // across
            oy  = ($signed(12'sd5)     * cos32(ang - 5'd8)) >>> 4;    // sin = cos(a - 90 deg)
            xr  = {1'b0, cx} + W12 + ox - 12'd3;                        // all 12 bit: ox stays signed
            bx[k]    <= (xr >= 2 * WORLD_W) ? xr - 2 * WORLD_W : (xr >= WORLD_W) ? xr - WORLD_W : xr[10:0];
            by[k]    <= cy + oy[9:0] - 10'd3;
            front[k] <= (oy >= 0);
        end
    end

    // ---- stage 1: is this pixel inside a star box ----
    reg        in_c, fr_c;
    reg [2:0]  sx_c, sy_c;
    reg [11:0] rxx;
    reg [9:0]  ryy;
    integer j;
    always @* begin
        in_c = 1'b0; fr_c = 1'b0; sx_c = 3'd0; sy_c = 3'd0;
        for (j = 2; j >= 0; j = j - 1) begin
            rxx = (world_x >= bx[j]) ? world_x - bx[j] : {1'b0, world_x} + WORLD_W - bx[j];
            ryy = world_y - by[j];
            if (en && (rxx < 12'd7) && (world_y >= by[j]) && (ryy < 10'd7)) begin
                in_c = 1'b1; fr_c = front[j]; sx_c = rxx[2:0]; sy_c = ryy[2:0];
            end
        end
    end
    reg       in_r, fr_r;
    reg [2:0] sx_r, sy_r;
    always @(posedge clk) begin
        in_r <= in_c; fr_r <= fr_c; sx_r <= sx_c; sy_r <= sy_c;
    end

    // ---- stage 2: star shape ----
    wire [2:0] adx = (sx_r >= 3'd3) ? sx_r - 3'd3 : 3'd3 - sx_r;
    wire [2:0] ady = (sy_r >= 3'd3) ? sy_r - 3'd3 : 3'd3 - sy_r;
    wire [3:0] sum = {1'b0, adx} + {1'b0, ady};
    wire star_b   = (adx == 3'd0) || (ady == 3'd0) || (sum <= 4'd1);       // 7x7 sparkle
    wire star_s = ((adx == 3'd0) && (ady <= 3'd2)) || ((ady == 3'd0) && (adx <= 3'd2));  // 5x5 plus
    wire mid   = (sum <= 4'd1);
    always @(posedge clk) begin
        pixel_on <= in_r && (fr_r ? star_b : star_s);
        rgb_out  <= fr_r ? (mid ? 12'hFFF : 12'hFE4) : 12'hCA4;
    end
endmodule
