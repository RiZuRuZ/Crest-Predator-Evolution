// shield_fx: glowing ring around the dragon while Tough Scales (the shield) is ready
//
// A circle around the centre of the player hitbox (head + body), radius = half the
// hitbox width + 12 px, that breathes in and out: the radius grows 0..6 px and back
// over 64 frames (about 1 s). Drawn in three parts (world coordinates, x wraps):
//   core   2 px bright ring at the radius
//   glow   3 px soft band inside and 3 px outside (the compositor blends it)
//   gleam  two bright arcs on opposite sides that go round the ring (one eighth of
//          the circle each, moving one eighth every 4 frames)
// Distances only up to 127 px on each axis are checked (radius is at most ~64 px).
// Timing: world_x / world_y (registered by camera) -> stage 1 register (offsets and
// squares) -> stage 2 register (outputs). Two clocks, ready before the compositor.
module shield_fx #(
    parameter WORLD_W = 1920
)(
    input  wire        clk,
    input  wire        en,             // shield ready (forms 3, 4) and playing
    input  wire [10:0] world_x,
    input  wire [9:0]  world_y,
    input  wire [10:0] cx,             // ring centre (world)
    input  wire [9:0]  cy,
    input  wire [6:0]  base_r,         // radius before the breathing
    input  wire [9:0]  anim_t,         // frame counter
    output reg         core,
    output reg         glow,
    output reg         gleam
);
    // ---- stage 1: offsets from the centre ----
    wire [10:0] dxa = (world_x >= cx) ? world_x - cx : cx - world_x;
    wire [10:0] dxw = (dxa > WORLD_W / 2) ? WORLD_W - dxa : dxa;          // x wraps
    wire        xneg_c = (world_x < cx) ^ (dxa > WORLD_W / 2);            // pixel left of centre
    wire [9:0]  dya = (world_y >= cy) ? world_y - cy : cy - world_y;
    wire        yneg_c = (world_y < cy);
    wire        near_c = (dxw < 11'd128) && (dya < 10'd128);

    reg        near_r, xneg_r, yneg_r;
    reg [6:0]  dx_r, dy_r;
    reg [13:0] dx2_r, dy2_r;
    always @(posedge clk) begin
        near_r <= near_c & en;
        xneg_r <= xneg_c;
        yneg_r <= yneg_c;
        dx_r   <= dxw[6:0];
        dy_r   <= dya[6:0];
        dx2_r  <= dxw[6:0] * dxw[6:0];
        dy2_r  <= dya[6:0] * dya[6:0];
    end

    // ---- breathing radius: triangle 0..6..0 over 64 frames ----
    wire [4:0] breath = anim_t[5] ? (5'd31 - {1'b0, anim_t[4:1]} * 2'd2) : ({1'b0, anim_t[4:1]} * 2'd2);
    wire [7:0] r    = {1'b0, base_r} + (breath >> 2);        // + 0..7
    wire [15:0] r_in  = (r - 8'd3) * (r - 8'd3);
    wire [15:0] r_c0  = r * r;
    wire [15:0] r_c1  = (r + 8'd2) * (r + 8'd2);
    wire [15:0] r_out = (r + 8'd5) * (r + 8'd5);
    wire [14:0] d2    = dx2_r + dy2_r;

    // octant 0..7 of the pixel around the centre (counter-clockwise from +x)
    wire       steep = (dy_r > dx_r);
    wire [2:0] oct = {yneg_r, xneg_r ^ yneg_r, steep ^ xneg_r ^ yneg_r};
    wire [2:0] rot = anim_t[4:2];

    always @(posedge clk) begin
        core  <= near_r && ({1'b0, d2} >= r_c0) && ({1'b0, d2} < r_c1);
        glow  <= near_r && ({1'b0, d2} >= r_in) && ({1'b0, d2} < r_out);
        gleam <= near_r && ({1'b0, d2} >= r_c0) && ({1'b0, d2} < r_c1) &&
                 ((oct == rot) || (oct == rot + 3'd4));
    end
endmodule
