// form_skills: per-form speed and the special abilities of each form (work plan EVO1..4)
//
// Speed (work plan: very fast / fast / medium / slowest), in quarter pixels per tick:
//   form 1: 16 (4.0)  form 2: 14 (3.5)  form 3: 11 (2.75)  form 4: 9 (2.25)
//   Fever adds 4 (1 px), the speed power-up (boost) adds 8 more (v20, was 4). `speed` is the whole pixels for this tick (accumulator).
// EVO1  Stealth       still for STEALTH_TICKS -> `stealth` (drawn see-through, the
//                     giant shark cannot see the player)
//       Bubble Breath double oxygen from bubbles (oxygen_ctrl.double_refill, in top)
//       Small dash    dash_len = 4 ticks
// EVO2  Super Dash    dash_len = 10 ticks, afterimage while dashing (`ghost`, also
//                     forms 3 and 4 so a Dash Chain always shows the trail)
//       Dash Chain    chain_en: dash again within 0.5 s after a dash (forms 2, 3, 4)
//       Current Rider no oxygen drain inside a water current (`oxy_hold`)
// EVO3  Tidal Roar    loud sound on the microphone (SW15 on) -> `roar` pulse, stuns the
//                     enemies around the player; ROAR_CD cooldown; `ring` grows 0..31
//                     for the shock-wave drawing
//       Tough Scales  one shield (player_health.shield); after it is used it comes back
//                     after SHIELD_TICKS
// EVO4  Tidal Roar and Tough Scales as form 3
//       Apex Feast    eats every fish and sea mines (fish_slot / mine_field)
//       Fever (Rage)  every FEVER_PER fish eaten fill one of FEVER_FILL cells; full -> Fever for
//                     FEVER_TICKS: faster, points x2, glowing frame, zoom out. The gauge
//                     empties during Fever (`gauge` 0..FEVER_FILL*16 for the HUD).
// PLACEHOLDERS: every number above.
module form_skills #(
    parameter STEALTH_TICKS = 60,     // 1 s
    parameter ROAR_CD       = 480,    // 8 s
    parameter SHIELD_TICKS  = 3000,   // 50 s (nerfed from 10 s, then 25 s)
    parameter FEVER_FILL    = 7,      // 7 cells, 2 fish per cell = 14 fish (harder)
    parameter FEVER_PER     = 2,
    parameter FEVER_TICKS   = 480     // 8 s
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       tick_60hz,
    input  wire [2:0] form,
    input  wire       moving,
    input  wire       dashing,
    input  wire       current_on,
    input  wire       mic_loud,
    input  wire       boost,          // speed power-up running
    input  wire       fish_eat,
    input  wire       shield_used,
    output reg  [3:0] speed,
    output wire       stealth,
    output wire [7:0] dash_len,
    output wire       chain_en,
    output wire       ghost,
    output wire       oxy_hold,
    output reg        roar,           // 1-clk pulse
    output wire [4:0] ring,           // shock wave radius step, 0 = none
    output wire       roar_ready,
    output wire       shield,
    output wire       fever,
    output wire [6:0] gauge,          // 0 .. 84 px
    output reg  [4:0] zoom            // 16 = 1.00 .. 20 = 1.25 (world px per screen px x16)
);
    // ---- speed -------------------------------------------------------------------
    reg [4:0] q;
    always @* begin
        case (form)
            3'd2:    q = 5'd14;
            3'd3:    q = 5'd11;
            3'd4:    q = 5'd9;
            default: q = 5'd16;
        endcase
    end
    reg [1:0] frac;
    wire [5:0] acc = {4'd0, frac} + q + (fever ? 5'd4 : 5'd0) + (boost ? 5'd8 : 5'd0);   // v20 boost +2 px (was +1)
    always @(posedge clk) begin
        if (rst) begin frac <= 2'd0; speed <= 4'd4; end
        else if (tick_60hz) begin
            speed <= acc[5:2];
            frac  <= acc[1:0];
        end
    end

    // ---- EVO1 Stealth -----------------------------------------------------------
    reg [6:0] still;
    always @(posedge clk) begin
        if (rst || moving || form != 3'd1) still <= 7'd0;
        else if (tick_60hz && still != STEALTH_TICKS) still <= still + 7'd1;
    end
    assign stealth = (form == 3'd1) && (still == STEALTH_TICKS);

    // ---- dash per form, EVO2 ---------------------------------------------------------
    assign dash_len = (form == 3'd1) ? 8'd4 : (form == 3'd2) ? 8'd10 : 8'd8;
    assign chain_en = (form >= 3'd2);           // Dash Chain from form 2 up
    assign ghost    = (form >= 3'd2) && dashing;    // afterimage on every dash from form 2
    assign oxy_hold = (form == 3'd2) && current_on;

    // ---- EVO3 Tidal Roar ------------------------------------------------------------
    reg [8:0] roar_cd;
    reg [4:0] ring_t;
    assign roar_ready = (form >= 3'd3) && (roar_cd == 9'd0);   // forms 3 and 4
    assign ring = ring_t;
    always @(posedge clk) begin
        roar <= 1'b0;
        if (rst) begin roar_cd <= 9'd0; ring_t <= 5'd0; end
        else begin
            if (roar_ready && mic_loud) begin
                roar    <= 1'b1;
                roar_cd <= ROAR_CD;
                ring_t  <= 5'd1;
            end else if (tick_60hz) begin
                if (roar_cd != 9'd0) roar_cd <= roar_cd - 9'd1;
                if (ring_t != 5'd0) ring_t <= (ring_t == 5'd31) ? 5'd0 : ring_t + 5'd1;
            end
        end
    end

    // ---- EVO3 Tough Scales ------------------------------------------------------------
    reg       sh_ready;
    reg [11:0] sh_t;
    always @(posedge clk) begin
        if (rst) begin sh_ready <= 1'b1; sh_t <= 12'd0; end
        else if (shield_used) begin sh_ready <= 1'b0; sh_t <= SHIELD_TICKS; end
        else if (!sh_ready && tick_60hz) begin
            if (sh_t == 12'd0) sh_ready <= 1'b1;
            else sh_t <= sh_t - 12'd1;
        end
    end
    assign shield = (form >= 3'd3) && sh_ready;             // forms 3 and 4

    // ---- EVO4 Fever ---------------------------------------------------------------------
    reg [2:0] cells;
    reg       half_cell;                   // FEVER_PER = 2 fish per cell
    reg [8:0] fev_t;
    assign fever = (fev_t != 9'd0);
    always @(posedge clk) begin
        if (rst || form != 3'd4) begin cells <= 3'd0; half_cell <= 1'b0; fev_t <= 9'd0; end
        else if (fever) begin
            if (tick_60hz) fev_t <= fev_t - 9'd1;
        end else if (fish_eat) begin
            half_cell <= ~half_cell;
            if (half_cell) begin
                if (cells == FEVER_FILL - 1) begin cells <= 3'd0; fev_t <= FEVER_TICKS; end
                else cells <= cells + 3'd1;
            end
        end
    end
    // gauge: cells x 16 while filling, remaining time while in Fever
    // gauge 0..84 px: 12 px per cell (+6 for a half cell); during Fever the time left
    // (84 / 480 = x179 / 1024)
    wire [17:0] fev_scaled = fev_t * 9'd179;
    assign gauge = fever ? fev_scaled[16:10] : (cells * 4'd12 + (half_cell ? 7'd6 : 7'd0));

    // zoom eases between 16 and 20, one step every 4 ticks
    reg [1:0] zdiv;
    always @(posedge clk) begin
        if (rst) begin zoom <= 5'd16; zdiv <= 2'd0; end
        else if (tick_60hz) begin
            zdiv <= zdiv + 2'd1;
            if (zdiv == 2'd0) begin
                if (fever && zoom < 5'd20)       zoom <= zoom + 5'd1;
                else if (!fever && zoom > 5'd16) zoom <= zoom - 5'd1;
            end
        end
    end
endmodule
