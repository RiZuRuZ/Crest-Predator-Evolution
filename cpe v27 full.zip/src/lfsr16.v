`timescale 1ns / 1ps
//==============================================================================
// lfsr16 - 16-bit Fibonacci LFSR (pseudo-random number generator)
//
// Polynomial : x^16 + x^14 + x^13 + x^11 + 1 (maximal length)
// Period     : 65535 states (every non-zero value appears exactly once)
// Shift dir  : right, feedback enters at bit 15
// Taps       : bits 0, 2, 3, 5 (XOR) -> new bit 15
//
// Project conventions (see conventions.md):
//   - single clock CLK100MHZ, no derived clocks
//   - rst is active-high and synchronous
//   - the state only advances when `en` is high, so the caller decides the
//     update rate (e.g. tie en to tick_60hz, or to a spawn request pulse)
//
// Notes for users:
//   - The all-zero state is a lock-up state for an XOR LFSR, so SEED must
//     never be 0. A parameter check below guards against that in simulation.
//   - Consecutive outputs are strongly correlated (they are shifted copies of
//     each other). Do not use `rnd[3:0]` of two adjacent steps as independent
//     values; either step the LFSR several times between uses or take bits
//     from one sample only.
//==============================================================================
module lfsr16 #(
    parameter [15:0] SEED = 16'hACE1   // must be non-zero
) (
    input  wire        clk,   // CLK100MHZ
    input  wire        rst,   // active-high, synchronous
    input  wire        en,    // advance the LFSR by one step when high
    output wire [15:0] rnd    // current state, usable as a random value
);

    reg [15:0] state;

    // XOR of taps 16, 14, 13, 11 (bit indices 0, 2, 3, 5)
    wire feedback = state[0] ^ state[2] ^ state[3] ^ state[5];

    always @(posedge clk) begin
        if (rst)
            state <= SEED;
        else if (en)
            state <= {feedback, state[15:1]};
    end

    assign rnd = state;

    // Simulation-only guard: a zero seed would freeze the LFSR forever.
    // synthesis translate_off
    initial begin
        if (SEED == 16'h0000) begin
            $display("ERROR: lfsr16 SEED must be non-zero");
            $finish;
        end
    end
    // synthesis translate_on

endmodule
