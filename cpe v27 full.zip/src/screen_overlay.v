// screen_overlay: TITLE / PAUSE / GAME OVER / WIN screens (text and a dark panel)
// state uses the game_fsm encoding: 0 TITLE, 1 PLAY, 2 PAUSE, 3 OVER, 4 WIN
// text_on / text_rgb : text pixels (top layer)
// panel_on           : dark box behind the text in PAUSE / OVER / WIN, so the frozen game
//                      stays visible around it
// Positions are centered on 640x480: x = (640 - N * 8 * scale) / 2
// Records (kept until the board is reset): HIGH = best score, BEST = fastest win time.
//   TITLE    : HIGH and BEST under the title, v18: "MODE: NORMAL" (left / right = difficulty)
//   OVER/WIN : SCORE, TIME of this game, HIGH, BEST ("--:--" before the first win)
// v20 grade (grade_calc in top.v): OVER / WIN show the four lines on the left, on WIN the
//   points in the middle (TIME, EVENT, COMBO, MODE, TOTAL) and the grade on the right
//   (big letter, or CHEAT); TITLE shows BEST GRADE (best grade without the cheat).
//   grade: 0 F, 1 D, 2 C, 3 B, 4 A, 5 S, 6 CHEAT
module screen_overlay (
    input  wire        clk,
    input  wire [2:0]  state,
    input  wire [9:0]  score,
    input  wire [9:0]  hi_score,
    input  wire [6:0]  t_min,          // time of this game
    input  wire [5:0]  t_sec,
    input  wire [6:0]  best_min,       // fastest win
    input  wire [5:0]  best_sec,
    input  wire        best_ok,        // a win was recorded
    input  wire [1:0]  diff,           // v18: difficulty chosen on TITLE (left / right)
    input  wire [2:0]  grade,          // v20
    input  wire [2:0]  best_grade,
    input  wire        best_g_ok,
    input  wire [4:0]  pt_time,        // points: time
    input  wire [6:0]  pt_ev,          //         events (v25: 7 bits, 3 per event)
    input  wire [2:0]  pt_combo,       //         combo
    input  wire [7:0]  total,
    input  wire        music_on,       // v24 / v27
    input  wire [9:0]  pixel_x,
    input  wire [9:0]  pixel_y,
    output wire        text_on,
    output wire [11:0] text_rgb,
    output wire        panel_on
);
    localparam [2:0] TITLE = 3'd0, PAUSE = 3'd2, OVER = 3'd3, WIN = 3'd4;

    // ---- TITLE ----
    wire t_title1, t_title2, t_press;
    text_line #(.X0(96),  .Y0(120), .S(2), .N(14), .TEXT("CREST PREDATOR")) u_t1 (
        .clk(clk), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_title1));
    text_line #(.X0(176), .Y0(170), .S(2), .N(9),  .TEXT("EVOLUTION")) u_t2 (
        .clk(clk), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_title2));
    text_line #(.X0(168), .Y0(300), .S(1), .N(19), .TEXT("PRESS CENTER BUTTON")) u_press (
        .clk(clk), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_press));

    // ---- PAUSE ----
    wire t_paused, t_resume, t_mus;
    // v24 / v27: PAUSE + centre button = music on / off
    reg [135:0] l_mus;
    always @(posedge clk) l_mus <= music_on ? "CENTER: MUSIC ON " : "CENTER: MUSIC OFF";
    text_dyn #(.X0(184), .Y0(290), .S(1), .N(17)) u_mus (.clk(clk), .chars(l_mus),
        .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_mus));
    text_line #(.X0(224), .Y0(180), .S(2), .N(6),  .TEXT("PAUSED")) u_paused (
        .clk(clk), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_paused));
    text_line #(.X0(176), .Y0(260), .S(1), .N(18), .TEXT("SW0 DOWN TO RESUME")) u_resume (
        .clk(clk), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_resume));

    // ---- OVER / WIN ----
    wire t_over, t_win;
    text_line #(.X0(176), .Y0(150), .S(2), .N(9),  .TEXT("GAME OVER")) u_over (
        .clk(clk), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_over));
    text_line #(.X0(208), .Y0(150), .S(2), .N(7),  .TEXT("YOU WIN")) u_win (
        .clk(clk), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_win));

    // ---- numbers as characters (registered: the values change rarely) ----
    function [7:0] dg(input [3:0] d); dg = 8'h30 + d; endfunction
    reg [79:0] l_score, l_time, l_high, l_best;
    always @(posedge clk) begin
        l_score <= {"SCORE ", 8'h20, dg(score / 100), dg((score / 10) % 10), dg(score % 10)};
        l_time  <= {"TIME ", dg(t_min / 10), dg(t_min % 10), ":", dg(t_sec / 10), dg(t_sec % 10)};
        l_high  <= {"HIGH ", 8'h20, 8'h20, dg(hi_score / 100), dg((hi_score / 10) % 10), dg(hi_score % 10)};
        l_best  <= best_ok ? {"BEST ", dg(best_min / 10), dg(best_min % 10), ":", dg(best_sec / 10), dg(best_sec % 10)}
                           : {"BEST --:--"};
    end
    // OVER / WIN: four lines; TITLE: HIGH and BEST between the title and the button text
    wire t_l1, t_l2, t_l3, t_l4, t_th, t_tb;
    text_dyn #(.X0(88),  .Y0(204), .S(1), .N(10)) u_l1 (.clk(clk), .chars(l_score), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_l1));
    text_dyn #(.X0(88),  .Y0(226), .S(1), .N(10)) u_l2 (.clk(clk), .chars(l_time),  .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_l2));
    text_dyn #(.X0(88),  .Y0(248), .S(1), .N(10)) u_l3 (.clk(clk), .chars(l_high),  .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_l3));
    text_dyn #(.X0(88),  .Y0(270), .S(1), .N(10)) u_l4 (.clk(clk), .chars(l_best),  .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_l4));
    text_dyn #(.X0(240), .Y0(236), .S(1), .N(10)) u_th (.clk(clk), .chars(l_high),  .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_th));
    text_dyn #(.X0(240), .Y0(258), .S(1), .N(10)) u_tb (.clk(clk), .chars(l_best),  .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_tb));
    // v18 difficulty line on TITLE
    reg [95:0] l_mode;
    always @(posedge clk)
        l_mode <= (diff == 2'd0) ? "MODE: EASY  " : (diff == 2'd2) ? "MODE: HARD  " : "MODE: NORMAL";   // no < > in the font
    wire t_mode;
    text_dyn #(.X0(224), .Y0(278), .S(1), .N(12)) u_mode (.clk(clk), .chars(l_mode), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_mode));
    wire on_mode = (state == TITLE) && t_mode;

    // ---- v20 grade ----
    function [7:0] gch(input [2:0] g);
        case (g)
            3'd0: gch = "F"; 3'd1: gch = "D"; 3'd2: gch = "C";
            3'd3: gch = "B"; 3'd4: gch = "A"; 3'd5: gch = "S";
            default: gch = "-";
        endcase
    endfunction
    reg [71:0] l_pt, l_pe, l_pc, l_pm, l_tot;
    reg [7:0]  l_g;
    reg [95:0] l_bg;
    always @(posedge clk) begin
        l_pt  <= {"TIME  +", dg(pt_time / 10), dg(pt_time % 10)};
        l_pe  <= {"EVENT +", dg(pt_ev / 10), dg(pt_ev % 10)};
        l_pc  <= {"COMBO +", dg(4'd0), dg({1'b0, pt_combo})};
        l_pm  <= (diff == 2'd0) ? "MODE  -10" : (diff == 2'd2) ? "MODE  +10" : "MODE  +00";
        l_tot <= {"TOTAL ", dg(total / 100), dg((total / 10) % 10), dg(total % 10)};
        l_g   <= gch(grade);
        l_bg  <= {"BEST GRADE ", best_g_ok ? gch(best_grade) : "-"};
    end
    wire t_pt, t_pe, t_pc, t_pm, t_tot, t_glbl, t_big, t_cheat, t_bg;
    text_dyn  #(.X0(272), .Y0(196), .S(1), .N(9)) u_pt  (.clk(clk), .chars(l_pt),  .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_pt));
    text_dyn  #(.X0(272), .Y0(214), .S(1), .N(9)) u_pe  (.clk(clk), .chars(l_pe),  .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_pe));
    text_dyn  #(.X0(272), .Y0(232), .S(1), .N(9)) u_pc  (.clk(clk), .chars(l_pc),  .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_pc));
    text_dyn  #(.X0(272), .Y0(250), .S(1), .N(9)) u_pm  (.clk(clk), .chars(l_pm),  .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_pm));
    text_dyn  #(.X0(272), .Y0(272), .S(1), .N(9)) u_tot (.clk(clk), .chars(l_tot), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_tot));
    text_line #(.X0(440), .Y0(196), .S(1), .N(5), .TEXT("GRADE")) u_glbl (
        .clk(clk), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_glbl));
    text_dyn  #(.X0(456), .Y0(218), .S(3), .N(1)) u_big (.clk(clk), .chars(l_g), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_big));
    text_line #(.X0(440), .Y0(238), .S(1), .N(5), .TEXT("CHEAT")) u_cht (
        .clk(clk), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_cheat));
    text_dyn  #(.X0(224), .Y0(214), .S(1), .N(12)) u_bg (.clk(clk), .chars(l_bg), .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_on(t_bg));
    wire ended   = (state == OVER || state == WIN);
    wire on_pts  = (state == WIN) && (grade != 3'd6) && (t_pt | t_pe | t_pc | t_pm | t_tot);
    wire on_glbl = ended && t_glbl;
    wire on_big  = ended && (grade != 3'd6) && t_big;
    wire on_cht  = ended && (grade == 3'd6) && t_cheat;
    wire on_bg   = (state == TITLE) && t_bg;
    wire [11:0] g_rgb = (grade == 3'd5) ? 12'hFD3 : (grade == 3'd4) ? 12'h9EF : (grade == 3'd3) ? 12'h8F8 :
                        (grade == 3'd2) ? 12'hFFF : (grade == 3'd1) ? 12'hFA4 : (grade == 3'd0) ? 12'hF55 : 12'hF6F;

    wire on_rec = ((state == OVER || state == WIN) && (t_l3 | t_l4)) || ((state == TITLE) && (t_th | t_tb));

    // "PRESS CENTER BUTTON" is reused on OVER / WIN at the same place as on TITLE
    wire on_title = (state == TITLE) && (t_title1 | t_title2);
    wire on_text  = ((state == TITLE)                  && t_press) ||
                    ((state == PAUSE)                  && (t_paused | t_resume | t_mus)) ||
                    ((state == OVER)                   && t_over) ||
                    ((state == WIN)                    && t_win) ||
                    ((state == OVER || state == WIN)   && (t_l1 | t_l2 | t_press));

    assign text_on  = on_title | on_text | on_rec | on_mode | on_pts | on_glbl | on_big | on_cht | on_bg;
    assign text_rgb = (on_big | on_cht) ? g_rgb : on_bg ? 12'hFD4 : on_pts ? 12'hFE9 :
                      on_title ? 12'hFD4 : on_rec ? 12'h9EF :
                      on_mode ? ((diff == 2'd0) ? 12'h7F7 : (diff == 2'd2) ? 12'hF66 : 12'hFE6) : 12'hFFF;   // gold title, light-blue records, white text

    assign panel_on = (state == PAUSE || state == OVER || state == WIN) &&
                      (pixel_x >= 10'd64)  && (pixel_x < 10'd576) &&
                      (pixel_y >= 10'd128) && (pixel_y < 10'd352);
endmodule
