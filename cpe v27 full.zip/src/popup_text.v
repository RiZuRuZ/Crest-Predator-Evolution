// popup_text: short colored words that pop up above the dragon's head and float away
//
// Every game event that the player should notice starts a popup (NSLOT at once):
//   kind  text           color        event
//   0     +1 +3 +5 ...   white        fish eaten (points, doubled in Fever)
//   1     +10 +20        gold         golden fish eaten
//   2     +O2            cyan         bubble eaten
//   3     -O2            orange       sea mine eaten (form 4)
//   4     STUN           yellow       jellyfish sting
//   5     -1 heart       red          heart lost
//   6     BLOCK          pale blue    the shield took the hit
//   7     ROAR!          aqua         Tidal Roar used
//   8     ROAR READY     aqua         Tidal Roar cooldown over
//   9     SHIELD READY   blue         shield recharged
//   10    FEVER!         gold-orange  Fever Time starts
//   11    EVOLVE!        pink         new form
//   12    HIDDEN         lavender     Stealth starts (form 1)
//   13    +1 heart       pink         heart power-up
//   14    SHIELD         blue         shield power-up
//   15    SPEED UP       yellow       speed power-up
// (kind 1 also shows the red shark: +100 / +200)
// An event sets its `pend` bit; one pending popup is started per clock in a free slot
// (the oldest slot is reused when all are busy). It appears centred on anchor_x and
// at anchor_y (above the head, screen coordinates), or 18 px above the last popup if
// that one is still young, so quick events stack instead of covering each other.
// A popup rises 1 px every 2 ticks for LIFE ticks and blinks out in its last 12 ticks.
// Drawn with font_rom at 2x (16 px cells) with a dark drop shadow 2 px down-right.
// Timing: pixel_x / pixel_y -> stage 1 register (slot, cell, glyph row/column)
// -> stage 2 register (font lookup), the same 2-clock latency as text_dyn.
module popup_text #(
    parameter NSLOT = 4,
    parameter LIFE  = 48
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       tick_60hz,
    input  wire       show,
    input  wire [9:0] anchor_x,       // screen x of the dragon's centre
    input  wire [9:0] anchor_y,       // screen y just above the dragon
    input  wire       ev_score,
    input  wire [7:0] score_val,
    input  wire       ev_gold,
    input  wire       ev_o2,
    input  wire       ev_mine,
    input  wire       ev_stun,
    input  wire       ev_heart,
    input  wire       ev_block,
    input  wire       ev_roar,
    input  wire       ev_roar_rdy,
    input  wire       ev_shield_rdy,
    input  wire       ev_fever,
    input  wire       ev_evolve,
    input  wire       ev_stealth,
    input  wire       ev_pu_heart,
    input  wire       ev_pu_shield,
    input  wire       ev_pu_speed,
    input  wire [9:0] pixel_x,
    input  wire [9:0] pixel_y,
    output reg        pixel_on,
    output reg [11:0] rgb_out
);
    localparam NK = 16;

    // ---- text of every kind ----
    function [3:0] tlen(input [3:0] kd, input [7:0] v);
        case (kd)
            4'd0, 4'd1: tlen = (v >= 8'd100) ? 4'd4 : (v >= 8'd10) ? 4'd3 : 4'd2;
            4'd13: tlen = 4'd3;
            4'd14: tlen = 4'd6;
            4'd15: tlen = 4'd8;
            4'd2, 4'd3, 4'd5: tlen = 4'd3;
            4'd4:  tlen = 4'd4;
            4'd6, 4'd7: tlen = 4'd5;
            4'd8:  tlen = 4'd10;
            4'd9:  tlen = 4'd12;
            4'd10, 4'd12: tlen = 4'd6;
            default: tlen = 4'd7;          // 11 EVOLVE!
        endcase
    endfunction
    function [7:0] tchar(input [3:0] kd, input [7:0] v, input [3:0] col);
        reg [95:0] str;
        reg [7:0]  hund, tens, ones;
        begin
            hund = 8'h30 + v / 100;
            tens = 8'h30 + (v / 10) % 10;
            ones = 8'h30 + v % 10;
            case (kd)
                4'd0, 4'd1: str = (v >= 8'd100) ? {"+", hund, tens, ones, 64'd0} :
                                  (v >= 8'd10)  ? {"+", tens, ones, 72'd0} : {"+", ones, 80'd0};
                4'd13: str = {"+1", 8'h03,    72'd0};
                4'd14: str = {"SHIELD",       48'd0};
                4'd15: str = {"SPEED UP",     32'd0};
                4'd2:  str = {"+O2",          72'd0};
                4'd3:  str = {"-O2",          72'd0};
                4'd4:  str = {"STUN",         64'd0};
                4'd5:  str = {"-1", 8'h03,    72'd0};
                4'd6:  str = {"BLOCK",        56'd0};
                4'd7:  str = {"ROAR!",        56'd0};
                4'd8:  str = {"ROAR READY",   16'd0};
                4'd9:  str = {"SHIELD READY"       };
                4'd10: str = {"FEVER!",       48'd0};
                4'd11: str = {"EVOLVE!",      40'd0};
                default: str = {"HIDDEN",     48'd0};
            endcase
            tchar = str[95 - 8 * col -: 8];
        end
    endfunction
    function [11:0] tcolor(input [3:0] kd);
        case (kd)
            4'd0:  tcolor = 12'hFFF;
            4'd1:  tcolor = 12'hFD3;
            4'd2:  tcolor = 12'h5EF;
            4'd3:  tcolor = 12'hF93;
            4'd4:  tcolor = 12'hFF4;
            4'd5:  tcolor = 12'hF44;
            4'd6:  tcolor = 12'hBEF;
            4'd7, 4'd8: tcolor = 12'h6FD;
            4'd9:  tcolor = 12'h8CF;
            4'd10: tcolor = 12'hFB2;
            4'd11: tcolor = 12'hF8F;
            4'd13: tcolor = 12'hF8A;
            4'd14: tcolor = 12'h8CF;
            4'd15: tcolor = 12'hFE4;
            default: tcolor = 12'hB9F;
        endcase
    endfunction

    // ---- pending events ----
    reg [NK-1:0] pend;
    reg [7:0]    pend_val, pend_gval;
    wire [NK-1:0] ev = {ev_pu_speed, ev_pu_shield, ev_pu_heart, ev_stealth, ev_evolve, ev_fever, ev_shield_rdy, ev_roar_rdy, ev_roar,
                        ev_block, ev_heart, ev_stun, ev_mine, ev_o2, ev_gold, ev_score};
    reg       take;
    reg [3:0] take_k;
    integer i;
    always @* begin
        take = 1'b0; take_k = 4'd0;
        for (i = NK - 1; i >= 0; i = i - 1)
            if (pend[i]) begin take = 1'b1; take_k = i[3:0]; end
    end

    // ---- slots ----
    reg        on   [0:NSLOT-1];
    reg [3:0]  kind [0:NSLOT-1];
    reg [7:0]  val  [0:NSLOT-1];
    reg [9:0]  sx   [0:NSLOT-1];     // left edge
    reg [9:0]  sy0  [0:NSLOT-1];     // top at age 0
    reg [5:0]  age  [0:NSLOT-1];
    reg [1:0]  last;                 // slot of the newest popup

    // slot to use: a free one, else the oldest
    reg [1:0] use_k;
    reg       found;
    reg [5:0] oldest;
    always @* begin
        found = 1'b0; use_k = 2'd0; oldest = 6'd0;
        for (i = NSLOT - 1; i >= 0; i = i - 1)
            if (!on[i]) begin found = 1'b1; use_k = i[1:0]; end
        if (!found)
            for (i = 0; i < NSLOT; i = i + 1)
                if (age[i] >= oldest) begin oldest = age[i]; use_k = i[1:0]; end
    end

    // where the new popup goes
    wire [7:0]  new_val = (take_k == 4'd1) ? pend_gval : pend_val;
    wire [3:0]  new_len = tlen(take_k, new_val);
    wire [10:0] half_w  = {3'd0, new_len, 3'd0};                  // len * 16 / 2
    wire [10:0] lx_r    = (anchor_x > half_w) ? {1'b0, anchor_x} - half_w : 11'd0;
    wire [10:0] max_x   = 11'd640 - {2'd0, new_len, 4'd0};
    wire [9:0]  new_x   = (lx_r > max_x) ? max_x[9:0] : lx_r[9:0];
    wire [9:0]  last_y  = sy0[last] - {5'd0, age[last][5:1]};
    wire        stack   = on[last] && (age[last] < 6'd18);
    wire [9:0]  ay_c    = (anchor_y < 10'd60) ? 10'd60 : (anchor_y > 10'd440) ? 10'd440 : anchor_y;
    wire [9:0]  new_y   = (stack && last_y < ay_c + 10'd18) ?
                          ((last_y > 10'd78) ? last_y - 10'd18 : 10'd60) : ay_c;

    always @(posedge clk) begin
        if (rst) begin
            pend <= {NK{1'b0}}; pend_val <= 8'd0; pend_gval <= 8'd0; last <= 2'd0;
            for (i = 0; i < NSLOT; i = i + 1) begin
                on[i] <= 1'b0; kind[i] <= 4'd0; val[i] <= 8'd0;
                sx[i] <= 10'd0; sy0[i] <= 10'd0; age[i] <= 6'd0;
            end
        end else begin
            // age the popups
            if (tick_60hz)
                for (i = 0; i < NSLOT; i = i + 1)
                    if (on[i]) begin
                        if (age[i] == LIFE - 1) on[i] <= 1'b0;
                        else age[i] <= age[i] + 6'd1;
                    end
            // start one pending popup
            if (take) begin
                on[use_k]   <= 1'b1;
                kind[use_k] <= take_k;
                val[use_k]  <= new_val;
                sx[use_k]   <= new_x;
                sy0[use_k]  <= new_y;
                age[use_k]  <= 6'd0;
                last        <= use_k;
            end
            // new events (an event arriving now wins over clearing its own bit)
            pend <= (pend & ~(take ? ({{(NK-1){1'b0}}, 1'b1} << take_k) : {NK{1'b0}})) | ev;
            if (ev_score) pend_val  <= score_val;
            if (ev_gold)  pend_gval <= score_val;
        end
    end

    // ---- stage 1: which popup is on this pixel (text or its shadow) ----
    reg        hit_c, shd_c;
    reg [1:0]  hk_c;
    reg [10:0] rx, ry;
    reg [10:0] w;
    reg [9:0]  yy;
    reg [10:0] mrx_c, mry_c;          // main glyph position
    integer s;
    always @* begin
        hit_c = 1'b0; hk_c = 2'd0; mrx_c = 11'd0; mry_c = 11'd0;
        for (s = NSLOT - 1; s >= 0; s = s - 1) begin
            yy = sy0[s] - {5'd0, age[s][5:1]};
            w  = {3'd0, tlen(kind[s], val[s]), 4'd0};
            rx = {1'b0, pixel_x} - {1'b0, sx[s]};
            ry = {1'b0, pixel_y} - {1'b0, yy};
            if (on[s] && (pixel_x >= sx[s]) && (pixel_y >= yy) &&
                (rx < w + 11'd2) && (ry < 11'd18) && (age[s] < LIFE - 12 || age[s][1])) begin
                hit_c = 1'b1; hk_c = s[1:0]; mrx_c = rx; mry_c = ry;
            end
        end
    end

    reg        hit_r;
    reg [3:0]  kind_r;
    reg [7:0]  val_r;
    reg [10:0] w_r;
    reg [10:0] mrx_r, mry_r;
    always @(posedge clk) begin
        hit_r  <= hit_c & show;
        kind_r <= kind[hk_c];
        val_r  <= val[hk_c];
        w_r    <= {3'd0, tlen(kind[hk_c], val[hk_c]), 4'd0};
        mrx_r  <= mrx_c;
        mry_r  <= mry_c;
    end

    // ---- stage 2: font lookups for the text and its shadow ----
    wire        m_in = (mrx_r < w_r) && (mry_r < 11'd16);
    wire [10:0] srx  = mrx_r - 11'd2;
    wire [10:0] sry  = mry_r - 11'd2;
    wire        s_in = (mrx_r >= 11'd2) && (mry_r >= 11'd2) && (srx < w_r) && (sry < 11'd16);
    wire [4:0]  m_bits, s_bits;
    font_rom u_fm (.ch(tchar(kind_r, val_r, mrx_r[7:4])), .row(mry_r[3:1]), .bits(m_bits));
    font_rom u_fs (.ch(tchar(kind_r, val_r, srx[7:4])),   .row(sry[3:1]),   .bits(s_bits));
    wire m_on = m_in && (mrx_r[3:1] < 3'd5) && (mry_r[3:1] < 3'd7) && m_bits[3'd4 - mrx_r[3:1]];
    wire s_on = s_in && (srx[3:1] < 3'd5)   && (sry[3:1] < 3'd7)   && s_bits[3'd4 - srx[3:1]];

    always @(posedge clk) begin
        pixel_on <= hit_r && (m_on || s_on);
        rgb_out  <= m_on ? tcolor(kind_r) : 12'h112;
    end
endmodule
