// hud: in-game display (screen coordinates, does not scroll)
//   top-left : 3 hearts (5 in the boss fight), red = left, dark = lost
//              oxygen bar under the hearts (120 px = full, red in the last quarter)
//   middle   : warnings - SHARK! / HIDE IN SEAWEED, STUN, LOW OXYGEN! (last quarter)
//   top-right: "EVO n  EP sss"  (form 1..4 and score 0..999)
//              v14: progress bar to the next form under it (x 436 .. 563, y 23 .. 28):
//              EP 0-25 / 25-75 / 75-200 for forms 1-3, 200-500 (win) for form 4
// Dark boxes behind both parts keep them readable over the map.
// show = 0 hides everything (TITLE screen).
module hud (
    input  wire        clk,
    input  wire        show,
    input  wire [2:0]  hearts,
    input  wire [2:0]  slots,          // v18: heart places (3 normal, 4 easy, boss 4..6)
    input  wire [1:0]  diff,           // v18: E / N / H after the time
    input  wire        show_eat,       // v18: "what can I eat" icons (bottom left)
    input  wire        rs_seen,        //      red shark in the map (form 2+)
    input  wire [2:0]  form,
    input  wire [9:0]  score,
    input  wire [9:0]  oxygen,         // 0 .. 960
    input  wire [6:0]  t_min,          // play time (top centre, mm:ss)
    input  wire [5:0]  t_sec,
    input  wire        blink,          // slow blink phase
    input  wire        shark_warn,     // "SHARK!" + "HIDE IN SEAWEED"
    input  wire        stunned,        // "STUN"
    input  wire        shield,         // EVO3 Tough Scales ready
    input  wire        roar_ready,     // EVO3 Tidal Roar ready
    input  wire        stealth,        // EVO1 hidden
    input  wire [6:0]  gauge,          // EVO4 Fever gauge 0..80
    input  wire        fever,
    input  wire        mic_on,         // SW15: microphone bar
    input  wire [4:0]  mic_level,
    input  wire        tilt_on,        // SW14: tilt test line at the bottom
    input  wire [7:0]  tilt_x,         // accelerometer readings (signed, 1 g ~ 64)
    input  wire [7:0]  tilt_y,
    input  wire [3:0]  tilt_dir,       // {up, down, left, right} detected
    input  wire [9:0]  pixel_x,
    input  wire [9:0]  pixel_y,
    output wire        hud_on,
    output wire [11:0] hud_rgb
);
    localparam [7:0] HEART = 8'h03;

    // Pipeline alignment (one clock = one pixel at 25 MHz): every part of the HUD must be
    // ready 3 clocks after pixel_x / pixel_y. The text (font lookup) takes 2 clocks, so it
    // gets the coordinates 1 clock late (tx_*); the plain boxes and bars take 0 clocks,
    // so they get them 3 clocks late (bx_*).
    reg [9:0] tx_x, tx_y, b2_x, b2_y, bx_x, bx_y;
    always @(posedge clk) begin
        tx_x <= pixel_x; tx_y <= pixel_y;
        b2_x <= tx_x;    b2_y <= tx_y;
        bx_x <= b2_x;    bx_y <= b2_y;
    end

    // ---- hearts: the red ones on top of three dark ones ----
    // v18: `slots` places (up to 6, x 12 .. 107)
    wire [47:0] full  = {HEART, HEART, (slots >= 3'd3) ? HEART : 8'h20, (slots >= 3'd4) ? HEART : 8'h20,
                         (slots >= 3'd5) ? HEART : 8'h20, (slots >= 3'd6) ? HEART : 8'h20};
    wire [47:0] left  = {(hearts >= 3'd1) ? HEART : 8'h20,
                         (hearts >= 3'd2) ? HEART : 8'h20,
                         (hearts >= 3'd3) ? HEART : 8'h20,
                         (hearts >= 3'd4) ? HEART : 8'h20,
                         (hearts >= 3'd5) ? HEART : 8'h20,
                         (hearts >= 3'd6) ? HEART : 8'h20};
    wire h_red, h_dim;
    text_dyn #(.X0(12), .Y0(10), .S(1), .N(6)) u_hred (
        .clk(clk), .chars(left), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(h_red));
    text_dyn #(.X0(12), .Y0(10), .S(1), .N(6)) u_hdim (
        .clk(clk), .chars(full), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(h_dim));

    // ---- form and score ----
    reg [3:0] d2, d1, d0;
    always @(posedge clk) begin
        d2 <= score / 100;
        d1 <= (score / 10) % 10;
        d0 <= score % 10;
    end
    wire [95:0] info = {"EVO", 8'h30 + form, "  EP ", 8'h30 + d2, 8'h30 + d1, 8'h30 + d0};
    wire t_info;
    text_dyn #(.X0(436), .Y0(10), .S(1), .N(12)) u_info (
        .clk(clk), .chars(info), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(t_info));

    // ---- play time, top centre: "mm:ss D" in a small dark box (x 276 .. 395, y 4 .. 29) ----
    //      v18: D = difficulty E / N / H
    reg [55:0] time_txt;
    always @(posedge clk)
        time_txt <= {8'h30 + t_min / 10, 8'h30 + t_min % 10, ":", 8'h30 + t_sec / 10, 8'h30 + t_sec % 10,
                     " ", (diff == 2'd0) ? "E" : (diff == 2'd2) ? "H" : "N"};
    wire t_time;
    text_dyn #(.X0(280), .Y0(9), .S(1), .N(7)) u_time (
        .clk(clk), .chars(time_txt), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(t_time));

    // ---- oxygen bar: x 12 .. 131, y 36 .. 41, one pixel = 8 units of oxygen ----
    wire       in_bar  = (bx_x >= 10'd12) && (bx_x < 10'd132) && (bx_y >= 10'd36) && (bx_y < 10'd42);
    wire [9:0] bar_pos = bx_x - 10'd12;
    wire       bar_on  = in_bar && (bar_pos < oxygen[9:3]);
    wire       oxy_low = (oxygen < 10'd240);

    // ---- progress to the next form (v14): 128 px, fill = (score - lo) * 128 / span ----
    //   form 1  0..25   x41 >> 3 (5.125)     form 2  25..75   x41 >> 4 (2.56)
    //   form 3  75..200 x131 >> 7 (1.02)     form 4  200..500 x109 >> 8 (0.43)
    reg  [9:0]  pg_rel;
    reg  [16:0] pg_mul;
    reg  [7:0]  pg_fill;
    always @(posedge clk) begin
        case (form)
            3'd1:    pg_rel <= score;
            3'd2:    pg_rel <= (score > 10'd25)  ? score - 10'd25  : 10'd0;
            3'd3:    pg_rel <= (score > 10'd75)  ? score - 10'd75  : 10'd0;
            default: pg_rel <= (score > 10'd200) ? score - 10'd200 : 10'd0;
        endcase
        case (form)
            3'd1:    pg_mul <= (pg_rel * 7'd41) >> 3;
            3'd2:    pg_mul <= (pg_rel * 7'd41) >> 4;
            3'd3:    pg_mul <= (pg_rel * 8'd131) >> 7;
            default: pg_mul <= (pg_rel * 7'd109) >> 8;
        endcase
        pg_fill <= (pg_mul > 17'd128) ? 8'd128 : pg_mul[7:0];
    end
    wire       in_pg  = (bx_x >= 10'd436) && (bx_x < 10'd564) && (bx_y >= 10'd23) && (bx_y < 10'd29);
    wire [9:0] pg_pos = bx_x - 10'd436;
    wire       pg_on  = in_pg && (pg_pos < {2'd0, pg_fill});
    wire       pg_tip = pg_on && (pg_pos + 10'd2 >= {2'd0, pg_fill});     // bright leading edge
    wire       pg_tic = in_pg && (pg_pos[4:0] == 5'd31);                  // marks every 32 px

    // ---- dark boxes ----
    // EVO4 Fever gauge under the oxygen bar (80 px), gold; blinks while Fever runs
    wire       in_gau  = (form == 3'd4) && (bx_x >= 10'd12) && (bx_x < 10'd92) &&
                         (bx_y >= 10'd45) && (bx_y < 10'd49);
    wire       gau_on  = in_gau && ((bx_x - 10'd12) < {3'd0, gauge}) && (!fever || blink);

    // status line in the right box: skill state
    //   form 1: STEALTH while hidden; forms 3, 4: SHLD = shield ready (blocks the next
    //   hit by itself), ROAR = Tidal Roar ready (SW15 on + shout); form 4: FEVER x2
    wire [63:0] status = stealth ? "STEALTH " :
                         fever   ? "FEVER X2" :
                         (form >= 3'd3) ? {shield ? "SHLD" : "    ", roar_ready ? "ROAR" : "    "} :
                         "        ";
    wire t_stat;
    text_dyn #(.X0(436), .Y0(34), .S(1), .N(8)) u_stat (
        .clk(clk), .chars(status), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(t_stat));

    // microphone level (SW15 on): bar in the right box, 2 px per step
    wire       in_mic  = mic_on && (bx_x >= 10'd572) && (bx_x < 10'd636) &&
                         (bx_y >= 10'd38) && (bx_y < 10'd46);
    wire       mic_bar = in_mic && ((bx_x - 10'd572) < {4'd0, mic_level, 1'b0});
    // white mark at the shout level (mic_level THRESH = 14 -> 28 px)
    wire       mic_mark = in_mic && (bx_x == 10'd600);

    // tilt test line (SW14): "X+1F Y-08 UDLR" - signed hex readings and the directions
    function [7:0] hexc(input [3:0] v);
        hexc = (v < 4'd10) ? 8'h30 + v : 8'h37 + v;
    endfunction
    wire [7:0] tx_abs = tilt_x[7] ? -tilt_x : tilt_x;
    wire [7:0] ty_abs = tilt_y[7] ? -tilt_y : tilt_y;
    wire [111:0] tilt_txt = {"X", tilt_x[7] ? "-" : "+", hexc(tx_abs[7:4]), hexc(tx_abs[3:0]),
                             " Y", tilt_y[7] ? "-" : "+", hexc(ty_abs[7:4]), hexc(ty_abs[3:0]),
                             " ", tilt_dir[3] ? "U" : ".", tilt_dir[2] ? "D" : ".",
                             tilt_dir[1] ? "L" : ".", tilt_dir[0] ? "R" : "."};
    wire t_tilt;
    text_dyn #(.X0(208), .Y0(452), .S(1), .N(14)) u_tilt (
        .clk(clk), .chars(tilt_txt), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(t_tilt));
    wire tilt_px = tilt_on && t_tilt;

    // warnings in the middle of the screen
    wire t_shark, t_hide, t_stun;
    text_line #(.X0(224), .Y0(150), .S(2), .N(6), .TEXT("SHARK!")) u_shark (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(t_shark));
    text_line #(.X0(200), .Y0(190), .S(1), .N(15), .TEXT("HIDE IN SEAWEED")) u_hide (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(t_hide));
    text_line #(.X0(288), .Y0(300), .S(1), .N(4), .TEXT("STUN")) u_stun (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(t_stun));
    // low oxygen (last quarter): blinking "LOW OXYGEN!" (top.v adds a red pulse at the edges)
    wire t_oxy;
    text_line #(.X0(232), .Y0(118), .S(1), .N(11), .TEXT("LOW OXYGEN!")) u_oxyw (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(t_oxy));
    wire oxy_txt = oxy_low && t_oxy && blink;
    wire warn_on = (shark_warn && (t_hide || (t_shark && blink))) || (stunned && t_stun) || oxy_txt;

    // v18 "what can I eat" (bottom left, x 4 .. 131, y 448 .. 475): small, medium, large,
    // golden fish, sea mine, red shark; dim + red slash = not edible in this form
    wire [2:0]  ei_k  = (bx_x - 10'd10) / 10'd20;                   // icon 0..5
    wire [9:0]  ei_x  = (bx_x - 10'd10) % 10'd20;                   // 0..15 inside
    wire [9:0]  ei_y  = bx_y - 10'd455;                             // 0..13 inside
    wire        in_ei = show_eat && (bx_x >= 10'd10) && (bx_x < 10'd130) && (ei_x < 10'd16) &&
                        (bx_y >= 10'd455) && (bx_y < 10'd469) && (ei_k != 3'd5 || rs_seen);
    wire        ei_box = show_eat && (bx_x >= 10'd4) && (bx_x < 10'd132) && (bx_y >= 10'd448) && (bx_y < 10'd476);
    (* rom_style = "distributed" *) reg [11:0] icons [0:1343];       // 6 x 16 x 14, 000 = clear
    initial $readmemh("eat_icons.mem", icons);
    wire [11:0] ei_c  = icons[ei_k * 11'd224 + ei_y[3:0] * 11'd16 + ei_x[3:0]];
    wire        ei_ok = (ei_k == 3'd0) ? 1'b1 : (ei_k == 3'd1) ? (form >= 3'd2) :
                        (ei_k == 3'd2) ? (form >= 3'd3) : (ei_k == 3'd3) ? 1'b1 : (form == 3'd4);
    wire        ei_slash = !ei_ok && (ei_x[3:0] == ei_y[3:0] || ei_x[3:0] == ei_y[3:0] + 4'd1);
    wire        ei_px = in_ei && (ei_slash || ei_c != 12'h000);
    wire [11:0] ei_rgb = ei_slash ? 12'hF33 : ei_ok ? ei_c : {2'b00, ei_c[11:10], 2'b00, ei_c[7:6], 1'b0, ei_c[3:2], 1'b1};

    wire box = ((bx_x >= 10'd276) && (bx_x < 10'd396) && (bx_y >= 10'd4) && (bx_y < 10'd30)) ||
               ei_box ||
               ((bx_x >= 10'd4)   && (bx_x < 10'd140) && (bx_y >= 10'd4) && (bx_y < 10'd52)) ||
               ((bx_x >= 10'd428) && (bx_x < 10'd636) && (bx_y >= 10'd4) && (bx_y < 10'd52));

    assign hud_on  = show & (h_red | h_dim | t_info | t_time | box | warn_on | tilt_px | ei_px);
    assign hud_rgb = warn_on ? ((stunned && t_stun) ? 12'h8DF : oxy_txt ? 12'hF66 : 12'hF42) :
                     tilt_px ? 12'hFF6 :
                     ei_px  ? ei_rgb :
                     h_red  ? 12'hF33 :
                     t_stat ? 12'hFD6 :
                     mic_mark ? 12'hFFF :
                     mic_bar ? 12'h6F6 :
                     in_mic ? 12'h234 :
                     gau_on ? 12'hFC2 :
                     pg_tip ? 12'hFFE :
                     pg_on  ? ((form == 3'd4) ? 12'hFB3 : 12'h6E9) :
                     pg_tic ? 12'h345 :
                     in_pg  ? 12'h234 :
                     in_gau ? 12'h332 :
                     h_dim  ? 12'h435 :
                     t_info ? 12'hFFF :
                     t_time ? 12'hDEF :
                     bar_on ? (oxy_low ? 12'hF44 : 12'h3CF) :
                     in_bar ? 12'h234 : 12'h013;
endmodule
