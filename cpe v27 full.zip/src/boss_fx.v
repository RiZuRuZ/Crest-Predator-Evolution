// boss_fx: boss fight effects drawn from the world position of the pixel (v15)
//
// Works on wx_d2 / wy_d2 (world position, clock 3) and the frozen camera, so the
// effects shake together with the map. Arena position of the pixel:
//   ax = (wx - cam_x) mod WORLD_W,  ay = wy - cam_y
// Plain comparisons and small squares only: the outputs are ready at clock 3.
//   bubbles   7 x radius 11: see-through fill, light rim, white spot
//   aim ring  radius 16..19 around the player while the boss warns (blinks)
//   eye       phase 3: the boss eye glows red (yellow while tired) over the darkness
//   dark      phase 3: brightness in eighths around the player:
//             8/8 inside 100 px, 5/8 to 125 px, 3/8 to 150 px, 1/8 outside
//             v20: also after a failed mini game event (`ev_dark`, outside the fight; the
//             circle is in world px, so it scales with the camera zoom)
module boss_fx #(
    parameter WORLD_W = 1920
)(
    input  wire [10:0] wx,
    input  wire [9:0]  wy,
    input  wire [10:0] cam_x,
    input  wire [9:0]  cam_y,
    input  wire        fight,           // boss fight on
    input  wire [6:0]  bub_on,
    input  wire [76:0] bub_x_vec,       // 7 x 11 arena px (centres)
    input  wire [69:0] bub_y_vec,       // 7 x 10
    input  wire        warn,
    input  wire        blink,
    input  wire [10:0] p_cx,            // player centre, arena px
    input  wire [9:0]  p_cy,
    input  wire        eye_on,
    input  wire        eye_tired,
    input  wire [10:0] eye_x,
    input  wire [9:0]  eye_y,
    input  wire        dark_on,         // phase 3
    input  wire        ev_dark,         // v20: failed event (no fight needed)
    output reg         bub_fill,
    output reg         bub_rim,
    output reg         bub_spot,
    output wire        aim_px,
    output wire        eye_px,
    output wire [11:0] eye_rgb,
    output wire [3:0]  dark_mul         // 8 = normal
);
    wire [11:0] ax_r = {1'b0, wx} + WORLD_W - cam_x;
    wire [10:0] ax   = (ax_r >= WORLD_W) ? ax_r - WORLD_W : ax_r[10:0];
    wire [9:0]  ay   = wy - cam_y;

    // ---- bubbles ----
    integer k;
    reg [10:0] bdx;
    reg [9:0]  bdy;
    reg [7:0]  bd2;
    always @* begin
        bub_fill = 1'b0; bub_rim = 1'b0; bub_spot = 1'b0;
        for (k = 0; k < 7; k = k + 1) begin
            bdx = (ax > bub_x_vec[11*k +: 11]) ? ax - bub_x_vec[11*k +: 11] : bub_x_vec[11*k +: 11] - ax;
            bdy = (ay > bub_y_vec[10*k +: 10]) ? ay - bub_y_vec[10*k +: 10] : bub_y_vec[10*k +: 10] - ay;
            if (fight && bub_on[k] && bdx < 11'd12 && bdy < 10'd12) begin
                bd2 = bdx[3:0] * bdx[3:0] + bdy[3:0] * bdy[3:0];
                if (bd2 <= 8'd121) begin
                    if (bd2 >= 8'd82) bub_rim = 1'b1;                      // outer 2 px
                    else bub_fill = 1'b1;
                    // spot up-left of the centre
                    if (ax + 11'd4 >= bub_x_vec[11*k +: 11] && ax + 11'd2 <= bub_x_vec[11*k +: 11] &&
                        ay + 10'd5 >= bub_y_vec[10*k +: 10] && ay + 10'd3 <= bub_y_vec[10*k +: 10])
                        bub_spot = 1'b1;
                end
            end
        end
    end

    // ---- aim ring and darkness around the player ----
    wire [10:0] pdx = (ax > p_cx) ? ax - p_cx : p_cx - ax;
    wire [9:0]  pdy = (ay > p_cy) ? ay - p_cy : p_cy - ay;
    wire        near = (pdx < 11'd150) && (pdy < 10'd150);
    wire [15:0] pd2  = pdx[7:0] * pdx[7:0] + pdy[7:0] * pdy[7:0];
    assign aim_px = fight && warn && blink && near && (pd2 >= 16'd256) && (pd2 < 16'd361);   // r 16..18
    assign dark_mul = !((fight && dark_on) || ev_dark) ? 4'd8 :
                      !near               ? 4'd1 :
                      (pd2 < 16'd10000)   ? 4'd8 :
                      (pd2 < 16'd15625)   ? 4'd5 :
                      (pd2 < 16'd22500)   ? 4'd3 : 4'd1;

    // ---- eye: 11 x 7 oval ----
    wire [10:0] edx = (ax > eye_x) ? ax - eye_x : eye_x - ax;
    wire [9:0]  edy = (ay > eye_y) ? ay - eye_y : eye_y - ay;
    assign eye_px  = fight && eye_on && ((edx <= 11'd5 && edy <= 10'd2) || (edx <= 11'd3 && edy == 10'd3));
    assign eye_rgb = eye_tired ? 12'hFD3 : 12'hF22;
endmodule
