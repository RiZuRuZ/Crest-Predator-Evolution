`timescale 1ns / 1ps
//==============================================================================
// score_ctrl - Evolution Point (EP) counter and win detection
//
// - Adds EP when a fish is eaten:  small +1, medium +3, large +5
//   (fish_type matches fish_spawner: 0 small, 1 medium, 2 large)
// - Score never decreases, and saturates at WIN_SCORE (500)
// - `win` goes high when score reaches WIN_SCORE and stays high until reset;
//   further eats are ignored once the game is won
//
// Inputs
//   eat        MUST be a ONE-CYCLE pulse per eaten fish. Every cycle with
//              eat = 1 adds points, so the caller has to generate a single
//              pulse per collision (e.g. remove the fish on the same event)
//              and must not hold eat high while the player overlaps a fish.
//   fish_type  type of the fish that was eaten, sampled together with eat
//
// Outputs
//   score[15:0]  current EP. 16 bits to match the work-plan interface of
//                ep_compare (score[15:0]); feeds evolution logic and the
//                7-segment display
//   win          1 when score == WIN_SCORE
//
// Project conventions: single clock CLK100MHZ, rst active-high synchronous.
//
// EP values are parameters. fish_type 3 = golden fish: +10 EP (work plan,
// "Score system"). The work plan lists a separate golden_eaten input; here
// golden is simply fish_type 3 on the same eat pulse.
//==============================================================================
module score_ctrl #(
    parameter [15:0] WIN_SCORE = 16'd500,
    parameter [15:0] EP_SMALL  = 16'd1,
    parameter [15:0] EP_MEDIUM = 16'd3,
    parameter [15:0] EP_LARGE  = 16'd5,
    parameter [15:0] EP_GOLDEN = 16'd10,   // rare golden fish (any form can eat it)
    parameter [15:0] EP_BONUS  = 16'd100,  // the red shark (form 4)
    parameter [15:0] CHEAT_EP  = 16'd50    // v16: developer code in PAUSE (dev_cheat)
) (
    input  wire        clk,        // CLK100MHZ
    input  wire        rst,        // active-high, synchronous
    input  wire        eat,        // 1-cycle pulse: a fish was eaten
    input  wire [1:0]  fish_type,  // type of the eaten fish
    input  wire        bonus,      // 1-cycle pulse: the red shark was eaten (+EP_BONUS)
    input  wire        double,     // Fever time (form 4): points x2
    input  wire        cheat,      // 1-cycle pulse: developer code entered (+CHEAT_EP)
    input  wire        jump,       // v18: 1-cycle pulse: score = next form threshold (25 / 75 / 200 / 500)
    output reg  [15:0] score,      // accumulated EP
    output wire        win         // score reached WIN_SCORE
);

    // points for the eaten fish
    reg [15:0] points;
    always @* begin
        case (fish_type)
            2'd0:    points = EP_SMALL;
            2'd1:    points = EP_MEDIUM;
            2'd2:    points = EP_LARGE;
            default: points = EP_GOLDEN;
        endcase
    end

    // 17-bit sum so the addition cannot overflow before the saturation check
    wire [15:0] pts = (eat ? points : 16'd0) + (bonus ? EP_BONUS : 16'd0);
    wire [16:0] sum = {1'b0, score} + (double ? {pts, 1'b0} : {1'b0, pts}) +
                      (cheat ? {1'b0, CHEAT_EP} : 17'd0);

    assign win = (score >= WIN_SCORE);

    always @(posedge clk) begin
        if (rst)
            score <= 16'd0;
        else if (jump && !win)
            score <= (score < 16'd25) ? 16'd25 : (score < 16'd75) ? 16'd75 :
                     (score < 16'd200) ? 16'd200 : WIN_SCORE;
        else if ((eat || bonus || cheat) && !win)
            score <= (sum >= {1'b0, WIN_SCORE}) ? WIN_SCORE : sum[15:0];
    end

endmodule
