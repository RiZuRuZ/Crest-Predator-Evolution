// text_number: draws value (0..999) as 3 decimal digits with font_rom
// Same cell layout and 2-clock latency as text_line. Leading zeros are shown (e.g. 042).
module text_number #(
    parameter X0 = 0,
    parameter Y0 = 0,
    parameter S  = 1
)(
    input  wire       clk,
    input  wire [9:0] value,
    input  wire [9:0] pixel_x,
    input  wire [9:0] pixel_y,
    output reg        pixel_on
);
    localparam W = 3 << (3 + S);
    localparam H = 8 << S;

    // digits (value changes rarely, one register stage is enough)
    reg [3:0] d2, d1, d0;
    always @(posedge clk) begin
        d2 <= value / 100;
        d1 <= (value / 10) % 10;
        d0 <= value % 10;
    end

    wire [10:0] rx     = {1'b0, pixel_x} - X0;
    wire [10:0] ry     = {1'b0, pixel_y} - Y0;
    wire        in_box = (pixel_x >= X0) && (pixel_x < X0 + W) &&
                         (pixel_y >= Y0) && (pixel_y < Y0 + H);
    wire [10:0] col    = rx >> (3 + S);

    reg       in_r;
    reg [7:0] ch_r;
    reg [2:0] row_r, px_r;
    always @(posedge clk) begin
        in_r  <= in_box;
        case (col)
            11'd0:   ch_r <= 8'h30 + d2;      // "0" + digit
            11'd1:   ch_r <= 8'h30 + d1;
            default: ch_r <= 8'h30 + d0;
        endcase
        row_r <= ry >> S;
        px_r  <= rx >> S;
    end

    wire [4:0] bits;
    font_rom u_font (.ch(ch_r), .row(row_r), .bits(bits));
    always @(posedge clk)
        pixel_on <= in_r && (px_r < 3'd5) && (row_r < 3'd7) && bits[3'd4 - px_r];
endmodule
