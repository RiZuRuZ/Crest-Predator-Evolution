// mine_field: sea mines that appear at random places, blink, then vanish or explode
//
// Each of the N slots: OFF -> ALIVE (LIFE ticks; blinks in the last BLINK ticks, then
// disappears) -> back to OFF. Touching the player:
//   form 1..3 : `hurt` pulse (costs a heart in player_health) and the mine explodes
//   form 4    : Apex Feast - the dragon eats the mine: `eaten` pulse (costs oxygen
//               instead of a heart, oxygen_ctrl.penalty) and the mine explodes
// Explosion: BOOM state plays the 6 explosion frames (BOOM_TICKS each), then OFF.
// `sweep` (the giant shark passing) removes every mine at once.
// A new mine is placed every SPAWN_TICKS in a free slot, inside the camera view, but
// never inside the safe box around the player (centre to centre: closer than safe_x
// on x AND closer than safe_y on y). top.v makes the box grow with the dragon's size,
// so a big form does not get a mine right on top of it. If the random spot is too
// close, it tries again on the next tick with a new random value.
// `pause` (giant shark event) stops new mines.
// Mine sprite 43x44 (seamine.mem), explosion 64x64 centred on the mine.
// Positions: x world, y world + 128 (slot_sprite convention).
// PLACEHOLDERS: N, SPAWN_TICKS, LIFE, BLINK, hitbox inset, safe box size (top.v).
module mine_field #(
    parameter N           = 3,
    parameter SPAWN_TICKS = 360,     // 6 s
    parameter LIFE        = 600,     // 10 s
    parameter BLINK       = 180,     // last 3 s
    parameter BOOM_TICKS  = 5,
    parameter WORLD_W     = 1920
)(
    input  wire            clk,
    input  wire            rst,
    input  wire            tick_60hz,
    input  wire [15:0]     rand,
    input  wire [10:0]     cam_x,
    input  wire [9:0]      cam_y,
    input  wire [10:0]     player_x,      // player hitbox
    input  wire [9:0]      player_y,
    input  wire [7:0]      player_w,
    input  wire [7:0]      player_h,
    input  wire [2:0]      form,
    input  wire [1:0]      diff,           // v18 difficulty: 0 easy, 1 normal, 2 hard
    input  wire            sweep,
    input  wire            pause,
    input  wire [10:0]     player_cx,     // player centre (spawn distance)
    input  wire [9:0]      player_cy,
    input  wire [8:0]      safe_x,        // no spawn this close to the player centre ...
    input  wire [8:0]      safe_y,        // ... on both axes
    output reg             hurt,          // 1-clk pulse
    output reg             eaten,         // 1-clk pulse (form 4)
    output reg             boom,          // 1-clk pulse: an explosion started (sound)
    output reg  [10:0]     hit_cx,        // centre of the mine that hit (knockback)
    output reg  [9:0]      hit_cy,
    // mine sprites
    output wire [N-1:0]    mine_vec,
    output wire [11*N-1:0] x_vec,
    output wire [11*N-1:0] y_vec,
    output wire [3*N-1:0]  frame_vec,
    // explosion sprites
    output wire [N-1:0]    boom_vec,
    output wire [11*N-1:0] bx_vec,
    output wire [11*N-1:0] by_vec,
    output wire [3*N-1:0]  bframe_vec
);
    localparam S_OFF = 2'd0, S_ALIVE = 2'd1, S_BOOM = 2'd2;
    reg [1:0]  st   [0:N-1];
    reg [10:0] mx   [0:N-1];
    reg [9:0]  my   [0:N-1];
    reg [9:0]  t    [0:N-1];
    reg [2:0]  bf   [0:N-1];
    reg [9:0]  spawn_t;
    reg [3:0]  anim;

    // free slot for spawning
    integer i;
    reg        have_free;
    reg [2:0]  free_k;
    always @* begin
        have_free = 1'b0; free_k = 3'd0;
        for (i = N - 1; i >= 0; i = i - 1)
            if (st[i] == S_OFF) begin have_free = 1'b1; free_k = i[2:0]; end
    end

    // spawn position inside the view (40 px margin), x wrapped
    wire [9:0]  rxv  = rand[9:0] % 10'd557;            // 0 .. 556 = 640 - 43 - 40
    wire [8:0]  ryv  = rand[15:7] % 9'd356;            // 0 .. 355 = 480 - 44 - 80
    wire [11:0] sx_r = {1'b0, cam_x} + 12'd20 + rxv;
    wire [10:0] sx_w = (sx_r >= WORLD_W) ? sx_r - WORLD_W : sx_r[10:0];
    wire [9:0]  sy_w = cam_y + 10'd60 + ryv;
    // distance from the player centre to the new mine centre
    wire [11:0] mcx_r = {1'b0, sx_w} + 12'd21;
    wire [10:0] mcx   = (mcx_r >= WORLD_W) ? mcx_r - WORLD_W : mcx_r[10:0];
    wire [10:0] sdx_a = (mcx >= player_cx) ? mcx - player_cx : player_cx - mcx;
    wire [10:0] sdx   = (sdx_a > WORLD_W / 2) ? WORLD_W - sdx_a : sdx_a;
    wire [9:0]  mcy   = sy_w + 10'd22;
    wire [9:0]  sdy   = (mcy >= player_cy) ? mcy - player_cy : player_cy - mcy;
    wire        too_close = (sdx < {2'd0, safe_x}) && (sdy < {1'b0, safe_y});

    // contact test per slot (mine core 33x34, 5 px inset)
    reg [N-1:0] touch;
    wire [N-1:0] touch_c;
    genvar g;
    generate
        for (g = 0; g < N; g = g + 1) begin : g_hit
            wire [11:0] hx_r = {1'b0, mx[g]} + 12'd5;
            wire [10:0] hx   = (hx_r >= WORLD_W) ? hx_r - WORLD_W : hx_r[10:0];
            aabb_collision #(.SCREEN_W(WORLD_W), .CW(11)) u_c (
                .ax(hx), .ay({1'b0, my[g] + 10'd5}), .aw(8'd33), .ah(8'd34),
                .bx(player_x), .by({1'b0, player_y}), .bw(player_w), .bh(player_h),
                .hit(touch_c[g])
            );
        end
    endgenerate

    always @(posedge clk) begin
        hurt <= 1'b0; eaten <= 1'b0; boom <= 1'b0;
        if (rst) begin
            for (i = 0; i < N; i = i + 1) begin st[i] <= S_OFF; t[i] <= 10'd0; bf[i] <= 3'd0; end
            spawn_t <= SPAWN_TICKS / 2;
            anim    <= 4'd0;
            touch   <= {N{1'b0}};
        end else begin
            touch <= touch_c;
            if (tick_60hz) begin
                anim <= anim + 4'd1;
                if (spawn_t != 10'd0)            spawn_t <= spawn_t - 10'd1;
                else if (!pause && !too_close)   spawn_t <= (diff == 2'd0) ? 10'd540 :
                                                             (diff == 2'd2) ? 10'd270 : SPAWN_TICKS;   // v18
                if (spawn_t == 10'd0 && have_free && !pause && !too_close) begin
                    st[free_k] <= S_ALIVE;
                    mx[free_k] <= sx_w;
                    my[free_k] <= sy_w;
                    t[free_k]  <= LIFE;
                end
            end
            for (i = 0; i < N; i = i + 1) begin
                if (sweep && st[i] != S_OFF) begin
                    st[i] <= S_OFF;
                end else if (st[i] == S_ALIVE) begin
                    if (touch[i]) begin
                        st[i] <= S_BOOM; t[i] <= BOOM_TICKS; bf[i] <= 3'd0;
                        boom  <= 1'b1;
                        hit_cx <= mx[i] + 11'd21;
                        hit_cy <= my[i] + 10'd22;
                        if (form == 3'd4) eaten <= 1'b1; else hurt <= 1'b1;
                    end else if (tick_60hz) begin
                        if (t[i] == 10'd0) st[i] <= S_OFF;
                        else               t[i] <= t[i] - 10'd1;
                    end
                end else if (st[i] == S_BOOM && tick_60hz) begin
                    if (t[i] == 10'd0) begin
                        t[i] <= BOOM_TICKS;
                        if (bf[i] == 3'd5) st[i] <= S_OFF;
                        else               bf[i] <= bf[i] + 3'd1;
                    end else t[i] <= t[i] - 10'd1;
                end
            end
        end
    end

    // sprite outputs; blinking = hidden every other 8 ticks in the last BLINK ticks
    generate
        for (g = 0; g < N; g = g + 1) begin : g_out
            wire blink_off = (t[g] < BLINK) && anim[3];
            assign mine_vec[g]          = (st[g] == S_ALIVE) && !blink_off;
            assign x_vec[11*g +: 11]    = mx[g];
            assign y_vec[11*g +: 11]    = {1'b0, my[g]} + 11'd128;
            assign frame_vec[3*g +: 3]  = {1'b0, anim[3:2]};
            assign boom_vec[g]          = (st[g] == S_BOOM);
            // explosion 64x64 centred on the 43x44 mine: shift by (-10, -10)
            assign bx_vec[11*g +: 11]   = (mx[g] >= 11'd10) ? mx[g] - 11'd10 : mx[g] + WORLD_W - 11'd10;
            assign by_vec[11*g +: 11]   = {1'b0, my[g]} + 11'd118;
            assign bframe_vec[3*g +: 3] = bf[g];
        end
    endgenerate
endmodule
