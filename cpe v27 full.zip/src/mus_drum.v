// mus_drum: v27 synthesised drum voice (no samples stored, no BRAM)
// kind: 1 kick (sine, pitch drops 160 -> 50 Hz), 2 snare (noise + 190 Hz sine),
// 3 closed hat / 4 open hat (high-passed noise), 5 crash (noise), 6 clap (noise, 3 hits).
// Noise: 16-bit LFSR, one step per sample. Same model as cpe_pc/src/music16.js.
// Pulses as mus_voice (stp / etk / smp). Every number is a PLACEHOLDER.
module mus_drum (
    input  wire              clk,
    input  wire              rst,
    input  wire              kill,
    input  wire              stp,
    input  wire [2:0]        s_kind,           // 0 = nothing new this step
    input  wire              etk,
    input  wire              smp,
    output reg  signed [7:0] out
);
    reg [2:0]  kind;
    reg [7:0]  lvl, sw;
    reg [23:0] ph;
    reg [2:0]  ct;
    reg [15:0] lfsr;
    reg signed [7:0] nprev;

    reg [5:0] vol; reg [2:0] dk;
    always @* begin
        case (kind)
            3'd1:    begin vol = 6'd58; dk = 3'd4; end
            3'd2:    begin vol = 6'd40; dk = 3'd4; end
            3'd3:    begin vol = 6'd15; dk = 3'd2; end
            3'd4:    begin vol = 6'd15; dk = 3'd5; end
            3'd5:    begin vol = 6'd21; dk = 3'd6; end
            default: begin vol = 6'd31; dk = 3'd3; end
        endcase
    end
    wire signed [7:0]  n8 = {~lfsr[7], lfsr[6:0]};                         // (lfsr & 255) - 128
    wire signed [7:0]  sn;
    mus_wave u_sine (.tab(3'd6), .idx(ph[23:18]), .s(sn));
    wire signed [8:0]  hp = ({n8[7], n8} - {nprev[7], nprev});            // n8 - previous
    wire signed [8:0]  sd = {n8[7], n8[7:1]} + {sn[7], sn[7:1]};          // n8 / 2 + sine / 2
    reg  signed [7:0]  x;
    reg  [23:0]        inc;
    always @* begin
        case (kind)
            3'd1:         begin x = sn;        inc = 24'd17180 + sw * 8'd148; end
            3'd2:         begin x = sd[7:0];   inc = 24'd65283;               end
            3'd3, 3'd4:   begin x = hp[8:1];   inc = 24'd0;                   end
            default:      begin x = n8;        inc = 24'd0;                   end
        endcase
    end
    wire signed [16:0] p0 = x * $signed({1'b0, lvl});
    wire signed [8:0]  p  = p0[16:8];
    wire signed [15:0] q0 = p * $signed({1'b0, vol});

    always @(posedge clk) begin
        if (rst || kill) begin
            kind <= 3'd0; lvl <= 8'd0; sw <= 8'd0; ph <= 24'd0; ct <= 3'd0;
            lfsr <= 16'hACE1; nprev <= 8'sd0; out <= 8'sd0;
        end else begin
            if (stp && s_kind != 3'd0) begin
                kind <= s_kind; lvl <= 8'd255; sw <= 8'd255; ct <= 3'd0; ph <= 24'd0;
            end
            if (etk && kind != 3'd0) begin
                if (kind == 3'd6 && (ct == 3'd1 || ct == 3'd3)) lvl <= 8'd255;   // clap re-hits
                else lvl <= lvl - (lvl >> dk);
                sw <= sw - {2'b00, sw[7:2]};
                if (ct != 3'd7) ct <= ct + 3'd1;
            end
            if (smp) begin
                out   <= (kind != 3'd0) ? q0[13:6] : 8'sd0;
                if (kind != 3'd0) ph <= ph + inc;
                nprev <= n8;
                lfsr  <= {1'b0, lfsr[15:1]} ^ (lfsr[0] ? 16'hB400 : 16'h0000);
            end
        end
    end
endmodule
