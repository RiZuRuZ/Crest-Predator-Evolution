// pixel_mixer: background (scrolling map) < objects (merged in top.v)
// The object layer already contains, from bottom to top: bubbles < fish < player < HUD / text.
// All outputs are registered together with hsync/vsync so their timing stays aligned.
module pixel_mixer (
    input  wire        clk,
    input  wire        rst,
    input  wire        pix_ce,
    input  wire        active_video,
    input  wire        hs_in,
    input  wire        vs_in,
    input  wire [11:0] bg_rgb,
    input  wire        obj_on,
    input  wire [11:0] obj_rgb,
    output reg  [3:0]  vga_r,
    output reg  [3:0]  vga_g,
    output reg  [3:0]  vga_b,
    output reg         vga_hs,
    output reg         vga_vs
);
    reg [11:0] px;

    always @* begin
        px = bg_rgb;
        if (obj_on) px = obj_rgb;
        if (!active_video) px = 12'h000;
    end

    always @(posedge clk) begin
        if (rst) begin
            vga_r  <= 4'h0;
            vga_g  <= 4'h0;
            vga_b  <= 4'h0;
            vga_hs <= 1'b1;
            vga_vs <= 1'b1;
        end else if (pix_ce) begin
            vga_r  <= px[11:8];
            vga_g  <= px[7:4];
            vga_b  <= px[3:0];
            vga_hs <= hs_in;
            vga_vs <= vs_in;
        end
    end
endmodule
