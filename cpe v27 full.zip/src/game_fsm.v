// game_fsm: TITLE / PLAY / PAUSE / OVER / WIN
// TITLE --start--> PLAY
// PLAY  --win--> WIN, --dead--> OVER, --pause_sw = 1--> PAUSE
// PAUSE --pause_sw = 0--> PLAY
// OVER / WIN --start--> TITLE
// start    : 1-cycle pulse (center button)
// pause_sw : synchronized level (SW0)
// dead     : hearts or oxygen ran out (sticky until the game state is reset)
// win      : score reached WIN_SCORE (sticky)
// in_title : hold the game state in reset (a new game starts fresh from TITLE)
// playing  : enable the game tick / dash only in PLAY (PAUSE, OVER and WIN freeze the game)
// If win and dead happen in the same clock, win is taken.
module game_fsm (
    input  wire       clk,
    input  wire       rst,
    input  wire       start,
    input  wire       pause_sw,
    input  wire       dead,
    input  wire       win,
    output reg  [2:0] state,
    output wire       in_title,
    output wire       playing
);
    localparam [2:0] TITLE = 3'd0, PLAY = 3'd1, PAUSE = 3'd2, OVER = 3'd3, WIN = 3'd4;

    always @(posedge clk) begin
        if (rst) begin
            state <= TITLE;
        end else begin
            case (state)
                TITLE:     if (start) state <= PLAY;
                PLAY: begin
                    if (win)           state <= WIN;
                    else if (dead)     state <= OVER;
                    else if (pause_sw) state <= PAUSE;
                end
                PAUSE:     if (!pause_sw) state <= PLAY;
                OVER, WIN: if (start) state <= TITLE;
                default:   state <= TITLE;
            endcase
        end
    end

    assign in_title = (state == TITLE);
    assign playing  = (state == PLAY);
endmodule
