// vga_timing: 640x480 @ 60 Hz (25 MHz pixel clock via pix_ce)
// H: 640 visible + 16 front + 96 sync + 48 back = 800
// V: 480 visible + 10 front +  2 sync + 33 back = 525
// Sync signals are active-low
module vga_timing (
    input  wire       clk,
    input  wire       rst,
    input  wire       pix_ce,
    output wire       hsync,
    output wire       vsync,
    output wire [9:0] x,
    output wire [9:0] y,
    output wire       active_video
);
    localparam H_VIS = 640, H_FP = 16, H_SYNC = 96, H_TOT = 800;
    localparam V_VIS = 480, V_FP = 10, V_SYNC = 2,  V_TOT = 525;

    reg [9:0] hc;
    reg [9:0] vc;

    always @(posedge clk) begin
        if (rst) begin
            hc <= 10'd0;
            vc <= 10'd0;
        end else if (pix_ce) begin
            if (hc == H_TOT - 1) begin
                hc <= 10'd0;
                if (vc == V_TOT - 1) vc <= 10'd0;
                else                 vc <= vc + 10'd1;
            end else begin
                hc <= hc + 10'd1;
            end
        end
    end

    assign x = hc;
    assign y = vc;
    assign active_video = (hc < H_VIS) && (vc < V_VIS);
    assign hsync = ~((hc >= H_VIS + H_FP) && (hc < H_VIS + H_FP + H_SYNC));
    assign vsync = ~((vc >= V_VIS + V_FP) && (vc < V_VIS + V_FP + V_SYNC));
endmodule
