// ep_compare: compares the score (EP) against the evolution thresholds of the current form
// FORM1 -> FORM2 at EP >= 25, FORM2 -> FORM3 at EP >= 75, FORM3 -> FORM4 at EP >= 200
// evolve_req is a combinational level; evolution_fsm turns it into a single form change
module ep_compare #(
    parameter EP_TO_2 = 25,
    parameter EP_TO_3 = 75,
    parameter EP_TO_4 = 200
)(
    input  wire [15:0] score,
    input  wire [2:0]  form_state,   // 1..4
    output reg         evolve_req
);
    always @* begin
        case (form_state)
            3'd1:    evolve_req = (score >= EP_TO_2);
            3'd2:    evolve_req = (score >= EP_TO_3);
            3'd3:    evolve_req = (score >= EP_TO_4);
            default: evolve_req = 1'b0;   // FORM4 is the last form, no regression either
        endcase
    end
endmodule
