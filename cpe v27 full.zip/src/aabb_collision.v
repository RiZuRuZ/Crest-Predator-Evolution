`timescale 1ns / 1ps
//==============================================================================
// aabb_collision - axis-aligned bounding box overlap test (combinational)
//
// Project conventions (see conventions.md):
//   - (x, y) is the TOP-LEFT corner of each box, y grows downward
//   - x wraps around at SCREEN_W (640), y does NOT wrap
//   - sizes are in pixels; a box covers x .. x+w-1 and y .. y+h-1
//
// hit = 1 when boxes A and B share at least one pixel.
//   - boxes that only touch edge-to-edge do NOT collide
//   - a box with width 0 or height 0 never collides
//
// X overlap on a circle of length SCREEN_W:
//   two arcs overlap exactly when the start of one lies inside the other.
//     (bx - ax) mod SCREEN_W < aw   -> B starts inside A
//     (ax - bx) mod SCREEN_W < bw   -> A starts inside B
//   This handles a box that straddles the right edge and re-enters on the
//   left (rule 4.4) with no special cases.
//
// Requirements: widths must be <= SCREEN_W; coordinates must be < SCREEN_W
// for x and < 2^CW for y (the game keeps y in 0 .. 480-h).
//
// Purely combinational, so the result can be sampled on tick_60hz by the
// caller. No clock or reset is needed.
//==============================================================================
module aabb_collision #(
    parameter SCREEN_W = 640,
    parameter CW       = 10,   // coordinate width (x, y)
    parameter SW       = 8     // size width (w, h) -> boxes up to 255 px
) (
    input  wire [CW-1:0] ax, ay,   // box A top-left
    input  wire [SW-1:0] aw, ah,   // box A size
    input  wire [CW-1:0] bx, by,   // box B top-left
    input  wire [SW-1:0] bw, bh,   // box B size
    output wire          hit
);

    localparam DW = CW + 1;                    // one extra bit for sign/carry
    localparam [DW-1:0] WRAP = SCREEN_W;

    // ---- X axis: circular distance from one start to the other ------------
    wire [DW-1:0] d_ab_raw = {1'b0, bx} - {1'b0, ax};   // bit DW-1 set => negative
    wire [DW-1:0] d_ba_raw = {1'b0, ax} - {1'b0, bx};
    wire [DW-1:0] d_ab     = d_ab_raw[DW-1] ? (d_ab_raw + WRAP) : d_ab_raw;
    wire [DW-1:0] d_ba     = d_ba_raw[DW-1] ? (d_ba_raw + WRAP) : d_ba_raw;

    wire b_starts_in_a = (d_ab < {{(DW-SW){1'b0}}, aw});
    wire a_starts_in_b = (d_ba < {{(DW-SW){1'b0}}, bw});
    wire x_overlap     = b_starts_in_a | a_starts_in_b;

    // ---- Y axis: plain interval overlap, no wrap ---------------------------
    wire [DW-1:0] a_bot = {1'b0, ay} + {{(DW-SW){1'b0}}, ah};
    wire [DW-1:0] b_bot = {1'b0, by} + {{(DW-SW){1'b0}}, bh};
    wire y_overlap      = ({1'b0, ay} < b_bot) && ({1'b0, by} < a_bot);

    // Empty boxes never collide
    wire nonempty = (aw != 0) && (ah != 0) && (bw != 0) && (bh != 0);

    assign hit = x_overlap & y_overlap & nonempty;

endmodule
