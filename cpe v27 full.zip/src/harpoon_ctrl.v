// harpoon_ctrl: harpoons that warn first, then shoot straight across the view
//
// FSM (work plan "harpoon_fsm"): IDLE -> WARN -> FIRE -> IDLE, for a volley of up to
// N harpoons at once. Higher forms are harder (difficulty):
//   volley size = form + 1 (2..5 harpoons), pause between volleys
//   form 1: 7..12 s   form 2: 6..10 s   form 3: 5..8 s   form 4: 4..7 s
//   WARN  WARN_TICKS: the line of every harpoon is shown (it blinks faster and faster
//         as the shot comes, see warn_t). Harpoon 0 is aimed at the player; the others
//         are spread out around him (lane k is k/2 steps of LANE_GAP away, odd lanes on
//         one side and even lanes on the other, plus a little random), so two lines of
//         one volley are never right next to each other. Each one is horizontal or
//         vertical at random and comes from either side.
//   Homing: in about 1 volley out of 5 (rand < HOME_P / 128) harpoon 0 is a homing
//         harpoon: during WARN its line follows the player until LOCK_TICKS before the
//         shot, then it locks. `homing`, `locked`, aim_x / aim_y let top.v draw the
//         aim mark on the target.
//   FIRE  the harpoons start slow and speed up: SPEED0 px per tick, +1 every tick up
//         to SPEED_MAX, from outside the view to the other side.
// `pause` (giant shark event) holds the IDLE timer: no new volley while the shark is out.
// v20 `clear` (a mini game starts: boss or event) removes the warning lines and the flying
// harpoons at once; the next volley comes after the normal pause.
// They cannot be eaten or destroyed. Touching one costs a heart (`hurt`, once per
// harpoon per volley).
// Sprites: harpoon_h 88x23 points right (mirrored when flying left),
//          harpoon_v 23x88 points down (mirrored when flying up).
// Positions: x world, y world + 128 (slot_sprite convention). Lane k uses bits
// [11*k +: 11] / [10*k +: 10] of the vectors.
// PLACEHOLDERS: timings, speeds, LANE_GAP, HOME_P, LOCK_TICKS.
module harpoon_ctrl #(
    parameter N          = 5,
    parameter WARN_TICKS = 90,      // 1.5 s
    parameter LOCK_TICKS = 30,      // homing line stops following 0.5 s before the shot
    parameter HOME_P     = 26,      // homing chance = 26 / 128 (about 20 %)
    parameter SPEED0     = 4,
    parameter SPEED_MAX  = 20,
    parameter WORLD_W    = 1920,
    parameter WORLD_H    = 640
)(
    input  wire            clk,
    input  wire            rst,
    input  wire            tick_60hz,
    input  wire [15:0]     rand,
    input  wire [2:0]      form,
    input  wire [1:0]      diff,           // v18 difficulty: 0 easy, 1 normal, 2 hard
    input  wire            pause,
    input  wire            clear,          // v20: 1-clk, all harpoons go away
    input  wire            wide,           // v21: view 800 x 600 (zoom 1.25: boss fight, Fever)
    input  wire [10:0]     cam_x,
    input  wire [9:0]      cam_y,
    input  wire [10:0]     player_cx,
    input  wire [9:0]      player_cy,
    input  wire [10:0]     player_x,      // player hitbox
    input  wire [9:0]      player_y,
    input  wire [7:0]      player_w,
    input  wire [7:0]      player_h,
    output reg             hurt,          // 1-clk pulse
    output reg  [10:0]     hit_cx,        // knockback centre (on the harpoon line)
    output reg  [9:0]      hit_cy,
    output wire            warn_on,
    output wire            fly_on,
    output wire [6:0]      warn_t,        // ticks left in WARN (blink speed)
    output reg             homing,        // harpoon 0 of this volley is homing
    output wire            locked,        // homing line no longer follows the player
    output reg  [10:0]     aim_x,         // homing target (world)
    output reg  [9:0]      aim_y,
    output reg  [N-1:0]    lane_on,       // lanes used in this volley
    output reg  [N-1:0]    vert,          // 1 = vertical
    output reg  [N-1:0]    back,          // 1 = flies left / up (mirrored)
    output wire [11*N-1:0] line_x_vec,    // vertical line: world x
    output wire [10*N-1:0] line_y_vec,    // horizontal line: world y
    output wire [11*N-1:0] hx_vec,        // sprite top-left x (world)
    output wire [11*N-1:0] hy_vec,        // sprite top-left y (world + 128)
    output wire [2:0]      frame
);
    localparam S_IDLE = 2'd0, S_WARN = 2'd1, S_FIRE = 2'd2;
    reg [1:0]  st;
    reg [10:0] t;                      // v18: 11 bits (easy pauses up to 1079 ticks)
    reg [10:0] dist;
    reg [4:0]  spd;
    reg [3:0]  anim;
    reg [10:0] lx [0:N-1];
    reg [9:0]  ly [0:N-1];
    reg [10:0] hx [0:N-1];
    reg [10:0] hy [0:N-1];
    reg [N-1:0] done_hit;

    assign warn_on = (st == S_WARN);
    assign fly_on  = (st == S_FIRE);
    assign frame   = {1'b0, anim[3:2]};
    assign warn_t  = (st == S_WARN) ? t[6:0] : 7'd0;
    assign locked  = (st == S_WARN) && (t <= LOCK_TICKS);

    // pause between volleys by form
    wire [9:0] base_n = (form == 3'd4) ? 10'd240 : (form == 3'd3) ? 10'd300 :
                        (form == 3'd2) ? 10'd360 : 10'd420;
    wire [8:0] span_n = (form == 3'd4) ? 9'd180 : (form == 3'd3) ? 9'd180 :
                        (form == 3'd2) ? 9'd240 : 9'd300;
    // v18 difficulty: easy pauses x1.5 and `form` harpoons, hard pauses x0.75
    wire [10:0] base_t = (diff == 2'd0) ? {1'b0, base_n} + base_n[9:1] :
                         (diff == 2'd2) ? {1'b0, base_n} - base_n[9:2] : {1'b0, base_n};
    wire [9:0]  span_t = (diff == 2'd0) ? {1'b0, span_n} + span_n[8:1] :
                         (diff == 2'd2) ? {1'b0, span_n} - span_n[8:2] : {1'b0, span_n};
    wire [2:0] volley = (diff == 2'd0) ? form : (form >= 3'd4) ? 3'd5 : form + 3'd1;
    wire [6:0] home_p = (diff == 2'd0) ? 7'd13 : (diff == 2'd2) ? 7'd45 : HOME_P;   // 10 / 20 / 35 %

    wire [11:0] xl_r = {1'b0, cam_x} + WORLD_W - 12'd88;       // just left of the view
    wire [11:0] xr_r = {1'b0, cam_x} + (wide ? 12'd800 : 12'd640);   // just right of the view
    wire [10:0] x_left  = (xl_r >= WORLD_W) ? xl_r - WORLD_W : xl_r[10:0];
    wire [10:0] x_right = (xr_r >= WORLD_W) ? xr_r - WORLD_W : xr_r[10:0];
    wire [10:0] py_o = {1'b0, player_y} + 11'd128;

    genvar g;
    wire [N-1:0] touch_c;
    wire [10:0] tlx [0:N-1];
    wire [9:0]  tly [0:N-1];
    generate
        for (g = 0; g < N; g = g + 1) begin : g_lane
            // spread line for lane g (lane 0 = the player): step (g + 1) / 2, side by
            // parity (flipped at random for the whole volley), plus a small random part
            wire [15:0] r    = (rand << (g * 5)) | (rand >> (16 - g * 5));
            wire [2:0]  step = (g + 1) / 2;
            wire        plus = ((g % 2) == 1) ^ rand[2];
            wire [8:0]  ox   = step * 9'd110 + (r[4:0] % 5'd30);     // x: 110 / 220 + 0..29
            wire [8:0]  oy   = step * 9'd80  + (r[9:5] % 5'd24);     // y:  80 / 160 + 0..23
            wire [11:0] rx_p = {1'b0, player_cx} + ox;
            wire [11:0] rx_m = {1'b0, player_cx} + WORLD_W - ox;
            wire [11:0] rx   = plus ? rx_p : rx_m;
            wire [10:0] rxw  = (rx >= WORLD_W) ? ((rx >= 2 * WORLD_W) ? rx - 2 * WORLD_W : rx - WORLD_W) : rx[10:0];
            wire [10:0] ry_s = plus ? {1'b0, player_cy} + oy : {1'b0, player_cy} - oy;
            wire [9:0]  ryc  = (ry_s[10] || ry_s < 11'd20) ? 10'd20 :
                               (ry_s > WORLD_H - 20) ? WORLD_H - 20 : ry_s[9:0];
            assign tlx[g] = (g == 0) ? player_cx : rxw;
            assign tly[g] = (g == 0) ? player_cy : ryc;

            // shaft box: horizontal 88 x 7 at y + 8, vertical 7 x 88 at x + 8
            wire [11:0] bx_r = {1'b0, hx[g]} + (vert[g] ? 12'd8 : 12'd0);
            wire [10:0] bx   = (bx_r >= WORLD_W) ? bx_r - WORLD_W : bx_r[10:0];
            wire [10:0] by_o = hy[g] + (vert[g] ? 11'd0 : 11'd8);   // still + 128
            wire        tc;
            aabb_collision #(.SCREEN_W(WORLD_W), .CW(11)) u_c (
                .ax(bx), .ay(by_o), .aw(vert[g] ? 8'd7 : 8'd88), .ah(vert[g] ? 8'd88 : 8'd7),
                .bx(player_x), .by(py_o), .bw(player_w), .bh(player_h),
                .hit(tc)
            );
            assign touch_c[g] = tc & lane_on[g];

            assign line_x_vec[11*g +: 11] = lx[g];
            assign line_y_vec[10*g +: 10] = ly[g];
            assign hx_vec[11*g +: 11]     = hx[g];
            assign hy_vec[11*g +: 11]     = hy[g];
        end
    endgenerate

    integer k;
    always @(posedge clk) begin
        hurt <= 1'b0;
        if (rst) begin
            st <= S_IDLE; t <= 10'd300; anim <= 4'd0; dist <= 11'd0; spd <= SPEED0;
            homing <= 1'b0; aim_x <= 11'd0; aim_y <= 10'd0;
            lane_on <= {N{1'b0}}; vert <= {N{1'b0}}; back <= {N{1'b0}}; done_hit <= {N{1'b0}};
            for (k = 0; k < N; k = k + 1) begin
                lx[k] <= 11'd0; ly[k] <= 10'd0; hx[k] <= 11'd0; hy[k] <= 11'd0;
            end
        end else if (clear) begin
            if (st != S_IDLE) t <= base_t;                      // (no second divider)
            st <= S_IDLE; lane_on <= {N{1'b0}}; homing <= 1'b0;
        end else begin
            if (st == S_FIRE)
                for (k = N - 1; k >= 0; k = k - 1)
                    if (touch_c[k] && !done_hit[k]) begin
                        hurt        <= 1'b1;
                        done_hit[k] <= 1'b1;
                        hit_cx      <= vert[k] ? lx[k] : player_cx;
                        hit_cy      <= vert[k] ? player_cy : ly[k];
                    end
            if (tick_60hz) begin
                anim <= anim + 4'd1;
                case (st)
                    S_IDLE: if (!pause) begin
                        if (t == 10'd0) begin
                            st     <= S_WARN;
                            t      <= WARN_TICKS;
                            homing <= (rand[15:9] < home_p);
                            aim_x  <= player_cx;
                            aim_y  <= player_cy;
                            for (k = 0; k < N; k = k + 1) begin
                                lane_on[k] <= (k < volley);
                                vert[k]    <= rand[(k * 3) % 16];
                                back[k]    <= rand[(k * 3 + 1) % 16];
                                lx[k]      <= tlx[k];
                                ly[k]      <= tly[k];
                            end
                        end else t <= t - 10'd1;
                    end
                    S_WARN: if (t == 10'd0) begin
                        st <= S_FIRE; dist <= 11'd0; spd <= SPEED0; done_hit <= {N{1'b0}};
                        for (k = 0; k < N; k = k + 1) begin
                            if (!vert[k]) begin
                                hx[k] <= back[k] ? x_right : x_left;
                                hy[k] <= {1'b0, ly[k]} + 11'd117;          // line - 11, + 128
                            end else begin
                                hx[k] <= (lx[k] >= 11'd11) ? lx[k] - 11'd11 : lx[k] + WORLD_W - 11'd11;
                                hy[k] <= back[k] ? {1'b0, cam_y} + (wide ? 11'd728 : 11'd608)  // cam_y + 480 / 600, + 128
                                                 : {1'b0, cam_y} + 11'd40;  // cam_y - 88,  + 128
                            end
                        end
                    end else begin
                        t <= t - 10'd1;
                        // homing: harpoon 0 keeps following the player until it locks
                        if (homing && t > LOCK_TICKS) begin
                            lx[0] <= player_cx; ly[0] <= player_cy;
                            aim_x <= player_cx; aim_y <= player_cy;
                        end
                    end
                    S_FIRE: begin
                        dist <= dist + spd;
                        if (spd < SPEED_MAX) spd <= spd + 5'd1;
                        for (k = 0; k < N; k = k + 1) begin
                            if (!vert[k]) begin
                                if (back[k]) hx[k] <= (hx[k] >= spd) ? hx[k] - spd : hx[k] + WORLD_W - spd;
                                else         hx[k] <= (hx[k] + spd >= WORLD_W) ? hx[k] + spd - WORLD_W : hx[k] + spd;
                            end else begin
                                hy[k] <= back[k] ? hy[k] - spd : hy[k] + spd;
                            end
                        end
                        if (dist >= (wide ? 11'd940 : 11'd760)) begin
                            st      <= S_IDLE;
                            lane_on <= {N{1'b0}};
                            homing  <= 1'b0;
                            t       <= base_t + {1'b0, rand[9:0] % span_t};
                        end
                    end
                    default: st <= S_IDLE;
                endcase
            end
        end
    end
endmodule
