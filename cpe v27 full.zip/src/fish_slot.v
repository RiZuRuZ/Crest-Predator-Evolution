`timescale 1ns / 1ps
//==============================================================================
// fish_slot - ONE fish on screen: state, movement, eat / hurt detection
//
// Several slots (a "pool") share the screen; a spawn allocator loads a new
// fish into a free slot (active = 0) by pulsing `load`.
//
// Rules (work plan, "Score system" and "Form 1..4" pages):
//   - player form 1 eats small only, form 2 small+medium, form 3 small,
//     medium and large, form 4 everything
//   - golden fish (fish_type 3) can be eaten by every form
//   - touching a fish the player CANNOT eat costs one heart (`hurt`)
//
//   can_eat = (fish_type == 3) || (fish_type < form)       form is 1..4
//
// Outputs are one-cycle pulses:
//   eat   fish eaten -> score_ctrl.eat (fish_type_o goes to score_ctrl.fish_type)
//         The slot deactivates on the same clock edge, so the pulse is exactly
//         one cycle long and the fish disappears. Used alone, tie eat_allow
//         to 1; fish_pool drives it to serialize simultaneous eats.
//   hurt  player first touches a fish it cannot eat. The fish stays on
//         screen; hurt fires again only after contact was lost and restored.
//         (A longer invulnerability time after a hit, if wanted, belongs to
//         the heart / shield logic, not here.)
//
// Movement (world coordinates, camera update): on each tick the fish moves
// FISH_SPEED pixels, dir = 0 right, dir = 1 left, wrapping around the world.
// The fish is removed when it is far outside the camera view: its position
// relative to the camera, (fish_x - cam_x) mod WORLD_W, is past
// VIEW_W + MARGIN on the right or more than MARGIN + MAXW on the left.
//
// Coordinates follow conventions.md: top-left corner, x 11 bits (world), y 10 bits.
//
// Sizes (fish-sprites.md): W*/H* = sprite size (art faces right). Collision uses
// only the head + body box HX*/HY*/HW*/HH* inside the sprite (no tail fin). A fish
// swimming left (dir = 1) is drawn mirrored, so its box is mirrored too:
//   box x = fish_x + (dir ? W - HX - HW : HX),   box y = fish_y + HY
// The player box (player_x/y/w/h) is the dragon's head + body box from player_geom.
//
// PLACEHOLDER (not decided by the team yet): FISH_SPEED.
//==============================================================================
module fish_slot #(
    parameter WORLD_W    = 1920,
    parameter VIEW_W     = 640,
    parameter MARGIN     = 64,                // off-screen distance before removal
    parameter MAXW       = 93,                // widest fish
    parameter FISH_SPEED = 2,                 // pixels per tick_60hz (placeholder)
    // sprite sizes (fish-sprites.md)
    parameter W0 = 31, H0 = 27,               // type 0 small
    parameter W1 = 52, H1 = 42,               // type 1 medium
    parameter W2 = 93, H2 = 52,               // type 2 large
    parameter W3 = 44, H3 = 35,               // type 3 golden
    // head + body hitbox inside the sprite, art facing right (fish-sprites.md)
    parameter HX0 = 7,  HY0 = 3, HW0 = 23, HH0 = 21,
    parameter HX1 = 12, HY1 = 4, HW1 = 40, HH1 = 34,
    parameter HX2 = 19, HY2 = 7, HW2 = 72, HH2 = 39,
    parameter HX3 = 11, HY3 = 3, HW3 = 32, HH3 = 29,
    parameter NEAR = 24,                      // `near` reach around the player hitbox
    // v14 fleeing: school fish and the golden fish swim away from the player
    parameter WORLD_H    = 640,
    parameter SLOT_ID    = 0,                 // slot number: spreads a school when it scatters
    parameter SCARE_X    = 110,               // player centre closer than this (x and y) ...
    parameter SCARE_Y    = 80,                // ... starts a panic
    parameter PANIC_TICKS = 50,               // flee fast this long (PLACEHOLDER)
    parameter CALM_TICKS  = 40,               // then swim normally this long: the chance to catch it
    parameter FLEE_SPEED  = 3                 // pixels per tick while panicking (form 1 player: 4)
) (
    input  wire        clk,            // CLK100MHZ
    input  wire        rst,            // active-high, synchronous
    input  wire        tick_60hz,      // 1-cycle pulse, 60 per second

    // load a new fish (only when active = 0); from fish_spawner via allocator
    input  wire        load,
    input  wire [1:0]  load_type,
    input  wire [10:0] load_x,
    input  wire [9:0]  load_y,
    input  wire        load_dir,       // 0 = swim right, 1 = swim left
    input  wire        load_school,    // part of a school: scatters when the player comes close

    // player hitbox (head + body, top-left corner, from player_geom)
    input  wire [10:0] player_x,
    input  wire [9:0]  player_y,
    input  wire [7:0]  player_w,
    input  wire [7:0]  player_h,
    input  wire [2:0]  form,           // 1..4
    input  wire [10:0] cam_x,          // camera x (screen left edge in the world)
    input  wire        clear,          // the giant shark sweeps every fish away
    input  wire        roar,           // EVO3 Tidal Roar pulse
    input  wire [10:0] roar_cx,        // player centre at the roar
    input  wire [9:0]  roar_cy,

    // fish state for renderers
    output reg         active,
    output reg  [1:0]  fish_type_o,
    output reg  [10:0] fish_x,
    output reg  [9:0]  fish_y,
    output reg         fish_dir,

    // one-cycle event pulses
    output wire        eat_req,        // wants to be eaten now (before arbitration)
    input  wire        eat_allow,      // pool grants this slot the eat (1 = single slot)
    output wire        eat,
    output wire        hurt,
    output wire        near            // an edible fish is within NEAR px (open the mouth)
);

    // ---- size of the current fish ------------------------------------------
    reg [7:0] fw, hx, hy, hw, hh;
    always @* begin
        case (fish_type_o)
            2'd0:    begin fw = W0; hx = HX0; hy = HY0; hw = HW0; hh = HH0; end
            2'd1:    begin fw = W1; hx = HX1; hy = HY1; hw = HW1; hh = HH1; end
            2'd2:    begin fw = W2; hx = HX2; hy = HY2; hw = HW2; hh = HH2; end
            default: begin fw = W3; hx = HX3; hy = HY3; hw = HW3; hh = HH3; end
        endcase
    end
    // hitbox position in the world (mirrored when swimming left)
    wire [7:0]  hx_eff = fish_dir ? (fw - hx - hw) : hx;
    wire [11:0] bx_raw = {1'b0, fish_x} + hx_eff;
    wire [10:0] box_x  = (bx_raw >= WORLD_W) ? bx_raw - WORLD_W : bx_raw[10:0];
    wire [9:0]  box_y  = fish_y + hy;

    // ---- collision (combinational) + one register stage for timing ----------
    wire hit_c;
    aabb_collision #(.SCREEN_W(WORLD_W), .CW(11)) u_hit (
        .ax(box_x),    .ay({1'b0, box_y}),    .aw(hw),       .ah(hh),
        .bx(player_x), .by({1'b0, player_y}), .bw(player_w), .bh(player_h),
        .hit(hit_c)
    );

    // Near box: the player hitbox grown by NEAR on every side (x wraps, y stops at 0).
    // Only used for the animation: the dragon opens its mouth before the fish arrives.
    wire [11:0] nx_raw = {1'b0, player_x} + WORLD_W - NEAR;
    wire [10:0] near_x = (nx_raw >= WORLD_W) ? nx_raw - WORLD_W : nx_raw[10:0];
    wire [9:0]  near_y = (player_y >= NEAR) ? player_y - NEAR : 10'd0;
    wire near_c;
    aabb_collision #(.SCREEN_W(WORLD_W), .CW(11)) u_near (
        .ax(box_x),  .ay({1'b0, box_y}),  .aw(hw), .ah(hh),
        .bx(near_x), .by({1'b0, near_y}), .bw(player_w + 2*NEAR), .bh(player_h + 2*NEAR),
        .hit(near_c)
    );
    reg near_r;
    always @(posedge clk) begin
        if (rst) near_r <= 1'b0;
        else     near_r <= near_c & active;
    end

    // Gating with `active` matters: right after a fish is eaten the slot may be
    // reloaded at once, and without the gate the stale hit of the OLD fish
    // would be seen as a hit of the NEW one for one cycle.
    reg hit_r;
    always @(posedge clk) begin
        if (rst) hit_r <= 1'b0;
        else     hit_r <= hit_c & active;
    end

    // ---- eat / hurt decision -----------------------------------------------
    wire can_eat = (fish_type_o == 2'd3) || ({1'b0, fish_type_o} < form);

    // If two fish are eatable in the same cycle, the pool lets only one eat
    // per cycle (score_ctrl takes one eat pulse per clock); the other keeps
    // `active` and is eaten one cycle later, so no points are lost.
    assign eat_req = active & hit_r & can_eat;
    assign eat     = eat_req & eat_allow;

    reg touching_d;                    // contact with an uneatable fish, last cycle
    always @(posedge clk) begin
        if (rst) touching_d <= 1'b0;
        else     touching_d <= active & hit_r & ~can_eat;
    end
    // Tidal Roar: a fish within ROAR_R of the player stops for ROAR_TICKS and cannot bite
    reg  [7:0]  stun_t;
    wire [10:0] fcx   = fish_x + {3'd0, fw[7:1]};
    wire [10:0] ddx_a = (fcx >= roar_cx) ? fcx - roar_cx : roar_cx - fcx;
    wire [10:0] ddx   = (ddx_a > WORLD_W / 2) ? WORLD_W - ddx_a : ddx_a;
    wire [9:0]  fcy   = fish_y + 10'd20;
    wire [9:0]  ddy   = (fcy >= roar_cy) ? fcy - roar_cy : roar_cy - fcy;
    wire        in_roar = (ddx < 11'd240) && (ddy < 10'd240);    // v19: 160 -> 240
    wire        stunned = (stun_t != 8'd0);

    assign hurt = active & hit_r & ~can_eat & ~touching_d & ~stunned;
    assign near = near_r & active & can_eat;

    // ---- fleeing (v14) ----------------------------------------------------------
    // A school fish or the golden fish panics when the player centre comes within
    // SCARE_X / SCARE_Y of its centre: for PANIC_TICKS it turns away from the player and
    // swims FLEE_SPEED px per tick, moving 1..2 px per tick away vertically as well.
    // Then it calms down for CALM_TICKS (normal speed, keeps the new direction) before
    // it can panic again, so a fast player still catches it.
    reg         school;
    wire        scary = school | (fish_type_o == 2'd3);
    // centres, x wrapped into the world
    wire [11:0] fcx_r = {1'b0, fish_x} + fw[7:1];
    wire [10:0] fcx_m = (fcx_r >= WORLD_W) ? fcx_r - WORLD_W : fcx_r[10:0];
    wire [11:0] pcx_r = {1'b0, player_x} + player_w[7:1];
    wire [10:0] pcx_m = (pcx_r >= WORLD_W) ? pcx_r - WORLD_W : pcx_r[10:0];
    wire [11:0] sx_r  = {1'b0, fcx_m} + WORLD_W - pcx_m;                    // 0 .. 2W-1
    wire [11:0] sx_m  = (sx_r >= WORLD_W) ? sx_r - WORLD_W : sx_r;          // 0 .. W-1
    wire        f_right = (sx_m < WORLD_W / 2);                             // fish right of the player
    wire [11:0] sdx   = f_right ? sx_m : WORLD_W - sx_m;
    wire [9:0]  fcy_c = fish_y + {2'd0, hh[7:1]} + {2'd0, hy};
    wire [9:0]  pcy_c = player_y + player_h[7:1];
    wire        f_below = (fcy_c >= pcy_c);
    wire [9:0]  sdy   = f_below ? fcy_c - pcy_c : pcy_c - fcy_c;
    reg         scared_r, right_r, below_r, ytie_r;
    always @(posedge clk) begin
        scared_r <= active & scary & (sdx < SCARE_X) & (sdy < SCARE_Y);
        right_r  <= f_right;
        below_r  <= f_below;
        ytie_r   <= (sdy < 10'd6);
    end
    localparam [1:0] SID = SLOT_ID % 4;
    reg  [6:0]  panic_t, calm_t;
    wire        panic = (panic_t != 7'd0);
    // vertical escape: away from the player; if level with him, by slot number
    wire        go_down = ytie_r ? SID[0] : below_r;
    wire [1:0]  vy      = SID[1] ? 2'd2 : 2'd1;
    reg  [7:0]  fh;
    always @* begin
        case (fish_type_o)
            2'd0:    fh = H0;
            2'd1:    fh = H1;
            2'd2:    fh = H2;
            default: fh = H3;
        endcase
    end
    wire [9:0]  y_max = WORLD_H - fh;
    wire [9:0]  y_dn  = (fish_y + vy > y_max) ? y_max : fish_y + vy;
    wire [9:0]  y_up  = (fish_y > vy) ? fish_y - vy : 10'd0;
    wire [3:0]  spd   = panic ? FLEE_SPEED : FISH_SPEED;

    // ---- state and movement ------------------------------------------------
    wire [11:0] x_r     = {1'b0, fish_x} + spd;                              // moving right
    wire [11:0] x_r_m   = (x_r >= WORLD_W) ? x_r - WORLD_W : x_r;
    wire [11:0] x_l_m   = (fish_x >= spd) ? fish_x - spd
                                          : {1'b0, fish_x} + WORLD_W - spd;
    wire [11:0] rel_raw = {1'b0, fish_x} + WORLD_W - cam_x;                  // position on screen
    wire [11:0] rel     = (rel_raw >= WORLD_W) ? rel_raw - WORLD_W : rel_raw;
    wire        far     = (rel >= VIEW_W + MARGIN) && (rel < WORLD_W - MARGIN - MAXW);

    always @(posedge clk) begin
        if (rst) begin
            active      <= 1'b0;
            fish_type_o <= 2'd0;
            fish_x      <= 11'd0;
            fish_y      <= 10'd0;
            fish_dir    <= 1'b0;
            school      <= 1'b0;
        end else if (clear) begin
            active      <= 1'b0;                                 // swept by the shark
        end else if (load && !active) begin
            active      <= 1'b1;
            fish_type_o <= load_type;
            fish_x      <= load_x;
            fish_y      <= load_y;
            fish_dir    <= load_dir;
            school      <= load_school;
        end else if (eat) begin
            active <= 1'b0;                                      // eaten
        end else if (active && tick_60hz) begin
            if (far)            active <= 1'b0;                  // left the camera view
            else if (stunned)   ;                                // stopped by Tidal Roar
            else begin
                if (!fish_dir) fish_x <= x_r_m[10:0];            // swim right
                else           fish_x <= x_l_m[10:0];            // swim left
                if (panic) begin
                    fish_dir <= ~right_r;                        // away from the player
                    fish_y   <= go_down ? y_dn : y_up;
                end
            end
        end
    end

    always @(posedge clk) begin
        if (rst || !active) begin
            panic_t <= 7'd0;
            calm_t  <= 7'd0;
        end else if (tick_60hz) begin
            if (panic) begin
                panic_t <= panic_t - 7'd1;
                if (panic_t == 7'd1) calm_t <= CALM_TICKS;
            end else if (calm_t != 7'd0)
                calm_t <= calm_t - 7'd1;
            else if (scared_r && !stunned)
                panic_t <= PANIC_TICKS;
        end
    end

    always @(posedge clk) begin
        if (rst || !active)              stun_t <= 8'd0;
        else if (roar && in_roar)        stun_t <= 8'd180;       // 3 s (PLACEHOLDER)
        else if (tick_60hz && stunned)   stun_t <= stun_t - 8'd1;
    end

endmodule
