// ev_hud: words of the mini game events (v20, screen coordinates)
//
//   BANNER  "EVENT!" (big) + the game: DODGE THE SPEARS / HIT THE ARROWS / STOP IN THE GREEN
//   GAME    spear: three hearts = hits left; timing: PRESS IN THE GREEN
//           (the arrow words come from boss_hud)
//   RESULT  v21: PERFECT! / GREAT! (+ "+1 HEART  SPEED UP") / GOOD, or FAILED (red) +
//           "DARKNESS 20 S"
// Alignment like boss_hud: text gets the coordinates 1 clock late (font lookup 2 clocks),
// so everything is ready at clock 3.
module ev_hud (
    input  wire        clk,
    input  wire        show,
    input  wire [1:0]  phase,        // 1 banner, 2 game, 3 result
    input  wire [1:0]  kind,         // 0 spear, 1 arrow, 2 timing
    input  wire        ok,
    input  wire [2:0]  rating,       // v21: 0 FAIL, 2 GOOD, 3 GREAT, 4 PERFECT
    input  wire [1:0]  hits,
    input  wire        blink,
    input  wire [9:0]  pixel_x,
    input  wire [9:0]  pixel_y,
    output wire        on,
    output wire [11:0] rgb
);
    reg [9:0] tx_x, tx_y;
    always @(posedge clk) begin tx_x <= pixel_x; tx_y <= pixel_y; end

    wire w_ev, w_k0, w_k1, w_k2, w_clr, w_fail, w_dark, w_tim, w_life, w_perf, w_great, w_rew;
    text_line #(.X0(224), .Y0(130), .S(2), .N(6),  .TEXT("EVENT!")) u_ev (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_ev));
    text_line #(.X0(192), .Y0(190), .S(1), .N(16), .TEXT("DODGE THE SPEARS")) u_k0 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_k0));
    text_line #(.X0(208), .Y0(190), .S(1), .N(14), .TEXT("HIT THE ARROWS")) u_k1 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_k1));
    text_line #(.X0(184), .Y0(190), .S(1), .N(17), .TEXT("STOP IN THE GREEN")) u_k2 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_k2));
    text_line #(.X0(256), .Y0(130), .S(2), .N(4),  .TEXT("GOOD")) u_clr (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_clr));
    text_line #(.X0(176), .Y0(130), .S(2), .N(8),  .TEXT("PERFECT!")) u_perf (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_perf));
    text_line #(.X0(208), .Y0(130), .S(2), .N(6),  .TEXT("GREAT!")) u_great (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_great));
    text_line #(.X0(184), .Y0(190), .S(1), .N(17), .TEXT("+1 HEART SPEED UP")) u_rew (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_rew));
    text_line #(.X0(224), .Y0(130), .S(2), .N(6),  .TEXT("FAILED")) u_fail (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_fail));
    text_line #(.X0(216), .Y0(190), .S(1), .N(13), .TEXT("DARKNESS 20 S")) u_dark (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_dark));
    text_line #(.X0(176), .Y0(170), .S(1), .N(18), .TEXT("PRESS IN THE GREEN")) u_tim (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_tim));
    // spear: hearts left (8'h03 = heart) above the box
    reg [23:0] life_txt;
    always @(posedge clk)
        life_txt <= {(hits < 2'd3) ? 8'h03 : 8'h20, (hits < 2'd2) ? 8'h03 : 8'h20,
                     (hits < 2'd1) ? 8'h03 : 8'h20};
    text_dyn #(.X0(296), .Y0(116), .S(1), .N(3)) u_life (
        .clk(clk), .chars(life_txt), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_life));

    wire ban  = (phase == 2'd1);
    wire game = (phase == 2'd2);
    wire res  = (phase == 2'd3);
    wire s_ev   = ban && w_ev && blink;
    wire s_kind = ban && (((kind == 2'd0) && w_k0) || ((kind == 2'd1) && w_k1) || ((kind == 2'd2) && w_k2));
    wire s_tim  = game && (kind == 2'd2) && w_tim;
    wire s_life = game && (kind == 2'd0) && w_life;
    wire s_clr  = res && ok && (((rating == 3'd4) && w_perf) || ((rating == 3'd3) && w_great) ||
                                ((rating <= 3'd2) && w_clr));
    wire s_rew  = res && ok && (rating >= 3'd3) && w_rew;
    wire s_fail = res && !ok && (w_fail || w_dark);

    assign on  = show && (s_ev | s_kind | s_tim | s_life | s_clr | s_fail | s_rew);
    assign rgb = s_ev   ? 12'hFD4 :
                 s_life ? 12'hF55 :
                 s_rew  ? 12'hF9C :
                 s_clr  ? ((rating == 3'd4) ? 12'hFD3 : (rating == 3'd3) ? 12'h9EF : 12'h7F7) :
                 s_fail ? 12'hF55 : 12'hFFF;
endmodule
