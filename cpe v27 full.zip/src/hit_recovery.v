// hit_recovery: invulnerability window, blinking and knockback after a hit
// hit          : 1-cycle pulse (player_health.hit_taken)
// player_x/y   : top-left corner of the player hitbox, player_w/h: its size
// hit_cx/cy    : center of the thing that hit the player (fish_pool.hurt_cx/cy),
//                must already hold the value when hit arrives
// invuln       : high for INVULN_TICKS ticks after a hit
// blink_hide   : toggles every BLINK_TICKS ticks while invuln; AND it out of player_on
// knock_dx/dy  : push away from the hitter's center, KNOCK_SPEED px/tick on each axis
//                for KNOCK_TICKS ticks (add to dx/dy before player_bounds)
// The x distance is measured the short way around the world (the map wraps around).
// If the centers match on an axis there is no push on that axis.
// All timing parameters are placeholders until the team decides the real values.
module hit_recovery #(
    parameter WORLD_W      = 1920,
    parameter INVULN_TICKS = 90,   // 1.5 s at 60 Hz
    parameter BLINK_TICKS  = 4,
    parameter KNOCK_TICKS  = 8,
    parameter KNOCK_SPEED  = 3
)(
    input  wire              clk,
    input  wire              rst,
    input  wire              tick_60hz,
    input  wire              hit,
    input  wire [10:0]       player_x,
    input  wire [9:0]        player_y,
    input  wire [7:0]        player_w,
    input  wire [7:0]        player_h,
    input  wire [10:0]       hit_cx,
    input  wire [9:0]        hit_cy,
    output wire              invuln,
    output wire              blink_hide,
    output reg  signed [6:0] knock_dx,
    output reg  signed [6:0] knock_dy
);
    // ---- direction from the hitter to the player ----------------------------
    wire [11:0] pcx = {1'b0, player_x} + {5'd0, player_w[7:1]};
    wire [10:0] pcy = {1'b0, player_y} + {4'd0, player_h[7:1]};

    reg signed [12:0] ddx, ddy;
    always @* begin
        ddx = $signed({1'b0, pcx}) - $signed({2'b00, hit_cx});
        if (ddx > WORLD_W / 2)         ddx = ddx - WORLD_W;
        else if (ddx < -(WORLD_W / 2)) ddx = ddx + WORLD_W;
        ddy = $signed({2'b00, pcy}) - $signed({3'b000, hit_cy});
    end

    // ---- timers -------------------------------------------------------------
    reg [7:0] inv_cnt;
    reg [7:0] knock_cnt;
    reg [3:0] blink_cnt;
    reg       blink_r;
    reg       kx_pos, kx_neg, ky_pos, ky_neg;

    always @(posedge clk) begin
        if (rst) begin
            inv_cnt   <= 8'd0;
            knock_cnt <= 8'd0;
            blink_cnt <= 4'd0;
            blink_r   <= 1'b0;
            kx_pos <= 1'b0; kx_neg <= 1'b0;
            ky_pos <= 1'b0; ky_neg <= 1'b0;
        end else if (hit) begin
            inv_cnt   <= INVULN_TICKS;
            knock_cnt <= KNOCK_TICKS;
            blink_cnt <= 4'd0;
            blink_r   <= 1'b1;
            kx_pos <= (ddx > 0);           // player is right of the hitter -> push right
            kx_neg <= (ddx < 0);
            ky_pos <= (ddy > 0);           // player is below the hitter -> push down
            ky_neg <= (ddy < 0);
        end else if (tick_60hz) begin
            if (knock_cnt != 8'd0) knock_cnt <= knock_cnt - 8'd1;
            if (inv_cnt != 8'd0) begin
                inv_cnt <= inv_cnt - 8'd1;
                if (blink_cnt == BLINK_TICKS - 1) begin
                    blink_cnt <= 4'd0;
                    blink_r   <= ~blink_r;
                end else begin
                    blink_cnt <= blink_cnt + 4'd1;
                end
            end
        end
    end

    assign invuln     = (inv_cnt != 8'd0);
    assign blink_hide = invuln & blink_r;

    wire knock_on = (knock_cnt != 8'd0);
    always @* begin
        knock_dx = 7'sd0;
        knock_dy = 7'sd0;
        if (knock_on && kx_pos) knock_dx = KNOCK_SPEED;
        if (knock_on && kx_neg) knock_dx = -KNOCK_SPEED;
        if (knock_on && ky_pos) knock_dy = KNOCK_SPEED;
        if (knock_on && ky_neg) knock_dy = -KNOCK_SPEED;
    end
endmodule
