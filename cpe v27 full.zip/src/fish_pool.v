`timescale 1ns / 1ps
//==============================================================================
// fish_pool - N fish slots, spawn timer and slot allocator
//
// Data flow (all wiring is done in top.v):
//
//   fish_pool.spawn_req --> fish_spawner.spawn_tick
//   fish_spawner.{spawn_valid, fish_type, spawn_x, spawn_y, spawn_dir}
//                       --> fish_pool.spawn_*
//   fish_pool.eat / eat_type --> score_ctrl.eat / score_ctrl.fish_type
//   fish_pool.hurt           --> heart logic (lose one heart)
//   fish_pool.*_vec          --> fish renderer(s) (one entry per slot)
//
// Spawn timer
//   Counts tick_60hz; every SPAWN_TICKS ticks (60 = 1 s) it raises spawn_req
//   for one cycle, but only if at least one slot is free. When the screen is
//   full the spawn is skipped, not queued. Because the timer counts
//   tick_60hz, it stops automatically when the game logic stops that tick
//   (pause, title, game over).
//
// Allocator
//   A spawn_valid pulse loads the new fish into the lowest-numbered free slot.
//   A spawn_valid pulse with no free slot is ignored (cannot happen with the
//   spawn_req gating above).
//
// Schools (v14)
//   When a small fish (type 0) spawns and school_rnd[1:0] == 0 (1 in 4), it leads a
//   school: 3..5 more small fish (school_rnd[3:2] % 3 + 3) are loaded behind it on the
//   next clocks, one per clock into the lowest free slot, in this formation
//   (dx behind the leader, dy):  (34,-28) (34,+28) (68,0) (68,-56) (68,+56).
//   All of them are marked `school`: they scatter when the player comes close
//   (fish_slot). The burst stops early when no slot is free.
//
// Eat / hurt
//   eat       one-cycle pulse, at most one per clock (simultaneous eats are
//             serialized, lower slot index first, nothing is lost)
//   eat_type  type of the fish eaten, valid while eat = 1
//   hurt      one-cycle pulse when any slot reports contact with a fish the
//             player cannot eat. If two slots report it in the same cycle
//             only one pulse is produced (one heart).
//   hurt_cx/cy center of the fish that caused the last hurt (lowest slot index
//             if several). Registered on the hurt pulse and held until the
//             next one, so hit_recovery can push the player away from it.
//
// Flattened per-slot outputs (slot i occupies bits [i*width +: width]):
//   active_vec[i], type_vec[2i+:2], x_vec[11i+:11], y_vec[10i+:10], dir_vec[i]
//
// World coordinates (camera update): x is 11 bits and wraps at WORLD_W. cam_x is
// passed to every slot, which removes its fish once it is far outside the view.
//
// PLACEHOLDERS: N, SPAWN_TICKS and FISH_SPEED are not decided by the team yet.
// Fish sizes are the sprite sizes; keep them identical to fish_spawner.
//==============================================================================
module fish_pool #(
    parameter N           = 4,
    parameter SPAWN_TICKS = 60,        // spawn attempt every 60 ticks = 1 s
    parameter WORLD_W     = 1920,
    parameter VIEW_W      = 640,
    parameter MARGIN      = 64,
    parameter MAXW        = 93,
    parameter FISH_SPEED  = 2,
    parameter W0 = 31, H0 = 27,        // sprite sizes (fish-sprites.md)
    parameter W1 = 52, H1 = 42,
    parameter W2 = 93, H2 = 52,
    parameter W3 = 44, H3 = 35,
    parameter WORLD_H     = 640
) (
    input  wire          clk,            // CLK100MHZ
    input  wire          rst,            // active-high, synchronous
    input  wire          tick_60hz,

    // spawn handshake with fish_spawner
    output reg           spawn_req,      // -> fish_spawner.spawn_tick
    input  wire          spawn_valid,    // from fish_spawner
    input  wire [1:0]    spawn_type,
    input  wire [10:0]   spawn_x,
    input  wire [9:0]    spawn_y,
    input  wire          spawn_dir,
    input  wire [3:0]    school_rnd,     // random bits: school or not, school size

    // player
    input  wire [10:0]   player_x,
    input  wire [9:0]    player_y,
    input  wire [7:0]    player_w,       // player hitbox (head + body) from player_geom
    input  wire [7:0]    player_h,
    input  wire [2:0]    form,           // 1..4
    input  wire [10:0]   cam_x,
    input  wire          clear,          // shark sweep: remove every fish
    input  wire          roar,           // EVO3 Tidal Roar pulse
    input  wire [10:0]   roar_cx,
    input  wire [9:0]    roar_cy,          // camera x

    // events
    output wire          eat,
    output wire [1:0]    eat_type,
    output wire          hurt,
    output wire          near,           // some edible fish is close (mouth animation)
    output reg  [10:0]   hurt_cx,
    output reg  [9:0]    hurt_cy,

    // per-slot state for the renderers
    output wire [N-1:0]    active_vec,
    output wire [2*N-1:0]  type_vec,
    output wire [11*N-1:0] x_vec,
    output wire [10*N-1:0] y_vec,
    output wire [N-1:0]    dir_vec
);

    // school burst state (see "school burst" below)
    reg  [10:0] ld_x;                    // leader position and direction
    reg  [9:0]  ld_y;
    reg         ld_dir;
    reg  [2:0]  b_k;                     // next follower 1..5, 0 = idle
    reg  [2:0]  b_last;
    wire        burst = (b_k != 3'd0);

    // ---- spawn timer --------------------------------------------------------
    reg  [15:0] t;
    wire        any_free = ~(&active_vec) & (b_k == 3'd0);
    wire        fire     = tick_60hz && (t == SPAWN_TICKS - 1);

    always @(posedge clk) begin
        if (rst) begin
            t         <= 16'd0;
            spawn_req <= 1'b0;
        end else begin
            spawn_req <= fire & any_free;
            if (tick_60hz)
                t <= (t == SPAWN_TICKS - 1) ? 16'd0 : t + 16'd1;
        end
    end

    // ---- school burst ---------------------------------------------------------
    reg  [6:0]  ox;                      // formation offset of follower b_k
    reg  signed [6:0] oy;
    always @* begin
        case (b_k)
            3'd1:    begin ox = 7'd34; oy = -7'sd28; end
            3'd2:    begin ox = 7'd34; oy =  7'sd28; end
            3'd3:    begin ox = 7'd68; oy =  7'sd0;  end
            3'd4:    begin ox = 7'd68; oy = -7'sd56; end
            default: begin ox = 7'd68; oy =  7'sd56; end
        endcase
    end
    // behind the leader: to the left when it swims right, to the right when it swims left
    wire [12:0] fx_r  = ld_dir ? {2'b00, ld_x} + ox : {2'b00, ld_x} + WORLD_W - ox;
    wire [12:0] fx_m  = (fx_r >= WORLD_W) ? fx_r - WORLD_W : fx_r;
    wire signed [11:0] fy_s = $signed({2'b00, ld_y}) + oy;
    wire [9:0]  fy_m  = (fy_s < 0) ? 10'd0 :
                        (fy_s > WORLD_H - H0) ? WORLD_H - H0 : fy_s[9:0];
    wire        start_school = spawn_valid && (spawn_type == 2'd0) && (school_rnd[1:0] == 2'b00);

    // ---- slots --------------------------------------------------------------
    wire [N-1:0] free = ~active_vec;
    wire         ld_now   = spawn_valid | burst;
    wire [1:0]   ld_type  = burst ? 2'd0 : spawn_type;
    wire [10:0]  ld_xm    = burst ? fx_m[10:0] : spawn_x;
    wire [9:0]   ld_ym    = burst ? fy_m : spawn_y;
    wire         ld_dirm  = burst ? ld_dir : spawn_dir;
    wire         ld_sch   = burst | start_school;

    always @(posedge clk) begin
        if (rst || clear) begin
            b_k <= 3'd0; b_last <= 3'd0;
            ld_x <= 11'd0; ld_y <= 10'd0; ld_dir <= 1'b0;
        end else if (start_school) begin
            ld_x <= spawn_x; ld_y <= spawn_y; ld_dir <= spawn_dir;
            b_k    <= 3'd1;
            b_last <= 3'd3 + ((school_rnd[3:2] == 2'd3) ? 3'd0 : {1'b0, school_rnd[3:2]});
        end else if (burst) begin
            if (b_k == b_last || ~(|free)) b_k <= 3'd0;
            else                           b_k <= b_k + 3'd1;
        end
    end
    wire [N-1:0] eat_req_v;
    wire [N-1:0] eat_v;
    wire [N-1:0] hurt_v;
    wire [N-1:0] near_v;

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : g_slot
            wire [N-1:0] low_mask = (1 << i) - 1;              // slots below i
            wire         grant    = free[i] & ~(|(free & low_mask));      // lowest free slot
            wire         allow    = ~(|(eat_req_v & low_mask));           // no lower slot eats now

            fish_slot #(
                .WORLD_W(WORLD_W), .VIEW_W(VIEW_W), .MARGIN(MARGIN), .MAXW(MAXW),
                .FISH_SPEED(FISH_SPEED),
                .W0(W0), .H0(H0), .W1(W1), .H1(H1),
                .W2(W2), .H2(H2), .W3(W3), .H3(H3),
                .WORLD_H(WORLD_H), .SLOT_ID(i)
            ) u_slot (
                .clk(clk), .rst(rst), .tick_60hz(tick_60hz),
                .load(ld_now & grant),
                .load_type(ld_type), .load_x(ld_xm), .load_y(ld_ym),
                .load_dir(ld_dirm), .load_school(ld_sch),
                .player_x(player_x), .player_y(player_y),
                .player_w(player_w), .player_h(player_h), .form(form), .cam_x(cam_x),
                .clear(clear), .roar(roar), .roar_cx(roar_cx), .roar_cy(roar_cy),
                .active(active_vec[i]),
                .fish_type_o(type_vec[2*i +: 2]),
                .fish_x(x_vec[11*i +: 11]),
                .fish_y(y_vec[10*i +: 10]),
                .fish_dir(dir_vec[i]),
                .eat_req(eat_req_v[i]), .eat_allow(allow),
                .eat(eat_v[i]), .hurt(hurt_v[i]), .near(near_v[i])
            );
        end
    endgenerate

    // ---- merge events -------------------------------------------------------
    assign eat  = |eat_v;
    assign hurt = |hurt_v;
    assign near = |near_v;

    // at most one eat_v bit is set (arbitration above), so OR-ing is a mux
    reg [1:0] eat_type_c;
    integer k;
    always @* begin
        eat_type_c = 2'd0;
        for (k = 0; k < N; k = k + 1)
            if (eat_v[k]) eat_type_c = eat_type_c | type_vec[2*k +: 2];
    end
    assign eat_type = eat_type_c;

    // ---- center of the fish that hurt the player ----------------------------
    function [9:0] half_w(input [1:0] t);
        case (t)
            2'd0:    half_w = W0 / 2;
            2'd1:    half_w = W1 / 2;
            2'd2:    half_w = W2 / 2;
            default: half_w = W3 / 2;
        endcase
    endfunction
    function [9:0] half_h(input [1:0] t);
        case (t)
            2'd0:    half_h = H0 / 2;
            2'd1:    half_h = H1 / 2;
            2'd2:    half_h = H2 / 2;
            default: half_h = H3 / 2;
        endcase
    endfunction

    reg [11:0] hurt_cx_w;
    reg [10:0] hurt_cx_c;
    reg [9:0]  hurt_cy_c;
    integer m;
    always @* begin
        hurt_cx_w = 12'd0;
        hurt_cx_c = 11'd0;
        hurt_cy_c = 10'd0;
        for (m = N - 1; m >= 0; m = m - 1)        // lowest slot index is assigned last, so it wins
            if (hurt_v[m]) begin
                hurt_cx_w = x_vec[11*m +: 11] + half_w(type_vec[2*m +: 2]);
                hurt_cx_c = (hurt_cx_w >= WORLD_W) ? hurt_cx_w - WORLD_W : hurt_cx_w[10:0];
                hurt_cy_c = y_vec[10*m +: 10] + half_h(type_vec[2*m +: 2]);
            end
    end

    always @(posedge clk) begin
        if (rst) begin
            hurt_cx <= 11'd0;
            hurt_cy <= 10'd0;
        end else if (hurt) begin
            hurt_cx <= hurt_cx_c;
            hurt_cy <= hurt_cy_c;
        end
    end

endmodule
