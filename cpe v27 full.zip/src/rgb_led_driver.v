// rgb_led_driver: the two RGB LEDs (LED16, LED17), dimmed with PWM (full brightness is blinding)
// LED16: color of the current form   1 cyan, 2 green, 3 magenta, 4 yellow; white on TITLE
// LED17: warnings                    fast red blink while invulnerable after a hit,
//                                    slow red blink while oxygen is low,
//                                    steady green while hidden in seaweed, otherwise off
// Outputs are {R, G, B}, active high.
module rgb_led_driver #(
    parameter [7:0] DUTY = 8'd16,         // brightness: on for DUTY/256 of the time
    // blink bits of the free-running counter (defaults for 100 MHz; 21 / 23 at 25 MHz)
    parameter FAST_BIT = 23,
    parameter SLOW_BIT = 25
)(
    input  wire       clk,
    input  wire       rst,
    input  wire [2:0] form,
    input  wire       in_title,
    input  wire       invuln,
    input  wire       oxy_low,
    input  wire       hidden,
    input  wire       stunned,        // jellyfish stun: blue blink
    input  wire       fever,          // Fever time: yellow
    output wire [2:0] led16,
    output wire [2:0] led17
);
    reg [25:0] cnt;
    always @(posedge clk) begin
        if (rst) cnt <= 26'd0;
        else     cnt <= cnt + 26'd1;
    end
    wire dim_on     = (cnt[7:0] < DUTY);
    wire blink_fast = cnt[FAST_BIT];      // ~6 Hz
    wire blink_slow = cnt[SLOW_BIT];      // ~1.5 Hz

    reg [2:0] form_rgb;
    always @* begin
        if (in_title) form_rgb = 3'b111;
        else case (form)
            3'd1:    form_rgb = 3'b011;   // cyan
            3'd2:    form_rgb = 3'b010;   // green
            3'd3:    form_rgb = 3'b101;   // magenta
            3'd4:    form_rgb = 3'b110;   // yellow
            default: form_rgb = 3'b000;
        endcase
    end

    wire [2:0] warn_rgb = (stunned && blink_fast) ? 3'b001 :
                          stunned                 ? 3'b000 :
                          (invuln  && blink_fast) ? 3'b100 :
                          (fever && !invuln)      ? 3'b110 :
                          (!invuln && oxy_low && blink_slow) ? 3'b100 :
                          (!invuln && !oxy_low && hidden)     ? 3'b010 : 3'b000;

    assign led16 = dim_on ? form_rgb : 3'b000;
    assign led17 = dim_on ? warn_rgb : 3'b000;
endmodule
