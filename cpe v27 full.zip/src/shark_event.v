// shark_event: the giant shark passes now and then; hide in the seaweed to survive
//
// FSM: IDLE -> WARN -> PASS -> IDLE
//   IDLE  random 45..75 s in forms 1, 2 and 25..40 s in forms 3, 4 (difficulty)
//         (the first one after FIRST_TICKS)
//   WARN  WARN_TICKS (10 s): siren + "SHARK!" (warn level); get into the seaweed
//   PASS  the shark shadow crosses the screen (5 px per tick, screen coordinates).
//         At the start it sweeps away every fish, jellyfish and mine (`sweep` pulse).
//         When the shark centre crosses the screen centre (where the player is), the
//         player is safe if hidden: in the seaweed with the switch puzzle solved, or
//         Stealth (form 1). Otherwise `bite` (costs one heart).
// Switch puzzle (switch_puzzle): starts the first time the player is in the seaweed
// during WARN / PASS (`puzzle_start`), and stays until the event ends.
// The shadow is the shape of the v21 boss (shark_mask.mem, 118x57 bits from frame 0 of
// the boss art, made by tools/build_boss.py) scaled x4.5 = 530x256 (v22; v21 472x228,
// v20 large fish x5 465x260).
// v20 `clear` (the boss fight starts) ends a warning / pass at once: no SHARK! word,
//     siren or switch puzzle left over during the fight.
// PLACEHOLDERS: all timings, shadow size / height.
module shark_event #(
    parameter FIRST_TICKS = 1800,    // 30 s after the game starts
    parameter WARN_TICKS  = 600,     // 10 s (7 s in v10, back to 10 s in v12)
    parameter SPEED       = 5,
    parameter TOP         = 110      // screen y of the shadow top
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        tick_60hz,
    input  wire [15:0] rand,
    input  wire        clear,          // v20: 1-clk, back to IDLE
    input  wire        in_seaweed,
    input  wire        solved,
    input  wire        stealth,
    input  wire [2:0]  form,
    input  wire [1:0]  diff,           // v18: warning 15 / 10 / 8 s
    input  wire [9:0]  pixel_x,
    input  wire [9:0]  pixel_y,
    output wire        warn,
    output wire        pass,
    output wire        active,         // WARN or PASS
    output reg         sweep,          // 1-clk pulse
    output reg         bite,           // 1-clk pulse
    output reg         puzzle_start,   // 1-clk pulse
    output wire        shadow_on       // this pixel is inside the shadow
);
    localparam S_IDLE = 2'd0, S_WARN = 2'd1, S_PASS = 2'd2;
    localparam SW = 530, SH = 256;
    reg [1:0]         st;
    reg [12:0]        t;
    reg signed [11:0] sx;              // shadow left edge, screen x
    reg               to_right;        // 1 = swims to the right (not mirrored)
    reg               checked, started;

    assign warn   = (st == S_WARN);
    assign pass   = (st == S_PASS);
    assign active = warn | pass;

    wire signed [11:0] centre = sx + SW / 2;

    always @(posedge clk) begin
        sweep <= 1'b0; bite <= 1'b0; puzzle_start <= 1'b0;
        if (rst) begin
            st <= S_IDLE; t <= FIRST_TICKS; sx <= 12'sd640; to_right <= 1'b0;
            checked <= 1'b0; started <= 1'b0;
        end else if (clear) begin
            st <= S_IDLE; t <= 13'd2700; started <= 1'b0; checked <= 1'b0;
        end else begin
            if (active && in_seaweed && !started) begin
                started      <= 1'b1;
                puzzle_start <= 1'b1;
            end
            if (tick_60hz) begin
                case (st)
                    S_IDLE: if (t == 13'd0) begin
                        st <= S_WARN; t <= (diff == 2'd0) ? 13'd900 : (diff == 2'd2) ? 13'd480 : WARN_TICKS; started <= 1'b0; checked <= 1'b0;
                        to_right <= rand[0];
                    end else t <= t - 13'd1;
                    S_WARN: if (t == 13'd0) begin
                        st    <= S_PASS;
                        sweep <= 1'b1;
                        sx    <= to_right ? -12'sd530 : 12'sd640;
                    end else t <= t - 13'd1;
                    S_PASS: begin
                        sx <= to_right ? sx + SPEED : sx - SPEED;
                        if (!checked && (to_right ? (centre >= 12'sd320) : (centre <= 12'sd320))) begin
                            checked <= 1'b1;
                            if (!((in_seaweed && solved) || stealth)) bite <= 1'b1;
                        end
                        if (to_right ? (sx > 12'sd640) : (sx < -12'sd530)) begin
                            st <= S_IDLE;
                            t  <= (form >= 3'd3) ? 13'd1500 + {2'b0, rand[10:0] % 11'd900}
                                                 : 13'd2700 + {1'b0, rand[11:0] % 12'd1800};
                        end
                    end
                    default: st <= S_IDLE;
                endcase
            end
        end
    end

    // ---- shadow pixels: screen coordinates, mask scaled x4.5 (x 57 / 256 back) -------
    wire signed [11:0] rx = $signed({2'b00, pixel_x}) - sx;
    wire signed [11:0] ry = $signed({2'b00, pixel_y}) - TOP;
    wire in_box = pass && (rx >= 0) && (rx < SW) && (ry >= 0) && (ry < SH);
    wire [9:0]  rxm = to_right ? rx[9:0] : (SW - 1 - rx[9:0]);     // v22: 10 bits (530 wide)
    wire [15:0] mxm = rxm * 7'd57;
    wire [13:0] mym = ry[7:0] * 7'd57;
    wire [6:0]  mx  = mxm[14:8];                        // 0..117
    wire [5:0]  my  = mym[13:8];                        // 0..56
    reg  [12:0] bit_r;
    reg         box_r;
    always @(posedge clk) begin
        bit_r <= my * 13'd118 + mx;
        box_r <= in_box;
    end
    (* ram_style = "distributed" *) reg [7:0] mask [0:840];
    initial $readmemh("shark_mask.mem", mask);
    reg [7:0] byte_q;
    reg [2:0] sel_q;
    reg       box_q;
    always @(posedge clk) begin
        byte_q <= mask[bit_r[12:3]];
        sel_q  <= bit_r[2:0];
        box_q  <= box_r;
    end
    assign shadow_on = box_q & byte_q[sel_q];
endmodule
