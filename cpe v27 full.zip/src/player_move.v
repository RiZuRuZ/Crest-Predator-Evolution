// player_move: converts the 4 direction buttons + speed + water current into movement per tick
// The y axis grows downward (btn_d = +y, btn_u = -y)
module player_move (
    input  wire              btn_u,
    input  wire              btn_d,
    input  wire              btn_l,
    input  wire              btn_r,
    input  wire [3:0]        speed,        // pixels per tick
    input  wire signed [5:0] current_dx,   // from current_ctrl (tied to 0 for now)
    output wire signed [6:0] dx,
    output wire signed [6:0] dy
);
    wire signed [6:0] sp = {3'b000, speed};
    wire signed [6:0] zero = 7'sd0;

    assign dx = (btn_r ? sp : zero) - (btn_l ? sp : zero) + current_dx;
    assign dy = (btn_d ? sp : zero) - (btn_u ? sp : zero);
endmodule
