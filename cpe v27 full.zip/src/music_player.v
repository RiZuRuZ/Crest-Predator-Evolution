// music_player: v27 background music ("16-bit" style, original tunes in tools/music16)
// track: 0 off, 1 title, 2 play, 3 boss phase 1-2, 4 boss phase 3, 5 event / giant shark.
// run = 0 holds the song (pause) and is silent. A new track starts from its first step.
// Song data: music16.mem, one 36-bit word per 16th-note step (BRAM, 1344 words):
//   {drum[2:0], v3{new, note[6:0]}, v2{..}, v1{..}, v0{..}, 1'b0}, note = MIDI, 0 = rest.
// Voices (mus_voice): v0 lead, v1 bell / harmony, v2 arpeggio, v3 bass; mus_drum.
// Sample rate 25 MHz / 512 = 48828 Hz; each sample: clock 0 step, 1 envelope tick
// (every 256 samples), 2 sample, 3 mix, 4 counters. Same integer model as the PC port
// (cpe_pc/src/music16.js), so the PC game sounds the same.
// mus: the music level -100..100 for sfx_player (added to its PWM duty).
module music_player (
    input  wire              clk,
    input  wire              rst,
    input  wire [2:0]        track,
    input  wire              run,
    output reg  signed [7:0] mus
);
    localparam signed [5:0] MGAIN = 6'sd7;   // mix gain / 16 (PLACEHOLDER)

    reg  [8:0] c;                            // clock in the sample period (0..511)
    reg  [2:0] trk;
    reg        kill;
    reg  [8:0] step;
    reg  [12:0] ins;                         // samples into this step
    reg  [7:0] smpc;                         // sample count (envelope tick every 256)
    reg  [4:0] lfo_ph;

    // track table: first word, steps, samples per step (ms x 48.83), voice instruments
    reg [10:0] t_start; reg [8:0] t_len; reg [12:0] t_ssmp; reg [11:0] t_inst;
    always @* begin
        case (trk)
            3'd1:    begin t_start = 11'd0;    t_len = 9'd128; t_ssmp = 13'd5371; t_inst = {3'd3, 3'd5, 3'd2, 3'd0}; end
            3'd2:    begin t_start = 11'd128;  t_len = 9'd320; t_ssmp = 13'd4443; t_inst = {3'd3, 3'd5, 3'd2, 3'd0}; end
            3'd3:    begin t_start = 11'd448;  t_len = 9'd352; t_ssmp = 13'd4248; t_inst = {3'd4, 3'd5, 3'd2, 3'd1}; end
            3'd4:    begin t_start = 11'd800;  t_len = 9'd352; t_ssmp = 13'd3711; t_inst = {3'd4, 3'd5, 3'd2, 3'd0}; end
            default: begin t_start = 11'd1152; t_len = 9'd192; t_ssmp = 13'd4150; t_inst = {3'd3, 3'd5, 3'd2, 3'd0}; end
        endcase
    end

    // song ROM (block RAM, registered read)
    (* rom_style = "block" *) reg [35:0] mrom [0:1343];
    initial $readmemh("music16.mem", mrom);
    reg  [35:0] q;
    wire [10:0] addr = t_start + {2'b00, step};
    always @(posedge clk) q <= mrom[addr];

    wire on  = (trk != 3'd0) && run;
    wire stp = on && (c == 9'd0) && (ins == 13'd0);
    wire etk = on && (c == 9'd1) && (smpc == 8'd0);
    wire smp = on && (c == 9'd2);
    wire signed [5:0] lfo6 = (lfo_ph < 5'd16) ? $signed({1'b0, lfo_ph}) - 6'sd8    // triangle
                                              : 6'sd23 - $signed({1'b0, lfo_ph});  // -8..7
    wire signed [4:0] lfo  = lfo6[4:0];

    always @(posedge clk) begin
        kill <= 1'b0;
        if (rst) begin
            c <= 9'd0; trk <= 3'd0; step <= 9'd0; ins <= 13'd0; smpc <= 8'd0; lfo_ph <= 5'd0;
            kill <= 1'b1;
        end else begin
            c <= c + 9'd1;
            if (c == 9'd256 && track != trk) begin            // change track between samples
                trk <= track; kill <= 1'b1;
                step <= 9'd0; ins <= 13'd0; smpc <= 8'd0; lfo_ph <= 5'd0;
            end else if (on && c == 9'd4) begin
                smpc <= smpc + 8'd1;
                if (ins == t_ssmp - 13'd1) begin
                    ins  <= 13'd0;
                    step <= (step == t_len - 9'd1) ? 9'd0 : step + 9'd1;
                end else ins <= ins + 13'd1;
            end
            if (etk) lfo_ph <= lfo_ph + 5'd1;
        end
    end

    wire signed [7:0] o0, o1, o2, o3, od;
    mus_voice u_v0 (.clk(clk), .rst(rst), .kill(kill), .stp(stp), .s_note(q[7:1]),   .s_new(q[8]),
                    .etk(etk), .smp(smp), .inst(t_inst[2:0]),  .lfo(lfo), .out(o0));
    mus_voice u_v1 (.clk(clk), .rst(rst), .kill(kill), .stp(stp), .s_note(q[15:9]),  .s_new(q[16]),
                    .etk(etk), .smp(smp), .inst(t_inst[5:3]),  .lfo(lfo), .out(o1));
    mus_voice u_v2 (.clk(clk), .rst(rst), .kill(kill), .stp(stp), .s_note(q[23:17]), .s_new(q[24]),
                    .etk(etk), .smp(smp), .inst(t_inst[8:6]),  .lfo(lfo), .out(o2));
    mus_voice u_v3 (.clk(clk), .rst(rst), .kill(kill), .stp(stp), .s_note(q[31:25]), .s_new(q[32]),
                    .etk(etk), .smp(smp), .inst(t_inst[11:9]), .lfo(lfo), .out(o3));
    mus_drum  u_dr (.clk(clk), .rst(rst), .kill(kill), .stp(stp), .s_kind(q[35:33]),
                    .etk(etk), .smp(smp), .out(od));

    // mix (clock 3): (sum x MGAIN) / 16, clamped to +-100
    wire signed [10:0] sum = o0 + o1 + o2 + o3 + od;
    wire signed [16:0] mg  = sum * MGAIN;
    wire signed [12:0] m   = mg[16:4];
    always @(posedge clk) begin
        if (rst || !on)        mus <= 8'sd0;
        else if (c == 9'd3)    mus <= (m > 13'sd100) ? 8'sd100 : (m < -13'sd100) ? -8'sd100 : m[7:0];
    end
endmodule
