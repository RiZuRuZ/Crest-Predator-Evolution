// bg_rom: animated scrolling map background (1920 x 640 world, stored at half resolution)
// The ROM holds 960 x 320 palette indexes (rows back to back, address = y*960 + x),
// each shown as a 2x2 block, split into banks of 32768 entries (bg_pix0..8.mem, and
// bg_pix9.mem holds the last 12288)
// so Vivado needs no BRAM cascading (a single ROM failed DRC REQP-1962).
//
// Animation (no extra picture memory, anim_t counts frames):
//   - water surface  (world y < SURF_H): rows wave gently left/right, +-1 screen px
//   - seaweed/coral  (PLANT_Y0 <= y < PLANT_Y1): pixels whose color is a plant color
//                    (is_plant(), built from bg_plant.mem) sway slowly, +-2 screen px (one stored pixel), on a
//                    32-step sine whose phase shifts every 2 rows, so the plant bends
//                    instead of jumping as a block; each step moves at most 1 px
//   - debug_plant    (SW14 in top.v) paints every sway-able plant pixel magenta
//   - light          slanted light bands with soft sides drift slowly and brighten the water:
//                    +2 levels near the top (fading to +1 by LIGHT2_Y1), then +1 fading out
//                    between LIGHT_Y0 and LIGHT_Y1; both fades use a 4x4 ordered dither
// Offsets are in screen (world) pixels; the ROM is half resolution, so an odd offset
// shifts only every other column. anim_t is 10 bits; every wave uses a slice whose
// wrap lines up with its own period, so nothing jumps when the counter rolls over.
// Each bank is read on two ports: A = the normal pixel, B = the shifted pixel. B is used
// on the surface rows, and on plant rows when either A or B is a plant color, so the plant
// moves over its own surroundings.
//
// All .mem files are made by tools/gen_background.py and must be in Design Sources.
// Pipeline (3 clocks, the pixel changes every 4): address -> bank ROMs -> bank select ->
// palette register; the light boost is added after the last register.
module bg_rom #(
    parameter WORLD_W   = 1920,
    parameter WORLD_H   = 640,
    parameter SURF_H    = 96,
    parameter PLANT_Y0  = 200,
    parameter PLANT_Y1  = 566,
    parameter LIGHT2_Y0 = 48,              // the second (stronger) light level fades from here
    parameter LIGHT2_Y1 = 176,             // ... to here (128 rows)
    parameter LIGHT_Y0  = 160,             // light starts fading here
    parameter LIGHT_Y1  = 288,             // ... and is gone here (LIGHT_Y1 - LIGHT_Y0 = 128)
    parameter PAL_FILE  = "bg_palette.mem"
)(
    input  wire        clk,
    input  wire [10:0] world_x,         // world position of the pixel (camera, registered)
    input  wire [9:0]  world_y,
    input  wire [9:0]  anim_t,          // frame counter (changes once per frame)
    input  wire        debug_plant,     // 1 = paint the pixels that count as plant magenta
    output wire [11:0] rgb
);
    // ---- stage 0: world position, animation offsets, addresses ----------------
    // (the camera gives the world position, so the map follows the Fever zoom too;
    //  this adds one clock: the output is ready one clock later than the sprites)
    wire [11:0] wx_m = {1'b0, world_x};
    wire [10:0] wy   = {1'b0, world_y};
    wire        inside = (wy < WORLD_H);

    wire surf  = (wy < SURF_H);
    wire plant_rows = (wy >= PLANT_Y0) && (wy < PLANT_Y1);

    // offsets are unsigned 0..4 meaning -2..+2 screen px (2 = no shift)
    wire [3:0] ph_w = wy[6:3] + anim_t[6:3];             // surface: 16 steps, ~2 s period
    wire [4:0] ph_s = wy[5:1] + anim_t[7:3];             // plants: 32 steps, ~4 s period
    // surface: -1 / 0 / +1 only (the water looked right at this size)
    function [2:0] wave16(input [3:0] p);
        case (p)
            4'd2, 4'd3, 4'd4, 4'd5, 4'd6:      wave16 = 3'd3;   // +1
            4'd9, 4'd10, 4'd11, 4'd12, 4'd13:  wave16 = 3'd1;   // -1
            default:                           wave16 = 3'd2;   //  0 (0, 1, 7, 8, 14, 15)
        endcase
    endfunction
    // plants: 32-step rounded sine of amplitude 2, steps of at most 1 px
    //   0 0 1 1 1 2 2 2 2 2 2 2 1 1 1 0 | 0 0 -1 -1 -1 -2 -2 -2 -2 -2 -2 -2 -1 -1 -1 0
    function [2:0] wave32(input [4:0] p);
        begin
            if      (p < 5'd2)   wave32 = 3'd2;   //  0
            else if (p < 5'd5)   wave32 = 3'd3;   // +1
            else if (p < 5'd12)  wave32 = 3'd4;   // +2
            else if (p < 5'd15)  wave32 = 3'd3;   // +1
            else if (p < 5'd18)  wave32 = 3'd2;   //  0
            else if (p < 5'd21)  wave32 = 3'd1;   // -1
            else if (p < 5'd28)  wave32 = 3'd0;   // -2
            else if (p < 5'd31)  wave32 = 3'd1;   // -1
            else                 wave32 = 3'd2;   //  0
        end
    endfunction
    wire [2:0] off_u = surf ? wave16(ph_w) : (plant_rows ? wave32(ph_s) : 3'd2);

    wire [8:0]  sy     = wy[9:1];                        // stored y 0..319
    wire [9:0]  sx     = wx_m[10:1];                     // stored x 0..959
    // shifted world x = wx + off - 2 (off_u 0..4), wrapped, then halved
    wire [11:0] wxb_r  = wx_m + WORLD_W - 2 + off_u;
    wire [11:0] wxb    = (wxb_r >= WORLD_W) ? wxb_r - WORLD_W : wxb_r;
    wire [9:0]  sxb    = wxb[10:1];
    // rows are stored back to back, 960 entries each (no padding to 1024):
    // address = sy * 960 + sx, and sy * 960 = sy * 1024 - sy * 64 (shifts only)
    wire [18:0] row_base = {sy, 10'd0} - {4'd0, sy, 6'd0};
    wire [18:0] addr_a = inside ? row_base + sx  : 19'd0;   // blanking reads address 0
    wire [18:0] addr_b = inside ? row_base + sxb : 19'd0;

    // ---- stage 1: all banks read both addresses ------------------------------
    wire [7:0] qa [0:9];
    wire [7:0] qb [0:9];
    reg  [3:0] bank_r;
    reg        surf1, plant1;
    reg [10:0] wx1, wy1;
    always @(posedge clk) begin
        bank_r <= addr_a[18:15];
        surf1  <= surf & inside;
        plant1 <= plant_rows & inside;
        wx1    <= wx_m[10:0];
        wy1    <= wy;
    end

    bg_bank #(.FILE("bg_pix0.mem")) u_b0 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[0]), .qb(qb[0]));
    bg_bank #(.FILE("bg_pix1.mem")) u_b1 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[1]), .qb(qb[1]));
    bg_bank #(.FILE("bg_pix2.mem")) u_b2 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[2]), .qb(qb[2]));
    bg_bank #(.FILE("bg_pix3.mem")) u_b3 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[3]), .qb(qb[3]));
    bg_bank #(.FILE("bg_pix4.mem")) u_b4 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[4]), .qb(qb[4]));
    bg_bank #(.FILE("bg_pix5.mem")) u_b5 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[5]), .qb(qb[5]));
    bg_bank #(.FILE("bg_pix6.mem")) u_b6 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[6]), .qb(qb[6]));
    bg_bank #(.FILE("bg_pix7.mem")) u_b7 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[7]), .qb(qb[7]));
    bg_bank #(.FILE("bg_pix8.mem")) u_b8 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[8]), .qb(qb[8]));
    bg_bank #(.FILE("bg_pix9.mem"), .DEPTH(12288)) u_b9 (.clk(clk), .addr_a(addr_a[14:0]), .addr_b(addr_b[14:0]), .qa(qa[9]), .qb(qb[9]));

    // ---- stage 2: pick the bank, work out the light boost --------------------
    reg [7:0]  qa2, qb2;
    reg        surf2, plant2;
    reg [1:0]  boost2;
    // slanted bands (period 128) drifting 1 px every 4 frames; anim_t[8:2] runs 0..127,
    // exactly one band period, so the drift wraps without a jump
    // (the old anim_t[7:2] wrapped at 64 = half a period and the light jumped back)
    wire [11:0] l1 = {1'b0, wx1} + {2'b00, wy1[10:1]} + {5'd0, anim_t[8:2]};

    // band strength 0..16: triangle around position 96 of the 128 period, 64 px wide
    wire [6:0] pos   = l1[6:0];
    wire [6:0] dist  = (pos >= 7'd96) ? pos - 7'd96 : 7'd96 - pos;
    wire [4:0] band  = (dist >= 7'd32) ? 5'd0 : 5'd16 - dist[5:1];
    // depth fade 0..16 between LIGHT_Y0 and LIGHT_Y1
    wire [10:0] depth = (wy1 < LIGHT_Y0) ? 11'd0 : wy1 - LIGHT_Y0;
    wire [4:0]  fade  = (wy1 < LIGHT_Y0) ? 5'd16 :
                        (wy1 >= LIGHT_Y1) ? 5'd0 : 5'd16 - depth[7:3];
    wire [4:0]  level = (band < fade) ? band : fade;
    // 4x4 ordered dither: light the pixel when its threshold is below the level
    reg  [3:0] bayer;
    always @* begin
        case ({wy1[1:0], wx1[1:0]})
            4'h0: bayer = 4'd0;  4'h1: bayer = 4'd8;  4'h2: bayer = 4'd2;  4'h3: bayer = 4'd10;
            4'h4: bayer = 4'd12; 4'h5: bayer = 4'd4;  4'h6: bayer = 4'd14; 4'h7: bayer = 4'd6;
            4'h8: bayer = 4'd3;  4'h9: bayer = 4'd11; 4'hA: bayer = 4'd1;  4'hB: bayer = 4'd9;
            4'hC: bayer = 4'd15; 4'hD: bayer = 4'd7;  4'hE: bayer = 4'd13; default: bayer = 4'd5;
        endcase
    end
    wire c1 = ({1'b0, bayer} < level);
    // second, stronger level near the top
    wire [10:0] depth2 = (wy1 < LIGHT2_Y0) ? 11'd0 : wy1 - LIGHT2_Y0;
    wire [4:0]  fade2  = (wy1 < LIGHT2_Y0) ? 5'd16 :
                         (wy1 >= LIGHT2_Y1) ? 5'd0 : 5'd16 - depth2[7:3];
    wire [4:0]  level2 = (band < fade2) ? band : fade2;
    wire c2 = ({1'b0, bayer} < level2);
    always @(posedge clk) begin
        qa2    <= (bank_r <= 4'd9) ? qa[bank_r] : 8'd0;
        qb2    <= (bank_r <= 4'd9) ? qb[bank_r] : 8'd0;
        surf2  <= surf1;
        plant2 <= plant1;
        boost2 <= {1'b0, c1} + {1'b0, c2};
    end

    // ---- stage 3: choose normal / shifted pixel, palette ---------------------
    reg [11:0] pal   [0:255];
    initial $readmemh(PAL_FILE, pal);
    // palette indexes that are plant colors (from bg_plant.mem, made by
    // tools/plant_table_to_verilog.py; regenerate after a new map)
    function is_plant(input [7:0] c);
        case (c)
            8'd8, 8'd10, 8'd18, 8'd19, 8'd20, 8'd21, 8'd23, 8'd33, 8'd38, 8'd41,
            8'd42, 8'd43, 8'd44, 8'd45, 8'd48, 8'd49, 8'd51, 8'd52, 8'd53, 8'd54,
            8'd55, 8'd56, 8'd58, 8'd59, 8'd60, 8'd61, 8'd62, 8'd65, 8'd66, 8'd67,
            8'd68, 8'd79, 8'd97, 8'd108, 8'd109, 8'd116, 8'd127, 8'd132, 8'd133, 8'd140,
            8'd141, 8'd142, 8'd143, 8'd145, 8'd160, 8'd161, 8'd162, 8'd163, 8'd164, 8'd165,
            8'd168, 8'd220: is_plant = 1'b1;
            default: is_plant = 1'b0;
        endcase
    endfunction
    wire       use_b = surf2 | (plant2 & (is_plant(qa2) | is_plant(qb2)));
    wire [7:0] q_sel = use_b ? qb2 : qa2;
    // debug view: shows on the board which pixels the plant table marks as plant
    // (if nothing turns magenta, the plant table is wrong and the plants cannot sway)
    wire       dbg   = debug_plant & plant2 & is_plant(q_sel);
    reg [11:0] rgb3;
    reg [1:0]  boost3;
    always @(posedge clk) begin
        rgb3   <= dbg ? 12'hF0F : pal[q_sel];
        boost3 <= dbg ? 2'd0 : boost2;
    end

    // light boost with saturation (after the last register, before pixel_mixer samples)
    wire [4:0] r = rgb3[11:8] + boost3;
    wire [4:0] g = rgb3[7:4]  + boost3;
    wire [4:0] b = rgb3[3:0]  + boost3;
    assign rgb = {r[4] ? 4'hF : r[3:0], g[4] ? 4'hF : g[3:0], b[4] ? 4'hF : b[3:0]};
endmodule

// One bank of the background ROM (32768 x 8, the last one 12288 x 8), two read ports
// (true dual-port BRAM, no cascade: at most 32K entries per bank)
module bg_bank #(
    parameter FILE  = "bg_pix0.mem",
    parameter DEPTH = 32768
)(
    input  wire        clk,
    input  wire [14:0] addr_a,
    input  wire [14:0] addr_b,
    output reg  [7:0]  qa,
    output reg  [7:0]  qb
);
    (* ram_style = "block" *) reg [7:0] mem [0:DEPTH-1];
    initial $readmemh(FILE, mem);
    always @(posedge clk) begin
        qa <= mem[addr_a];
        qb <= mem[addr_b];
    end
endmodule
