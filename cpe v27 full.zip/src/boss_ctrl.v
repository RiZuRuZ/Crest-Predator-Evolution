// boss_ctrl: the boss fight (v15) - starts when the score reaches 500 EP
//
// Arena: the camera is frozen for the fight (top.v), so the boss works in ARENA
// coordinates = screen pixels of the frozen view (x 0..639, y 0..479). Positions are
// kept in 1/16 px. The boss is the large-fish sprite drawn 3x (279 x 156) by
// fish_renderer; (ax, ay) is its centre.
//
// HP 12 = 3 phases of 4:  phase 1 HP 12..9, phase 2 HP 8..5, phase 3 HP 4..1
//   bite while the boss is TIRED          -1 (once per tired round)
//   boss charges into a sea mine          -2 (and stays tired longer)
//   switch mini game solved (crash)       -1
//   arrow mini game (FINISH) at HP 1      -> 0 = defeated
// Damage stops at HP 1; only the arrow mini game takes the last point.
//
// States
//   INTRO    swims in from the right                     (top.v refills 5 hearts)
//   CIRCLE   swims around a point, then picks the next attack (table per phase)
//   WARN     blinks red and aims at the player (RGB LED red)
//   CHARGE   straight dash at the aim point; a wall -> TIRED (phase 2: a second
//            WARN + CHARGE first); a shout (mic_hit) when close = PERFECT ROAR -> TIRED
//   TIRED    stars, can be bitten once
//   BUBBLE   bubble fan from the mouth (5 or 7 bubbles), two volleys
//   LWARN    short warning, then LUNGE: fast bite at the player
//   GRAB     the player is held in the jaws: shake the board (shake_in) to get free,
//            not free after GRAB_TICKS = -1 heart
//   MINE     a sea mine appears; the boss circles, warns and charges: lure it into it
//   SW_EXIT .. SW_BACK  switch mini game (once, when HP <= 8): the boss leaves, the
//            switch puzzle starts (LEDs show the switches), then it sweeps across the
//            screen at the player's height. Solved = hidden (no damage) and the boss
//            crashes (-1); not solved = the sweep hurts.
//   SPEAR    spear mini game (once, phase 2 when HP <= 6): spear_game.v runs, then TIRED
//   ARROW    arrow mini game when HP = 1: arrow_game.v; success = defeated, else HP 3
//   DEAD     upside down, sinks; `won` goes high after DEAD_TICKS (game_fsm WIN)
//
// v22: new boss sprite (boss_sprite.v, 6 frames: swim 0..3, CHARGE 4, LUNGE 5) drawn
//      323 x 156, about the size of the v20 boss (279 x 156); all boxes and positions are
//      the v20 ones (arena 640 x 480, no zoom), only the eye moved to the new art.
// v23: PERFECT ROAR is easier to get: a shout (the start of a loud sound) counts for
//      SHOUT_T ticks (0.5 s), and it works in WARN, CHARGE, LWARN and LUNGE (v22: only
//      in the CHARGE tick of the shout itself, so it rarely worked). The sea mine: the boss sets it off
//      with its drawn size (+-160 x +-70, the v22 sprite is 323 wide); a new mine is not
//      put on the player and blinks ARM_T ticks before it can hurt the player.
// v26: the boss sets the sea mine off by its drawn shape (3 rows of the sprite row table),
//      not by a box.
// v25: PERFECT ROAR only while the boss charges / lunges (CHARGE, LUNGE); a shout while
//      it aims (WARN, LWARN) does nothing.
// Every timing / speed / size below is a PLACEHOLDER.
module boss_ctrl (
    input  wire        clk,
    input  wire        rst,
    input  wire        tick,            // game tick (60 Hz, only while playing)
    input  wire [15:0] rand,
    input  wire        start,           // 1-clk pulse: the fight begins
    input  wire [1:0]  diff,            // v18: easy charges -20 % / tired x1.3, hard +15 % / x0.8
    // player in arena coordinates
    input  wire [10:0] p_x,             // hitbox top-left
    input  wire [9:0]  p_y,
    input  wire [7:0]  p_w,
    input  wire [7:0]  p_h,
    input  wire [10:0] p_cx,            // sprite centre
    input  wire [9:0]  p_cy,
    input  wire        mic_hit,         // 1-clk pulse: a shout (PERFECT ROAR)
    input  wire        p_dodge,         // v17: the player dodges (form 4 dash): bubbles, mines
                                        //      and the bite pass through
    input  wire [5:0]  shake_in,        // shake amount of this tick (accelerometer + buttons)
    input  wire        sw_solved,       // switch_puzzle solved
    input  wire        spear_done,      // 1-clk pulses from the mini games
    input  wire        arrow_done,
    input  wire        arrow_ok,
    // boss
    output wire        lock,            // the fight is on (camera frozen, map paused)
    output wire        on,              // boss sprite visible
    output wire signed [11:0] ax,       // centre, arena px
    output wire signed [10:0] ay,
    output reg         dir,             // 1 = faces left
    output wire [2:0]  frame,           // v22: 0..3 swim, 4 CHARGE, 5 LUNGE (boss_sprite)
    output reg  [2:0]  pal,             // colour mode for boss_sprite
    output wire        flipy,
    output reg  [3:0]  hp,
    output wire [1:0]  phase,
    output wire        warn,            // WARN / LWARN
    output wire        tired,           // stars over the head
    output wire        intro,
    output wire        grab,            // the player is held
    output wire [10:0] grab_x,          // player centre while held (arena)
    output wire [9:0]  grab_y,
    output reg  [7:0]  grab_meter,      // 0 .. GRAB_NEED
    output wire        sw_active,       // switch mini game (puzzle running + sweep)
    output wire        sw_hidden,       // solved: the player is hidden
    output reg         sw_start,        // 1-clk pulses: start the mini games
    output reg         spear_start,
    output reg         arrow_start,
    output wire        spear_on,
    output wire        arrow_on,
    output wire        eye_on,          // phase 3: glowing eye (dark screen)
    output wire [10:0] eye_x,
    output wire [9:0]  eye_y,
    output reg         hurt,            // 1-clk: the player is hit
    output reg  [10:0] hit_cx,          // centre of what hit (arena)
    output reg  [9:0]  hit_cy,
    output reg         bite,            // 1-clk: the player bit the boss
    output reg         dmg,             // 1-clk: the boss lost HP
    output reg         boom,            // 1-clk: a mine exploded
    output reg         parry,           // 1-clk: PERFECT ROAR
    output reg         warn_start,      // 1-clk: a warning starts (alarm sound)
    output reg         wall,            // 1-clk: v17 the boss crashed into the arena edge
    output reg         won,             // stays 1 after the defeat animation
    // sea mine and explosion (centres, arena px)
    output reg         mine_on,
    output wire        mine_arm,        // v23: the new mine is not armed yet (blinks)
    output reg  [10:0] mine_x,
    output reg  [9:0]  mine_y,
    output wire        boom_on,
    output reg  [10:0] boom_x,
    output reg  [9:0]  boom_y,
    output wire [2:0]  boom_f,
    // bubbles (centres, arena px)
    output reg  [6:0]  bub_on,
    output wire [76:0] bub_x_vec,       // 7 x 11
    output wire [69:0] bub_y_vec        // 7 x 10
);
    // ---------------- parameters (PLACEHOLDERS) ----------------
    localparam HP_MAX      = 4'd12;
    localparam BHW = 139, BHH = 78;     // half sprite size (279 x 156)
    localparam X_MIN = 110, X_MAX = 530, Y_MIN = 80, Y_MAX = 400;   // walls for the centre
    localparam GRAB_NEED   = 8'd200;    // shake needed to get free
    localparam GRAB_TICKS  = 180;       // 3 s
    localparam SW_WAIT     = 300;       // 5 s to flip the switches
    localparam TIRED_MINE  = 180;
    localparam DEAD_TICKS  = 150;

    localparam [4:0] S_OFF = 0, S_INTRO = 1, S_CIRCLE = 2, S_WARN = 3, S_CHARGE = 4,
                     S_TIRED = 5, S_BUBBLE = 6, S_LWARN = 7, S_LUNGE = 8, S_GRAB = 9,
                     S_MINE = 10, S_SWEXIT = 11, S_SWWAIT = 12, S_SWEEP = 13, S_SWBACK = 14,
                     S_SPEAR = 15, S_ARROW = 16, S_DEAD = 17;
    reg [4:0] st;
    reg [9:0] t;                         // ticks in this state

    // ---------------- position (1/16 px) ----------------
    reg signed [15:0] bx, by;            // centre
    reg signed [15:0] vx, vy;            // charge / lunge velocity per tick
    assign ax = bx[15:4];
    assign ay = by[14:4];
    wire signed [12:0] axe = {ax[11], ax};
    wire signed [12:0] aye = {{2{ay[10]}}, ay};

    assign phase = (hp > 4'd8) ? 2'd1 : (hp > 4'd4) ? 2'd2 : 2'd3;
    assign lock  = (st != S_OFF);
    assign on    = (st != S_OFF);
    assign intro = (st == S_INTRO);
    assign warn  = (st == S_WARN) || (st == S_LWARN);
    assign tired = (st == S_TIRED) || (st == S_ARROW);
    assign grab  = (st == S_GRAB);
    assign flipy = (st == S_DEAD);
    assign sw_active = (st == S_SWEXIT) || (st == S_SWWAIT) || (st == S_SWEEP);
    assign sw_hidden = sw_active && sw_solved;
    assign spear_on  = (st == S_SPEAR);
    assign arrow_on  = (st == S_ARROW);

    // ---------------- per phase ----------------
    wire [3:0] chg_n    = (phase == 2'd1) ? 4'd8 : (phase == 2'd2) ? 4'd10 : 4'd11;
    // v18 difficulty: easy 6 / 8 / 9, hard 9 / 12 / 13 px per tick
    wire [3:0] chg_spd  = (diff == 2'd0) ? chg_n - {2'b00, chg_n[3:2]} :
                          (diff == 2'd2) ? chg_n + {3'b000, chg_n[3]} + {3'b000, chg_n[3] & chg_n[1]} : chg_n;
    wire [3:0] lunge_spd = (diff == 2'd0) ? 4'd7 : (diff == 2'd2) ? 4'd10 : 4'd9;
    // tired time x1.3 (easy) / x0.8 (hard)
    function [9:0] tscale_d(input [9:0] v, input [1:0] d);
        tscale_d = (d == 2'd0) ? v + {2'b00, v[9:2]} + {4'b0000, v[9:4]} :
                   (d == 2'd2) ? v - {2'b00, v[9:2]} + {4'b0000, v[9:4]} : v;
    endfunction
    wire [9:0] circ_t   = (phase == 2'd1) ? 10'd100 : (phase == 2'd2) ? 10'd60 : 10'd70;
    wire [9:0] warn_t   = (phase == 2'd1) ? 10'd60 : 10'd40;
    wire [9:0] tired_t  = tscale_d((phase == 2'd1) ? 10'd120 : (phase == 2'd2) ? 10'd110 : 10'd100, diff);
    wire [2:0] nbub     = (phase == 2'd1) ? 3'd5 : 3'd7;
    wire [2:0] bub_spd  = (phase == 2'd1) ? 3'd3 : 3'd4;

    // ---------------- helpers ----------------
    function [4:0] c8(input [3:0] r);
        case (r)
            4'd0: c8 = 5'd16; 4'd1: c8 = 5'd16; 4'd2: c8 = 5'd15; 4'd3: c8 = 5'd13;
            4'd4: c8 = 5'd11; 4'd5: c8 = 5'd9;  4'd6: c8 = 5'd6;  4'd7: c8 = 5'd3;
            default: c8 = 5'd0;
        endcase
    endfunction
    // cos(k * 11.25 deg) * 16 for k = 0..31 (y grows downwards)
    function signed [5:0] cos32(input [4:0] k);
        reg [4:0] c;
        reg [3:0] r;
        begin
            r = {1'b0, k[2:0]};
            case (k[4:3])
                2'd0: begin c = c8(r);          cos32 =  $signed({1'b0, c}); end
                2'd1: begin c = c8(4'd8 - r);   cos32 = -$signed({1'b0, c}); end
                2'd2: begin c = c8(r);          cos32 = -$signed({1'b0, c}); end
                default: begin c = c8(4'd8 - r); cos32 = $signed({1'b0, c}); end
            endcase
        end
    endfunction
    // direction 0..31 (11.25 deg steps) of the vector (dx, dy)
    function [4:0] dir32(input signed [12:0] dx, input signed [12:0] dy);
        reg [12:0] mx, mn, adx, ady;
        reg [2:0]  s;
        reg [3:0]  a;
        begin
            adx = dx[12] ? -dx : dx;
            ady = dy[12] ? -dy : dy;
            mx  = (adx >= ady) ? adx : ady;
            mn  = (adx >= ady) ? ady : adx;
            // tan 5.6 / 16.9 / 28.1 / 39.4 deg x 256 = 25 / 78 / 137 / 210
            s = ({mn, 8'd0} >= mx * 8'd210) ? 3'd4 :
                ({mn, 8'd0} >= mx * 8'd137) ? 3'd3 :
                ({mn, 8'd0} >= mx * 8'd78)  ? 3'd2 :
                ({mn, 8'd0} >= mx * 8'd25)  ? 3'd1 : 3'd0;
            a = (adx >= ady) ? {1'b0, s} : 4'd8 - {1'b0, s};     // 0..8 in the quadrant
            if (!dx[12] && !dy[12])     dir32 = {1'b0, a};
            else if (dx[12] && !dy[12]) dir32 = 5'd16 - {1'b0, a};
            else if (dx[12] && dy[12])  dir32 = 5'd16 + {1'b0, a};
            else                        dir32 = 5'd0 - {1'b0, a};
        end
    endfunction
    // step from cur towards tgt by at most s (all 1/16 px)
    function signed [15:0] towards(input signed [15:0] cur, input signed [15:0] tgt,
                                   input [11:0] s);
        reg signed [16:0] d;
        begin
            d = tgt - cur;
            if (d > $signed({5'd0, s}))       towards = cur + $signed({4'd0, s});
            else if (d < -$signed({5'd0, s})) towards = cur - $signed({4'd0, s});
            else                              towards = tgt;
        end
    endfunction

    // ---------------- boxes (arena px) ----------------
    wire signed [12:0] pl = {2'b00, p_x};
    wire signed [12:0] pr = {2'b00, p_x} + p_w;
    wire signed [12:0] pt = {3'b000, p_y};
    wire signed [12:0] pb = {3'b000, p_y} + p_h;
    // body (trimmed sprite box) and head (front third)
    wire body_hit = (pr > axe - 13'sd120) && (pl < axe + 13'sd120) &&
                    (pb > aye - 13'sd55)  && (pt < aye + 13'sd55);
    wire signed [12:0] hd_l = dir ? axe - 13'sd135 : axe + 13'sd50;
    wire head_hit = (pr > hd_l) && (pl < hd_l + 13'sd85) &&
                    (pb > aye - 13'sd45) && (pt < aye + 13'sd50);
    // player centre - boss centre
    wire signed [12:0] pdx = {2'b00, p_cx} - axe;
    wire signed [12:0] pdy = {3'b000, p_cy} - aye;
    wire [12:0] apdx = pdx[12] ? -pdx : pdx;
    wire [12:0] apdy = pdy[12] ? -pdy : pdy;
    wire        close = (apdx < 13'd280) && (apdy < 13'd280);     // v19: 230 -> 280

    assign grab_x = dir ? (ax - 12'sd150) : (ax + 12'sd150);
    assign grab_y = ay + 11'sd10;
    assign eye_on = (phase == 2'd3) && (st != S_DEAD) && (st != S_OFF);
    assign eye_x  = dir ? (ax - 12'sd101) : (ax + 12'sd101);   // v22 eye: art (96, 27) x 2.74
    assign eye_y  = ay - 11'sd4;

    // mine (43 x 44 sprite, box +-18 around its centre)
    wire signed [12:0] mxe = {2'b00, mine_x};
    wire signed [12:0] mye = {3'b000, mine_y};
    // v26: the boss sets the mine off by its drawn shape (mine_shape, below), not a box.
    //      v23 used a box of +-160 x +-70: a mine 70..95 px above / below the centre was
    //      drawn over the body but did not go off, and a mine at a box corner (the clear
    //      corners of the sprite) went off without touching. Simulated (PC port, 720 charges):
    //      box 160 x 70: 8 pass-throughs, 51 booms with no contact; shape: 0 and 4.
    wire mine_boss;
    localparam ARM_T = 45;              // v23: 0.75 s before a new mine can hurt the player
    reg [5:0] arm_t;
    assign mine_arm = (arm_t != 6'd0);
    wire mine_play = mine_on && !mine_arm && !p_dodge && (pr > mxe - 13'sd18) && (pl < mxe + 13'sd18) &&
                     (pb > mye - 13'sd18) && (pt < mye + 13'sd18);
    reg [5:0] boom_t;
    assign boom_on = (boom_t != 6'd0);
    assign boom_f  = (6'd36 - boom_t) / 6'd6;

    // ---------------- bubbles ----------------
    reg signed [15:0] bbx [0:6];
    reg signed [15:0] bby [0:6];
    reg [4:0]  bbd [0:6];
    reg [2:0]  bbs;                      // speed of the volley, px per tick
    wire [6:0] bub_hit;
    genvar gi;
    generate
        for (gi = 0; gi < 7; gi = gi + 1) begin : g_bub
            assign bub_x_vec[11*gi +: 11] = bbx[gi][14:4];
            assign bub_y_vec[10*gi +: 10] = bby[gi][13:4];
            wire signed [12:0] cx = {bbx[gi][15], bbx[gi][15:4]};
            wire signed [12:0] cy = {bby[gi][15], bby[gi][15:4]};
            assign bub_hit[gi] = bub_on[gi] && !p_dodge && (pr > cx - 13'sd9) && (pl < cx + 13'sd9) &&
                                    (pb > cy - 13'sd9) && (pt < cy + 13'sd9);
        end
    endgenerate

    // ---------------- attack plan ----------------
    localparam [1:0] A_CHARGE = 0, A_BUBBLE = 1, A_LUNGE = 2, A_MINE = 3;
    reg [2:0] step;
    reg [1:0] atk;
    always @* begin
        case (phase)
            2'd1: case (step)
                      3'd0: atk = A_CHARGE; 3'd1: atk = A_BUBBLE; 3'd2: atk = A_CHARGE;
                      3'd3: atk = A_LUNGE;  default: atk = A_MINE;
                  endcase
            2'd2: case (step[1:0])
                      2'd0: atk = A_CHARGE; 2'd1: atk = A_BUBBLE; 2'd2: atk = A_LUNGE;
                      default: atk = A_MINE;
                  endcase
            default: case (step[1:0])
                      2'd0: atk = A_CHARGE; 2'd1: atk = A_LUNGE; 2'd2: atk = A_MINE;
                      default: atk = A_BUBBLE;
                  endcase
        endcase
    end
    wire [2:0] step_n = (phase == 2'd1) ? ((step >= 3'd4) ? 3'd0 : step + 3'd1)
                                        : {1'b0, step[1:0] + 2'd1};

    // circle waypoints: 8 points around (cxc, 200), radius 110 x 60
    reg [2:0]  wp;
    reg [10:0] cxc;
    reg signed [8:0] wpx, wpy;
    always @* begin
        case (wp)
            3'd0: begin wpx =  9'sd110; wpy =  9'sd0;   end
            3'd1: begin wpx =  9'sd78;  wpy =  9'sd42;  end
            3'd2: begin wpx =  9'sd0;   wpy =  9'sd60;  end
            3'd3: begin wpx = -9'sd78;  wpy =  9'sd42;  end
            3'd4: begin wpx = -9'sd110; wpy =  9'sd0;   end
            3'd5: begin wpx = -9'sd78;  wpy = -9'sd42;  end
            3'd6: begin wpx =  9'sd0;   wpy = -9'sd60;  end
            default: begin wpx = 9'sd78; wpy = -9'sd42; end
        endcase
    end
    // v20: while the sea mine waits (MINE) the boss circles further away from the player's
    // side (centre 470 / 170) and half as wide (x radius 55), so the mine can sit nearer
    // the middle of the screen without the boss touching it while it circles
    wire        mcirc = (st == S_MINE);
    wire [10:0] cxe   = !mcirc ? cxc : (cxc == 11'd430) ? 11'd470 : 11'd170;
    wire signed [8:0] wpx_e = mcirc ? (wpx >>> 1) : wpx;
    wire signed [15:0] wtx = $signed({1'b0, cxe, 4'd0}) + $signed({wpx_e, 4'd0});
    wire signed [15:0] wty = $signed(16'd3200) + $signed({{3{wpy[8]}}, wpy, 4'd0});  // 200 px

    // ---------------- flags and counters ----------------
    reg        bitten, sw_done, sp_done, dbl, mine_mode, sw_ok, volley2;
    reg [9:0]  tired_len;
    reg [4:0]  flash_t;
    reg [5:0]  fr;
    reg signed [15:0] tx, ty;            // aim point (1/16 px)
    reg [4:0]  aim_d;
    assign frame = (st == S_TIRED || st == S_ARROW || st == S_DEAD) ? 3'd0 :
                   (st == S_WARN  || st == S_CHARGE)                 ? 3'd4 :
                   (st == S_LWARN || st == S_LUNGE || st == S_GRAB)  ? 3'd5 : {1'b0, fr[5:4]};

    // ---------------- v26 mine vs boss shape ----------------
    // The boss is drawn 323 x 156 from 118 x 57 source rows (boss_sprite.v, x / y * 94 >> 8).
    // A copy of the row table (boss_rows.mem, {off, x0, len} per source row) gives the drawn
    // part of 3 rows: the mine centre row and 16 px above / below. The mine (radius MR) goes
    // off when it overlaps one of them. One row per clock, a result every 3 clocks (the boss
    // moves once per tick, so the result is always up to date at the next tick).
    localparam MR = 16;
    (* ram_style = "distributed" *) reg [28:0] mrows [0:341];
    initial $readmemh("boss_rows.mem", mrows);
    reg  [1:0] ms_k;                                   // sample 0 / 1 / 2: -16 / 0 / +16
    reg        ms_acc, mine_shape;
    wire signed [12:0] ms_oy  = (ms_k == 2'd0) ? -13'sd16 : (ms_k == 2'd1) ? 13'sd0 : 13'sd16;
    wire signed [12:0] ms_ry  = mye + ms_oy - aye + 13'sd78;          // row in the drawn sprite
    wire               ms_in  = (ms_ry >= 13'sd0) && (ms_ry < 13'sd156);
    wire        [14:0] ms_sy0 = ms_ry[7:0] * 7'd94;
    wire         [5:0] ms_sy  = (ms_sy0[13:8] > 6'd56) ? 6'd56 : ms_sy0[13:8];   // source row
    wire         [8:0] ms_idx = frame * 6'd57 + {3'd0, ms_sy};
    wire        [28:0] ms_e   = mrows[ms_idx];
    wire         [6:0] ms_x0  = ms_e[13:7];
    wire         [6:0] ms_n   = ms_e[6:0];
    wire        [16:0] ms_l0  = ms_x0 * 10'd697;                      // x 256 / 94 = 2.723
    wire        [16:0] ms_r0  = ({1'b0, ms_x0} + {1'b0, ms_n}) * 10'd697;
    wire         [8:0] ms_dl  = ms_l0[16:8];                          // drawn columns dl..dr
    wire         [8:0] ms_dr  = ms_r0[16:8] - 9'd1;
    wire         [8:0] ms_L   = dir ? 9'd322 - ms_dr : ms_dl;         // mirrored when it swims left
    wire         [8:0] ms_R   = dir ? 9'd322 - ms_dl : ms_dr;
    wire signed [12:0] ms_al  = axe - 13'sd161 + $signed({4'd0, ms_L});
    wire signed [12:0] ms_ar  = axe - 13'sd161 + $signed({4'd0, ms_R});
    wire               ms_hit = ms_in && (ms_n != 7'd0) &&
                                (mxe + MR > ms_al) && (mxe - MR <= ms_ar);
    always @(posedge clk) begin
        if (rst) begin
            ms_k <= 2'd0; ms_acc <= 1'b0; mine_shape <= 1'b0;
        end else if (ms_k == 2'd2) begin
            mine_shape <= ms_acc | ms_hit; ms_acc <= 1'b0; ms_k <= 2'd0;
        end else begin
            ms_acc <= ms_acc | ms_hit; ms_k <= ms_k + 2'd1;
        end
    end
    assign mine_boss = mine_on && mine_shape;

    // the mini games and the microphone give 1-clk pulses at any time: keep them until
    // the next tick
    reg mic_l, spd_l, ard_l, ark_l;
    // v23: a shout counts for SHOUT_T ticks (so a shout a bit early still parries)
    // v25: a shout while the boss aims (WARN / LWARN) does not count and is not kept
    localparam SHOUT_T = 30;
    reg [5:0] shout_t;
    always @(posedge clk) begin
        if (rst) shout_t <= 6'd0;
        else if (st == S_WARN || st == S_LWARN) shout_t <= 6'd0;
        else if (mic_hit) shout_t <= SHOUT_T;
        else if (tick && shout_t != 6'd0) shout_t <= shout_t - 6'd1;
    end
    wire shout = (shout_t != 6'd0);
    always @(posedge clk) begin
        if (rst || tick) begin
            mic_l <= 1'b0; spd_l <= 1'b0; ard_l <= 1'b0; ark_l <= 1'b0;
        end
        if (!rst) begin
            if (mic_hit)    mic_l <= 1'b1;
            if (spear_done) spd_l <= 1'b1;
            if (arrow_done) begin ard_l <= 1'b1; ark_l <= arrow_ok; end
        end
    end

    function [3:0] hp_sub(input [3:0] h, input [3:0] n);
        hp_sub = (h > n + 4'd1) ? h - n : 4'd1;
    endfunction

    integer i;
    always @(posedge clk) begin
        hurt <= 1'b0; bite <= 1'b0; dmg <= 1'b0; boom <= 1'b0; parry <= 1'b0;
        sw_start <= 1'b0; spear_start <= 1'b0; arrow_start <= 1'b0; warn_start <= 1'b0;
        wall <= 1'b0;
        if (rst) begin
            st <= S_OFF; t <= 10'd0; hp <= HP_MAX; dir <= 1'b1; pal <= 3'd0;
            bx <= 16'sd0; by <= 16'sd0; vx <= 16'sd0; vy <= 16'sd0;
            step <= 3'd0; wp <= 3'd0; cxc <= 11'd430;
            bitten <= 1'b0; sw_done <= 1'b0; sp_done <= 1'b0; dbl <= 1'b0;
            mine_mode <= 1'b0; sw_ok <= 1'b0; volley2 <= 1'b0; won <= 1'b0;
            tired_len <= 10'd0; flash_t <= 5'd0; fr <= 6'd0; grab_meter <= 8'd0;
            tx <= 16'sd0; ty <= 16'sd0; aim_d <= 5'd0;
            mine_on <= 1'b0; mine_x <= 11'd0; mine_y <= 10'd0; arm_t <= 6'd0;
            boom_t <= 6'd0; boom_x <= 11'd0; boom_y <= 10'd0;
            bub_on <= 7'd0; bbs <= 3'd3;
            hit_cx <= 11'd0; hit_cy <= 10'd0;
            for (i = 0; i < 7; i = i + 1) begin bbx[i] <= 16'sd0; bby[i] <= 16'sd0; bbd[i] <= 5'd0; end
        end else if (start && st == S_OFF) begin
            st <= S_INTRO; t <= 10'd0;
            bx <= 16'sd15680; by <= 16'sd3040;          // 980, 190
            dir <= 1'b1; hp <= HP_MAX;
        end else if (tick && st != S_OFF) begin
            t  <= t + 10'd1;
            fr <= fr + 6'd1;
            if (flash_t != 5'd0) flash_t <= flash_t - 5'd1;
            if (boom_t != 6'd0)  boom_t  <= boom_t - 6'd1;
            if (arm_t != 6'd0)   arm_t   <= arm_t - 6'd1;          // v23 mine arming

            // palette: white flash > red warning blink > phase colour
            pal <= (flash_t != 5'd0 && flash_t[1]) ? 3'd4 :
                   (warn && t[2])                  ? 3'd1 :
                   (phase == 2'd1) ? 3'd0 : (phase == 2'd2) ? 3'd2 : 3'd3;

            // ---- bubbles move, hit the player, leave the arena ----
            for (i = 0; i < 7; i = i + 1) begin
                if (bub_on[i]) begin
                    bbx[i] <= bbx[i] + cos32(bbd[i]) * $signed({1'b0, bbs});
                    bby[i] <= bby[i] + cos32(bbd[i] - 5'd8) * $signed({1'b0, bbs});
                    if (bub_hit[i] ||
                        bbx[i] < 16'sd160 || bbx[i] > 16'sd10080 ||
                        bby[i] < 16'sd160 || bby[i] > 16'sd7520)
                        bub_on[i] <= 1'b0;
                end
            end
            if (|bub_hit) begin
                hurt <= 1'b1; hit_cx <= p_cx + 11'd20; hit_cy <= p_cy;
            end
            // no bubbles during the mini games
            if (st == S_SPEAR || st == S_ARROW || st == S_SWEXIT || st == S_GRAB) bub_on <= 7'd0;

            // ---- the player touches the mine ----
            if (mine_play) begin
                mine_on <= 1'b0; boom <= 1'b1; boom_t <= 6'd36;
                boom_x <= mine_x; boom_y <= mine_y;
                hurt <= 1'b1; hit_cx <= mine_x; hit_cy <= mine_y;
            end

            // ---- touching the boss body hurts (not while it is tired / hidden, and not in
            //      the first 0.5 s of CIRCLE: time to swim away after a bite / escape) ----
            if (body_hit && ((st == S_CIRCLE && t >= 10'd30) || st == S_MINE || st == S_WARN ||
                             st == S_CHARGE || st == S_BUBBLE || st == S_LWARN ||
                             (st == S_LUNGE && !head_hit) || (st == S_SWEEP && !sw_solved))) begin
                hurt <= 1'b1; hit_cx <= ax[10:0]; hit_cy <= ay[9:0];
            end

            case (st)
            // ------------------------------------------------------------------
            S_INTRO: begin
                dir <= 1'b1;
                bx  <= towards(bx, 16'sd7520, 12'd32);             // 470 px, 2 px/tick
                if (bx <= 16'sd7520) begin st <= S_CIRCLE; t <= 10'd0; end
            end
            // ------------------------------------------------------------------
            S_CIRCLE, S_MINE: begin
                if (t == 10'd0 && st == S_CIRCLE) cxc <= (p_cx < 11'd320) ? 11'd430 : 11'd210;
                bx <= towards(bx, wtx, 12'd40);                    // 2.5 px/tick
                by <= towards(by, wty, 12'd40);
                if ((bx - wtx < 16'sd64) && (wtx - bx < 16'sd64) &&
                    (by - wty < 16'sd64) && (wty - by < 16'sd64)) wp <= wp + 3'd1;
                if (wtx > bx + 16'sd16) dir <= 1'b0; else if (wtx < bx - 16'sd16) dir <= 1'b1;
                if (st == S_MINE) begin
                    if (t >= 10'd90) begin st <= S_WARN; t <= 10'd0; warn_start <= 1'b1; end
                end else if (t >= circ_t) begin
                    t <= 10'd0;
                    if (hp <= 4'd8 && !sw_done) begin
                        st <= S_SWEXIT; sw_start <= 1'b1; sw_ok <= 1'b0;
                    end else if (phase == 2'd2 && hp <= 4'd6 && !sp_done) begin
                        st <= S_SPEAR; spear_start <= 1'b1;
                    end else begin
                        step <= step_n;
                        dbl  <= (phase == 2'd2);
                        case (atk)
                            A_CHARGE: begin st <= S_WARN; warn_start <= 1'b1; mine_mode <= 1'b0; volley2 <= 1'b0; end
                            A_BUBBLE: begin st <= S_BUBBLE; volley2 <= 1'b0; end
                            A_LUNGE:  begin st <= S_LWARN; warn_start <= 1'b1; end
                            default:  begin
                                st <= S_MINE; mine_mode <= 1'b1; mine_on <= 1'b1; volley2 <= 1'b0;
                                // v20: on the player's side but nearer the middle (v19 was at the
                                // screen edge: x 60..187 / 452..579): x 150..220 or 420..490
                                mine_x <= (cxc == 11'd430) ? 11'd150 + {5'd0, rand[6:1]} + {8'd0, rand[3:1]}
                                                           : 11'd420 + {5'd0, rand[6:1]} + {8'd0, rand[3:1]};
                                // v23: never on the player: if the place is within 90 px of
                                // the player in y, the mine goes to the far end (170 or 297)
                                mine_y <= (((10'd170 + {3'd0, rand[14:8]}) + 10'd90 > p_cy) &&
                                           ((10'd170 + {3'd0, rand[14:8]}) < p_cy + 10'd90))
                                          ? ((p_cy > 10'd233) ? 10'd170 : 10'd297)
                                          : 10'd170 + {3'd0, rand[14:8]};          // 170 .. 297
                                arm_t  <= ARM_T;
                            end
                        endcase
                    end
                end
            end
            // ------------------------------------------------------------------
            S_WARN: begin
                tx <= {1'b0, p_cx, 4'd0};
                ty <= {2'b00, p_cy, 4'd0};
                dir <= pdx[12];                               // face the player
                if (t >= (volley2 ? 10'd35 : warn_t)) begin   // second charge: short warning
                    aim_d <= dir32(pdx, pdy);
                    st <= S_CHARGE; t <= 10'd0;
                end
            end
            S_CHARGE: begin
                if (t == 10'd0) begin
                    vx <= cos32(aim_d) * $signed({1'b0, chg_spd});
                    vy <= cos32(aim_d - 5'd8) * $signed({1'b0, chg_spd});
                    dir <= (aim_d > 5'd8 && aim_d < 5'd24);
                end else begin
                    bx <= bx + vx;
                    by <= by + vy;
                end
                // (the mine and the PERFECT ROAR are checked after this case)
                if (t > 10'd0 && (((ax < X_MIN) && vx[15]) || ((ax > X_MAX) && !vx[15]) ||
                                           ((ay < Y_MIN) && vy[15]) || ((ay > Y_MAX) && !vy[15]) ||
                                           t > 10'd90)) begin
                    t <= 10'd0; wall <= (t <= 10'd90);
                    if (dbl && !volley2) begin               // phase 2: second charge
                        volley2 <= 1'b1; st <= S_WARN; warn_start <= 1'b1;
                    end else begin
                        volley2 <= 1'b0; dbl <= 1'b0;
                        st <= S_TIRED; tired_len <= tired_t; bitten <= 1'b0;
                        if (mine_mode) mine_on <= 1'b0;      // missed the mine: it goes away
                    end
                end
            end
            // ------------------------------------------------------------------
            S_TIRED: begin
                if (!bitten && head_hit) begin
                    bitten <= 1'b1; bite <= 1'b1; dmg <= 1'b1; flash_t <= 5'd12;
                    hp <= hp_sub(hp, 4'd1);
                    if (hp_sub(hp, 4'd1) == 4'd1) begin
                        st <= S_ARROW; t <= 10'd0; arrow_start <= 1'b1;
                    end
                end else if (t >= tired_len) begin
                    st <= S_CIRCLE; t <= 10'd0;
                end
            end
            // ------------------------------------------------------------------
            S_BUBBLE: begin
                dir <= pdx[12];
                if (t == 10'd20) begin                     // fire the fan
                    aim_d <= dir32(pdx, pdy);
                end
                if (t == 10'd21) begin
                    bbs <= bub_spd;
                    for (i = 0; i < 7; i = i + 1) begin
                        bub_on[i] <= (i < nbub);
                        bbx[i]    <= dir ? bx - 16'sd1920 : bx + 16'sd1920;   // mouth: +-120 px
                        bby[i]    <= by + 16'sd192;
                        bbd[i]    <= aim_d + i[4:0] - ((nbub == 3'd7) ? 5'd3 : 5'd2);
                    end
                end
                if (t >= 10'd80) begin
                    if (!volley2) begin volley2 <= 1'b1; t <= 10'd0; end
                    else begin volley2 <= 1'b0; st <= S_CIRCLE; t <= 10'd0; end
                end
            end
            // ------------------------------------------------------------------
            S_LWARN: begin
                dir <= pdx[12];
                if (t >= 10'd35) begin
                    aim_d <= dir32(pdx, pdy); st <= S_LUNGE; t <= 10'd0;
                end
            end
            S_LUNGE: begin
                if (t == 10'd0) begin
                    vx <= cos32(aim_d) * $signed({1'b0, lunge_spd});
                    vy <= cos32(aim_d - 5'd8) * $signed({1'b0, lunge_spd});
                end else begin
                    bx <= bx + vx; by <= by + vy;
                end
                if (t > 10'd0 && head_hit && !p_dodge) begin
                    st <= S_GRAB; t <= 10'd0; grab_meter <= 8'd0;
                end else if (t > 10'd45 || (ax < X_MIN && vx[15]) || (ax > X_MAX && !vx[15]) ||
                             (ay < Y_MIN && vy[15]) || (ay > Y_MAX && !vy[15])) begin
                    wall <= (t <= 10'd45);
                    st <= S_TIRED; t <= 10'd0; tired_len <= tscale_d(10'd60, diff); bitten <= 1'b0;
                end
            end
            S_GRAB: begin
                grab_meter <= ({1'b0, grab_meter} + shake_in >= {1'b0, GRAB_NEED}) ? GRAB_NEED
                                                                                   : grab_meter + shake_in;
                if (grab_meter >= GRAB_NEED) begin
                    st <= S_CIRCLE; t <= 10'd0;                  // shaken free
                end else if (t >= GRAB_TICKS) begin
                    hurt <= 1'b1; hit_cx <= ax[10:0]; hit_cy <= ay[9:0];
                    st <= S_CIRCLE; t <= 10'd0;
                end
            end
            // ------------------------------------------------------------------
            S_SWEXIT: begin                                     // leave to the right
                dir <= 1'b0;
                bx  <= towards(bx, 16'sd15680, 12'd96);          // 980 px, 6 px/tick
                if (bx >= 16'sd15680) begin st <= S_SWWAIT; t <= 10'd0; end
            end
            S_SWWAIT: begin
                by <= {2'b00, ((p_cy < 10'd80) ? 10'd80 : (p_cy > 10'd400) ? 10'd400 : p_cy), 4'd0};
                if (t >= SW_WAIT) begin
                    st <= S_SWEEP; t <= 10'd0; dir <= 1'b1; warn_start <= 1'b1;
                end
            end
            S_SWEEP: begin
                bx <= bx - 16'sd208;                             // 13 px/tick
                if (t == 10'd1) sw_ok <= sw_solved;
                if (bx < -16'sd5120) begin                       // -320 px
                    st <= S_SWBACK; t <= 10'd0; sw_done <= 1'b1;
                    bx <= -16'sd5120; by <= 16'sd3680; dir <= 1'b0;   // y 230
                end
            end
            S_SWBACK: begin
                bx <= towards(bx, 16'sd2400, 12'd112);           // 150 px, 7 px/tick
                if (bx >= 16'sd2400) begin
                    t <= 10'd0;
                    if (sw_ok) begin                             // crashes into the rock
                        hp <= hp_sub(hp, 4'd1); dmg <= 1'b1; flash_t <= 5'd12;
                        st <= S_TIRED; tired_len <= 10'd60; bitten <= 1'b1;
                    end else
                        st <= S_CIRCLE;
                end
            end
            // ------------------------------------------------------------------
            S_SPEAR: begin
                dir <= 1'b1;
                bx  <= towards(bx, 16'sd8320, 12'd48);           // 520, 170
                by  <= towards(by, 16'sd2720, 12'd48);
                if (spd_l) begin
                    sp_done <= 1'b1; st <= S_TIRED; t <= 10'd0;
                    tired_len <= tscale_d(10'd120, diff); bitten <= 1'b0;
                end
            end
            S_ARROW: begin
                if (ard_l) begin
                    t <= 10'd0;
                    if (ark_l) begin
                        hp <= 4'd0; dmg <= 1'b1; flash_t <= 5'd20; st <= S_DEAD;
                    end else begin
                        hp <= 4'd3; st <= S_CIRCLE;              // the boss recovers 2
                    end
                end
            end
            S_DEAD: begin
                if (t[0]) by <= by + 16'sd16;                    // sinks 0.5 px/tick
                if (t >= DEAD_TICKS) won <= 1'b1;
            end
            default: st <= S_OFF;
            endcase

            // ---- PERFECT ROAR: a shout in the last SHOUT_T ticks while the boss charges /
            //      lunges and the player is close -> TIRED (v25: not while it aims) ----
            if (shout && close && (st == S_CHARGE || st == S_LUNGE)) begin
                parry <= 1'b1; st <= S_TIRED; t <= 10'd0; tired_len <= tired_t;
                bitten <= 1'b0; dbl <= 1'b0; volley2 <= 1'b0;
            end
            // ---- the boss runs into the sea mine with a CHARGE or a LUNGE: -2, long rest
            //      (v19: not while circling; after the case, so it wins over a state change
            //      in the same tick) ----
            if (mine_boss && (st == S_CHARGE || st == S_LUNGE)) begin
                mine_on <= 1'b0; boom <= 1'b1; boom_t <= 6'd36;
                boom_x <= mine_x; boom_y <= mine_y;
                hp <= hp_sub(hp, 4'd2); dmg <= 1'b1; flash_t <= 5'd12;
                st <= (hp_sub(hp, 4'd2) == 4'd1) ? S_ARROW : S_TIRED;
                arrow_start <= (hp_sub(hp, 4'd2) == 4'd1);
                t <= 10'd0; tired_len <= tscale_d(TIRED_MINE, diff); bitten <= 1'b0; dbl <= 1'b0; volley2 <= 1'b0;
            end
        end
    end
endmodule
