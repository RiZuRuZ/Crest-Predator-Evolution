// ps2_keys: turns PS/2 scan codes (set 2) into key-held levels
// W = 1D, A = 1C, S = 1B, D = 23, Space = 29
// F0 = the next code is a key release, E0 = the next code is an extended key (ignored,
// so for example the arrow keys never look like WASD).
module ps2_keys (
    input  wire       clk,
    input  wire       rst,
    input  wire [7:0] code,
    input  wire       valid,
    output reg        key_w,
    output reg        key_a,
    output reg        key_s,
    output reg        key_d,
    output reg        key_space
);
    reg brk, ext;

    always @(posedge clk) begin
        if (rst) begin
            brk <= 1'b0; ext <= 1'b0;
            key_w <= 1'b0; key_a <= 1'b0; key_s <= 1'b0; key_d <= 1'b0; key_space <= 1'b0;
        end else if (valid) begin
            if (code == 8'hF0) begin
                brk <= 1'b1;
            end else if (code == 8'hE0) begin
                ext <= 1'b1;
            end else begin
                if (!ext) begin
                    case (code)
                        8'h1D: key_w     <= ~brk;
                        8'h1C: key_a     <= ~brk;
                        8'h1B: key_s     <= ~brk;
                        8'h23: key_d     <= ~brk;
                        8'h29: key_space <= ~brk;
                        default: ;
                    endcase
                end
                brk <= 1'b0;
                ext <= 1'b0;
            end
        end
    end
endmodule
