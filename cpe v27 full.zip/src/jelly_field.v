// jelly_field: jellyfish that appear at random places and drift slowly
//
// N slots. A jellyfish appears in a free slot inside the camera view; higher forms get
// more and more often (difficulty): at most `form` jellyfish at once, one new every
//   form 1: 8 s   form 2: 6 s   form 3: 5 s   form 4: 4 s
// `pause` (giant shark event) stops new jellyfish.
// Like the mines, a jellyfish never appears inside the safe box around the player
// (safe_x / safe_y from top.v, growing with the dragon); a spot too close is retried on
// the next tick with a new random value.
// bobs up and down (1 px every 4 ticks, turning every 64 ticks) and drifts sideways
// (1 px every 4 ticks), and disappears after LIFE ticks or when the shark sweeps.
// Touching the player gives a `sting` pulse (no heart lost): the player is knocked back
// from the jellyfish centre (hit_cx / hit_cy) and stunned (stun_ctrl).
// Tidal Roar (`roar` pulse, form 3) stuns every jellyfish within ROAR_R of the player
// centre for ROAR_TICKS: it stops moving and cannot sting.
// Sprite 37x52, 4 frames (jellyfish.mem). Positions: x world, y world + 128.
// PLACEHOLDERS: N, SPAWN_TICKS, LIFE, drift speed, ROAR_R, ROAR_TICKS.
module jelly_field #(
    parameter N           = 4,
    parameter SPAWN_TICKS = 480,     // 8 s
    parameter LIFE        = 1200,    // 20 s
    parameter ROAR_R      = 160,
    parameter ROAR_TICKS  = 180,     // 3 s
    parameter WORLD_W     = 1920,
    parameter WORLD_H     = 640
)(
    input  wire            clk,
    input  wire            rst,
    input  wire            tick_60hz,
    input  wire [15:0]     rand,
    input  wire [10:0]     cam_x,
    input  wire [9:0]      cam_y,
    input  wire [10:0]     player_x,      // player hitbox
    input  wire [9:0]      player_y,
    input  wire [7:0]      player_w,
    input  wire [7:0]      player_h,
    input  wire [10:0]     player_cx,     // player centre (roar / spawn distance)
    input  wire [9:0]      player_cy,
    input  wire [8:0]      safe_x,        // no spawn this close to the player centre ...
    input  wire [8:0]      safe_y,        // ... on both axes
    input  wire            sweep,
    input  wire            pause,
    input  wire [2:0]      form,
    input  wire [1:0]      diff,           // v18 difficulty: 0 easy, 1 normal, 2 hard
    input  wire            roar,
    output reg             sting,         // 1-clk pulse
    output reg  [10:0]     hit_cx,
    output reg  [9:0]      hit_cy,
    output wire [N-1:0]    active_vec,
    output wire [11*N-1:0] x_vec,
    output wire [11*N-1:0] y_vec,
    output wire [3*N-1:0]  frame_vec
);
    reg        on   [0:N-1];
    reg [10:0] jx   [0:N-1];
    reg [9:0]  jy   [0:N-1];
    reg [10:0] life [0:N-1];
    reg [7:0]  stun [0:N-1];
    reg        dirx [0:N-1];
    reg [9:0]  spawn_t;
    reg [7:0]  anim;

    integer i;
    reg        have_free;
    reg [1:0]  free_k;
    always @* begin
        have_free = 1'b0; free_k = 2'd0;
        for (i = N - 1; i >= 0; i = i - 1)
            if (!on[i] && i < form) begin have_free = 1'b1; free_k = i[1:0]; end
    end
    wire [9:0] spawn_n = (form == 3'd4) ? 10'd240 : (form == 3'd3) ? 10'd300 :
                         (form == 3'd2) ? 10'd360 : 10'd480;
    // v18 difficulty: easy x1.5, hard x0.75
    wire [9:0] spawn_ticks = (diff == 2'd0) ? spawn_n + {1'b0, spawn_n[9:1]} :
                             (diff == 2'd2) ? spawn_n - {2'b00, spawn_n[9:2]} : spawn_n;

    wire [9:0]  rxv  = rand[9:0] % 10'd523;            // 640 - 37 - 80
    wire [8:0]  ryv  = rand[15:7] % 9'd348;            // 480 - 52 - 80
    wire [11:0] sx_r = {1'b0, cam_x} + 12'd40 + rxv;
    wire [10:0] sx_w = (sx_r >= WORLD_W) ? sx_r - WORLD_W : sx_r[10:0];
    wire [9:0]  sy_w = cam_y + 10'd40 + ryv;
    // distance from the player centre to the new jellyfish centre (18, 26)
    wire [11:0] ncx_r = {1'b0, sx_w} + 12'd18;
    wire [10:0] ncx   = (ncx_r >= WORLD_W) ? ncx_r - WORLD_W : ncx_r[10:0];
    wire [10:0] sdx_a = (ncx >= player_cx) ? ncx - player_cx : player_cx - ncx;
    wire [10:0] sdx   = (sdx_a > WORLD_W / 2) ? WORLD_W - sdx_a : sdx_a;
    wire [9:0]  ncy   = sy_w + 10'd26;
    wire [9:0]  sdy   = (ncy >= player_cy) ? ncy - player_cy : player_cy - ncy;
    wire        too_close = (sdx < {2'd0, safe_x}) && (sdy < {1'b0, safe_y});

    wire [N-1:0] touch_c;
    reg  [N-1:0] touch;
    wire [N-1:0] near_c;
    genvar g;
    generate
        for (g = 0; g < N; g = g + 1) begin : g_hit
            // body box (bell + upper tentacles): 6, 4, 25 x 36
            wire [11:0] hx_r = {1'b0, jx[g]} + 12'd6;
            wire [10:0] hx   = (hx_r >= WORLD_W) ? hx_r - WORLD_W : hx_r[10:0];
            aabb_collision #(.SCREEN_W(WORLD_W), .CW(11)) u_c (
                .ax(hx), .ay({1'b0, jy[g] + 10'd4}), .aw(8'd25), .ah(8'd36),
                .bx(player_x), .by({1'b0, player_y}), .bw(player_w), .bh(player_h),
                .hit(touch_c[g])
            );
            // roar range: |centre distance| < ROAR_R on both axes (x wraps)
            wire [11:0] jcx_r = {1'b0, jx[g]} + 12'd18;
            wire [10:0] jcx   = (jcx_r >= WORLD_W) ? jcx_r - WORLD_W : jcx_r[10:0];
            wire [10:0] ddx_a = (jcx >= player_cx) ? jcx - player_cx : player_cx - jcx;
            wire [10:0] ddx   = (ddx_a > WORLD_W / 2) ? WORLD_W - ddx_a : ddx_a;
            wire [9:0]  jcy   = jy[g] + 10'd26;
            wire [9:0]  ddy   = (jcy >= player_cy) ? jcy - player_cy : player_cy - jcy;
            assign near_c[g] = (ddx < ROAR_R) && (ddy < ROAR_R);
        end
    endgenerate

    always @(posedge clk) begin
        sting <= 1'b0;
        if (rst) begin
            for (i = 0; i < N; i = i + 1) begin on[i] <= 1'b0; stun[i] <= 8'd0; end
            spawn_t <= SPAWN_TICKS / 2;
            anim    <= 8'd0;
            touch   <= {N{1'b0}};
        end else begin
            touch <= touch_c;
            if (tick_60hz) begin
                anim    <= anim + 8'd1;
                if (spawn_t != 10'd0)            spawn_t <= spawn_t - 10'd1;
                else if (!pause && !too_close)   spawn_t <= spawn_ticks;
                if (spawn_t == 10'd0 && have_free && !pause && !too_close) begin
                    on[free_k]   <= 1'b1;
                    jx[free_k]   <= sx_w;
                    jy[free_k]   <= sy_w;
                    life[free_k] <= LIFE;
                    stun[free_k] <= 8'd0;
                    dirx[free_k] <= rand[3];
                end
            end
            for (i = 0; i < N; i = i + 1) begin
                if (sweep) on[i] <= 1'b0;
                else if (on[i]) begin
                    if (roar && near_c[i]) stun[i] <= ROAR_TICKS;
                    if (touch[i] && stun[i] == 8'd0 && !(roar && near_c[i])) begin
                        sting  <= 1'b1;
                        hit_cx <= jx[i] + 11'd18;
                        hit_cy <= jy[i] + 10'd26;
                    end
                    if (tick_60hz) begin
                        if (life[i] == 11'd0) on[i] <= 1'b0;
                        else life[i] <= life[i] - 11'd1;
                        if (stun[i] != 8'd0) stun[i] <= stun[i] - 8'd1;
                        else if (anim[1:0] == 2'd0) begin
                            // drift sideways (wraps) and bob up / down
                            if (dirx[i]) jx[i] <= (jx[i] == 11'd0) ? WORLD_W - 1 : jx[i] - 11'd1;
                            else         jx[i] <= (jx[i] == WORLD_W - 1) ? 11'd0 : jx[i] + 11'd1;
                            if (anim[6]) begin if (jy[i] > 10'd8) jy[i] <= jy[i] - 10'd1; end
                            else         begin if (jy[i] < WORLD_H - 60) jy[i] <= jy[i] + 10'd1; end
                        end
                    end
                end
            end
        end
    end

    generate
        for (g = 0; g < N; g = g + 1) begin : g_out
            assign active_vec[g]         = on[g];
            assign x_vec[11*g +: 11]     = jx[g];
            assign y_vec[11*g +: 11]     = {1'b0, jy[g]} + 11'd128;
            // frame changes every 8 ticks; frozen while stunned by the roar
            wire [1:0] ph = anim[4:3] + g;
            assign frame_vec[3*g +: 3]   = (stun[g] != 8'd0) ? 3'd0 : {1'b0, ph};
        end
    endgenerate
endmodule
