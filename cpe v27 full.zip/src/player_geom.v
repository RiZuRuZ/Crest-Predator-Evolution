// player_geom: sprite box and hitbox of the player for the current form (combinational)
//
// The player position (cx, cy) is the CENTER of the sprite, so the dragon grows around
// its center when it evolves. From it this module gives:
//   spr_x, spr_y, spr_w, spr_h  sprite top-left corner and size (renderer, camera, bounds)
//   hb_x,  hb_y,  hb_w,  hb_h   head + body hitbox (fish, bubbles, knockback)
// x wraps around the world. spr_y is clamped at 0: right after evolving near the top of
// the world the center can be closer to the top than half the new height; player_bounds
// moves the player down on the next tick.
//
// Sizes and hitboxes come from sprite-format.md / fish-sprites.md (art faces right):
//   form  sprite    hitbox x, y, w, h
//   1     73x41     32, 12, 35, 22
//   2     96x58     45, 22, 44, 24
//   3     126x74    55, 20, 69, 32
//   4     171x106   78, 34, 91, 42
// Facing left mirrors the sprite, so the hitbox x becomes W - x - w (y is the same).
// The same box is used for every animation frame of a form.
// v17: shrink = 1 (boss fight, form 4) makes the dragon x0.75: sprite 128x80,
// hitbox 58, 25, 68, 32 (player_renderer draws the sprite scaled the same way).
module player_geom #(
    parameter WORLD_W = 1920
)(
    input  wire [10:0] cx,
    input  wire [9:0]  cy,
    input  wire [2:0]  form,          // 1..4
    input  wire        facing_left,
    input  wire        shrink,         // v17 boss fight: form 4 drawn x0.75 (128 x 80)
    output reg  [7:0]  spr_w,
    output reg  [7:0]  spr_h,
    output wire [10:0] spr_x,
    output wire [9:0]  spr_y,
    output wire [10:0] hb_x,
    output wire [9:0]  hb_y,
    output reg  [7:0]  hb_w,
    output reg  [7:0]  hb_h
);
    reg [7:0] hx, hy;
    always @* begin
        case (form)
            3'd2:    begin spr_w = 8'd96;  spr_h = 8'd58;  hx = 8'd45; hy = 8'd22; hb_w = 8'd44; hb_h = 8'd24; end
            3'd3:    begin spr_w = 8'd126; spr_h = 8'd74;  hx = 8'd55; hy = 8'd20; hb_w = 8'd69; hb_h = 8'd32; end
            3'd4:    if (shrink)   // x0.75
                         begin spr_w = 8'd128; spr_h = 8'd80;  hx = 8'd58; hy = 8'd25; hb_w = 8'd68; hb_h = 8'd32; end
                     else begin spr_w = 8'd171; spr_h = 8'd106; hx = 8'd78; hy = 8'd34; hb_w = 8'd91; hb_h = 8'd42; end
            default: begin spr_w = 8'd73;  spr_h = 8'd41;  hx = 8'd32; hy = 8'd12; hb_w = 8'd35; hb_h = 8'd22; end
        endcase
    end

    // sprite top-left: center minus half the size (x modulo the world width)
    wire [6:0]  half_w = spr_w[7:1];
    wire [6:0]  half_h = spr_h[7:1];
    wire [11:0] sx_raw = {1'b0, cx} + WORLD_W - half_w;
    assign spr_x = (sx_raw >= WORLD_W) ? sx_raw - WORLD_W : sx_raw[10:0];
    assign spr_y = (cy >= half_h) ? cy - half_h : 10'd0;

    // hitbox: offset inside the sprite, mirrored when facing left
    wire [7:0]  hx_eff = facing_left ? (spr_w - hx - hb_w) : hx;
    wire [11:0] hb_raw = {1'b0, spr_x} + hx_eff;
    assign hb_x = (hb_raw >= WORLD_W) ? hb_raw - WORLD_W : hb_raw[10:0];
    assign hb_y = spr_y + hy;
endmodule
