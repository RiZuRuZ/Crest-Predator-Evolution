// spear_game: the "soul" mini game (Undertale style) - v21: three patterns in a row
//
// The screen is dimmed and a white box (x 170..469, y 140..339) appears. The player
// steers a small heart (the dragon's soul) with the direction inputs. Three patterns of
// PT ticks each (6 s), one after the other; `pat` tells which one runs:
//   0 SPEARS  spears fly through the box from the 4 sides (v15 game)
//   1 BARS    full-height bars sweep across the box from the left or the right.
//             BLUE bar: passes through you only if you stand STILL (no direction held).
//             ORANGE bar: passes through you only if you MOVE (a direction held).
//   2 BEAMS   a thin red line aims at the heart (horizontal or vertical) and blinks,
//             then a thick beam fires along it: leave the line before it fires.
//             The beams come faster and faster during the pattern.
//             v23: normal / hard fire TWO beams at once, a cross (one horizontal, one
//             vertical, both through the heart); easy keeps one beam.
//   v22: in patterns 1 and 2 white harpoons (like the pattern 0 spears, same speed) fly
//   through the box too, one every HARP_GAP ticks, on top of the bars / beams
//   (v21b had slow golden ones).
// After the 3 patterns: `done`. Every hit gives `hit` (1 clk) and INV_TICKS without hits
// (the heart blinks).
//   boss = 0 (event): the hits are counted by event_ctrl (3 hits = failed, `stop`)
//   boss = 1 (boss fight): every pattern starts with a PURPLE heart that takes the first
//            hit of that pattern; a hit without the purple heart costs a real heart (`hurt`)
// Speed by difficulty: spears / bars easy 2, normal 3, hard 4 px per tick; beam warning
// easy 44, normal 36, hard 28 ticks.
//
// Drawing uses screen coordinates 3 clocks late (px_d3 / py_d3 in top.v): all plain
// comparisons, so the output is ready at clock 3 like the other layers.
// Every number is a PLACEHOLDER.
module spear_game (
    input  wire        clk,
    input  wire        rst,
    input  wire        tick,
    input  wire [15:0] rand,
    input  wire        start,          // 1-clk pulse
    input  wire        stop,           // v20: 1-clk pulse, ends the game (no done)
    input  wire [1:0]  diff,           // v20: 0 easy, 1 normal, 2 hard
    input  wire        boss,           // v21: boss fight (purple heart, real hearts)
    input  wire        go_u, go_d, go_l, go_r,
    input  wire [9:0]  px,             // screen x / y, 3 clocks late
    input  wire [9:0]  py,
    output reg         active,
    output reg         done,           // 1-clk pulse: survived the 3 patterns
    output reg         hit,            // 1-clk pulse: v21 any hit (event counts these)
    output reg         hurt,           // 1-clk pulse: a real heart is lost (boss fight)
    output reg  [1:0]  pat,            // v21: 0 spears, 1 bars, 2 beams
    output reg         purple,         // v21: the purple heart is still there (boss)
    output wire        pixel_on,
    output wire [11:0] rgb
);
    localparam BL = 170, BR = 469, BT = 140, BB = 339;      // box (inclusive)
    localparam PT = 360, INV_TICKS = 50, SOUL_SPD = 3;
    localparam SPAWN = 16;              // v17 slower: was a spear every 12 ticks at 4 px/tick
    localparam BAR_GAP = 45;            // a bar every 45 ticks
    localparam HARP_GAP = 40;           // v22: a harpoon every 40 ticks (patterns 1, 2)
    localparam NS = 8, NB = 4;
    wire [9:0] spd    = (diff == 2'd0) ? 10'd2 : (diff == 2'd2) ? 10'd4 : 10'd3;   // v20
    wire [6:0] warn_t = (diff == 2'd0) ? 7'd44 : (diff == 2'd2) ? 7'd28 : 7'd36;   // v21
    localparam FIRE_T = 18;

    reg [9:0] t;                       // ticks in this pattern
    reg [5:0] inv;
    reg [9:0] sx, sy;                  // heart centre
    reg [3:0] sp_t;                    // spear spawn timer
    reg [5:0] bar_t;                   // bar spawn timer
    reg [6:0] bm_t;                    // beam spawn timer
    reg [5:0] hp_t;                    // v21b harpoon spawn timer
    wire      moving = go_u | go_d | go_l | go_r;

    // ---- pattern 0: spears ----
    reg        s_on   [0:NS-1];
    reg [1:0]  s_kind [0:NS-1];        // 0 from left, 1 from right, 2 from top, 3 from bottom
    reg [9:0]  s_x    [0:NS-1];        // centre
    reg [9:0]  s_y    [0:NS-1];
    // ---- pattern 1: bars ----
    reg        b_on   [0:NB-1];
    reg        b_rt   [0:NB-1];        // 1 = moves to the right
    reg        b_or   [0:NB-1];        // 1 = orange (move), 0 = blue (stand still)
    reg [9:0]  b_x    [0:NB-1];        // centre x
    // ---- pattern 2: beams (2) ----
    reg        e_on   [0:1];
    reg        e_vert [0:1];           // 1 = vertical line at x = e_p, else horizontal at y = e_p
    reg [9:0]  e_p    [0:1];
    reg [6:0]  e_t    [0:1];           // ticks since the warning started
    reg        e_last;                 // which beam slot was used last

    // first free slots
    reg [2:0] fs;  reg ff;
    reg [1:0] fbs; reg fbf;
    integer k, k1, k2, k3;
    always @* begin
        ff = 1'b0; fs = 3'd0; fbf = 1'b0; fbs = 2'd0;
        for (k1 = NS - 1; k1 >= 0; k1 = k1 - 1)
            if (!s_on[k1]) begin ff = 1'b1; fs = k1[2:0]; end
        for (k1 = NB - 1; k1 >= 0; k1 = k1 - 1)
            if (!b_on[k1]) begin fbf = 1'b1; fbs = k1[1:0]; end
    end

    // hit tests (heart +-5)
    reg any_hit;
    reg [9:0] hdx, hdy;
    always @* begin
        any_hit = 1'b0;
        for (k2 = 0; k2 < NS; k2 = k2 + 1) begin
            hdx = (s_x[k2] > sx) ? s_x[k2] - sx : sx - s_x[k2];
            hdy = (s_y[k2] > sy) ? s_y[k2] - sy : sy - s_y[k2];
            if (s_on[k2] && ((s_kind[k2][1] == 1'b0) ? (hdx < 10'd25 && hdy < 10'd8)
                                                     : (hdx < 10'd8  && hdy < 10'd25)))
                any_hit = 1'b1;
        end
        for (k2 = 0; k2 < NB; k2 = k2 + 1) begin
            hdx = (b_x[k2] > sx) ? b_x[k2] - sx : sx - b_x[k2];
            if (b_on[k2] && hdx < 10'd8 && (b_or[k2] ? !moving : moving))
                any_hit = 1'b1;
        end
        for (k2 = 0; k2 < 2; k2 = k2 + 1) begin
            hdx = (e_p[k2] > sx) ? e_p[k2] - sx : sx - e_p[k2];
            hdy = (e_p[k2] > sy) ? e_p[k2] - sy : sy - e_p[k2];
            if (e_on[k2] && e_t[k2] >= warn_t &&
                (e_vert[k2] ? (hdx < 10'd12) : (hdy < 10'd11)))
                any_hit = 1'b1;
        end
    end

    wire [9:0] lane_y = 10'd152 + {2'd0, rand[9:2]} - {4'd0, rand[9:4]};   // 152 .. 391 -> clamp
    wire [9:0] lane_x = 10'd182 + {2'd0, rand[9:2]};                       // 182 .. 437
    // beams come faster: 70 ticks apart at the start, 40 at the end
    wire [6:0] bm_gap = 7'd70 - {2'b00, t[8:4]};

    always @(posedge clk) begin
        done <= 1'b0; hit <= 1'b0; hurt <= 1'b0;
        if (rst) begin
            active <= 1'b0; t <= 10'd0; inv <= 6'd0; sx <= 10'd320; sy <= 10'd240; sp_t <= 4'd0;
            bar_t <= 6'd0; bm_t <= 7'd0; pat <= 2'd0; purple <= 1'b0; e_last <= 1'b0; hp_t <= 6'd0;
            for (k = 0; k < NS; k = k + 1) begin
                s_on[k] <= 1'b0; s_kind[k] <= 2'd0; s_x[k] <= 10'd0; s_y[k] <= 10'd0;
            end
            for (k = 0; k < NB; k = k + 1) begin
                b_on[k] <= 1'b0; b_rt[k] <= 1'b0; b_or[k] <= 1'b0; b_x[k] <= 10'd0;
            end
            for (k = 0; k < 2; k = k + 1) begin
                e_on[k] <= 1'b0; e_vert[k] <= 1'b0; e_p[k] <= 10'd0; e_t[k] <= 7'd0;
            end
        end else if (start) begin
            active <= 1'b1; t <= 10'd0; inv <= 6'd0; sx <= 10'd320; sy <= 10'd240; sp_t <= 4'd0;
            bar_t <= 6'd0; bm_t <= 7'd0; pat <= 2'd0; purple <= boss; hp_t <= 6'd0;
            for (k = 0; k < NS; k = k + 1) s_on[k] <= 1'b0;
            for (k = 0; k < NB; k = k + 1) b_on[k] <= 1'b0;
            for (k = 0; k < 2; k = k + 1)  e_on[k] <= 1'b0;
        end else if (stop) begin
            active <= 1'b0;
        end else if (tick && active) begin
            t <= t + 10'd1;
            if (inv != 6'd0) inv <= inv - 6'd1;
            // the heart
            if (go_l && sx > BL + 10) sx <= sx - SOUL_SPD;
            if (go_r && sx < BR - 10) sx <= sx + SOUL_SPD;
            if (go_u && sy > BT + 10) sy <= sy - SOUL_SPD;
            if (go_d && sy < BB - 10) sy <= sy + SOUL_SPD;
            // spears move and leave
            for (k = 0; k < NS; k = k + 1) if (s_on[k]) begin
                case (s_kind[k])
                    2'd0: begin s_x[k] <= s_x[k] + spd; if (s_x[k] > BR + 30) s_on[k] <= 1'b0; end
                    2'd1: begin s_x[k] <= s_x[k] - spd; if (s_x[k] < BL - 30) s_on[k] <= 1'b0; end
                    2'd2: begin s_y[k] <= s_y[k] + spd; if (s_y[k] > BB + 30) s_on[k] <= 1'b0; end
                    default: begin s_y[k] <= s_y[k] - spd; if (s_y[k] < BT - 30) s_on[k] <= 1'b0; end
                endcase
            end
            // bars move and leave
            for (k = 0; k < NB; k = k + 1) if (b_on[k]) begin
                if (b_rt[k]) begin b_x[k] <= b_x[k] + spd; if (b_x[k] > BR) b_on[k] <= 1'b0; end
                else         begin b_x[k] <= b_x[k] - spd; if (b_x[k] < BL) b_on[k] <= 1'b0; end
            end
            // beams: warning, then fire, then gone
            for (k = 0; k < 2; k = k + 1) if (e_on[k]) begin
                e_t[k] <= e_t[k] + 7'd1;
                if (e_t[k] >= warn_t + FIRE_T) e_on[k] <= 1'b0;
            end

            // spawning (nothing new in the last second of a pattern)
            sp_t  <= (sp_t == SPAWN - 1) ? 4'd0 : sp_t + 4'd1;
            bar_t <= (bar_t == BAR_GAP - 1) ? 6'd0 : bar_t + 6'd1;
            bm_t  <= (bm_t >= bm_gap) ? 7'd0 : bm_t + 7'd1;
            hp_t  <= (hp_t == HARP_GAP - 1) ? 6'd0 : hp_t + 6'd1;
            if (t < PT - 60) begin
                if (((pat == 2'd0 && sp_t == 4'd0) || (pat != 2'd0 && hp_t == 6'd0)) && ff) begin
                    s_on[fs]   <= 1'b1;
                    s_kind[fs] <= rand[1:0];
                    case (rand[1:0])
                        2'd0: begin s_x[fs] <= BL - 22; s_y[fs] <= (lane_y > BB - 10) ? BB - 10 : lane_y; end
                        2'd1: begin s_x[fs] <= BR + 22; s_y[fs] <= (lane_y > BB - 10) ? BB - 10 : lane_y; end
                        2'd2: begin s_y[fs] <= BT - 22; s_x[fs] <= lane_x; end
                        default: begin s_y[fs] <= BB + 22; s_x[fs] <= lane_x; end
                    endcase
                end
                if (pat == 2'd1 && bar_t == 6'd0 && fbf) begin
                    b_on[fbs] <= 1'b1;
                    b_rt[fbs] <= rand[0];
                    b_or[fbs] <= rand[1];
                    b_x[fbs]  <= rand[0] ? BL + 4 : BR - 4;
                end
                if (pat == 2'd2 && bm_t == 7'd0) begin
                    if (diff == 2'd0) begin                          // easy: one beam
                        if (!e_on[!e_last]) begin
                            e_last          <= !e_last;
                            e_on[!e_last]   <= 1'b1;
                            e_t[!e_last]    <= 7'd0;
                            e_vert[!e_last] <= rand[0];
                            e_p[!e_last]    <= rand[0] ? sx : sy;    // aimed at the heart
                        end
                    end else if (!e_on[0] && !e_on[1]) begin         // v23: a cross of two
                        e_on[0] <= 1'b1; e_t[0] <= 7'd0; e_vert[0] <= 1'b0; e_p[0] <= sy;
                        e_on[1] <= 1'b1; e_t[1] <= 7'd0; e_vert[1] <= 1'b1; e_p[1] <= sx;
                    end
                end
            end

            // hits
            if (any_hit && inv == 6'd0) begin
                hit <= 1'b1; inv <= INV_TICKS;
                if (boss) begin
                    if (purple) purple <= 1'b0;                      // the purple heart takes it
                    else        hurt   <= 1'b1;
                end
            end

            // next pattern / end
            if (t >= PT - 1) begin
                t <= 10'd0;
                for (k = 0; k < NS; k = k + 1) s_on[k] <= 1'b0;
                for (k = 0; k < NB; k = k + 1) b_on[k] <= 1'b0;
                for (k = 0; k < 2; k = k + 1)  e_on[k] <= 1'b0;
                if (pat == 2'd2) begin active <= 1'b0; done <= 1'b1; end
                else begin pat <= pat + 2'd1; purple <= boss; end
            end
        end
    end

    // ---------------- drawing ----------------
    wire in_box  = (px >= BL) && (px <= BR) && (py >= BT) && (py <= BB);
    wire inner   = (px >= BL + 4) && (px <= BR - 4) && (py >= BT + 4) && (py <= BB - 4);
    wire border  = in_box && !inner;

    // spears: shaft 40 x 2 (grey) with an 8 px head (white, 6 px wide at the back)
    reg sp_shaft, sp_head, bar_b, bar_o, bm_warn, bm_fire;
    reg [9:0] ddx, ddy, along;
    always @* begin
        sp_shaft = 1'b0; sp_head = 1'b0; bar_b = 1'b0; bar_o = 1'b0; bm_warn = 1'b0; bm_fire = 1'b0;
        for (k3 = 0; k3 < NS; k3 = k3 + 1) begin
            ddx = (px > s_x[k3]) ? px - s_x[k3] : s_x[k3] - px;
            ddy = (py > s_y[k3]) ? py - s_y[k3] : s_y[k3] - py;
            if (s_on[k3] && inner) begin
                if (s_kind[k3][1] == 1'b0) begin                     // horizontal
                    along = (s_kind[k3][0] == 1'b0) ? (s_x[k3] + 10'd20 - px) : (px + 10'd20 - s_x[k3]);
                    if (ddx < 10'd20 && along < 10'd8 && ddy <= {1'b0, along[9:1]}) sp_head = 1'b1;
                    else if (ddx < 10'd20 && ddy < 10'd1 + 10'd1 && along >= 10'd8) sp_shaft = 1'b1;
                end else begin                                       // vertical
                    along = (s_kind[k3][0] == 1'b0) ? (s_y[k3] + 10'd20 - py) : (py + 10'd20 - s_y[k3]);
                    if (ddy < 10'd20 && along < 10'd8 && ddx <= {1'b0, along[9:1]}) sp_head = 1'b1;
                    else if (ddy < 10'd20 && ddx < 10'd2 && along >= 10'd8) sp_shaft = 1'b1;
                end
            end
        end
        for (k3 = 0; k3 < NB; k3 = k3 + 1) begin
            ddx = (px > b_x[k3]) ? px - b_x[k3] : b_x[k3] - px;
            if (b_on[k3] && inner && ddx < 10'd3) begin
                if (b_or[k3]) bar_o = 1'b1; else bar_b = 1'b1;
            end
        end
        for (k3 = 0; k3 < 2; k3 = k3 + 1) begin
            ddx = (px > e_p[k3]) ? px - e_p[k3] : e_p[k3] - px;
            ddy = (py > e_p[k3]) ? py - e_p[k3] : e_p[k3] - py;
            if (e_on[k3] && inner) begin
                if (e_t[k3] >= warn_t) begin
                    if (e_vert[k3] ? (ddx < 10'd7) : (ddy < 10'd7)) bm_fire = 1'b1;
                end else if ((e_vert[k3] ? (ddx < 10'd1) : (ddy < 10'd1)) && !e_t[k3][2])
                    bm_warn = 1'b1;                                  // blinking red line
            end
        end
    end

    // heart 11 x 9 around (sx, sy)
    function [10:0] heart_row(input [3:0] r);
        case (r)
            4'd0: heart_row = 11'b00111011100;
            4'd1: heart_row = 11'b01111111110;
            4'd2: heart_row = 11'b11111111111;
            4'd3: heart_row = 11'b11111111111;
            4'd4: heart_row = 11'b01111111110;
            4'd5: heart_row = 11'b00111111100;
            4'd6: heart_row = 11'b00011111000;
            4'd7: heart_row = 11'b00001110000;
            4'd8: heart_row = 11'b00000100000;
            default: heart_row = 11'd0;
        endcase
    endfunction
    wire [9:0] hx = px - sx + 10'd5;                  // 0..10 inside
    wire [9:0] hy = py - sy + 10'd4;                  // 0..8 inside
    wire [10:0] hrow = heart_row(hy[3:0]);
    wire soul = (hx < 10'd11) && (hy < 10'd9) && hrow[10 - hx[3:0]] && !(inv[2]);
    // purple heart (boss): 22 x 18 above the box, centre x 320
    wire [9:0] ux = px - 10'd309;
    wire [9:0] uy = py - 10'd116;
    wire [10:0] urow = heart_row(uy[4:1]);
    wire pheart = boss && purple && (ux < 10'd22) && (uy < 10'd18) && urow[10 - ux[4:1]];

    // time left of this pattern under the box: 300 px when full
    wire [15:0] left_w = (PT - t) * 16'd53;           // x 53 / 64: 360 -> 298 px
    wire [9:0]  left_px = left_w[15:6];
    wire bar  = (py >= BB + 8) && (py < BB + 14) && (px >= BL) && (px < BL + left_px);

    assign pixel_on = active && (border || sp_shaft || sp_head || soul || bar || bar_b || bar_o ||
                                 bm_warn || bm_fire || pheart);
    assign rgb = soul     ? (moving ? 12'hFB4 : 12'h7CF) :      // heart tints orange while moving
                 pheart   ? 12'hB5F :
                 border   ? 12'hFFF :
                 bm_fire  ? 12'hFFF :
                 bm_warn  ? 12'hF33 :
                 bar_o    ? 12'hF92 :
                 bar_b    ? 12'h3AF :
                 sp_head  ? 12'hEEF :
                 sp_shaft ? 12'h9AB : 12'hFD5;
endmodule
