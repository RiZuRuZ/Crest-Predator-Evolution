// bubble_renderer (temporary): draws each bubble as a bright square with cut corners
// until the bubble sprite exists. Works in world coordinates (world_x / world_y from
// camera); the x distance wraps around the world.
// A white rim keeps the real bubbles different from the bubbles painted in the map.
module bubble_renderer #(
    parameter N            = 3,
    parameter SIZE         = 16,
    parameter WORLD_W      = 1920,
    parameter [11:0] COLOR = 12'hAEF,
    parameter [11:0] RIM   = 12'hFFF
)(
    input  wire [10:0]     world_x,
    input  wire [9:0]      world_y,
    input  wire [N-1:0]    active_vec,
    input  wire [11*N-1:0] x_vec,
    input  wire [10*N-1:0] y_vec,
    output reg             pixel_on,
    output reg  [11:0]     rgb_out
);
    integer k;
    reg [10:0] bx;
    reg [9:0]  by;
    reg [11:0] rx;
    reg [10:0] ry;
    reg        corner, on_rim;

    always @* begin
        pixel_on = 1'b0;
        rgb_out  = COLOR;
        for (k = 0; k < N; k = k + 1) begin
            bx = x_vec[11*k +: 11];
            by = y_vec[10*k +: 10];
            rx = (world_x >= bx) ? (world_x - bx) : ({1'b0, world_x} + WORLD_W - bx);
            ry = {1'b0, world_y} - {1'b0, by};
            corner = ((rx < 3) || (rx >= SIZE - 3)) && ((ry < 3) || (ry >= SIZE - 3));
            on_rim = (rx < 2) || (rx >= SIZE - 2) || (ry < 2) || (ry >= SIZE - 2);
            if (active_vec[k] && world_y >= by && rx < SIZE && ry < SIZE && !corner) begin
                pixel_on = 1'b1;
                rgb_out  = on_rim ? RIM : COLOR;
            end
        end
    end
endmodule
