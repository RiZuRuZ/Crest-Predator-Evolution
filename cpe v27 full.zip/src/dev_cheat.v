// dev_cheat: secret code for the developers (v16) - more EP while testing
//
// Only in PAUSE (SW0 on). Press the direction buttons (or W S A D) in this order:
//     UP UP DOWN DOWN LEFT RIGHT LEFT RIGHT
// A wrong button starts again (it counts as the first press if it is UP).
// After the 8th press: `hit` (1-clk pulse). v19: top.v makes it a jump to the next form
// (score 25 / 75 / 200 / 500, score_ctrl.jump) and plays the bubble sound. Enter it again
// for the form after that (form 4 -> 500 EP = the boss fight).
// Leaving PAUSE clears a half-entered code.
module dev_cheat (
    input  wire clk,
    input  wire rst,
    input  wire en,                    // game is in PAUSE
    input  wire p_u, p_d, p_l, p_r,    // 1-clk presses
    output reg  hit
);
    localparam [1:0] U = 2'd0, D = 2'd1, L = 2'd2, R = 2'd3;
    // code, first press in the lowest 2 bits: U U D D L R L R
    localparam [15:0] CODE = {R, L, R, L, D, D, U, U};

    reg  [2:0] idx;                    // presses matched so far
    wire       press = p_u | p_d | p_l | p_r;
    wire [1:0] key   = p_u ? U : p_d ? D : p_l ? L : R;
    wire [1:0] want  = CODE[2*idx +: 2];

    always @(posedge clk) begin
        hit <= 1'b0;
        if (rst || !en) begin
            idx <= 3'd0;
        end else if (press) begin
            if (key == want) begin
                if (idx == 3'd7) begin
                    hit <= 1'b1;
                    idx <= 3'd0;
                end else
                    idx <= idx + 3'd1;
            end else
                idx <= (key == U) ? ((idx == 3'd2) ? 3'd2 : 3'd1) : 3'd0;
        end
    end
endmodule
