// sprite_bank: one block-RAM ROM of 4-bit palette indexes (part of a sprite sheet)
// - DEPTH must be at most 32768: a deeper ROM makes Vivado cascade RAMB36 blocks,
//   which failed DRC REQP-1962 on this board (conventions.md). Bigger sheets are split
//   into several banks by tools/split_sprite_roms.py.
// - index 0 = transparent; the caller turns the index into a color with its palette.
// - latency: 1 clock (idx is registered inside the block RAM).
module sprite_bank #(
    parameter DEPTH = 32768,
    parameter FILE  = "evo1_b0.mem"
)(
    input  wire        clk,
    input  wire [14:0] addr,
    output reg  [3:0]  idx
);
    (* ram_style = "block" *) reg [3:0] mem [0:DEPTH-1];
    initial $readmemh(FILE, mem);

    always @(posedge clk)
        idx <= mem[addr];
endmodule

// sprite_bank2: the same ROM with two read ports (true dual-port block RAM), so two
// sprites stored in one bank can be read for the same pixel (fish_renderer: two
// overlapping fish of the same type). Same rules: DEPTH at most 32768, latency 1 clock.
module sprite_bank2 #(
    parameter DEPTH = 32768,
    parameter FILE  = "fish0.mem"
)(
    input  wire        clk,
    input  wire [14:0] addr_a,
    input  wire [14:0] addr_b,
    output reg  [3:0]  idx_a,
    output reg  [3:0]  idx_b
);
    (* ram_style = "block" *) reg [3:0] mem [0:DEPTH-1];
    initial $readmemh(FILE, mem);

    always @(posedge clk) begin
        idx_a <= mem[addr_a];
        idx_b <= mem[addr_b];
    end
endmodule
