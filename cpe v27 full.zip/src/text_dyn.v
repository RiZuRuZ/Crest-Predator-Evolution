// text_dyn: like text_line, but the N characters come from an input (can change while playing)
// chars = N ASCII codes, first character in the top byte. Same cell layout and
// 2-clock latency as text_line. Uses screen coordinates (HUD does not scroll).
module text_dyn #(
    parameter X0 = 0,
    parameter Y0 = 0,
    parameter S  = 1,
    parameter N  = 4
)(
    input  wire           clk,
    input  wire [8*N-1:0] chars,
    input  wire [9:0]     pixel_x,
    input  wire [9:0]     pixel_y,
    output reg            pixel_on
);
    localparam W = N << (3 + S);
    localparam H = 8 << S;

    wire [10:0] rx     = {1'b0, pixel_x} - X0;
    wire [10:0] ry     = {1'b0, pixel_y} - Y0;
    wire        in_box = (pixel_x >= X0) && (pixel_x < X0 + W) &&
                         (pixel_y >= Y0) && (pixel_y < Y0 + H);
    wire [10:0] col    = in_box ? (rx >> (3 + S)) : 11'd0;

    reg       in_r;
    reg [7:0] ch_r;
    reg [2:0] row_r, px_r;
    always @(posedge clk) begin
        in_r  <= in_box;
        ch_r  <= chars[8*(N-1-col) +: 8];
        row_r <= ry >> S;
        px_r  <= rx >> S;
    end

    wire [4:0] bits;
    font_rom u_font (.ch(ch_r), .row(row_r), .bits(bits));
    always @(posedge clk)
        pixel_on <= in_r && (px_r < 3'd5) && (row_r < 3'd7) && bits[3'd4 - px_r];
endmodule
