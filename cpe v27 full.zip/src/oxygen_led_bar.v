// oxygen_led_bar: oxygen level on the 16 LEDs, LED[0] is the last one to go out
// LED[i] is on while oxygen > i * OXY_MAX / 16
module oxygen_led_bar #(
    parameter OXY_MAX = 960
)(
    input  wire [9:0]  oxygen,
    output wire [15:0] led
);
    genvar i;
    generate
        for (i = 0; i < 16; i = i + 1) begin : g_led
            assign led[i] = (oxygen > (i * OXY_MAX) / 16);
        end
    endgenerate
endmodule
