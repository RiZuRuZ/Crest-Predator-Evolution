// timing_game: event mini game 3 (v20) - stop the bar in the green zone
//
// A track in the middle of the screen (x 170..469, y 210..245). A white cursor runs
// left and right very fast; a green zone (ZONE px) sits somewhere on the track.
// Press any button (centre / arrows / W A S D / Space) while the cursor is inside the
// zone: a hit (one of NEED pips lights up) and the zone jumps to a new place. A press
// outside the zone is a miss: the time bar loses PEN ticks (no instant loss).
// NEED hits before the time bar (TIME ticks) is empty: done with ok = 1, else ok = 0.
// Cursor speed by difficulty: easy 5, normal 7, hard 9 px per tick.
// Drawing uses screen coordinates 3 clocks late (like spear_game): plain comparisons.
// Every number is a PLACEHOLDER.
module timing_game #(
    parameter NEED = 5,
    parameter TIME = 360,           // 6 s
    parameter PEN  = 60,            // 1 s per miss
    parameter ZONE = 40
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        tick,
    input  wire [15:0] rand,
    input  wire        start,       // 1-clk pulse
    input  wire [1:0]  diff,        // 0 easy, 1 normal, 2 hard
    input  wire        press,       // 1-clk pulse: any button / key
    input  wire [9:0]  px,          // screen x / y, 3 clocks late
    input  wire [9:0]  py,
    output reg         active,
    output reg         done,        // 1-clk pulse
    output reg         ok,          // valid with done
    output reg         hit_p,       // 1-clk: a hit (sound)
    output reg         miss_p,      // 1-clk: a miss (sound)
    output reg  [2:0]  misses,      // v21: misses in this game (event rating)
    output wire        pixel_on,
    output wire [11:0] rgb
);
    localparam TL = 176, TR = 463;          // cursor centre range
    localparam BL = 170, BR = 469, BT = 210, BB = 245;

    reg [9:0] cx;                           // cursor centre
    reg       dir;                          // 1 = to the right
    reg [9:0] zl;                           // zone left
    reg [2:0] got;
    reg [8:0] tl;                           // time left
    reg [4:0] fl_t;                         // flash after a hit / miss
    reg       fl_ok;

    wire [3:0] spd = (diff == 2'd0) ? 4'd5 : (diff == 2'd2) ? 4'd9 : 4'd7;
    // new zone: 186 .. 416 (+ ZONE stays inside the track)
    wire [7:0] zr  = (rand[7:0] > 8'd230) ? rand[7:0] - 8'd100 : rand[7:0];
    wire [9:0] zn  = 10'd186 + {2'b00, zr};
    wire       in_zone = (cx + 10'd2 >= zl) && (cx < zl + ZONE + 10'd2);

    always @(posedge clk) begin
        done <= 1'b0; hit_p <= 1'b0; miss_p <= 1'b0;
        if (rst) begin
            active <= 1'b0; ok <= 1'b0; cx <= TL; dir <= 1'b1; zl <= 10'd300; got <= 3'd0;
            tl <= 9'd0; fl_t <= 5'd0; fl_ok <= 1'b0; misses <= 3'd0;
        end else if (start) begin
            active <= 1'b1; ok <= 1'b0; cx <= TL; dir <= 1'b1; zl <= zn; got <= 3'd0;
            tl <= TIME; fl_t <= 5'd0; misses <= 3'd0;
        end else if (active) begin
            if (press) begin
                fl_t <= 5'd12;
                if (in_zone) begin
                    fl_ok <= 1'b1; hit_p <= 1'b1; got <= got + 3'd1; zl <= zn;
                    if (got == NEED - 1) begin active <= 1'b0; done <= 1'b1; ok <= 1'b1; end
                end else begin
                    fl_ok <= 1'b0; miss_p <= 1'b1;
                    if (misses != 3'd7) misses <= misses + 3'd1;
                    tl <= (tl > PEN) ? tl - PEN : 9'd0;
                end
            end else if (tick) begin
                if (fl_t != 5'd0) fl_t <= fl_t - 5'd1;
                // the cursor bounces between TL and TR
                if (dir) begin
                    if (cx + spd >= TR) begin cx <= TR; dir <= 1'b0; end
                    else cx <= cx + spd;
                end else begin
                    if (cx <= TL + spd) begin cx <= TL; dir <= 1'b1; end
                    else cx <= cx - spd;
                end
                if (tl == 9'd0) begin active <= 1'b0; done <= 1'b1; ok <= 1'b0; end
                else tl <= tl - 9'd1;
            end
        end
    end

    // ---------------- drawing ----------------
    wire in_box = (px >= BL) && (px <= BR) && (py >= BT) && (py <= BB);
    wire inner  = (px >= BL + 3) && (px <= BR - 3) && (py >= BT + 3) && (py <= BB - 3);
    wire border = in_box && !inner;
    wire zone   = inner && (px >= zl) && (px < zl + ZONE);
    wire cur    = (px + 10'd2 >= cx) && (px < cx + 10'd2) && (py >= BT - 4) && (py <= BB + 4);
    // NEED pips under the track: 14 x 14 boxes every 24 px from x 266
    wire [9:0] pr  = px - 10'd266;
    wire [2:0] pi  = pr / 10'd24;
    wire pip_area  = (px >= 10'd266) && (px < 10'd266 + 24 * NEED) && (py >= 10'd258) && (py < 10'd272) &&
                     ((pr % 10'd24) < 10'd14);
    wire pip_full  = pip_area && (pi < got);
    // time bar: 300 px when full
    wire [12:0] bar_w = (tl * 13'd13) >> 4;              // TIME 360 -> 292 px
    wire bar = (py >= 10'd282) && (py < 10'd288) && (px >= BL) && (px < BL + bar_w[9:0]);

    assign pixel_on = active && (in_box || cur || pip_area || bar);
    assign rgb = cur      ? 12'hFFF :
                 border   ? ((fl_t != 5'd0) ? (fl_ok ? 12'h7F7 : 12'hF44) : 12'hFFF) :
                 zone     ? ((fl_t != 5'd0 && fl_ok) ? 12'hBFB : 12'h3C4) :
                 inner    ? 12'h123 :
                 pip_full ? 12'hFD4 :
                 pip_area ? 12'h456 : 12'hFD5;
endmodule
