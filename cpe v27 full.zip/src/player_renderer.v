// player_renderer: draws the dragon sprite of the current form and animation frame
//
// Works in world coordinates: world_x / world_y is the world position of the pixel being
// drawn (registered by camera). spr_x / spr_y is the sprite top-left (player_geom). The x
// distance wraps around the world, so the dragon can stand on the map seam.
//
// form   1..4 selects the sprite: 73x41, 96x58, 126x74, 171x106
// frame  0..9 from player_anim_fsm (0,1 idle | 2..5 swim | 6..9 bite = swim with mouth open)
// facing_left mirrors the sprite (art faces right)
// flash  1 = draw the sprite brighter (half way to white), used when eating / hit
//
// ROM (tools/split_sprite_roms.py), row spans to save block RAM:
//   About 65 % of the dragon pixels are transparent, so every sprite row stores only the
//   span from its first to its last visible pixel, and all forms share one address
//   space (only one form is on screen at a time).
//   dragon_rows.mem  one entry per sprite row: {offset[17:0], x0[7:0], len[7:0]}
//                    row index = ROW_BASE[form] + frame * H + y
//   dragon_b0..b6    4-bit palette indexes (index 0 transparent), banks of 32K entries,
//                    bank = offset[17:15]; a span never crosses a bank boundary
//   pixel x is inside the span when x0 <= x < x0 + len, at address offset + (x - x0)
//   Palettes: one 16-color palette per form (evoN_pal.mem).
//
// Timing (the pixel changes every 4 clocks, pixel_mixer samples on the 4th):
//   clock 1  camera registers world_x / world_y
//   clock 2  row table read (block RAM), x inside the sprite registered
//   clock 3  pixel read (block RAM) at offset + (x - x0)
//   then     bank / palette select is combinational
module player_renderer #(
    parameter WORLD_W = 1920
)(
    input  wire        clk,
    input  wire [10:0] world_x,
    input  wire [9:0]  world_y,
    input  wire [10:0] spr_x,
    input  wire [9:0]  spr_y,
    input  wire        facing_left,
    input  wire [2:0]  form,          // 1..4
    input  wire [3:0]  frame,         // 0..9
    input  wire        flash,
    input  wire        shrink,         // v17 boss fight: form 4 drawn x0.75 (128 x 80)
    output wire        pixel_on,
    output wire [11:0] rgb_out,
    // afterimage (EVO2 Super Dash): the same sprite drawn again at an older position,
    // read through the second port of every block RAM (no extra memory)
    input  wire        g_en,
    input  wire [10:0] g_x,
    input  wire [9:0]  g_y,
    output wire        g_on,
    output wire [11:0] g_rgb
);
    // ---- stage 1: position inside the sprite, row table address ---------------
    reg [7:0]  w, h;
    reg [11:0] row_base;
    always @* begin
        case (form)
            3'd2:    begin w = 8'd96;  h = 8'd58;  row_base = 12'd410;  end
            3'd3:    begin w = 8'd126; h = 8'd74;  row_base = 12'd990;  end
            3'd4:    begin w = 8'd171; h = 8'd106; row_base = 12'd1730; end
            default: begin w = 8'd73;  h = 8'd41;  row_base = 12'd0;    end
        endcase
    end

    // v17 shrink (boss fight, form 4): the box on screen is 128 x 80 and a screen pixel
    // maps back to sprite pixel * 4/3 (x 341 / 256: 127 -> 169, 79 -> 105)
    wire        sm    = shrink && (form == 3'd4);
    wire [7:0]  dw    = sm ? 8'd128 : w;                       // box on screen
    wire [7:0]  dh    = sm ? 8'd80  : h;
    wire [11:0] rel_x = (world_x >= spr_x) ? (world_x - spr_x)
                                           : ({1'b0, world_x} + WORLD_W - spr_x);
    wire [9:0]  rel_y = world_y - spr_y;
    wire        in_x  = (rel_x < {4'd0, dw});
    wire        in_y  = (world_y >= spr_y) && (rel_y < {2'd0, dh});
    wire [15:0] scx   = rel_x[7:0] * 9'd341;
    wire [15:0] scy   = rel_y[7:0] * 9'd341;
    wire [7:0]  ux    = sm ? scx[15:8] : rel_x[7:0];           // sprite pixel
    wire [7:0]  uy    = sm ? scy[15:8] : rel_y[7:0];
    wire [7:0]  sx    = facing_left ? (w - 8'd1 - ux) : ux;
    wire [11:0] row   = row_base + frame * h + uy;              // 0 .. 2789 when inside

    // afterimage position inside the sprite
    wire [11:0] grel_x = (world_x >= g_x) ? (world_x - g_x) : ({1'b0, world_x} + WORLD_W - g_x);
    wire [9:0]  grel_y = world_y - g_y;
    wire        g_in   = g_en && (grel_x < {4'd0, dw}) && (world_y >= g_y) && (grel_y < {2'd0, dh});
    wire [15:0] gscx   = grel_x[7:0] * 9'd341;
    wire [15:0] gscy   = grel_y[7:0] * 9'd341;
    wire [7:0]  gux    = sm ? gscx[15:8] : grel_x[7:0];
    wire [7:0]  guy    = sm ? gscy[15:8] : grel_y[7:0];
    wire [7:0]  gsx    = facing_left ? (w - 8'd1 - gux) : gux;
    wire [11:0] grow   = row_base + frame * h + guy;

    (* ram_style = "block" *) reg [33:0] rows [0:2789];
    initial $readmemh("dragon_rows.mem", rows);
    reg [33:0] row_q, grow_q;               // registered by the block RAM (2 ports)
    always @(posedge clk) begin
        row_q  <= rows[row];
        grow_q <= rows[grow];
    end
    reg [7:0] gsx_r;
    reg       g_in_r;
    always @(posedge clk) begin
        gsx_r  <= gsx;
        g_in_r <= g_in;
    end

    reg [7:0] sx_r;
    reg [2:0] form_r;
    reg       in_r, flash_r;
    always @(posedge clk) begin
        sx_r    <= sx;
        form_r  <= form;
        in_r    <= in_x & in_y;
        flash_r <= flash;
    end

    // ---- stage 2: pixel address from the row span ----------------------------
    wire [17:0] off   = row_q[33:16];
    wire [7:0]  x0    = row_q[15:8];
    wire [7:0]  len   = row_q[7:0];
    wire [7:0]  dxs   = sx_r - x0;                              // valid when sx_r >= x0
    wire        in_sp = (sx_r >= x0) && (dxs < len);
    wire [17:0] addr  = off + dxs;

    wire [17:0] goff   = grow_q[33:16];
    wire [7:0]  gx0    = grow_q[15:8];
    wire [7:0]  glen   = grow_q[7:0];
    wire [7:0]  gdxs   = gsx_r - gx0;
    wire        g_insp = (gsx_r >= gx0) && (gdxs < glen);
    wire [17:0] gaddr  = goff + gdxs;

    wire [3:0] q [0:6];
    wire [3:0] gq [0:6];
    sprite_bank2 #(.DEPTH(32768), .FILE("dragon_b0.mem")) u_d0 (.clk(clk), .addr_a(addr[14:0]), .addr_b(gaddr[14:0]), .idx_a(q[0]), .idx_b(gq[0]));
    sprite_bank2 #(.DEPTH(32768), .FILE("dragon_b1.mem")) u_d1 (.clk(clk), .addr_a(addr[14:0]), .addr_b(gaddr[14:0]), .idx_a(q[1]), .idx_b(gq[1]));
    sprite_bank2 #(.DEPTH(32768), .FILE("dragon_b2.mem")) u_d2 (.clk(clk), .addr_a(addr[14:0]), .addr_b(gaddr[14:0]), .idx_a(q[2]), .idx_b(gq[2]));
    sprite_bank2 #(.DEPTH(32768), .FILE("dragon_b3.mem")) u_d3 (.clk(clk), .addr_a(addr[14:0]), .addr_b(gaddr[14:0]), .idx_a(q[3]), .idx_b(gq[3]));
    sprite_bank2 #(.DEPTH(32768), .FILE("dragon_b4.mem")) u_d4 (.clk(clk), .addr_a(addr[14:0]), .addr_b(gaddr[14:0]), .idx_a(q[4]), .idx_b(gq[4]));
    sprite_bank2 #(.DEPTH(32768), .FILE("dragon_b5.mem")) u_d5 (.clk(clk), .addr_a(addr[14:0]), .addr_b(gaddr[14:0]), .idx_a(q[5]), .idx_b(gq[5]));
    sprite_bank2 #(.DEPTH(13089), .FILE("dragon_b6.mem")) u_d6 (.clk(clk), .addr_a(addr[14:0]), .addr_b(gaddr[14:0]), .idx_a(q[6]), .idx_b(gq[6]));
    reg [2:0] gbank_d;
    reg       g_on_d;
    always @(posedge clk) begin
        gbank_d <= gaddr[17:15];
        g_on_d  <= g_in_r & g_insp;
    end

    reg [2:0] bank_d, form_d;
    reg       on_d, flash_d;
    always @(posedge clk) begin
        bank_d  <= addr[17:15];
        form_d  <= form_r;
        on_d    <= in_r & in_sp;
        flash_d <= flash_r;
    end

    // ---- stage 3: pick the bank and the palette (combinational) ---------------
    reg [11:0] pal1 [0:15];
    reg [11:0] pal2 [0:15];
    reg [11:0] pal3 [0:15];
    reg [11:0] pal4 [0:15];
    initial begin
        $readmemh("evo1_pal.mem", pal1);
        $readmemh("evo2_pal.mem", pal2);
        $readmemh("evo3_pal.mem", pal3);
        $readmemh("evo4_pal.mem", pal4);
    end

    wire [3:0] idx = (bank_d <= 3'd6) ? q[bank_d] : 4'd0;
    reg [11:0] rgb;
    always @* begin
        case (form_d)
            3'd2:    rgb = pal2[idx];
            3'd3:    rgb = pal3[idx];
            3'd4:    rgb = pal4[idx];
            default: rgb = pal1[idx];
        endcase
    end

    // flash: each channel half way to white, (c + 15) / 2
    wire [4:0] fr = {1'b0, rgb[11:8]} + 5'd15;
    wire [4:0] fg = {1'b0, rgb[7:4]}  + 5'd15;
    wire [4:0] fb = {1'b0, rgb[3:0]}  + 5'd15;

    wire [3:0] gidx = (gbank_d <= 3'd6) ? gq[gbank_d] : 4'd0;
    reg [11:0] grgb;
    always @* begin
        case (form_d)
            3'd2:    grgb = pal2[gidx];
            3'd3:    grgb = pal3[gidx];
            3'd4:    grgb = pal4[gidx];
            default: grgb = pal1[gidx];
        endcase
    end
    assign g_on  = g_on_d & (gidx != 4'd0);
    assign g_rgb = grgb;

    assign pixel_on = on_d & (idx != 4'd0);
    assign rgb_out  = flash_d ? {fr[4:1], fg[4:1], fb[4:1]} : rgb;
endmodule
