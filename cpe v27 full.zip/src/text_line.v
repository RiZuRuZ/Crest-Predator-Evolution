// text_line: draws a fixed string with font_rom
// Each character cell is 8x8 font pixels (5x7 glyph, left-aligned), scaled by 2^S.
// (X0, Y0) = top-left corner on screen. TEXT is an ASCII string of exactly N characters.
// Two register stages keep the logic short at 100 MHz. The output is 2 clocks late,
// which is safe: pixel_x/pixel_y change every 4 clocks (pix_ce) and pixel_mixer
// samples on the next pix_ce.
module text_line #(
    parameter X0 = 0,
    parameter Y0 = 0,
    parameter S  = 1,                      // scale = 2^S (0 = 1x, 1 = 2x, 2 = 4x)
    parameter N  = 4,
    parameter [8*N-1:0] TEXT = "TEXT"
)(
    input  wire       clk,
    input  wire [9:0] pixel_x,
    input  wire [9:0] pixel_y,
    output reg        pixel_on
);
    localparam W = N << (3 + S);
    localparam H = 8 << S;

    wire [10:0] rx     = {1'b0, pixel_x} - X0;
    wire [10:0] ry     = {1'b0, pixel_y} - Y0;
    wire        in_box = (pixel_x >= X0) && (pixel_x < X0 + W) &&
                         (pixel_y >= Y0) && (pixel_y < Y0 + H);
    wire [10:0] col    = in_box ? (rx >> (3 + S)) : 11'd0;

    // stage 1: which character, which glyph row / column
    reg       in_r;
    reg [7:0] ch_r;
    reg [2:0] row_r, px_r;
    always @(posedge clk) begin
        in_r  <= in_box;
        ch_r  <= TEXT[8*(N-1-col) +: 8];
        row_r <= ry >> S;
        px_r  <= rx >> S;
    end

    // stage 2: glyph lookup
    wire [4:0] bits;
    font_rom u_font (.ch(ch_r), .row(row_r), .bits(bits));
    always @(posedge clk)
        pixel_on <= in_r && (px_r < 3'd5) && (row_r < 3'd7) && bits[3'd4 - px_r];
endmodule
