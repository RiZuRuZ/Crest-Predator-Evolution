`timescale 1ns / 1ps
//==============================================================================
// fish_spawner - decides type, side and position of a newly spawned fish
//
// Interface follows the team work plan (Notion: "Spawn fish"):
//   in : clk, rst, spawn_tick, rand[15:0]
//   out: spawn_valid, fish_type[1:0], spawn_x, spawn_y
//   extra: spawn_dir (not in the work plan, see below)
//
// Behaviour
//   - When spawn_tick is high for one cycle, the module samples `rand` and
//     emits ONE spawn_valid pulse on the next cycle together with
//     fish_type / spawn_x / spawn_y / spawn_dir. Outputs hold their value
//     until the next spawn.
//   - Who decides WHEN to spawn (timer, max number of fish on screen, free
//     slot) is outside this module: it only reacts to spawn_tick.
//
// Everything is taken from ONE sample of `rand`, using disjoint bit fields,
// so it does not matter that consecutive LFSR outputs are correlated:
//     rand[1:0]   fish type   00,01 -> 0 (small, 50 %)
//                             10     -> 1 (medium, 25 %)
//                             11     -> 2 (large, 25 %)
//     rand[2]     direction   0 = enters at the left edge, swims right
//                             1 = enters at the right edge, swims left
//     rand[15:7]  y position  scaled into 0 .. VIEW_H - height (+ cam_y)
//   fish_type 3 = golden fish, about 1 spawn in 32 (rand[8:4] = 11111).
//
// Position rules (conventions.md: x,y = top-left corner)
//   - World coordinates (camera update): the fish appears just outside the
//     screen and swims in. dir 0 enters at the left edge of the view
//     (x = cam_x - width), dir 1 at the right edge (x = cam_x + VIEW_W),
//     both modulo WORLD_W because the map wraps around.
//   - spawn_y is inside the part of the world the camera shows now:
//     cam_y .. cam_y + VIEW_H - height
//   - spawn_y is never equal to the previous spawn_y ("no identical
//     consecutive positions")
//
// spawn_dir is an addition to the work-plan interface: without it the fish
// movement logic cannot know which way to swim. Leave it unconnected if the
// team decides all fish swim the same way (then tie dir 0 by setting
// FIXED_DIR = 1 below).
//
// Fish sizes are the sprite sizes (fish-sprites.md); keep them identical to fish_pool.
//==============================================================================
module fish_spawner #(
    parameter WORLD_W  = 1920,
    parameter VIEW_W   = 640,
    parameter VIEW_H   = 480,
    // fish sprite sizes in pixels (type 0 = small, 1 = medium, 2 = large; fish-sprites.md)
    parameter W0 = 31, H0 = 27,
    parameter W1 = 52, H1 = 42,
    parameter W2 = 93, H2 = 52,
    // 1 = all fish enter from the left and swim right (ignore rand[2])
    parameter FIXED_DIR = 0
) (
    input  wire        clk,          // CLK100MHZ
    input  wire        rst,          // active-high, synchronous
    input  wire        spawn_tick,   // 1-cycle request to spawn one fish
    input  wire [15:0] rand,         // random value (lfsr16.rnd)
    input  wire [10:0] cam_x,        // camera (screen top-left in the world)
    input  wire [9:0]  cam_y,
    output reg         spawn_valid,  // 1-cycle pulse, outputs below are valid
    output reg  [1:0]  fish_type,    // 0 small, 1 medium, 2 large
    output reg  [10:0] spawn_x,      // top-left x (world)
    output reg  [9:0]  spawn_y,      // top-left y (world)
    output reg         spawn_dir     // 0 = swim right, 1 = swim left
);

    // ---- fish type from rand[1:0]; rand[8:4] = 11111 (1 in 32) -> golden fish ----
    // (golden rate is a PLACEHOLDER; the work plan only says "very rare"; was 1 in 64)
    wire       golden = (rand[8:4] == 5'b11111);
    wire [1:0] ftype = golden          ? 2'd3 :
                       (~rand[1])      ? 2'd0 :     // 00, 01
                       (~rand[0])      ? 2'd1 :     // 10
                                         2'd2;      // 11

    // ---- size of the chosen type -------------------------------------------
    reg [9:0] w, h;
    always @* begin
        case (ftype)
            2'd0:    begin w = W0; h = H0; end
            2'd1:    begin w = W1; h = H1; end
            2'd3:    begin w = 10'd44; h = 10'd35; end      // golden fish sprite
            default: begin w = W2; h = H2; end
        endcase
    end

    // ---- y: scale a 9-bit random number into 0 .. VIEW_H - h (then + cam_y) --
    // range = number of legal y values. floor(r9 * range / 512) <= range - 1.
    wire [9:0]  range = VIEW_H + 1 - h;
    wire [18:0] prod  = rand[15:7] * range;
    wire [9:0]  y_raw = prod[18:9];

    // never repeat the previous y (range is always >= 2 for sane sizes)
    reg  [9:0] last_y;
    wire [9:0] y_next = (y_raw != last_y) ? y_raw :
                        (y_raw == range - 1) ? (y_raw - 1'b1) : (y_raw + 1'b1);

    // ---- direction and x ---------------------------------------------------
    wire dir_next = (FIXED_DIR != 0) ? 1'b0 : rand[2];
    wire [12:0] x_left  = {2'b00, cam_x} + WORLD_W - w;     // just left of the view
    wire [12:0] x_right = {2'b00, cam_x} + VIEW_W;          // just right of the view
    wire [12:0] x_l_m   = (x_left  >= WORLD_W) ? x_left  - WORLD_W : x_left;
    wire [12:0] x_r_m   = (x_right >= WORLD_W) ? x_right - WORLD_W : x_right;
    wire [10:0] x_next  = dir_next ? x_r_m[10:0] : x_l_m[10:0];

    always @(posedge clk) begin
        if (rst) begin
            spawn_valid <= 1'b0;
            fish_type   <= 2'd0;
            spawn_x     <= 11'd0;
            spawn_y     <= 10'd0;
            spawn_dir   <= 1'b0;
            last_y      <= 10'd0;
        end else begin
            spawn_valid <= spawn_tick;
            if (spawn_tick) begin
                fish_type <= ftype;
                spawn_x   <= x_next;
                spawn_y   <= cam_y + y_next;
                spawn_dir <= dir_next;
                last_y    <= y_next;
            end
        end
    end

endmodule
