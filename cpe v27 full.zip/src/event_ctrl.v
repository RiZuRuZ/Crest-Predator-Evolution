// event_ctrl: mini game events between the boss fights (v20)
//
// Every PERIOD ticks of normal play (fixed, not random) an event starts. The events take
// turns: spear dodge (spear_game) -> arrows (arrow_game) -> timing bar (timing_game) ->
// spear dodge ...
// FSM: IDLE -> BANNER -> GAME -> RESULT -> IDLE
//   IDLE    counts PERIOD ticks (only while `en`: no boss fight). When the time is up
//           and the giant shark is out (`hold`: warning or passing), it waits until the
//           shark has gone, so an event never overlaps the shark.
//   BANNER  BANNER_T ticks: "EVENT!" + the name of the game; `clear` (1 clk) at the
//           start removes the flying harpoons
//   GAME    the mini game runs until its `done`:
//             spear  ok when it ends with fewer than SPEAR_HITS hits; the SPEAR_HITS-th
//                    hit stops it at once (spear_stop) and fails (hits cost no hearts)
//             arrow  ok = arrow_ok (fewer than 3 misses)
//             timing ok = tim_ok (5 hits before the time bar is empty)
//   RESULT  RESULT_T ticks: CLEAR! or FAILED; then a failed event darkens the map for
//           DARK_T ticks (only a light circle around the player, boss_fx)
// v21 rating of the result (shown on RESULT, `rating`):
//             PERFECT       GREAT        GOOD         FAIL
//   spear     0 hits        1 hit        2 hits       3 hits (3 patterns, ~18 s)
//   arrow     0 misses      1-2          3+           v25: 5 / 6 / 7+ (16 / 24 / 28 notes)
//   timing    0 misses      1            2+           time over
//   PERFECT / GREAT: `reward_p` (+1 heart and the speed boost, top.v) when the event ends;
//   GOOD: nothing; FAIL: the dark map.
// `busy` (BANNER, GAME, RESULT) freezes everything outside the mini game (top.v).
// Leaving `en` (the boss fight starts) ends everything at once.
// PLACEHOLDERS: PERIOD, BANNER_T, RESULT_T, DARK_T, SPEAR_HITS.
module event_ctrl #(
    parameter PERIOD     = 3000,    // 50 s
    parameter BANNER_T   = 120,     // 2 s
    parameter RESULT_T   = 90,      // 1.5 s
    parameter DARK_T     = 1200,    // 20 s
    parameter SPEAR_HITS = 3
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       tick,         // game tick (60 Hz, only while playing)
    input  wire       en,           // no boss fight
    input  wire       hold,         // giant shark warning / passing
    input  wire       spear_done,   // 1-clk pulses from the mini games
    input  wire       spear_hurt,
    input  wire       arrow_done,
    input  wire       arrow_ok,
    input  wire [4:0] arrow_misses,  // v21
    input  wire       tim_done,
    input  wire       tim_ok,
    input  wire [2:0] tim_misses,    // v21
    output wire       busy,
    output wire [1:0] phase,        // 0 idle, 1 banner, 2 game, 3 result
    output reg  [1:0] kind,         // 0 spear, 1 arrow, 2 timing
    output reg        ok,           // result of the last event (not FAIL)
    output reg  [2:0] rating,       // v21: 0 FAIL, 2 GOOD, 3 GREAT, 4 PERFECT
    output reg  [1:0] hits,         // spear hits in this event
    output wire       dark,
    output reg        clear,        // 1-clk: an event starts (banner)
    output reg        spear_start,  // 1-clk starts / stop
    output reg        spear_stop,
    output reg        arrow_start,
    output reg        tim_start,
    output reg        pass_p,       // 1-clk: an event was cleared
    output reg        fail_p,       // 1-clk: an event was failed
    output reg        reward_p      // 1-clk: v21 PERFECT / GREAT reward
);
    localparam [1:0] S_IDLE = 2'd0, S_BANNER = 2'd1, S_GAME = 2'd2, S_RESULT = 2'd3;
    reg [1:0]  st;
    reg [11:0] t;
    reg [10:0] dark_t;

    assign phase = st;
    assign busy  = (st != S_IDLE);
    assign dark  = (dark_t != 11'd0);

    always @(posedge clk) begin
        clear <= 1'b0; spear_start <= 1'b0; spear_stop <= 1'b0; arrow_start <= 1'b0;
        tim_start <= 1'b0; pass_p <= 1'b0; fail_p <= 1'b0; reward_p <= 1'b0;
        if (rst) begin
            st <= S_IDLE; t <= PERIOD; dark_t <= 11'd0; kind <= 2'd0; ok <= 1'b0; hits <= 2'd0;
            rating <= 3'd0;
        end else if (!en) begin
            st <= S_IDLE; dark_t <= 11'd0;
        end else begin
            case (st)
            S_IDLE: if (tick) begin
                if (dark_t != 11'd0) dark_t <= dark_t - 11'd1;
                if (t != 12'd0) t <= t - 12'd1;
                else if (!hold) begin
                    st <= S_BANNER; t <= BANNER_T; clear <= 1'b1;
                end
            end
            S_BANNER: if (tick) begin
                if (t != 12'd0) t <= t - 12'd1;
                else begin
                    st <= S_GAME; hits <= 2'd0;
                    case (kind)
                        2'd0:    spear_start <= 1'b1;
                        2'd1:    arrow_start <= 1'b1;
                        default: tim_start   <= 1'b1;
                    endcase
                end
            end
            S_GAME: begin
                if (kind == 2'd0) begin
                    if (spear_hurt) begin
                        if (hits == SPEAR_HITS - 1) begin
                            hits <= hits + 2'd1; spear_stop <= 1'b1;
                            ok <= 1'b0; rating <= 3'd0; st <= S_RESULT; t <= RESULT_T;
                        end else hits <= hits + 2'd1;
                    end else if (spear_done) begin
                        ok <= 1'b1; st <= S_RESULT; t <= RESULT_T;
                        rating <= (hits == 2'd0) ? 3'd4 : (hits == 2'd1) ? 3'd3 : 3'd2;
                    end
                end else if (kind == 2'd1) begin
                    if (arrow_done) begin
                        ok <= arrow_ok; st <= S_RESULT; t <= RESULT_T;
                        rating <= !arrow_ok ? 3'd0 : (arrow_misses == 5'd0) ? 3'd4 :
                                  (arrow_misses <= 5'd2) ? 3'd3 : 3'd2;
                    end
                end else begin
                    if (tim_done) begin
                        ok <= tim_ok; st <= S_RESULT; t <= RESULT_T;
                        rating <= !tim_ok ? 3'd0 : (tim_misses == 3'd0) ? 3'd4 :
                                  (tim_misses == 3'd1) ? 3'd3 : 3'd2;
                    end
                end
            end
            default: if (tick) begin                       // S_RESULT
                if (t != 12'd0) t <= t - 12'd1;
                else begin
                    st <= S_IDLE; t <= PERIOD;
                    kind <= (kind == 2'd2) ? 2'd0 : kind + 2'd1;
                    if (ok) begin pass_p <= 1'b1; reward_p <= (rating >= 3'd3); end
                    else begin fail_p <= 1'b1; dark_t <= DARK_T; end
                end
            end
            endcase
        end
    end
endmodule
