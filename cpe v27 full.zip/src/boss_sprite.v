// boss_sprite: the boss (purple fire shark) drawn from its own ROM
//
// v22: all 6 frames (0..3 swim, 4 CHARGE, 5 LUNGE) of the 118 x 57 art, drawn as big as
// the v20 boss: 323 x 156 world px (x 2.737; a screen pixel maps back to sprite pixel
// * 94 / 256). The art has a dark purple inner outline (palette index 1) so the boss
// does not melt into the sea.
// ROM with row spans (like player_renderer / dragon_rows.mem), so 6 frames still fit
// in 3 RAMB36 (v21: 6 frames as full rectangles needed 137 / 135 RAMB36):
//   boss_rows.mem  6 x 57 = 342 entries {offset[28:14], x0[13:7], len[6:0]}
//                  row index = frame * 57 + y
//   boss_0.mem     23761 4-bit palette indexes (0 = transparent): pixel x of the row is
//                  inside the span when x0 <= x < x0 + len, at address offset + (x - x0)
//   (made by tools/build_boss.py: rows_board())
// The art faces right; `flipx` mirrors it (boss swims left), `flipy` turns it upside
// down (defeated).
// Palette boss_spr_pal.mem (16 x 12 bit). The colour mode changes it in logic:
//   0 normal, 1 red (warning blink), 2 phase 2 (redder), 3 phase 3 (crimson),
//   4 white flash (hit)
// Timing like player_renderer: world_x / world_y (clock 1) -> row table read (clock 2)
// -> pixel read (clock 3) -> palette (combinational).
// Position: top-left world x, and world y + 128 (so it may start above the world top).
module boss_sprite #(
    parameter WORLD_W = 1920
)(
    input  wire        clk,
    input  wire [10:0] world_x,
    input  wire [9:0]  world_y,
    input  wire        on,
    input  wire [10:0] x,            // top-left, world
    input  wire [10:0] y,            // top-left, world y + 128
    input  wire [2:0]  frame,        // 0..5
    input  wire        flipx,
    input  wire        flipy,
    input  wire [2:0]  mode,         // colour mode (see above)
    output wire        pixel_on,
    output wire [11:0] rgb_out
);
    localparam SW = 118, SH = 57;                   // stored size
    localparam DW = 323, DH = 156;                  // drawn size (x 94 / 256 back)

    // ---- stage 1: position inside the sprite, row table read --------------------------
    wire [10:0] wy = {1'b0, world_y} + 11'd128;
    wire [11:0] rx = (world_x >= x) ? (world_x - x) : ({1'b0, world_x} + WORLD_W - x);
    wire [10:0] ry = wy - y;
    wire        inside = on && (rx < DW) && (wy >= y) && (ry < DH);
    wire [16:0] mx  = rx[8:0] * 8'd94;
    wire [15:0] my  = ry[7:0] * 8'd94;
    wire [6:0]  sx0 = (mx[15:8] > 8'd117) ? 7'd117 : mx[14:8];   // stored x 0..117
    wire [5:0]  sy0 = my[13:8];                                 // stored y 0..56
    wire [6:0]  sx  = flipx ? (7'd117 - sx0) : sx0;
    wire [5:0]  sy  = flipy ? (6'd56 - sy0) : sy0;
    wire [8:0]  row = frame * 6'd57 + sy;                       // 0 .. 341

    (* ram_style = "distributed" *) reg [28:0] rows [0:341];
    initial $readmemh("boss_rows.mem", rows);
    reg [28:0] row_q;
    reg [6:0]  sx_r;
    reg        in_r;
    always @(posedge clk) begin
        row_q <= rows[row];
        sx_r  <= sx;
        in_r  <= inside;
    end

    // ---- stage 2: pixel address from the row span, pixel read ----------------------------
    wire [14:0] off   = row_q[28:14];
    wire [6:0]  x0    = row_q[13:7];
    wire [6:0]  len   = row_q[6:0];
    wire [6:0]  dxs   = sx_r - x0;                              // valid when sx_r >= x0
    wire        in_sp = (sx_r >= x0) && (dxs < len);
    wire [14:0] addr  = off + dxs;

    (* ram_style = "block" *) reg [3:0] rom0 [0:23760];
    initial $readmemh("boss_0.mem", rom0);
    reg [3:0] q0;
    reg       v_d;
    always @(posedge clk) begin
        q0  <= rom0[addr];
        v_d <= in_r & in_sp;
    end

    // ---- stage 3: palette + colour mode ----------------------------------------------
    reg [11:0] pal [0:15];
    initial $readmemh("boss_spr_pal.mem", pal);
    wire [3:0]  idx = q0;
    wire [11:0] c   = pal[idx];
    wire [3:0]  r = c[11:8], g = c[7:4], b = c[3:0];
    function [3:0] add_sat(input [3:0] a, input [3:0] n);
        add_sat = ({1'b0, a} + n > 5'd15) ? 4'hF : a + n;
    endfunction
    reg [11:0] cm;
    always @* begin
        case (mode)
            3'd1:    cm = {4'hF, 1'b0, g[3:1], 1'b0, b[3:1]};                  // red blink
            3'd2:    cm = {add_sat(r, 4'd4), g, b - {2'b00, b[3:2]}};          // phase 2
            3'd3:    cm = {add_sat(r, 4'd6), 1'b0, g[3:1], b - {1'b0, b[3:1]}}; // phase 3
            3'd4:    cm = {add_sat(r, 4'd8), add_sat(g, 4'd8), add_sat(b, 4'd8)}; // flash
            default: cm = c;
        endcase
    end
    assign pixel_on = v_d & (idx != 4'd0);
    assign rgb_out  = cm;
endmodule
