// current_ctrl: water currents that push the player now and then (work plan "current_ctrl")
//
// IDLE random (form 1: 10..20 s, 2: 8..16 s, 3: 6..12 s, 4: 5..10 s, difficulty)
// -> ACTIVE CUR_TICKS: pushes the player 1 px per tick in one of
// the 4 directions (added to the movement in top.v, so swimming against it slows the
// player or stops him). Form 2 (Current Rider) uses no oxygen while it is active.
// streak_on: light streaks drawn over the map that flow with the current, so the
// player can see it (world coordinates, no picture memory).
// PLACEHOLDERS: timings, push strength, streak look.
module current_ctrl #(
    parameter CUR_TICKS = 360            // 6 s
)(
    input  wire              clk,
    input  wire              rst,
    input  wire              tick_60hz,
    input  wire [15:0]       rand,
    input  wire [2:0]        form,
    input  wire [10:0]       world_x,
    input  wire [9:0]        world_y,
    output wire              active,
    output reg  signed [6:0] cur_dx,
    output reg  signed [6:0] cur_dy,
    output wire              streak_on
);
    reg [10:0] t;
    reg        on;
    reg [1:0]  dir;                      // 0 right, 1 left, 2 down, 3 up
    reg [6:0]  phase;
    assign active = on;

    always @(posedge clk) begin
        if (rst) begin on <= 1'b0; t <= 11'd900; dir <= 2'd0; phase <= 7'd0; end
        else if (tick_60hz) begin
            phase <= phase + 7'd3;
            if (t == 11'd0) begin
                on <= ~on;
                t  <= !on ? CUR_TICKS :
                      (form == 3'd4) ? 11'd300 + {2'b0, rand[8:0] % 9'd300} :
                      (form == 3'd3) ? 11'd360 + {2'b0, rand[8:0] % 9'd360} :
                      (form == 3'd2) ? 11'd480 + {2'b0, rand[8:0] % 9'd480} :
                                       11'd600 + {2'b0, rand[8:0] % 9'd600};
                if (!on) dir <= rand[11:10];
            end else t <= t - 11'd1;
        end
    end

    always @* begin
        cur_dx = 7'sd0; cur_dy = 7'sd0;
        if (on) case (dir)
            2'd0: cur_dx =  7'sd1;
            2'd1: cur_dx = -7'sd1;
            2'd2: cur_dy =  7'sd1;
            default: cur_dy = -7'sd1;
        endcase
    end

    // streaks: thin dashes on every 24th line, offset per line, moving with the flow
    wire        horiz = ~dir[1];
    wire [10:0] along = horiz ? world_x : {1'b0, world_y};
    wire [10:0] cross = horiz ? {1'b0, world_y} : world_x;
    wire [4:0]  lane  = cross[4:0];
    wire [5:0]  lane_id = cross[10:5];
    wire [10:0] moved = dir[0] ? (along + {4'd0, phase}) : (along - {4'd0, phase});
    wire [6:0]  pos   = moved[6:0] + {lane_id, 1'b0} * 7'd23;
    assign streak_on = on && (lane == 5'd7) && (pos < 7'd20);
endmodule
