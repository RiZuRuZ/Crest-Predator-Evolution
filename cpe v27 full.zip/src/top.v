// top: Crest Predator Evolution on the Nexys A7-100T
//   P1  VGA, buttons, player
//   P2  fish (spawner, pool, eat/score), 7-segment score + form
//   P3  dash, oxygen + LED bar, bubbles
//   evolution_fsm, hearts / hit recovery, game_fsm + text screens, HUD
//   camera: 1920 x 640 world that wraps left/right, the player stays in the middle
//   animated map, deco bubbles, dragon / fish sprites
//   hazards: sea mines, jellyfish (stun), harpoons, water currents, giant shark event
//   hiding seaweed + switch mini game, golden fish, skills of every form, Fever time
//   inputs: buttons, keyboard (WASD + Space), tilt (accelerometer), microphone
//   v18 difficulty EASY / NORMAL / HARD (left / right on TITLE), power-ups more often,
//       "what can I eat" icons bottom left
//   v27 background music: music_player (16-bit style: 4 wavetable voices + synthesised
//       drums, song data in BRAM music16.mem), mixed in sfx_player; PAUSE + centre = on / off
//   v25 easier grade (time 5 / 6 / 7 / 8 min, 3 per event, S 90 A 80 B 70), the clock
//       stops during an event, PERFECT ROAR only while the boss charges / lunges;
//       arrow game: +2 px (6 / 7 / 8), 16 / 24 / 28 notes every 26 / 20 / 16 ticks,
//       box +-28, FAIL at 5 / 6 / 7 misses (v24 music not used: v25 is built on v23)
//   v23 boss mine box / arming, PERFECT ROAR window, beam cross, faster arrows
//   v22 boss sprite: 6 frames (row spans) drawn 323 x 156 with a dark outline, v20 boxes,
//       arena back to 640 x 480 (no zoom); soul game patterns 2 / 3: white harpoons at the
//       pattern 1 speed every 40 ticks; giant shark shadow 530 x 256
//   v21 soul mini game = 3 patterns (spears, blue / orange bars, aimed beams), purple
//       heart in the boss fight; arrows: 16 notes, slow / fast, centre-button notes;
//       event rating PERFECT / GREAT (+1 heart, speed) / GOOD / FAIL (dark); new boss
//       sprite (boss_sprite, 4 frames, 3 RAMB36) and giant shark shadow; boss arena 800 x 600
//       (zoom x1.25); stunned red shark can be eaten; grade time 4 / 5 / 6 min
//   v20 mini game events every 50 s (event_ctrl: spears -> arrows -> timing bar, the
//       world stops, failed = dark map 20 s), grade F D C B A S (grade on OVER / WIN,
//       7-seg, BEST GRADE on TITLE), harpoons vanish when a mini game starts, boss sea
//       mine nearer the middle, no second shield, faster speed power-up, mini game speed
//       by difficulty, the giant shark warning ends when the boss fight starts
//   v19 PAUSE code U U D D L R L R = next form, Tidal Roar reach 160 -> 240 px,
//       the boss only sets off its sea mine with a charge / lunge (not while circling)
//   v17 boss tuning: form 4 dash i-frames, dragon x0.75 in the fight, mines always hit,
//       slower spear mini game, screen shake when the boss hits the edge
//   v16 developer code in PAUSE: U U D D L R L R = +50 EP (dev_cheat)
//   v15 boss fight at 500 EP (boss_ctrl): 3 phases, sea mines, bubbles, bite / shake free,
//   switch / spear / arrow mini games; the win comes when the boss is defeated
//
// Switches: SW0 pause, SW1 mute, SW2..SW13 hiding mini game, SW14 tilt control on,
//           SW15 microphone on (Tidal Roar, shorter stun)
module top (
    input  wire        CLK100MHZ,
    input  wire        CPU_RESETN,    // active-low on the board
    input  wire        BTNU,
    input  wire        BTND,
    input  wire        BTNL,
    input  wire        BTNR,
    input  wire        BTNC,          // start (menus) / dash (in game)
    input  wire        PS2_CLK,       // USB keyboard through the board's PS/2 emulation
    input  wire        PS2_DATA,
    input  wire [15:0] SW,
    output wire [15:0] LED,           // oxygen bar, or the mini game switches to flip
    output wire [2:0]  LED16,         // RGB {R,G,B}: form color
    output wire [2:0]  LED17,         // RGB {R,G,B}: warnings
    output wire        AUD_PWM,       // mono audio, driven low or high-Z only
    output wire        AUD_SD,        // audio amplifier enable
    output wire        M_CLK,         // PDM microphone
    input  wire        M_DATA,
    output wire        M_LRSEL,
    output wire        ACL_SCLK,      // ADXL362 accelerometer (SPI)
    output wire        ACL_MOSI,
    input  wire        ACL_MISO,
    output wire        ACL_CSN,
    output wire [3:0]  VGA_R,
    output wire [3:0]  VGA_G,
    output wire [3:0]  VGA_B,
    output wire        VGA_HS,
    output wire        VGA_VS,
    output wire [6:0]  SEG,           // 7-segment (active low), SEG[0] = CA ... SEG[6] = CG
    output wire        DP,
    output wire [7:0]  AN             // AN[0] = rightmost digit
);
    localparam WORLD_W = 1920;
    localparam WORLD_H = 640;

    // ======================= forward declarations ============================
    // (signals used before the block that drives them)
    wire signed [6:0] cur_dx, cur_dy;          // water current push
    wire        current_on;
    wire [3:0]  speed;                         // per form (form_skills)
    wire [7:0]  dash_len;
    wire        chain_en, oxy_hold, roar, roar_ready, fever, stealth, ghost;
    wire [4:0]  ring, zoom;
    wire [6:0]  gauge;
    wire        mic_loud;
    wire [4:0]  mic_level;
    wire        stunned;
    wire        shark_sweep, shark_warn, shark_pass, shark_active;
    wire [2:0]  game_state;
    wire        rs_hurt, rs_eaten, rs_near;          // red shark
    wire [10:0] rs_hcx;
    wire [9:0]  rs_hcy;
    wire        pu_got;                              // power-up taken
    wire [1:0]  pu_got_kind;
    reg         pshield;                             // shield power-up held
    reg  [8:0]  boost_t;                             // speed power-up time left
    wire        boost_on = (boost_t != 9'd0);
    // boss fight (v15)
    wire        boss_lock;                           // fight on: camera frozen, map paused
    wire        boss_grab, boss_freeze;              // player held / mini game (no moving)
    wire        boss_intro;                          // v21: BOSS! (the camera still follows)
    wire [10:0] boss_gx;                             // player centre while held (arena)
    wire [9:0]  boss_gy;
    wire        boss_start_p;                        // 1-clk: the fight starts
    wire        boss_small;                          // v17: form 4 drawn x0.75 in the fight
    wire        dodging;                             // v17: form 4 dash i-frames
    // the red shark is gone during the fight
    wire        rs_hurt_g  = rs_hurt  & ~boss_lock;
    wire        rs_eaten_g = rs_eaten & ~boss_lock;
    wire        harp_hold;                           // no harpoons (boss phase 1, mini games)
    // v20 mini game events
    wire        ev_busy;                             // banner / mini game / result: world frozen
    wire        ev_clear, ev_spear_start, ev_spear_stop, ev_arrow_start, ev_tim_start;
    wire        spear_start, arrow_start, boss_sw_start;   // boss mini game starts (harpoon clear)
    wire        ev_reward_p;                         // v21: PERFECT / GREAT event reward

    // ======================= clocks, reset, game flow ========================

    // The whole design runs on one 25 MHz clock made by an MMCM from the 100 MHz board
    // clock: 100 MHz x 10 / 40 = 25 MHz = the VGA pixel rate, so one clock = one pixel.
    // (At 100 MHz with a pixel every 4 clocks most of the picture and game logic could
    // not finish in one 10 ns clock: timing failed by up to 12 ns. At 25 MHz every path
    // has 40 ns.) Peripherals that count clocks get 25 MHz values below.
    wire clk_fb, clk_mmcm, mmcm_locked, clk;
    MMCME2_BASE #(
        .CLKIN1_PERIOD(10.0), .CLKFBOUT_MULT_F(10.0), .DIVCLK_DIVIDE(1),
        .CLKOUT0_DIVIDE_F(40.0)
    ) u_mmcm (
        .CLKIN1(CLK100MHZ), .CLKFBIN(clk_fb), .CLKFBOUT(clk_fb),
        .CLKOUT0(clk_mmcm), .LOCKED(mmcm_locked), .RST(1'b0), .PWRDWN(1'b0),
        .CLKFBOUTB(), .CLKOUT0B(), .CLKOUT1(), .CLKOUT1B(), .CLKOUT2(), .CLKOUT2B(),
        .CLKOUT3(), .CLKOUT3B(), .CLKOUT4(), .CLKOUT5(), .CLKOUT6()
    );
    BUFG u_bufg (.I(clk_mmcm), .O(clk));

    // Internal reset is active-high and synchronized to clk (held until the MMCM locks)
    reg [1:0] rst_ff = 2'b11;
    always @(posedge clk) rst_ff <= {rst_ff[0], ~CPU_RESETN | ~mmcm_locked};
    wire rst = rst_ff[1];

    // Game flow (game_fsm, further down):
    //   in_title : the game state is held in reset, so every game starts fresh (rule 4.3)
    //   playing  : only PLAY advances the game; PAUSE / OVER / WIN freeze it
    wire player_dead;
    wire oxy_empty;
    wire in_title, playing;
    wire game_rst = rst | in_title;

    wire pix_ce, tick_60hz_unused;
    clock_divider #(.PIX_DIV(1), .TICK_DIV(416667)) u_clkdiv (   // pix_ce = 1: every clock
        .clk(clk), .rst(rst), .pix_ce(pix_ce), .tick_60hz(tick_60hz_unused)
    );

    wire hsync, vsync, active_video;
    wire [9:0] pixel_x, pixel_y;
    vga_timing u_vga (
        .clk(clk), .rst(rst), .pix_ce(pix_ce),
        .hsync(hsync), .vsync(vsync), .x(pixel_x), .y(pixel_y),
        .active_video(active_video)
    );

    // The game tick is the start of vertical blanking (~60 Hz, once per frame)
    wire frame_tick = pix_ce && (pixel_x == 10'd0) && (pixel_y == 10'd480);
    reg  frame_tick_d;
    always @(posedge clk) frame_tick_d <= frame_tick;
    wire game_tick = frame_tick & playing;
    // v20: the world (everything except the mini games, the boss and the play time) stops
    // during an event
    wire wtick = game_tick & ~ev_busy;

    // Animation clock for the map and decorations: counts frames, never stops
    reg [9:0] anim_t;
    always @(posedge clk) begin
        if (rst)             anim_t <= 10'd0;
        else if (frame_tick) anim_t <= anim_t + 10'd1;
    end

    // Picture pipeline alignment (one clock = one pixel). pixel_x / pixel_y / sync come
    // from vga_timing at clock 0; world_x / world_y (camera) at clock 1. Every layer must
    // reach the compositor registers at clock 3 (the map, bg_rom, is ready at clock 4,
    // together with those registers). The sprite renderers take 2 clocks from world_x;
    // the other layers get delayed copies of the coordinates or extra output registers:
    //   px_d1 / py_d1   text-like layers (2-clock font lookup): popups, menu text, harpoon signs
    //   px_d3 / py_d3   layers that are plain comparisons: Fever frame, screen edge effects
    //   wx_d2 / wy_d2   world comparisons without registers: roar ring
    //   hs_d3 / vs_d3 / av_d3   sync and active, so the picture and sync stay together
    reg [9:0]  px_d1, py_d1, px_d2, py_d2, px_d3, py_d3;
    reg [10:0] wx_d1, wx_d2;
    reg [9:0]  wy_d1, wy_d2;
    reg [2:0]  hs_sr, vs_sr, av_sr;
    wire [10:0] world_x;
    wire [9:0]  world_y;
    always @(posedge clk) begin
        px_d1 <= pixel_x; py_d1 <= pixel_y;
        px_d2 <= px_d1;   py_d2 <= py_d1;
        px_d3 <= px_d2;   py_d3 <= py_d2;
        wx_d1 <= world_x; wy_d1 <= world_y;
        wx_d2 <= wx_d1;   wy_d2 <= wy_d1;
        hs_sr <= {hs_sr[1:0], hsync};
        vs_sr <= {vs_sr[1:0], vsync};
        av_sr <= {av_sr[1:0], active_video};
    end
    wire hs_d3 = hs_sr[2], vs_d3 = vs_sr[2], av_d3 = av_sr[2];

    // ======================= inputs ==========================================

    wire bu, bd, bl, br, bc;
    wire bu_p, bd_p, bl_p, br_p, bc_p;
    button_conditioner #(.DEBOUNCE_CYCLES(250000)) u_bu (.clk(clk), .rst(rst), .raw_btn(BTNU), .btn_sync(bu), .btn_pulse(bu_p));
    button_conditioner #(.DEBOUNCE_CYCLES(250000)) u_bd (.clk(clk), .rst(rst), .raw_btn(BTND), .btn_sync(bd), .btn_pulse(bd_p));
    button_conditioner #(.DEBOUNCE_CYCLES(250000)) u_bl (.clk(clk), .rst(rst), .raw_btn(BTNL), .btn_sync(bl), .btn_pulse(bl_p));
    button_conditioner #(.DEBOUNCE_CYCLES(250000)) u_br (.clk(clk), .rst(rst), .raw_btn(BTNR), .btn_sync(br), .btn_pulse(br_p));
    button_conditioner #(.DEBOUNCE_CYCLES(250000)) u_bc (.clk(clk), .rst(rst), .raw_btn(BTNC), .btn_sync(bc), .btn_pulse(bc_p));

    // Keyboard: W A S D move, Space dashes (same as the buttons)
    wire [7:0] ps2_code;
    wire       ps2_valid;
    ps2_receiver #(.TIMEOUT(50000)) u_ps2 (
        .clk(clk), .rst(rst), .ps2_clk(PS2_CLK), .ps2_data(PS2_DATA),
        .data(ps2_code), .valid(ps2_valid)
    );
    wire key_w, key_a, key_s, key_d, key_space;
    ps2_keys u_keys (
        .clk(clk), .rst(rst), .code(ps2_code), .valid(ps2_valid),
        .key_w(key_w), .key_a(key_a), .key_s(key_s), .key_d(key_d), .key_space(key_space)
    );
    reg [1:0] kad_d;
    always @(posedge clk) kad_d <= rst ? 2'b00 : {key_a, key_d};
    wire ka_p_t = key_a & ~kad_d[1], kd_p_t = key_d & ~kad_d[0];   // A / D presses (TITLE)
    reg key_space_d;
    always @(posedge clk) key_space_d <= rst ? 1'b0 : key_space;
    wire space_p = key_space & ~key_space_d;       // 1-cycle pulse on Space press

    // Switches (synchronized)
    reg [15:0] sw_m, sw_s;
    always @(posedge clk) begin
        sw_m <= SW;
        sw_s <= sw_m;
    end
    // v18 difficulty, chosen on TITLE with left / right (kept between games):
    // 0 EASY, 1 NORMAL, 2 HARD
    reg [1:0] diff;
    always @(posedge clk) begin
        if (rst) diff <= 2'd1;
        else if (in_title && (bl_p | ka_p_t) && diff != 2'd0) diff <= diff - 2'd1;
        else if (in_title && (br_p | kd_p_t) && diff != 2'd2) diff <= diff + 2'd1;
    end
    wire pause_sw = sw_s[0];
    wire mute_sw  = sw_s[1];
    wire tilt_sw  = sw_s[14];
    wire mic_sw   = sw_s[15];

    // Tilt control (SW14): the accelerometer works like the arrow buttons
    wire tilt_l, tilt_r, tilt_u, tilt_d;
    wire [7:0] tilt_x, tilt_y;
    // Axes measured on the board (2026-11-20): the sensor X axis is the screen up/down
    // direction and its Y axis is left/right, both reversed, so swap and invert both.
    // After this the HUD test line shows X + = right, Y + = down.
    accel_tilt #(.SWAP_XY(1), .INV_X(1), .INV_Y(1),
                 .HALF(13), .START(25000), .GAP(250000)) u_tilt (
        .clk(clk), .rst(rst),
        .sclk(ACL_SCLK), .mosi(ACL_MOSI), .miso(ACL_MISO), .csn(ACL_CSN),
        .tilt_l(tilt_l), .tilt_r(tilt_r), .tilt_u(tilt_u), .tilt_d(tilt_d),
        .ax_out(tilt_x), .ay_out(tilt_y)
    );

    // Microphone (SW15): loud sound = Tidal Roar (form 3) / faster stun recovery
    mic_level #(.THRESH(14), .DIV(5), .DECAY_BITS(18)) u_mic (   // THRESH 10 -> 14 (v12)
        .clk(clk), .rst(rst), .enable(mic_sw),
        .m_data(M_DATA), .m_clk(M_CLK), .m_lrsel(M_LRSEL),
        .level(mic_level), .loud(mic_loud)
    );

    // Stunned by a jellyfish: no movement and no dash
    // (boss fight: no moving while held in the jaws or in the spear / arrow mini game;
    //  the raw directions steer the heart in the spear mini game)
    wire raw_u = bu | key_w | (tilt_sw & tilt_u);
    wire raw_d = bd | key_s | (tilt_sw & tilt_d);
    wire raw_l = bl | key_a | (tilt_sw & tilt_l);
    wire raw_r = br | key_d | (tilt_sw & tilt_r);
    wire no_move = stunned | boss_freeze | boss_grab | ev_busy;
    wire go_u = ~no_move & raw_u;
    wire go_d = ~no_move & raw_d;
    wire go_l = ~no_move & raw_l;
    wire go_r = ~no_move & raw_r;
    wire dash_req = (bc_p | space_p) & playing & ~no_move;   // center button = start outside PLAY
    // key presses as pulses (arrow mini game)
    reg  [3:0] keys_d;
    always @(posedge clk) keys_d <= rst ? 4'd0 : {key_w, key_s, key_a, key_d};
    wire kw_p = key_w & ~keys_d[3], ks_p = key_s & ~keys_d[2];
    wire ka_p = key_a & ~keys_d[1], kd_p = key_d & ~keys_d[0];

    // ======================= player ==========================================

    wire signed [6:0] dx, dy;
    player_move u_move (
        .btn_u(go_u), .btn_d(go_d), .btn_l(go_l), .btn_r(go_r),
        .speed(speed), .current_dx(6'sd0), .dx(dx), .dy(dy)
    );

    // Dash and knockback are added to the player's own movement
    wire signed [6:0] knock_dx, knock_dy;
    wire signed [6:0] dash_dx, dash_dy;
    wire              dash_start, dashing, dash_cooling;   // cooling not used
    wire              oxy_can_dash;
    dash_controller u_dash (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick),
        .dash_req(dash_req), .move_dx(dx), .move_dy(dy), .can_pay(oxy_can_dash),
        .dash_len(dash_len), .chain_en(chain_en),
        .dash_start(dash_start), .dashing(dashing), .cooling(dash_cooling),
        .dash_dx(dash_dx), .dash_dy(dash_dy)
    );

    // + the water current (current_ctrl, environment section)
    wire signed [6:0] total_dx = dx + knock_dx + dash_dx + (boss_lock ? 7'sd0 : cur_dx);
    wire signed [6:0] total_dy = dy + knock_dy + dash_dy + (boss_lock ? 7'sd0 : cur_dy);

    // The player position (player_cx, player_cy) is the CENTER of the dragon sprite.
    // player_geom turns it into the sprite box (drawing, camera, bounds) and the
    // head + body hitbox (fish, bubbles, knockback) of the current form.
    wire [10:0] player_cx, spr_x, hb_x, next_x;
    wire [9:0]  player_cy, spr_y, hb_y, next_y;
    wire [7:0]  spr_w, spr_h, hb_w, hb_h;
    wire [2:0]  form;
    reg         facing_left;
    player_geom #(.WORLD_W(WORLD_W)) u_geom (
        .cx(player_cx), .cy(player_cy), .form(form), .facing_left(facing_left), .shrink(boss_small),
        .spr_w(spr_w), .spr_h(spr_h), .spr_x(spr_x), .spr_y(spr_y),
        .hb_x(hb_x), .hb_y(hb_y), .hb_w(hb_w), .hb_h(hb_h)
    );

    // Bounds work on the sprite box: x wraps, the sprite stays inside the world top/bottom.
    // next_y is the new sprite top, so the new center is next_y + half the height.
    player_bounds #(.WORLD_W(WORLD_W), .WORLD_H(WORLD_H)) u_bounds (
        .x(player_cx), .y(spr_y), .dx(total_dx), .dy(total_dy),
        .size_h(spr_h), .next_x(next_x), .next_y(next_y)
    );

    // Boss fight: the camera is frozen, the dragon stays inside the frozen view (the
    // arena); held in the jaws it sits at the boss mouth; in a mini game it does not move.
    wire [10:0] cam_x;
    wire [9:0]  cam_y;
    wire [9:0]  nxt_cy  = next_y + {3'd0, spr_h[7:1]};
    wire [11:0] rel_r   = {1'b0, next_x} + WORLD_W - cam_x;
    wire [10:0] rel_x   = boss_grab ? boss_gx : ((rel_r >= WORLD_W) ? rel_r - WORLD_W : rel_r[10:0]);
    wire [10:0] hw      = {4'd0, spr_w[7:1]};
    // (v21 tried an 800 x 600 arena with zoom x1.25; v22 is back to 640 x 480)
    wire [10:0] rel_xc  = (rel_x > 11'd1500) ? hw :                   // negative (wrapped)
                          (rel_x < hw) ? hw : (rel_x > 11'd640 - hw) ? 11'd640 - hw : rel_x;
    wire [11:0] arena_x = {1'b0, cam_x} + rel_xc;
    wire [10:0] clamp_x = (arena_x >= WORLD_W) ? arena_x - WORLD_W : arena_x[10:0];
    wire [9:0]  hh      = {3'd0, spr_h[7:1]};
    wire [9:0]  want_y  = boss_grab ? cam_y + boss_gy : nxt_cy;
    wire [9:0]  clamp_y = (want_y < cam_y + hh) ? cam_y + hh :
                          (want_y > cam_y + 10'd480 - hh) ? cam_y + 10'd480 - hh : want_y;
    wire [10:0] pos_nx  = !boss_lock ? next_x : boss_freeze ? player_cx : clamp_x;
    wire [9:0]  pos_ny  = !boss_lock ? nxt_cy : boss_freeze ? player_cy : clamp_y;
    player_position #(.INIT_X(960), .INIT_Y(320)) u_pos (     // world center
        .clk(clk), .rst(game_rst), .en(wtick),
        .next_x(pos_nx), .next_y(pos_ny),
        .player_x(player_cx), .player_y(player_cy)
    );

    // Facing follows the player's own left/right input (not knockback or dash)
    always @(posedge clk) begin
        if (game_rst)                    facing_left <= 1'b0;
        else if (wtick && dx < 0)    facing_left <= 1'b1;
        else if (wtick && dx > 0)    facing_left <= 1'b0;
    end

    // ======================= camera ==========================================

    reg  signed [3:0] shk_x, shk_y;        // screen shake (driven in "screen shake" below)
    // boss fight: frozen camera at zoom 1.0 (the arena = the view, 640 x 480)
    camera #(.WORLD_W(WORLD_W), .WORLD_H(WORLD_H)) u_cam (
        .clk(clk), .rst(rst), .update(frame_tick_d & ~boss_lock),
        .player_x(spr_x), .player_y(spr_y), .player_w(spr_w), .player_h(spr_h),
        .zoom(boss_lock ? 5'd16 : zoom), .pixel_x(pixel_x), .pixel_y(pixel_y),
        .shake_x(shk_x), .shake_y(shk_y),
        .cam_x(cam_x), .cam_y(cam_y), .world_x(world_x), .world_y(world_y)
    );

    // ======================= fish, eating, score, evolution ==================

    // Current form (1..4) comes from evolution_fsm, driven by the score (EP).
    // The sprite and hitbox size follow the form (player_geom).
    wire        evolve_pulse;
    wire [15:0] score;

    // Random source: free-running 16-bit LFSR (runs during TITLE too, so every game differs)
    wire [15:0] rnd;
    lfsr16 u_lfsr (
        .clk(clk), .rst(rst), .en(1'b1), .rnd(rnd)
    );

    wire        spawn_req, spawn_valid, spawn_dir;
    wire [1:0]  spawn_type;
    wire [10:0] spawn_x;
    wire [9:0]  spawn_y;
    fish_spawner #(.WORLD_W(WORLD_W)) u_spawner (
        .clk(clk), .rst(game_rst),
        .spawn_tick(spawn_req), .rand(rnd), .cam_x(cam_x), .cam_y(cam_y),
        .spawn_valid(spawn_valid), .fish_type(spawn_type),
        .spawn_x(spawn_x), .spawn_y(spawn_y), .spawn_dir(spawn_dir)
    );

    wire        fish_eat;                  // 1-cycle pulse: a fish was eaten
    wire [1:0]  fish_eat_type;
    wire        fish_hurt;                 // 1-cycle pulse: touched an uneatable fish
    wire [10:0] fish_hurt_cx;              // center of that fish, held after the pulse
    wire [9:0]  fish_hurt_cy;
    // NFISH fish at once (was 4, then 8); a new one every 40 ticks.
    // v14: 12 slots so a school (4..6 small fish) fits next to the other fish.
    localparam NFISH = 12;
    wire [NFISH-1:0]    fish_active;
    wire [2*NFISH-1:0]  fish_type_vec;
    wire [11*NFISH-1:0] fish_x_vec;
    wire [10*NFISH-1:0] fish_y_vec;
    wire [NFISH-1:0]    fish_dir_vec;      // 1 = swims left, drawn mirrored
    wire fish_near;                        // an edible fish is close: open the mouth
    // MARGIN 96 (was 64): school followers start up to 68 px further outside the view
    fish_pool #(.N(NFISH), .SPAWN_TICKS(40), .WORLD_W(WORLD_W), .WORLD_H(WORLD_H),
                .MARGIN(96)) u_pool (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick & ~boss_lock),
        .spawn_req(spawn_req),
        .spawn_valid(spawn_valid), .spawn_type(spawn_type),
        .spawn_x(spawn_x), .spawn_y(spawn_y), .spawn_dir(spawn_dir),
        .school_rnd(rnd[12:9]),
        .player_x(hb_x), .player_y(hb_y),
        .player_w(hb_w), .player_h(hb_h), .form(form), .cam_x(cam_x),
        .clear(shark_sweep | boss_start_p), .roar(roar), .roar_cx(player_cx), .roar_cy(player_cy),
        .eat(fish_eat), .eat_type(fish_eat_type), .hurt(fish_hurt), .near(fish_near),
        .hurt_cx(fish_hurt_cx), .hurt_cy(fish_hurt_cy),
        .active_vec(fish_active), .type_vec(fish_type_vec),
        .x_vec(fish_x_vec), .y_vec(fish_y_vec), .dir_vec(fish_dir_vec)
    );

    // EP 500 no longer wins: it starts the boss fight (boss_ctrl); the game is won when
    // the boss is defeated (boss_won)
    wire ep_full, boss_won;
    // v16 developer code: in PAUSE press U U D D L R L R (buttons or W S A D) = +50 EP
    // v19: in PAUSE, U U D D L R L R = straight to the next form (25 / 75 / 200 / 500 EP)
    wire cheat_hit;
    dev_cheat u_cheat (
        .clk(clk), .rst(game_rst), .en((game_state == 3'd2) & ~ev_busy),   // v20: not in an event
        .p_u(bu_p | kw_p), .p_d(bd_p | ks_p), .p_l(bl_p | ka_p), .p_r(br_p | kd_p),
        .hit(cheat_hit)
    );
    score_ctrl u_score (
        .clk(clk), .rst(game_rst),
        .eat(fish_eat), .fish_type(fish_eat_type), .bonus(rs_eaten_g), .double(fever),
        .cheat(1'b0), .jump(cheat_hit),
        .score(score), .win(ep_full)
    );
    reg ep_full_d;
    always @(posedge clk) ep_full_d <= game_rst ? 1'b0 : ep_full;
    assign boss_start_p = ep_full & ~ep_full_d;

    // FORM1 -> FORM4 at EP 25 / 75 / 200, never goes back
    evolution_fsm u_evo (
        .clk(clk), .rst(game_rst), .score(score),
        .form_state(form), .evolve_pulse(evolve_pulse)
    );

    // Evolve: for EVO_TICKS after a form change the dragon blinks and takes no damage
    localparam EVO_TICKS = 90;                // 1.5 s (work plan: 1-2 s) PLACEHOLDER
    reg  [6:0] evo_t;
    wire       evolving = (evo_t != 7'd0);
    always @(posedge clk) begin
        if (game_rst)                    evo_t <= 7'd0;
        else if (evolve_pulse)           evo_t <= EVO_TICKS;
        else if (wtick && evolving)  evo_t <= evo_t - 7'd1;
    end

    // Play time (counts only while playing) and the records (kept until board reset):
    // hi_score = best score, best_* = fastest win
    reg [5:0] t_sub, t_sec, best_sec;
    reg [6:0] t_min, best_min;
    reg [9:0] hi_score;
    reg       best_ok, ended_d;
    always @(posedge clk) begin
        if (game_rst) begin t_sub <= 6'd0; t_sec <= 6'd0; t_min <= 7'd0; end
        else if (wtick) begin                    // v25: the clock stops during an event
            if (t_sub == 6'd59) begin
                t_sub <= 6'd0;
                if (t_sec == 6'd59) begin
                    t_sec <= 6'd0;
                    if (t_min != 7'd99) t_min <= t_min + 7'd1;
                end else t_sec <= t_sec + 6'd1;
            end else t_sub <= t_sub + 6'd1;
        end
    end
    wire game_ended = (game_state == 3'd3) || (game_state == 3'd4);    // OVER / WIN
    always @(posedge clk) begin
        if (rst) begin
            hi_score <= 10'd0; best_ok <= 1'b0; best_min <= 7'd0; best_sec <= 6'd0; ended_d <= 1'b0;
        end else begin
            ended_d <= game_ended;
            if (game_ended && !ended_d) begin
                if (score[9:0] > hi_score) hi_score <= score[9:0];
                if (game_state == 3'd4 &&
                    (!best_ok || {t_min, t_sec} < {best_min, best_sec})) begin
                    best_ok <= 1'b1; best_min <= t_min; best_sec <= t_sec;
                end
            end
        end
    end

    // ======================= hearts ==========================================

    // Everything that costs a heart: biting fish, sea mines (forms 1..3), harpoons and the
    // giant shark. The centre of whatever hit is kept for the knockback; hit_taken comes
    // one clock after the hurt pulse, when the centre is already stored.
    wire        mine_hurt, mine_eaten, mine_boom, harp_hurt, shark_bite, jelly_sting;
    wire        shark_bite_g = shark_bite & ~boss_lock;
    wire [10:0] mine_cx, harp_cx, jelly_cx;
    wire [9:0]  mine_cy, harp_cy, jelly_cy;
    wire        boss_hurt, spear_hurt;
    wire [10:0] boss_hcx;                           // arena
    wire [9:0]  boss_hcy;
    wire [11:0] bh_r  = {1'b0, cam_x} + boss_hcx;
    wire [10:0] bh_wx = (bh_r >= WORLD_W) ? bh_r - WORLD_W : bh_r[10:0];
    // v20: nothing hurts during an event (the event counts its own spear hits); the spear
    // mini game costs hearts only in the boss fight
    wire        spear_hurt_b = spear_hurt & boss_lock;
    wire        hurt_any = ((fish_hurt | mine_hurt | harp_hurt | shark_bite_g | rs_hurt_g) & ~ev_busy) |
                           boss_hurt | spear_hurt_b;
    reg  [10:0] hit_src_x;
    reg  [9:0]  hit_src_y;
    always @(posedge clk) begin
        if (fish_hurt)       begin hit_src_x <= fish_hurt_cx; hit_src_y <= fish_hurt_cy; end
        else if (boss_hurt)  begin hit_src_x <= bh_wx;        hit_src_y <= cam_y + boss_hcy; end
        else if (spear_hurt_b) begin hit_src_x <= player_cx;    hit_src_y <= player_cy + 10'd8; end
        else if (rs_hurt_g)  begin hit_src_x <= rs_hcx;       hit_src_y <= rs_hcy;       end
        else if (mine_hurt)  begin hit_src_x <= mine_cx;      hit_src_y <= mine_cy;      end
        else if (harp_hurt)  begin hit_src_x <= harp_cx;      hit_src_y <= harp_cy;      end
        else if (shark_bite_g) begin hit_src_x <= player_cx;  hit_src_y <= player_cy + 10'd8; end
    end

    wire [2:0] hearts;                     // 5 in the boss fight
    wire       hit_taken, shield_used;
    wire       invuln, blink_hide;
    wire       shield;                     // EVO3 Tough Scales (form_skills)
    player_health u_health (
        .clk(clk), .rst(game_rst),
        .hurt(hurt_any), .invuln(invuln | evolving | dodging),
        .heart_up((pu_got && pu_got_kind == 2'd0) | ev_reward_p), .shield(shield | pshield),   // v21 event reward
        .diff(diff), .refill(boss_start_p), .big(boss_lock),
        .hearts(hearts), .dead(player_dead),
        .hit_taken(hit_taken), .shield_used(shield_used)
    );

    // Jellyfish sting: no heart, knockback + stun (5 s, twice as fast while shouting)
    wire       sting = jelly_sting & ~invuln & ~stunned & ~evolving & ~dodging & ~ev_busy;

    // v17 dodge (form 4): no damage while dashing and DODGE_TAIL ticks after the dash
    localparam DODGE_TAIL = 9;                         // 0.15 s PLACEHOLDER
    reg [4:0] dodge_t;
    always @(posedge clk) begin
        if (game_rst)                               dodge_t <= 5'd0;
        else if (dash_start && form == 3'd4)        dodge_t <= dash_len[4:0] + DODGE_TAIL;
        else if (wtick && dodge_t != 5'd0)      dodge_t <= dodge_t - 5'd1;
    end
    assign dodging = (dodge_t != 5'd0);
    reg  [8:0] stun_t;
    assign     stunned = (stun_t != 9'd0);
    always @(posedge clk) begin
        if (game_rst)                stun_t <= 9'd0;
        else if (sting)              stun_t <= 9'd300;      // PLACEHOLDER (work plan: 5 s)
        else if (wtick && stunned)
            stun_t <= (mic_loud && stun_t > 9'd1) ? stun_t - 9'd2 : stun_t - 9'd1;
    end

    hit_recovery #(.WORLD_W(WORLD_W)) u_recover (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick),
        .hit(hit_taken | sting),
        .player_x(hb_x), .player_y(hb_y), .player_w(hb_w), .player_h(hb_h),
        .hit_cx(sting ? jelly_cx : hit_src_x), .hit_cy(sting ? jelly_cy : hit_src_y),
        .invuln(invuln), .blink_hide(blink_hide),
        .knock_dx(knock_dx), .knock_dy(knock_dy)
    );

    // ======================= bubbles and oxygen ==============================

    wire        bubble_eat;
    wire [2:0]  bub_active;
    wire [32:0] bub_x_vec;
    wire [29:0] bub_y_vec;
    bubble_ctrl #(.WORLD_W(WORLD_W), .WORLD_H(WORLD_H)) u_bubbles (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick),
        .rand({rnd[7:0], rnd[15:8]}),      // other bit order than fish_spawner
        .cam_x(cam_x),
        .player_x(hb_x), .player_y(hb_y), .player_w(hb_w), .player_h(hb_h),
        .eat(bubble_eat), .active_vec(bub_active), .x_vec(bub_x_vec), .y_vec(bub_y_vec)
    );

    // EVO1 Bubble Breath: bubbles refill twice as much in form 1
    wire [9:0] oxygen;
    oxygen_ctrl u_oxy (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick), .diff(diff),
        .dash_start(dash_start), .bubble_eat(bubble_eat), .double_refill(form == 3'd1),
        .hold(oxy_hold | boss_lock), .penalty(mine_eaten),
        .oxygen(oxygen), .empty(oxy_empty), .can_dash(oxy_can_dash)
    );
    wire oxy_low = (oxygen < 10'd240);     // last quarter

    // ======================= game flow =======================================

    game_fsm u_game (
        .clk(clk), .rst(rst),
        .start(bc_p), .pause_sw(pause_sw),
        .dead(player_dead | oxy_empty), .win(boss_won),
        .state(game_state), .in_title(in_title), .playing(playing)
    );

    // ======================= skills of the forms =============================

    form_skills u_skills (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick),
        .form(form), .moving((dx != 7'sd0) || (dy != 7'sd0)), .dashing(dashing),
        .current_on(current_on), .mic_loud(mic_loud), .fish_eat(fish_eat),
        .shield_used(shield_used & ~pshield),        // the power-up shield is used first
        .boost(boost_on),
        .speed(speed), .stealth(stealth), .dash_len(dash_len), .chain_en(chain_en),
        .ghost(ghost), .oxy_hold(oxy_hold), .roar(roar), .ring(ring),
        .roar_ready(roar_ready), .shield(shield), .fever(fever), .gauge(gauge), .zoom(zoom)
    );

    // ======================= environment and hazards =========================

    wire streak_on0;
    current_ctrl u_current (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick), .rand({rnd[3:0], rnd[15:4]}),
        .form(form), .world_x(world_x), .world_y(world_y),
        .active(current_on), .cur_dx(cur_dx), .cur_dy(cur_dy), .streak_on(streak_on0)
    );
    // the streaks are combinational on world_x (clock 1): two more registers
    reg streak_on1, streak_on;
    always @(posedge clk) begin streak_on1 <= streak_on0; streak_on <= streak_on1; end

    // Safe box around the player where no mine / jellyfish may appear: half the sprite
    // + 90 px on x, half the sprite + 80 px on y (form 1: 126 x 100, form 4: 175 x 133)
    wire [8:0]  safe_x = {2'd0, spr_w[7:1]} + 9'd90;
    wire [8:0]  safe_y = {2'd0, spr_h[7:1]} + 9'd80;

    wire [2:0]  mine_on_v, boom_on_v;
    wire [32:0] mine_x_v, mine_y_v, boom_x_v, boom_y_v;
    wire [8:0]  mine_f_v, boom_f_v;
    mine_field #(.WORLD_W(WORLD_W)) u_mines (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick), .rand({rnd[10:0], rnd[15:11]}),
        .cam_x(cam_x), .cam_y(cam_y),
        .player_x(hb_x), .player_y(hb_y), .player_w(hb_w), .player_h(hb_h),
        .form(form), .diff(diff), .sweep(shark_sweep | boss_start_p), .pause(shark_active | boss_lock),
        .player_cx(player_cx), .player_cy(player_cy), .safe_x(safe_x), .safe_y(safe_y),
        .hurt(mine_hurt), .eaten(mine_eaten), .boom(mine_boom),
        .hit_cx(mine_cx), .hit_cy(mine_cy),
        .mine_vec(mine_on_v), .x_vec(mine_x_v), .y_vec(mine_y_v), .frame_vec(mine_f_v),
        .boom_vec(boom_on_v), .bx_vec(boom_x_v), .by_vec(boom_y_v), .bframe_vec(boom_f_v)
    );

    wire [3:0]  jelly_on_v;
    wire [43:0] jelly_x_v, jelly_y_v;
    wire [11:0] jelly_f_v;
    jelly_field #(.WORLD_W(WORLD_W), .WORLD_H(WORLD_H), .ROAR_R(240)) u_jelly (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick), .rand({rnd[5:0], rnd[15:6]}),
        .cam_x(cam_x), .cam_y(cam_y),
        .player_x(hb_x), .player_y(hb_y), .player_w(hb_w), .player_h(hb_h),
        .player_cx(player_cx), .player_cy(player_cy), .safe_x(safe_x), .safe_y(safe_y),
        .sweep(shark_sweep | boss_start_p), .pause(shark_active | boss_lock), .form(form), .diff(diff), .roar(roar),
        .sting(jelly_sting), .hit_cx(jelly_cx), .hit_cy(jelly_cy),
        .active_vec(jelly_on_v), .x_vec(jelly_x_v), .y_vec(jelly_y_v), .frame_vec(jelly_f_v)
    );

    // Harpoon volleys: form + 1 harpoons at once (difficulty), sometimes one homing
    localparam NHARP = 5;
    wire        harp_warn, harp_fly, harp_homing, harp_locked;
    wire [6:0]  harp_warn_t;
    wire [10:0] harp_aim_x;
    wire [9:0]  harp_aim_y;
    wire [NHARP-1:0]    harp_lane, harp_vert, harp_back;
    wire [11*NHARP-1:0] harp_lx_v, harp_x_v, harp_y_v;
    wire [10*NHARP-1:0] harp_ly_v;
    wire [2:0]  harp_f;
    harpoon_ctrl #(.N(NHARP), .WORLD_W(WORLD_W), .WORLD_H(WORLD_H)) u_harpoon (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick), .rand({rnd[12:0], rnd[15:13]}),
        .form(form), .diff(diff), .pause(shark_active | harp_hold),
        // v20: every mini game (boss or event) and the boss start remove the harpoons
        .clear(ev_clear | spear_start | arrow_start | boss_sw_start | boss_start_p),
        .wide(~boss_lock & (zoom != 5'd16)),                    // v21: 800 x 600 view (Fever)
        .cam_x(cam_x), .cam_y(cam_y), .player_cx(player_cx), .player_cy(player_cy),
        .player_x(hb_x), .player_y(hb_y), .player_w(hb_w), .player_h(hb_h),
        .hurt(harp_hurt), .hit_cx(harp_cx), .hit_cy(harp_cy),
        .warn_on(harp_warn), .fly_on(harp_fly), .warn_t(harp_warn_t),
        .homing(harp_homing), .locked(harp_locked), .aim_x(harp_aim_x), .aim_y(harp_aim_y),
        .lane_on(harp_lane), .vert(harp_vert), .back(harp_back),
        .line_x_vec(harp_lx_v), .line_y_vec(harp_ly_v),
        .hx_vec(harp_x_v), .hy_vec(harp_y_v), .frame(harp_f)
    );

    // Red shark: one in the map from form 2; forms 2, 3 must avoid it, form 4 eats it (+100)
    wire        rs_on;
    wire [10:0] rs_x;
    wire [9:0]  rs_y;
    wire        rs_dir;
    wire [1:0]  rs_frame;
    red_shark #(.WORLD_W(WORLD_W), .WORLD_H(WORLD_H)) u_rshark (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick & ~boss_lock), .rand({rnd[9:0], rnd[15:10]}),
        .form(form), .diff(diff), .player_cx(player_cx), .player_cy(player_cy),
        .player_x(hb_x), .player_y(hb_y), .player_w(hb_w), .player_h(hb_h), .roar(roar),
        .active(rs_on), .x(rs_x), .y(rs_y), .dir(rs_dir), .frame(rs_frame),
        .hurt(rs_hurt), .eaten(rs_eaten), .hit_cx(rs_hcx), .hit_cy(rs_hcy), .near(rs_near)
    );

    // Power-ups: heart / shield / speed, one at a time in the view (none in the boss fight)
    wire        pu_on_r, pu_got_r;
    wire        pu_on  = pu_on_r  & ~boss_lock;
    assign      pu_got = pu_got_r & ~boss_lock;
    wire [1:0]  pu_kind;
    wire [10:0] pu_x, pu_y, pu_cx;
    wire [9:0]  pu_cy;
    powerup_ctrl #(.WORLD_W(WORLD_W)) u_pu (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick & ~boss_lock), .diff(diff), .rand({rnd[2:0], rnd[15:3]}),
        .cam_x(cam_x), .cam_y(cam_y), .player_cx(player_cx), .player_cy(player_cy),
        .safe_x(safe_x), .safe_y(safe_y),
        .player_x(hb_x), .player_y(hb_y), .player_w(hb_w), .player_h(hb_h),
        .hearts((hearts >= ((diff == 2'd0) ? 3'd4 : 3'd3)) ? 2'd3 : 2'd0), .anim(anim_t[5:0]),   // 3 = full
        .has_shield(pshield | shield),                                                   // v20
        .on(pu_on_r), .kind(pu_kind), .x(pu_x), .y(pu_y), .cx(pu_cx), .cy(pu_cy),
        .got(pu_got_r), .got_kind(pu_got_kind)
    );
    localparam BOOST_TICKS = 480;            // speed power-up: 8 s
    always @(posedge clk) begin
        if (game_rst) begin pshield <= 1'b0; boost_t <= 9'd0; end
        else begin
            if (pu_got && pu_got_kind == 2'd1)       pshield <= 1'b1;
            else if (shield_used)                    pshield <= 1'b0;
            if ((pu_got && pu_got_kind == 2'd2) || ev_reward_p) boost_t <= BOOST_TICKS;   // v21 event reward
            else if (wtick && boost_on)          boost_t <= boost_t - 9'd1;
        end
    end

    // Hiding seaweed (in front of the player); hidden = hitbox centre inside a spot
    wire        weed_on, in_seaweed;
    wire [11:0] weed_rgb;
    seaweed_field #(.WORLD_W(WORLD_W)) u_weed (
        .clk(clk), .world_x(world_x), .world_y(world_y), .anim_frame(anim_t[5:3]),
        .probe_x(hb_x + {4'd0, hb_w[7:1]}), .probe_y(hb_y + {3'd0, hb_h[7:1]}),
        .pixel_on(weed_on), .rgb_out(weed_rgb), .in_seaweed(in_seaweed)
    );

    // Giant shark event + switch mini game
    wire puzzle_start, puzzle_solved, puzzle_running, shadow_on0;
    wire [11:0] puzzle_led;
    shark_event u_shark (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick & ~boss_lock), .rand({rnd[7:0], rnd[15:8]} ^ rnd),
        .clear(boss_start_p),                                   // v20: no warning left in the fight
        .in_seaweed(in_seaweed), .solved(puzzle_solved), .stealth(stealth), .form(form), .diff(diff),
        .pixel_x(pixel_x), .pixel_y(pixel_y),
        .warn(shark_warn), .pass(shark_pass), .active(shark_active),
        .sweep(shark_sweep), .bite(shark_bite), .puzzle_start(puzzle_start),
        .shadow_on(shadow_on0)
    );
    // the shadow is ready at clock 2: one more register
    reg shadow_on;
    always @(posedge clk) shadow_on <= shadow_on0 & ~boss_lock;
    // the boss uses the same switch puzzle (mini game 1); its start comes one clock after
    // the boss state changed, so `active` is already high
    wire boss_sw_active, boss_sw_hidden;
    reg  boss_sw_start_d;
    always @(posedge clk) boss_sw_start_d <= game_rst ? 1'b0 : boss_sw_start;
    switch_puzzle u_puzzle (
        .clk(clk), .rst(game_rst), .start(puzzle_start | boss_sw_start_d),
        .active(shark_active | boss_sw_active),
        .sw(sw_s[13:2]), .rand(rnd ^ {anim_t, 6'd0}), .blink(anim_t[3]),
        .led(puzzle_led), .solved(puzzle_solved), .running(puzzle_running)
    );


    // ======================= boss fight (v15) ================================
    // Arena coordinates = pixels of the frozen view (see boss_ctrl.v)
    wire [11:0] pa_r_x  = {1'b0, hb_x} + WORLD_W - cam_x;
    wire [10:0] ar_hb_x = (pa_r_x >= WORLD_W) ? pa_r_x - WORLD_W : pa_r_x[10:0];
    wire [9:0]  ar_hb_y = hb_y - cam_y;
    wire [11:0] pc_r_x  = {1'b0, player_cx} + WORLD_W - cam_x;
    wire [10:0] ar_cx   = (pc_r_x >= WORLD_W) ? pc_r_x - WORLD_W : pc_r_x[10:0];
    wire [9:0]  ar_cy   = player_cy - cam_y;

    // shout = PERFECT ROAR (rising edge of the loud level, SW15 on)
    reg  mic_loud_d;
    always @(posedge clk) mic_loud_d <= rst ? 1'b0 : mic_loud;
    wire mic_hit = mic_sw & mic_loud & ~mic_loud_d;

    // shake meter input per tick: accelerometer change beyond a dead zone of 8, plus
    // 12 for every button / key press (also works without the accelerometer)
    reg  [7:0] acc_px, acc_py;
    reg  [3:0] press_n;
    reg  [5:0] shake_in;
    wire [7:0] adx_s = tilt_x - acc_px;
    wire [7:0] ady_s = tilt_y - acc_py;
    wire [7:0] adx_a = adx_s[7] ? -adx_s : adx_s;
    wire [7:0] ady_a = ady_s[7] ? -ady_s : ady_s;
    wire [8:0] acc_d = adx_a + ady_a;
    wire [8:0] acc_v = (acc_d > 9'd8) ? (acc_d - 9'd8) >> 1 : 9'd0;
    wire       any_press = bu_p | bd_p | bl_p | br_p | bc_p | space_p | kw_p | ks_p | ka_p | kd_p;
    wire [9:0] shake_sum = acc_v + {press_n, 3'b000} + {press_n, 2'b00};       // + 12 per press
    always @(posedge clk) begin
        if (game_rst) begin
            acc_px <= 8'd0; acc_py <= 8'd0; press_n <= 4'd0; shake_in <= 6'd0;
        end else if (game_tick) begin
            acc_px <= tilt_x; acc_py <= tilt_y;
            shake_in <= (shake_sum > 10'd63) ? 6'd63 : shake_sum[5:0];
            press_n  <= any_press ? 4'd1 : 4'd0;
        end else if (any_press && press_n != 4'd15)
            press_n <= press_n + 4'd1;
    end

    wire        boss_on, boss_dir, boss_flipy, boss_warn, boss_tired;
    wire signed [11:0] boss_ax;
    wire signed [10:0] boss_ay;
    wire [2:0]  boss_frame;                         // v22: 0..5
    wire [1:0]  boss_phase;
    wire [2:0]  boss_pal;
    wire [3:0]  boss_hp;
    wire [7:0]  boss_meter;
    wire        boss_spear_on, boss_arrow_on;
    wire        eye_on, boss_bite, boss_dmg, boss_boom, boss_parry, boss_warn_start, boss_wall;
    wire [10:0] eye_x;
    wire [9:0]  eye_y;
    wire        bmine_on, bboom_on, bmine_arm;
    wire [10:0] bmine_x, bboom_x;
    wire [9:0]  bmine_y, bboom_y;
    wire [2:0]  bboom_f;
    wire [6:0]  bbub_on;
    wire [76:0] bbub_x;
    wire [69:0] bbub_y;
    wire        spear_done, arrow_done, arrow_ok;
    boss_ctrl u_boss (
        .clk(clk), .rst(game_rst), .tick(game_tick), .rand(rnd), .start(boss_start_p), .diff(diff),
        .p_x(ar_hb_x), .p_y(ar_hb_y), .p_w(hb_w), .p_h(hb_h), .p_cx(ar_cx), .p_cy(ar_cy),
        .mic_hit(mic_hit), .p_dodge(dodging), .shake_in(shake_in), .sw_solved(puzzle_solved),
        .spear_done(spear_done & boss_lock), .arrow_done(arrow_done & boss_lock), .arrow_ok(arrow_ok),
        .lock(boss_lock), .on(boss_on), .ax(boss_ax), .ay(boss_ay), .dir(boss_dir),
        .frame(boss_frame), .pal(boss_pal), .flipy(boss_flipy), .hp(boss_hp), .phase(boss_phase),
        .warn(boss_warn), .tired(boss_tired), .intro(boss_intro),
        .grab(boss_grab), .grab_x(boss_gx), .grab_y(boss_gy), .grab_meter(boss_meter),
        .sw_active(boss_sw_active), .sw_hidden(boss_sw_hidden),
        .sw_start(boss_sw_start), .spear_start(spear_start), .arrow_start(arrow_start),
        .spear_on(boss_spear_on), .arrow_on(boss_arrow_on),
        .eye_on(eye_on), .eye_x(eye_x), .eye_y(eye_y),
        .hurt(boss_hurt), .hit_cx(boss_hcx), .hit_cy(boss_hcy),
        .bite(boss_bite), .dmg(boss_dmg), .boom(boss_boom), .parry(boss_parry),
        .warn_start(boss_warn_start), .wall(boss_wall), .won(boss_won),
        .mine_on(bmine_on), .mine_arm(bmine_arm), .mine_x(bmine_x), .mine_y(bmine_y),
        .boom_on(bboom_on), .boom_x(bboom_x), .boom_y(bboom_y), .boom_f(bboom_f),
        .bub_on(bbub_on), .bub_x_vec(bbub_x), .bub_y_vec(bbub_y)
    );
    assign boss_freeze = boss_spear_on | boss_arrow_on;
    assign boss_small  = boss_lock & (form == 3'd4);
    assign harp_hold   = boss_lock & ((boss_phase == 2'd1) | boss_freeze | boss_sw_active |
                                      boss_grab | boss_intro | ~boss_on);

    // boss sprite position in the world (top-left), for boss_sprite (v22: 323 x 156)
    wire [12:0] bw_r  = {2'b00, cam_x} + 2 * WORLD_W + {boss_ax[11], boss_ax} - 13'd161;
    wire [12:0] bw_x1 = (bw_r >= 3 * WORLD_W) ? bw_r - 3 * WORLD_W :
                        (bw_r >= 2 * WORLD_W) ? bw_r - 2 * WORLD_W :
                        (bw_r >= WORLD_W)     ? bw_r - WORLD_W : bw_r;
    wire [10:0] boss_wx = bw_x1[10:0];
    wire [10:0] boss_wy = {1'b0, cam_y} + {boss_ay[10], boss_ay[9:0]} + 11'd50;    // world y + 128 - 78

    // mini game 2: spears (phase 2) and 3: arrows (FINISH)
    wire spear_px, arrow_px, arrow_hit;
    wire [11:0] spear_rgb, arrow_rgb;
    wire [1:0]  arrow_rating;
    wire [5:0]  arrow_rate_t;
    wire [3:0]  arrow_combo;
    wire        spear_act, arrow_act;
    wire        spear_hit;                          // v21: any soul hit (event counts)
    wire [1:0]  spear_pat;
    wire [4:0]  arrow_misses;
    spear_game u_spear (
        .clk(clk), .rst(game_rst), .tick(game_tick), .rand(rnd), .start(spear_start | ev_spear_start),
        .stop(ev_spear_stop), .diff(diff), .boss(boss_lock),
        .go_u(raw_u), .go_d(raw_d), .go_l(raw_l), .go_r(raw_r),
        .px(px_d3), .py(py_d3),
        .active(spear_act), .done(spear_done), .hit(spear_hit), .hurt(spear_hurt),
        .pat(spear_pat), .purple(),
        .pixel_on(spear_px), .rgb(spear_rgb)
    );
    arrow_game u_arrow (
        .clk(clk), .rst(game_rst), .tick(game_tick), .rand(rnd), .start(arrow_start | ev_arrow_start),
        .diff(diff),
        .p_u(bu_p | kw_p), .p_d(bd_p | ks_p), .p_l(bl_p | ka_p), .p_r(br_p | kd_p),
        .p_c(bc_p | space_p),                                   // v21 centre note
        .px(px_d3), .py(py_d3),
        .active(arrow_act), .misses(arrow_misses), .done(arrow_done), .ok(arrow_ok),
        .rating(arrow_rating), .rate_t(arrow_rate_t), .combo(arrow_combo), .hit(arrow_hit),
        .pixel_on(arrow_px), .rgb(arrow_rgb)
    );

    // ======================= mini game events (v20) ===========================
    // event_ctrl: every 50 s outside the boss fight (waits for the giant shark), the games
    // take turns: spears -> arrows -> timing bar. The world stops (wtick) while it runs.
    wire        tim_px, tim_act, tim_done, tim_ok, tim_hit, tim_miss;
    wire [2:0]  tim_misses, ev_rating;
    wire [11:0] tim_rgb;
    wire [1:0]  ev_phase, ev_kind, ev_hits;
    wire        ev_ok, ev_dark, ev_pass_p, ev_fail_p;
    wire        any_btn_p = bc_p | space_p | bu_p | bd_p | bl_p | br_p | kw_p | ks_p | ka_p | kd_p;
    // the event gets the tick one clock late, so a giant shark warning that starts on the
    // same tick is already seen in `hold` (the event then waits for the shark)
    reg game_tick_d;
    always @(posedge clk) game_tick_d <= rst ? 1'b0 : game_tick;
    event_ctrl u_event (
        .clk(clk), .rst(game_rst), .tick(game_tick_d), .en(~boss_lock), .hold(shark_active),
        .spear_done(spear_done & ~boss_lock), .spear_hurt(spear_hit & ~boss_lock),
        .arrow_done(arrow_done & ~boss_lock), .arrow_ok(arrow_ok), .arrow_misses(arrow_misses),
        .tim_done(tim_done), .tim_ok(tim_ok), .tim_misses(tim_misses), .rating(ev_rating),
        .reward_p(ev_reward_p),
        .busy(ev_busy), .phase(ev_phase), .kind(ev_kind), .ok(ev_ok), .hits(ev_hits),
        .dark(ev_dark), .clear(ev_clear),
        .spear_start(ev_spear_start), .spear_stop(ev_spear_stop), .arrow_start(ev_arrow_start),
        .tim_start(ev_tim_start), .pass_p(ev_pass_p), .fail_p(ev_fail_p)
    );
    timing_game u_timing (
        .clk(clk), .rst(game_rst), .tick(game_tick), .rand(rnd), .start(ev_tim_start),
        .diff(diff), .press(any_btn_p), .px(px_d3), .py(py_d3),
        .active(tim_act), .done(tim_done), .ok(tim_ok), .hit_p(tim_hit), .miss_p(tim_miss),
        .misses(tim_misses),
        .pixel_on(tim_px), .rgb(tim_rgb)
    );
    wire        evh_on;
    wire [11:0] evh_rgb;
    ev_hud u_evhud (
        .clk(clk), .show(ev_busy & ~in_title), .phase(ev_phase), .kind(ev_kind), .ok(ev_ok),
        .rating(ev_rating),
        .hits(ev_hits), .blink(anim_t[3]), .pixel_x(pixel_x), .pixel_y(pixel_y),
        .on(evh_on), .rgb(evh_rgb)
    );

    // ======================= grade (v20) =====================================
    // WIN:  60 + time (v25: under 5 / 6 / 7 / 8 min: 20 / 15 / 10 / 5) + 3 per event cleared
    //       (v25, was 2) + 5 for an eat combo of 6 + mode (easy -10, hard +10)
    //       v25: S >= 90, A >= 80, B >= 70, else C (v20: 100 / 88 / 75)
    // OVER: D when the boss fight was reached, else F. The secret code = CHEAT (6).
    // grade: 0 F, 1 D, 2 C, 3 B, 4 A, 5 S, 6 CHEAT. PLACEHOLDER numbers.
    reg  [4:0] ev_pass;
    reg        combo6, cheat_used, boss_seen;
    wire [2:0] eat_combo;                            // driven by the combo counter (sound)
    always @(posedge clk) begin
        if (game_rst) begin
            ev_pass <= 5'd0; combo6 <= 1'b0; cheat_used <= 1'b0; boss_seen <= 1'b0;
        end else begin
            if (ev_pass_p && ev_pass != 5'd31) ev_pass <= ev_pass + 5'd1;
            if (eat_combo >= 3'd5)               combo6 <= 1'b1;         // 6 eats in a row
            if (cheat_hit)                       cheat_used <= 1'b1;
            if (boss_start_p)                    boss_seen <= 1'b1;
        end
    end
    wire [4:0] pt_time  = (t_min < 7'd5) ? 5'd20 : (t_min < 7'd6) ? 5'd15 :
                          (t_min < 7'd7) ? 5'd10 : (t_min < 7'd8) ? 5'd5  : 5'd0;   // v25: 5 / 6 / 7 / 8 min
    wire [6:0] pt_ev    = {2'b00, ev_pass} + {1'b0, ev_pass, 1'b0};                // v25: 3 per event
    wire [2:0] pt_combo = combo6 ? 3'd5 : 3'd0;
    wire [7:0] pt_sum   = 8'd60 + pt_time + pt_ev + pt_combo;
    wire [7:0] total    = (diff == 2'd0) ? pt_sum - 8'd10 : (diff == 2'd2) ? pt_sum + 8'd10 : pt_sum;
    wire [2:0] grade_n  = cheat_used           ? 3'd6 :
                          (game_state != 3'd4) ? (boss_seen ? 3'd1 : 3'd0) :
                          (total >= 8'd90)     ? 3'd5 : (total >= 8'd80) ? 3'd4 :
                          (total >= 8'd70)     ? 3'd3 : 3'd2;                    // v25
    reg  [2:0] grade, best_grade;
    reg        best_g_ok;
    always @(posedge clk) begin
        if (rst) begin
            grade <= 3'd0; best_grade <= 3'd0; best_g_ok <= 1'b0;
        end else if (game_ended && !ended_d) begin
            grade <= grade_n;
            if (grade_n != 3'd6 && (!best_g_ok || grade_n > best_grade)) begin
                best_grade <= grade_n; best_g_ok <= 1'b1;
            end
        end
    end
    // 7-segment letter for the grade: 16 A, 17 b, 18 C, 19 d, 20 F, 21 S, 22 -
    wire [4:0] grade_seg = (grade == 3'd0) ? 5'd20 : (grade == 3'd1) ? 5'd19 : (grade == 3'd2) ? 5'd18 :
                           (grade == 3'd3) ? 5'd17 : (grade == 3'd4) ? 5'd16 : (grade == 3'd5) ? 5'd21 : 5'd22;

    // PERFECT ROAR word: 1 s
    reg [5:0] parry_t;
    always @(posedge clk) begin
        if (game_rst)                         parry_t <= 6'd0;
        else if (boss_parry)                  parry_t <= 6'd60;
        else if (game_tick && parry_t != 0)   parry_t <= parry_t - 6'd1;
    end

    // ======================= board outputs ===================================

    sevenseg_driver #(.SHOW_FORM(1), .SCAN_BITS(12)) u_seg (
        .clk(clk), .rst(rst), .value(boss_lock ? {12'd0, boss_hp} : score),
        .form(in_title ? 5'd10 + {3'b000, diff} : game_ended ? grade_seg : {2'b00, form}),   // TITLE: E / n / H, v20: grade
        .an(AN), .seg(SEG), .dp(DP)
    );

    // LEDs: oxygen bar; during the hiding mini game the LEDs above SW2..SW13 show
    // which switches still have to be flipped
    wire [15:0] oxy_led;
    oxygen_led_bar u_oxy_led (.oxygen(oxygen), .led(oxy_led));
    // boss fight: LED15..LED4 = boss HP (from LED15 down), unless the switch puzzle runs
    wire [11:0] boss_led = ~(12'hFFF >> boss_hp);
    assign LED = puzzle_running ? {2'b00, puzzle_led, 2'b00} :
                 boss_lock      ? {boss_led, 4'b0000} : oxy_led;

    wire player_hidden = (in_seaweed | stealth | boss_sw_hidden) & playing;
    rgb_led_driver #(.FAST_BIT(21), .SLOW_BIT(23)) u_rgb (
        .clk(clk), .rst(rst), .form(form), .in_title(in_title),
        .invuln(invuln | boss_warn | boss_grab), .oxy_low(oxy_low & playing), .hidden(player_hidden),
        .stunned(stunned), .fever(fever | boss_tired),
        .led16(LED16), .led17(LED17)
    );

    // Sound: death / win on the rising edge of the sticky flags; alarm when the shark
    // warning or a harpoon warning starts; explosions and stings use the hit sound
    wire dead_any = player_dead | oxy_empty;
    reg  dead_d, win_d, swarn_d, hwarn_d;
    always @(posedge clk) begin
        dead_d  <= rst ? 1'b0 : dead_any;
        win_d   <= rst ? 1'b0 : boss_won;
        swarn_d <= rst ? 1'b0 : shark_warn;
        hwarn_d <= rst ? 1'b0 : harp_warn;
    end
    wire sfx_pwm;
    // ---- eat combo for the sound (v14) --------------------------------------------
    // Every eat within COMBO_TICKS of the last one raises the eat sound one step (max 7);
    // a longer pause starts again at step 0.
    localparam COMBO_TICKS = 90;                   // 1.5 s PLACEHOLDER
    reg  [6:0] combo_t;
    reg  [2:0] combo;
    assign eat_combo = (combo_t == 7'd0) ? 3'd0 : combo;
    // (v20: arrow hits of an event are not eats: no combo, bubble sound instead)
    wire       any_eat = fish_eat | mine_eaten | rs_eaten_g | boss_bite | (arrow_hit & boss_lock);
    always @(posedge clk) begin
        if (game_rst) begin
            combo_t <= 7'd0; combo <= 3'd0;
        end else if (any_eat) begin
            combo   <= (combo_t == 7'd0) ? 3'd0 : (combo == 3'd7) ? 3'd7 : combo + 3'd1;
            combo_t <= COMBO_TICKS;
        end else if (wtick && combo_t != 7'd0)
            combo_t <= combo_t - 7'd1;
    end

    // ---- v27 background music (music_player: 16-bit style, 5 tracks, BRAM song data) ----
    // TITLE / play / boss phase 1-2 / boss phase 3 / event + giant shark. PAUSE: the centre
    // button turns the music on / off (SW1 still mutes everything).
    reg music_on;
    always @(posedge clk) begin
        if (rst)                              music_on <= 1'b1;
        else if (game_state == 3'd2 && bc_p)  music_on <= ~music_on;
    end
    wire [2:0] mus_track = !music_on                    ? 3'd0 :
                           in_title                     ? 3'd1 :
                           game_ended                   ? 3'd0 :
                           boss_lock                    ? ((boss_phase == 2'd3) ? 3'd4 : 3'd3) :
                           (ev_busy | shark_active)     ? 3'd5 : 3'd2;
    wire signed [7:0] mus_lvl;
    music_player u_music (
        .clk(clk), .rst(rst), .track(mus_track), .run(game_state != 3'd2), .mus(mus_lvl)
    );

    sfx_player #(.CLK_SHIFT(2), .MS_CLKS(25000)) u_sfx (
        .clk(clk), .rst(rst), .mute(mute_sw),
        .eat(any_eat),
        .eat_step((combo_t == 7'd0) ? 3'd0 : (combo == 3'd7) ? 3'd7 : combo + 3'd1),
        .bubble(bubble_eat | roar | shield_used | pu_got | boss_parry | cheat_hit | tim_hit |
                (arrow_hit & ~boss_lock)),
        .evolve(evolve_pulse | ev_pass_p),
        .hit(hit_taken | mine_boom | sting | boss_dmg | boss_boom | tim_miss | ev_fail_p |
             (spear_hit & ~boss_lock)),
        .death(dead_any & ~dead_d), .win(boss_won & ~win_d),
        .alarm((shark_warn & ~swarn_d) | (harp_warn & ~hwarn_d) | boss_warn_start | boss_start_p | ev_clear),
        .mus(mus_lvl),                                          // v27 music
        .pwm_out(sfx_pwm)
    );
    assign AUD_PWM = sfx_pwm ? 1'bz : 1'b0;   // the board needs open-drain style driving
    assign AUD_SD  = 1'b1;

    // ======================= picture =========================================

    // Map background (camera world position -> ROM), animated. Ready one clock later
    // than the sprites (see the compositor below).
    wire [11:0] bg_rgb;
    bg_rom #(.WORLD_W(WORLD_W), .WORLD_H(WORLD_H)) u_bg (
        .clk(clk), .world_x(world_x), .world_y(world_y), .anim_t(anim_t),
        .debug_plant(1'b0), .rgb(bg_rgb)
    );

    wire        deco_on0;
    wire [11:0] deco_rgb0;
    deco_bubbles #(.WORLD_W(WORLD_W)) u_deco (
        .clk(clk), .rst(rst), .frame_tick(frame_tick), .cam_x(cam_x),
        .world_x(world_x), .world_y(world_y),
        .pixel_on(deco_on0), .rgb(deco_rgb0)
    );
    // deco_bubbles is ready at clock 2: one more register
    reg         deco_on;
    reg  [11:0] deco_rgb;
    always @(posedge clk) begin deco_on <= deco_on0; deco_rgb <= deco_rgb0; end

    // Player animation: idle / swim loop (frame 0..5). Eating: lunge + flash; hit: flash.
    wire [3:0] player_frame;
    wire [1:0] player_lunge;
    wire       player_flash;
    wire [1:0] player_anim_state;          // not used (debug)
    player_anim_fsm u_panim (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick),
        .moving((dx != 7'sd0) || (dy != 7'sd0)),
        .hurt(1'b0), .eat(fish_eat | mine_eaten | rs_eaten_g | boss_bite | arrow_hit),
        .near(fish_near | (rs_near & ~boss_lock) | boss_tired),   // hurt: red + shake below
        .frame(player_frame), .lunge(player_lunge), .flash(player_flash),
        .state(player_anim_state)
    );

    // The lunge only moves the drawing, in the facing direction (x wraps)
    // Getting hurt: the dragon shakes (+-2 px) and flashes red for HURT_TICKS.
    // Stunned: it sways +-1 px (and the stars circle over its head, stun_fx).
    localparam HURT_TICKS = 24;                    // 0.4 s PLACEHOLDER
    reg [4:0] hurt_t;
    always @(posedge clk) begin
        if (game_rst)                          hurt_t <= 5'd0;
        else if (hit_taken & ~shield_used)     hurt_t <= HURT_TICKS;
        else if (wtick && hurt_t != 5'd0)  hurt_t <= hurt_t - 5'd1;
    end
    wire hurting = (hurt_t != 5'd0);

    // ---- screen shake (v14) -------------------------------------------------------
    // The whole map shakes (the HUD does not): the camera adds shk_x / shk_y to world_x /
    // world_y for drawing only. A new jolt keeps the stronger amplitude:
    //   mine explosion  3 px for 24 ticks      evolve  2 px for 30 ticks
    //   giant shark passing: 1 px rumble the whole time
    // The last 8 ticks of a jolt shake 1 px (fade out). Direction is random per tick.
    reg  [4:0] shk_t;
    reg  [1:0] shk_a;
    wire [1:0] amp = (shk_t == 5'd0) ? ((shark_pass | boss_grab) ? 2'd1 : 2'd0) :
                     (shk_t < 5'd8)  ? 2'd1 : shk_a;
    always @(posedge clk) begin
        if (game_rst) begin
            shk_t <= 5'd0; shk_a <= 2'd0; shk_x <= 4'sd0; shk_y <= 4'sd0;
        end else begin
            if (mine_boom | boss_boom | boss_wall) begin     // v17: the boss hits the edge too
                shk_t <= 5'd24; shk_a <= 2'd3;
            end else if (boss_dmg && (shk_t == 5'd0 || shk_a <= 2'd2)) begin
                shk_t <= 5'd20; shk_a <= 2'd2;
            end else if (evolve_pulse && (shk_t == 5'd0 || shk_a <= 2'd2)) begin
                shk_t <= 5'd30; shk_a <= 2'd2;
            end else if (wtick && shk_t != 5'd0)
                shk_t <= shk_t - 5'd1;
            if (wtick || in_title) begin
                shk_x <= (in_title || amp == 2'd0) ? 4'sd0 :
                         rnd[0] ? $signed({2'b00, amp}) : -$signed({2'b00, amp});
                shk_y <= (in_title || amp == 2'd0) ? 4'sd0 :
                         rnd[1] ? $signed({2'b00, amp}) : -$signed({2'b00, amp});
            end
        end
    end

    wire [2:0] shake_p = hurting ? (hurt_t[1] ? 3'd4 : 3'd0) : stunned ? (anim_t[3] ? 3'd3 : 3'd1) : 3'd2;
    // (shake_p - 2 is the offset: -2..+2)

    // The lunge only moves the drawing, in the facing direction; the shake moves it
    // both ways (x wraps). All 13 bit: spr_x + 2 * WORLD_W keeps every sum positive.
    wire [12:0] draw_x_r = (facing_left ? ({2'b00, spr_x} + 2 * WORLD_W - player_lunge)
                                        : ({2'b00, spr_x} + 2 * WORLD_W + player_lunge))
                           + shake_p - 13'd2;
    wire [12:0] draw_x_1 = (draw_x_r >= 3 * WORLD_W) ? draw_x_r - 3 * WORLD_W :
                           (draw_x_r >= 2 * WORLD_W) ? draw_x_r - 2 * WORLD_W : draw_x_r - WORLD_W;
    wire [10:0] draw_x   = draw_x_1[10:0];

    // Afterimage (EVO2 Super Dash): where the dragon was 6 ticks ago
    reg [10:0] hist_x [0:5];
    reg [9:0]  hist_y [0:5];
    integer hi;
    always @(posedge clk) begin
        if (wtick) begin
            hist_x[0] <= draw_x; hist_y[0] <= spr_y;
            for (hi = 1; hi < 6; hi = hi + 1) begin
                hist_x[hi] <= hist_x[hi-1]; hist_y[hi] <= hist_y[hi-1];
            end
        end
    end

    wire        player_on, ghost_on;
    wire [11:0] player_rgb, ghost_rgb;
    player_renderer #(.WORLD_W(WORLD_W)) u_prend (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .spr_x(draw_x), .spr_y(spr_y), .facing_left(facing_left),
        .form(form), .frame(player_frame), .flash(player_flash), .shrink(boss_small),
        .pixel_on(player_on), .rgb_out(player_rgb),
        .g_en(ghost), .g_x(hist_x[5]), .g_y(hist_y[5]),
        .g_on(ghost_on), .g_rgb(ghost_rgb)
    );

    wire [1:0] fish_frame_base;
    fish_anim_counter u_fanim (
        .clk(clk), .rst(game_rst), .tick_60hz(wtick), .frame_base(fish_frame_base)
    );

    wire        fish_on;
    wire [11:0] fish_rgb;
    fish_renderer #(.N(NFISH), .WORLD_W(WORLD_W)) u_frend (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .active_vec(fish_active), .type_vec(fish_type_vec),
        .x_vec(fish_x_vec), .y_vec(fish_y_vec), .dir_vec(fish_dir_vec),
        .frame_base(fish_frame_base),
        // v21: the boss has its own renderer (boss_sprite); the red shark slot is off in the fight
        .rs_on(rs_on & ~boss_lock), .rs_x(rs_x),
        .rs_y(rs_y), .rs_dir(rs_dir),
        .rs_frame(rs_frame),
        .rs_big(1'b0), .rs_pal(3'd0), .rs_flipy(1'b0),
        .pixel_on(fish_on), .rgb_out(fish_rgb)
    );

    // v22 boss sprite (row spans: 6 frames in 3 RAMB36, drawn 323 x 156)
    wire        bspr_on;
    wire [11:0] bspr_rgb;
    boss_sprite #(.WORLD_W(WORLD_W)) u_bspr (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .on(boss_lock & boss_on & ~in_title), .x(boss_wx), .y(boss_wy), .frame(boss_frame),
        .flipx(boss_dir), .flipy(boss_flipy), .mode(boss_pal),
        .pixel_on(bspr_on), .rgb_out(bspr_rgb)
    );

    wire        bub_on0;
    wire [11:0] bub_rgb0;
    bubble_renderer #(.WORLD_W(WORLD_W)) u_brend (
        .world_x(world_x), .world_y(world_y),
        .active_vec(bub_active), .x_vec(bub_x_vec), .y_vec(bub_y_vec),
        .pixel_on(bub_on0), .rgb_out(bub_rgb0)
    );
    // bubble_renderer is combinational (clock 1): two more registers
    reg         bub_on1, bub_on;
    reg  [11:0] bub_rgb1, bub_rgb;
    always @(posedge clk) begin
        bub_on1 <= bub_on0; bub_rgb1 <= bub_rgb0;
        bub_on  <= bub_on1; bub_rgb  <= bub_rgb1;
    end

    // Props
    wire        mine_px, boom_px, jelly_px, harp_px;
    wire [11:0] mine_rgb, boom_rgb, jelly_rgb, harph_rgb, harpv_rgb;
    wire        harph_px, harpv_px;
    // Power-up item (24 x 24, frame = kind) and its glowing aura (a soft disc that
    // breathes 15..18 px, color by kind). The aura is a plain comparison of wx_d2 / wy_d2.
    wire        pu_px;
    wire [11:0] pu_rgb;
    slot_sprite #(.N(1), .W(24), .H(24), .FRAMES(3), .FPB(3),
                  .FILE0("powerup.mem"), .PAL("powerup_pal.mem"), .WORLD_W(WORLD_W)) u_spu (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .active_vec(pu_on & ~in_title), .x_vec(pu_x), .y_vec(pu_y), .frame_vec({1'b0, pu_kind}),
        .mirx_vec(1'b0), .miry_vec(1'b0), .pixel_on(pu_px), .rgb_out(pu_rgb));
    wire [10:0] pa_xa = (wx_d2 >= pu_cx) ? wx_d2 - pu_cx : pu_cx - wx_d2;
    wire [10:0] pa_x  = (pa_xa > WORLD_W / 2) ? WORLD_W - pa_xa : pa_xa;
    wire [9:0]  pa_y  = (wy_d2 >= pu_cy) ? wy_d2 - pu_cy : pu_cy - wy_d2;
    wire [11:0] pa_d2 = pa_x[5:0] * pa_x[5:0] + pa_y[5:0] * pa_y[5:0];
    wire [4:0]  pa_r  = 5'd15 + (anim_t[5] ? 5'd3 - {3'd0, anim_t[4:3]} : {3'd0, anim_t[4:3]});
    wire [9:0]  pa_r2 = pa_r * pa_r;
    wire [9:0]  pa_i2 = (pa_r - 5'd5) * (pa_r - 5'd5);
    wire        aura_in  = pu_on && (pa_x < 11'd32) && (pa_y < 10'd32) && (pa_d2 < {2'b00, pa_i2});
    wire        aura_out = pu_on && (pa_x < 11'd32) && (pa_y < 10'd32) && (pa_d2 < {2'b00, pa_r2}) &&
                           (pa_d2 >= {2'b00, pa_i2}) && (wx_d2[0] ^ wy_d2[0]);
    wire        aura_px  = (aura_in | aura_out) & ~in_title;
    wire [11:0] aura_rgb = (pu_kind == 2'd0) ? 12'hF8A : (pu_kind == 2'd1) ? 12'h6CF : 12'hFD4;

    // boss fight: slot 0 of the mine / explosion sprites shows the boss's sea mine
    wire [11:0] bm_r  = {1'b0, cam_x} + bmine_x - 11'd21;
    wire [10:0] bm_wx = (bm_r >= WORLD_W) ? bm_r - WORLD_W : bm_r[10:0];
    wire [11:0] bb_r  = {1'b0, cam_x} + bboom_x - 11'd32;
    wire [10:0] bb_wx = (bb_r >= WORLD_W) ? bb_r - WORLD_W : bb_r[10:0];
    wire [2:0]  m_on  = boss_lock ? {2'b00, bmine_on & ~(bmine_arm & anim_t[2])} : mine_on_v;   // v23: blinks while arming
    wire [32:0] m_x   = boss_lock ? {22'd0, bm_wx} : mine_x_v;
    wire [32:0] m_y   = boss_lock ? {22'd0, 1'b0, cam_y + bmine_y - 10'd22} : mine_y_v;
    wire [8:0]  m_f   = boss_lock ? {6'd0, 1'b0, anim_t[5:4]} : mine_f_v;
    wire [2:0]  b_on  = boss_lock ? {2'b00, bboom_on} : boom_on_v;
    wire [32:0] b_x   = boss_lock ? {22'd0, bb_wx} : boom_x_v;
    wire [32:0] b_y   = boss_lock ? {22'd0, 1'b0, cam_y + bboom_y - 10'd32} : boom_y_v;
    wire [8:0]  b_f   = boss_lock ? {6'd0, bboom_f} : boom_f_v;
    slot_sprite #(.N(3), .W(43), .H(44), .FRAMES(4), .FPB(4),
                  .FILE0("seamine.mem"), .PAL("seamine_pal.mem"), .WORLD_W(WORLD_W)) u_smine (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .active_vec(m_on), .x_vec(m_x), .y_vec(m_y), .frame_vec(m_f),
        .mirx_vec(3'b010), .miry_vec(3'b000), .pixel_on(mine_px), .rgb_out(mine_rgb));
    slot_sprite #(.N(3), .W(64), .H(64), .FRAMES(6), .FPB(6),
                  .FILE0("seamine_boom.mem"), .PAL("seamine_boom_pal.mem"), .WORLD_W(WORLD_W)) u_sboom (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .active_vec(b_on), .x_vec(b_x), .y_vec(b_y), .frame_vec(b_f),
        .mirx_vec(3'b000), .miry_vec(3'b000), .pixel_on(boom_px), .rgb_out(boom_rgb));
    slot_sprite #(.N(4), .W(37), .H(52), .FRAMES(4), .FPB(4),
                  .FILE0("jellyfish.mem"), .PAL("jellyfish_pal.mem"), .WORLD_W(WORLD_W)) u_sjelly (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .active_vec(jelly_on_v), .x_vec(jelly_x_v), .y_vec(jelly_y_v), .frame_vec(jelly_f_v),
        .mirx_vec(4'b1010), .miry_vec(4'b0000), .pixel_on(jelly_px), .rgb_out(jelly_rgb));
    wire [NHARP-1:0]   harp_fly_v = {NHARP{harp_fly}} & harp_lane;
    wire [3*NHARP-1:0] harp_f_v   = {NHARP{harp_f}};
    slot_sprite #(.N(NHARP), .W(88), .H(23), .FRAMES(4), .FPB(4),
                  .FILE0("harpoon_h.mem"), .PAL("harpoon_pal.mem"), .WORLD_W(WORLD_W)) u_sharph (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .active_vec(harp_fly_v & ~harp_vert), .x_vec(harp_x_v), .y_vec(harp_y_v), .frame_vec(harp_f_v),
        .mirx_vec(harp_back), .miry_vec({NHARP{1'b0}}), .pixel_on(harph_px), .rgb_out(harph_rgb));
    slot_sprite #(.N(NHARP), .W(23), .H(88), .FRAMES(4), .FPB(4),
                  .FILE0("harpoon_v.mem"), .PAL("harpoon_pal.mem"), .WORLD_W(WORLD_W)) u_sharpv (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .active_vec(harp_fly_v & harp_vert), .x_vec(harp_x_v), .y_vec(harp_y_v), .frame_vec(harp_f_v),
        .mirx_vec({NHARP{1'b0}}), .miry_vec(harp_back), .pixel_on(harpv_px), .rgb_out(harpv_rgb));
    assign harp_px = harph_px | harpv_px;

    // Around the harpoons: warning lines (blink faster before the shot), homing line +
    // aim mark, bubble trails, warning signs at the screen edge
    wire warn_px, home_px, aim_px, trail_px, sign_px;
    wire [11:0] sign_rgb;
    harpoon_fx #(.N(NHARP), .WORLD_W(WORLD_W)) u_harpfx (
        .clk(clk), .world_x(world_x), .world_y(world_y),
        .pixel_x(px_d1), .pixel_y(py_d1), .cam_x(cam_x), .cam_y(cam_y), .anim_t(anim_t),
        .warn_on(harp_warn & ~in_title), .fly_on(harp_fly & ~in_title), .warn_t(harp_warn_t),
        .homing(harp_homing), .locked(harp_locked), .aim_x(harp_aim_x), .aim_y(harp_aim_y),
        .lane_on(harp_lane), .vert(harp_vert), .back(harp_back),
        .line_x_vec(harp_lx_v), .line_y_vec(harp_ly_v), .hx_vec(harp_x_v), .hy_vec(harp_y_v),
        .warn_px(warn_px), .home_px(home_px), .aim_px(aim_px), .trail_px(trail_px),
        .sign_px(sign_px), .sign_rgb(sign_rgb)
    );

    // Tough Scales ready (forms 3, 4): breathing ring around the head + body
    wire [11:0] hbc_x_r = {1'b0, hb_x} + {4'd0, hb_w[7:1]};
    wire [10:0] hbc_x   = (hbc_x_r >= WORLD_W) ? hbc_x_r - WORLD_W : hbc_x_r[10:0];
    wire [9:0]  hbc_y   = hb_y + {3'd0, hb_h[7:1]};
    wire sh_core, sh_glow, sh_gleam;
    shield_fx #(.WORLD_W(WORLD_W)) u_shfx (
        .clk(clk), .en((shield | pshield) & ~in_title), .world_x(world_x), .world_y(world_y),
        .cx(hbc_x), .cy(hbc_y), .base_r(hb_w[7:1] + 7'd12), .anim_t(anim_t),
        .core(sh_core), .glow(sh_glow), .gleam(sh_gleam)
    );

    // Stunned: three stars circle above the head (in front of the hitbox, toward the face)
    wire [11:0] st_x_r = facing_left ? ({1'b0, hb_x} + {4'd0, hb_w[7:2]})
                                     : ({1'b0, hb_x} + {4'd0, hb_w[7:1]} + {4'd0, hb_w[7:2]});
    wire [10:0] st_x   = (st_x_r >= WORLD_W) ? st_x_r - WORLD_W : st_x_r[10:0];
    wire [9:0]  st_y   = (hb_y > 10'd14) ? hb_y - 10'd10 : 10'd4;
    wire        star_on;
    wire [11:0] star_rgb;
    stun_fx #(.WORLD_W(WORLD_W)) u_stars (
        .clk(clk), .en(stunned & ~in_title), .world_x(world_x), .world_y(world_y),
        .cx(st_x), .cy(st_y), .rx(6'd12 + {2'd0, form, 1'b0}), .anim_t(anim_t),
        .pixel_on(star_on), .rgb_out(star_rgb)
    );

    // Popup words above the dragon's head (events, skills); screen position of the head
    wire [11:0] anc_x_r = {1'b0, player_cx} + WORLD_W - cam_x;
    wire [10:0] anc_x   = (anc_x_r >= WORLD_W) ? anc_x_r - WORLD_W : anc_x_r[10:0];
    wire [9:0]  anc_y_s = spr_y - cam_y;
    wire [9:0]  anc_y_w = (spr_y < cam_y + 10'd24) ? 10'd0 : anc_y_s - 10'd24;
    // v21: world offset -> screen px when the view is zoomed out (boss fight x1.25, Fever):
    // x 205 / 256 = 0.8
    wire        anc_z   = ~boss_lock & (zoom != 5'd16);
    wire [18:0] anc_xm  = anc_x * 8'd205;
    wire [17:0] anc_ym  = anc_y_w * 8'd205;
    wire [10:0] anc_xs  = anc_z ? anc_xm[18:8] : anc_x;
    wire [9:0]  anc_y   = anc_z ? anc_ym[17:8] : anc_y_w;
    reg  roar_rdy_d, shield_d, fever_d, stealth_d;
    always @(posedge clk) begin
        roar_rdy_d <= game_rst ? 1'b0 : roar_ready;
        shield_d   <= game_rst ? 1'b0 : shield;
        fever_d    <= game_rst ? 1'b0 : fever;
        stealth_d  <= game_rst ? 1'b0 : stealth;
    end
    wire [4:0] fish_pts  = (fish_eat_type == 2'd0) ? 5'd1 : (fish_eat_type == 2'd1) ? 5'd3 :
                           (fish_eat_type == 2'd2) ? 5'd5 : 5'd10;
    wire [4:0] fish_show = fever ? {fish_pts[3:0], 1'b0} : fish_pts;
    wire       pop_on;
    wire [11:0] pop_rgb;
    popup_text u_popup (
        .clk(clk), .rst(game_rst), .tick_60hz(game_tick), .show(~in_title),
        .anchor_x(anc_xs[9:0]), .anchor_y(anc_y),
        .ev_score(fish_eat && fish_eat_type != 2'd3),
        .score_val(rs_eaten ? (fever ? 8'd200 : 8'd100) : {3'd0, fish_show}),
        .ev_gold((fish_eat && fish_eat_type == 2'd3) || rs_eaten),
        .ev_o2(bubble_eat), .ev_mine(mine_eaten), .ev_stun(sting),
        .ev_heart(hit_taken & ~shield_used), .ev_block(shield_used), .ev_roar(roar),
        .ev_roar_rdy(roar_ready & ~roar_rdy_d & playing),
        .ev_shield_rdy(shield & ~shield_d & playing),
        .ev_fever(fever & ~fever_d), .ev_evolve(evolve_pulse),
        .ev_stealth(stealth & ~stealth_d),
        .ev_pu_heart((pu_got && pu_got_kind == 2'd0) | ev_reward_p), .ev_pu_shield(pu_got && pu_got_kind == 2'd1),
        .ev_pu_speed((pu_got && pu_got_kind == 2'd2) | ev_reward_p),
        .pixel_x(px_d1), .pixel_y(py_d1),
        .pixel_on(pop_on), .rgb_out(pop_rgb)
    );

    // Screen edge distance (for the seaweed vignette and the low-oxygen warning)
    wire [9:0] ed_l = px_d3;
    wire [9:0] ed_r = 10'd639 - px_d3;
    wire [9:0] ed_t = py_d3;
    wire [9:0] ed_b = 10'd479 - py_d3;
    wire [9:0] ed_x = (ed_l < ed_r) ? ed_l : ed_r;
    wire [9:0] ed_y = (ed_t < ed_b) ? ed_t : ed_b;
    wire [9:0] ed   = (ed_x < ed_y) ? ed_x : ed_y;
    // brightness in eighths while hiding: 4/8 at the very edge .. 7/8 at 30..39 px
    wire [3:0] edge_mul = (ed < 10'd10) ? 4'd4 : (ed < 10'd20) ? 4'd5 :
                          (ed < 10'd30) ? 4'd6 : (ed < 10'd40) ? 4'd7 : 4'd8;

    // Tidal Roar shock wave: a ring around the player growing 6 px per tick
    wire [10:0] rdx_a = (wx_d2 >= player_cx) ? wx_d2 - player_cx : player_cx - wx_d2;
    wire [10:0] rdx   = (rdx_a > WORLD_W / 2) ? WORLD_W - rdx_a : rdx_a;
    wire [9:0]  rdy   = (wy_d2 >= player_cy) ? wy_d2 - player_cy : player_cy - wy_d2;
    wire [21:0] rd2   = rdx * rdx + rdy * rdy;
    wire [7:0]  rr    = {ring, 3'b000};                   // v19: 8 px per tick (reach 240)
    wire [15:0] rr2   = rr * rr;
    wire [15:0] rbw   = {rr, 3'b000};                     // ring width ~ 4 px
    wire ring_px = (ring != 5'd0) && (rdx < 11'd260) && (rdy < 10'd260) &&
                   (rd2 + rbw >= rr2) && (rd2 < rr2 + rbw);

    // Fever: glowing frame around the screen (pulsing)
    wire edge8 = (px_d3 < 10'd8) || (px_d3 >= 10'd632) || (py_d3 < 10'd8) || (py_d3 >= 10'd472);
    wire fever_px = fever && edge8;

    // HUD and menu text use screen coordinates
    wire        hud_on;
    wire [11:0] hud_rgb;
    hud u_hud (
        .clk(clk), .show(~in_title),
        .hearts(hearts), .slots(boss_lock ? ((diff == 2'd0) ? 3'd6 : (diff == 2'd2) ? 3'd4 : 3'd5)
                                          : ((diff == 2'd0) ? 3'd4 : 3'd3)),
        .diff(diff), .show_eat(~boss_lock), .rs_seen(form >= 3'd2),
        .form(form), .score(score[9:0]), .oxygen(oxygen),
        .t_min(t_min), .t_sec(t_sec),
        .blink(anim_t[4]), .shark_warn(shark_warn), .stunned(stunned),
        .shield(shield), .roar_ready(roar_ready), .stealth(stealth),
        .gauge(gauge), .fever(fever), .mic_on(mic_sw), .mic_level(mic_level),
        .tilt_on(tilt_sw), .tilt_x(tilt_x), .tilt_y(tilt_y),
        .tilt_dir({tilt_u, tilt_d, tilt_l, tilt_r}),
        .pixel_x(pixel_x), .pixel_y(pixel_y),
        .hud_on(hud_on), .hud_rgb(hud_rgb)
    );

    wire        text_on;
    wire [11:0] text_rgb;
    wire        panel_on0;
    screen_overlay u_screen (
        .clk(clk), .state(game_state), .score(score[9:0]),
        .hi_score(hi_score), .t_min(t_min), .t_sec(t_sec),
        .best_min(best_min), .best_sec(best_sec), .best_ok(best_ok), .diff(diff),
        .grade(grade), .best_grade(best_grade), .best_g_ok(best_g_ok), .music_on(music_on),
        .pt_time(pt_time), .pt_ev(pt_ev), .pt_combo(pt_combo), .total(total),
        .pixel_x(px_d1), .pixel_y(py_d1),
        .text_on(text_on), .text_rgb(text_rgb), .panel_on(panel_on0)
    );
    // the panel is a plain comparison of the (1-clock-late) coordinates: 2 more registers
    reg panel_on1, panel_on;
    always @(posedge clk) begin panel_on1 <= panel_on0; panel_on <= panel_on1; end

    // Boss fight effects (world position, clock 3) and words / HP bar (screen)
    wire bfx_fill, bfx_rim, bfx_spot, bfx_aim, bfx_eye;
    wire [11:0] bfx_eye_rgb;
    wire [3:0]  bfx_dark;
    boss_fx #(.WORLD_W(WORLD_W)) u_bfx (
        .wx(wx_d2), .wy(wy_d2), .cam_x(cam_x), .cam_y(cam_y), .fight(boss_lock & ~in_title),
        .bub_on(bbub_on), .bub_x_vec(bbub_x), .bub_y_vec(bbub_y),
        .warn(boss_warn), .blink(anim_t[2]), .p_cx(ar_cx), .p_cy(ar_cy),
        .eye_on(eye_on & (boss_warn | boss_tired | boss_grab | (anim_t[5:4] == 2'd0))),
        .eye_tired(boss_tired), .eye_x(eye_x), .eye_y(eye_y),
        .dark_on(boss_phase == 2'd3 && !boss_freeze),
        .ev_dark(ev_dark & ~ev_busy & ~in_title),                 // v20: failed event
        .bub_fill(bfx_fill), .bub_rim(bfx_rim), .bub_spot(bfx_spot),
        .aim_px(bfx_aim), .eye_px(bfx_eye), .eye_rgb(bfx_eye_rgb), .dark_mul(bfx_dark)
    );
    wire        bhud_on;
    wire [11:0] bhud_rgb;
    boss_hud u_bhud (
        .clk(clk), .show((boss_lock | ev_busy) & ~in_title), .fight(boss_lock), .hp(boss_hp), .blink(anim_t[3]),
        .intro(boss_intro), .grab(boss_grab), .meter(boss_meter), .sw_active(boss_sw_active),
        .sw_hidden(boss_sw_hidden), .parry_show(parry_t != 6'd0),
        .spear_on(spear_act), .spear_pat(spear_pat), .arrow_on(arrow_act),
        .rating(arrow_rating), .rating_show(arrow_rate_t != 6'd0), .combo(arrow_combo),
        .pixel_x(pixel_x), .pixel_y(pixel_y),
        .on(bhud_on), .rgb(bhud_rgb)
    );

    // ---- compositor -----------------------------------------------------------------
    // Every layer arrives at clock 3 and is registered here (clock 4, together with the
    // map from bg_rom), mixed combinationally and registered by pixel_mixer (clock 5),
    // with hsync / vsync / active delayed the same way.
    // Layers, bottom to top: map < current streaks < deco < bubbles < mines/explosions
    //   < jellyfish < fish < harpoon bubble trail < harpoon warning (homing: amber)
    //   < harpoon < afterimage < player < shield ring < seaweed (hides the player)
    //   < aim mark < roar ring < shark shadow < dark screen edge while hiding
    //   < red edge pulse (low oxygen) < Fever frame < harpoon edge signs < popup words
    //   < HUD < menu panel < menu text
    wire player_vis = player_on & ~blink_hide & ~in_title & ~(evolving & anim_t[2]);
    reg  L_streak, L_deco, L_bub, L_mine, L_boom, L_jelly, L_fish, L_warn, L_harp;
    reg  L_ghost, L_player, L_weed, L_ring, L_shadow, L_fever, L_hud, L_panel, L_text;
    reg  L_stealth, L_home, L_aim, L_trail, L_sign, L_core, L_glow, L_gleam, L_pop;
    reg  L_oxyw, L_hurt, L_star, L_pu, L_aura;
    reg  L_bfill, L_brim, L_bspot, L_baim, L_beye, L_mgdim, L_spear, L_arrow, L_bhud;
    reg  L_tim, L_evh, L_bspr;
    reg  [11:0] C_tim, C_evh, C_bspr;
    reg  [3:0]  L_dark;
    reg  [11:0] C_beye, C_spear, C_arrow, C_bhud;
    reg  [11:0] C_pu, C_aura;
    reg  [11:0] C_star;
    reg  [3:0]  L_dim;
    reg  [11:0] C_sign, C_pop;
    reg  [11:0] C_deco, C_bub, C_mine, C_boom, C_jelly, C_fish, C_harp, C_ghost, C_player;
    reg  [11:0] C_weed, C_hud, C_text;
    reg  L_active, L_hs, L_vs, L_pulse;
    always @(posedge clk) begin
        L_streak <= streak_on & ~in_title & ~boss_lock;
        L_deco   <= deco_on;                        C_deco   <= deco_rgb;
        L_bub    <= bub_on;                         C_bub    <= bub_rgb;
        L_mine   <= mine_px;                        C_mine   <= mine_rgb;
        L_boom   <= boom_px;                        C_boom   <= boom_rgb;
        L_jelly  <= jelly_px;                       C_jelly  <= jelly_rgb;
        L_fish   <= fish_on;                        C_fish   <= fish_rgb;
        L_bspr   <= bspr_on;                        C_bspr   <= bspr_rgb;
        L_aura   <= aura_px;                        C_aura   <= aura_rgb;
        L_pu     <= pu_px;                          C_pu     <= pu_rgb;
        L_warn   <= warn_px;
        L_home   <= home_px;
        L_aim    <= aim_px;
        L_trail  <= trail_px;
        L_sign   <= sign_px;                        C_sign   <= sign_rgb;
        L_core   <= sh_core;
        L_glow   <= sh_glow;
        L_gleam  <= sh_gleam;
        L_pop    <= pop_on;                         C_pop    <= pop_rgb;
        L_dim    <= (in_seaweed & playing) ? edge_mul : 4'd8;
        L_oxyw   <= oxy_low & playing & anim_t[4] & (ed < 10'd12);
        L_hurt   <= hurting & hurt_t[2];
        L_star   <= star_on;                        C_star   <= star_rgb;
        L_harp   <= harp_px;                        C_harp   <= harph_px ? harph_rgb : harpv_rgb;
        L_ghost  <= ghost_on & ~in_title;           C_ghost  <= ghost_rgb;
        L_player <= player_vis;                     C_player <= player_rgb;
        L_stealth <= stealth | boss_sw_hidden;
        L_bfill  <= bfx_fill;
        L_brim   <= bfx_rim;
        L_bspot  <= bfx_spot;
        L_baim   <= bfx_aim;
        L_beye   <= bfx_eye;                        C_beye   <= bfx_eye_rgb;
        L_dark   <= bfx_dark;
        L_mgdim  <= (spear_act | (ev_busy & ~boss_lock)) & ~in_title;   // v20: events dim too
        L_tim    <= tim_px & ~in_title;             C_tim    <= tim_rgb;
        L_evh    <= evh_on;                         C_evh    <= evh_rgb;
        L_spear  <= spear_px & ~in_title;           C_spear  <= spear_rgb;
        L_arrow  <= arrow_px & ~in_title;           C_arrow  <= arrow_rgb;
        L_bhud   <= bhud_on;                        C_bhud   <= bhud_rgb;
        L_weed   <= weed_on;                        C_weed   <= weed_rgb;
        L_ring   <= ring_px;
        L_shadow <= shadow_on;
        L_fever  <= fever_px;
        L_pulse  <= anim_t[3];
        L_hud    <= hud_on;                         C_hud    <= hud_rgb;
        L_panel  <= panel_on;
        L_text   <= text_on;                        C_text   <= text_rgb;
        L_active <= av_d3;
        L_hs     <= hs_d3;
        L_vs     <= vs_d3;
    end

    function [11:0] avg(input [11:0] a, input [11:0] b);     // 50 % blend
        reg [4:0] r, g, bl;
        begin
            r   = a[11:8] + b[11:8];
            g   = a[7:4]  + b[7:4];
            bl  = a[3:0]  + b[3:0];
            avg = {r[4:1], g[4:1], bl[4:1]};
        end
    endfunction
    function [11:0] lift(input [11:0] a);                    // lighter (+3, saturating)
        lift = {(a[11:8] > 4'd12) ? 4'hF : a[11:8] + 4'd3,
                (a[7:4]  > 4'd12) ? 4'hF : a[7:4]  + 4'd3,
                (a[3:0]  > 4'd12) ? 4'hF : a[3:0]  + 4'd3};
    endfunction
    function [11:0] dim(input [11:0] a, input [3:0] m);     // a * m / 8
        reg [7:0] r, g, bl;
        begin
            r   = a[11:8] * m;
            g   = a[7:4]  * m;
            bl  = a[3:0]  * m;
            dim = {r[6:3], g[6:3], bl[6:3]};
        end
    endfunction
    function [11:0] shade(input [11:0] a);                   // shark shadow: dark blue
        shade = {2'b00, a[11:10], 2'b00, a[7:6], 1'b0, a[3:2], 1'b1};
    endfunction

    reg [11:0] px;
    always @* begin
        px = bg_rgb;
        if (L_streak) px = lift(px);
        if (L_deco)   px = C_deco;
        if (L_bub)    px = C_bub;
        if (L_mine)   px = C_mine;
        if (L_boom)   px = C_boom;
        if (L_jelly)  px = C_jelly;
        if (L_fish)   px = C_fish;
        if (L_bspr)   px = C_bspr;                          // v21 boss
        if (L_aura)   px = avg(px, C_aura);
        if (L_pu)     px = C_pu;
        if (L_trail)  px = 12'hCEF;
        if (L_warn)   px = 12'hF22;
        if (L_home)   px = 12'hFB2;
        if (L_harp)   px = C_harp;
        if (L_bfill)  px = avg(px, 12'hBEF);                // boss bubbles
        if (L_brim)   px = 12'hDFF;
        if (L_bspot)  px = 12'hFFF;
        if (L_ghost && !L_player) px = avg(px, C_ghost);
        if (L_player) px = L_stealth ? avg(px, C_player) : L_hurt ? avg(C_player, 12'hF22) : C_player;
        if (L_glow && !L_core) px = avg(px, 12'h6CF);
        if (L_core)   px = L_gleam ? 12'hFFF : 12'h9EF;
        if (L_weed)   px = C_weed;
        if (L_star)   px = C_star;
        if (L_aim)    px = 12'hFE2;
        if (L_ring)   px = 12'hBFF;
        if (L_shadow) px = shade(px);
        if (L_baim)   px = 12'hF33;                         // boss aims at the player
        if (L_dark != 4'd8) px = dim(px, L_dark);           // boss phase 3: darkness
        if (L_beye)   px = C_beye;
        if (L_mgdim)  px = dim(px, 4'd3);                   // spear mini game
        if (L_spear)  px = C_spear;
        if (L_arrow)  px = C_arrow;
        if (L_tim)    px = C_tim;                           // v20 timing bar
        if (L_dim != 4'd8) px = dim(px, L_dim);
        if (L_oxyw)   px = avg(px, 12'hF11);
        if (L_fever)  px = L_pulse ? 12'hFE6 : 12'hF92;
        if (L_sign)   px = C_sign;
        if (L_pop)    px = C_pop;
        if (L_hud)    px = C_hud;
        if (L_bhud)   px = C_bhud;
        if (L_evh)    px = C_evh;                           // v20 event words
        if (L_panel)  px = 12'h013;
        if (L_text)   px = C_text;
    end

    reg pix_ce_d;                          // pix_ce is 1 every clock at 25 MHz
    always @(posedge clk) pix_ce_d <= pix_ce;

    pixel_mixer u_mix (
        .clk(clk), .rst(rst), .pix_ce(pix_ce_d),
        .active_video(L_active), .hs_in(L_hs), .vs_in(L_vs),
        .bg_rgb(px), .obj_on(1'b0), .obj_rgb(12'h000),
        .vga_r(VGA_R), .vga_g(VGA_G), .vga_b(VGA_B),
        .vga_hs(VGA_HS), .vga_vs(VGA_VS)
    );
endmodule
