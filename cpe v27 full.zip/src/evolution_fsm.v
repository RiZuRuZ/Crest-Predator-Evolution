// evolution_fsm: FORM1 -> FORM4 driven by EP (score)
// form_state uses the project-wide encoding 1..4
// There is no way back to a lower form; only rst returns to FORM1
// evolve_pulse is high for 1 clk on every form change (starts the evolve animation later)
module evolution_fsm (
    input  wire        clk,
    input  wire        rst,
    input  wire [15:0] score,
    output reg  [2:0]  form_state,
    output reg         evolve_pulse
);
    localparam [2:0] FORM1 = 3'd1, FORM2 = 3'd2, FORM3 = 3'd3, FORM4 = 3'd4;

    wire evolve_req;
    ep_compare u_cmp (.score(score), .form_state(form_state), .evolve_req(evolve_req));

    always @(posedge clk) begin
        if (rst) begin
            form_state   <= FORM1;
            evolve_pulse <= 1'b0;
        end else begin
            evolve_pulse <= 1'b0;
            if (evolve_req) begin
                case (form_state)
                    FORM1:   form_state <= FORM2;
                    FORM2:   form_state <= FORM3;
                    FORM3:   form_state <= FORM4;
                    default: form_state <= FORM4;
                endcase
                evolve_pulse <= 1'b1;
            end
        end
    end
endmodule
