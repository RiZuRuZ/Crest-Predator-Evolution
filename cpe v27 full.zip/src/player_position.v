// player_position: register holding the player's world x,y (top-left corner), updated every game tick
module player_position #(
    parameter INIT_X = 952,   // world center for a 16px player: (1920-16)/2
    parameter INIT_Y = 312    // (640-16)/2
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        en,
    input  wire [10:0] next_x,
    input  wire [9:0]  next_y,
    output reg  [10:0] player_x,
    output reg  [9:0]  player_y
);
    always @(posedge clk) begin
        if (rst) begin
            player_x <= INIT_X;
            player_y <= INIT_Y;
        end else if (en) begin
            player_x <= next_x;
            player_y <= next_y;
        end
    end
endmodule
