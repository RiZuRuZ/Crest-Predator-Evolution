`timescale 1ns / 1ps
//==============================================================================
// sevenseg_driver - shows the EP score in decimal on the Nexys A7 7-segment
//
// Display layout (8 digits, AN0 = rightmost):
//     [blank x5] [hundreds] [tens] [ones]
//   SHOW_FORM = 1 adds the current form (1..4) on the leftmost digit (AN7):
//     [form] [blank x4] [hundreds] [tens] [ones]   (4 digits scanned, 1/4 duty)
//   - leading zeros are blanked, the ones digit is always shown (EP 0 -> "0")
//   - values above 999 are clamped to 999 (the game ends at 500, so this
//     never happens in normal play)
//
// Hardware (Nexys A7-100T): common-anode display, segments AND digit
// enables are ACTIVE LOW.
//     an[7:0]   digit enable, an[0] = rightmost digit (0 = lit)
//     seg[6:0]  {CG,CF,CE,CD,CC,CB,CA} -> seg[0] = CA ... seg[6] = CG (0 = on)
//     dp        decimal point, held off (1)
//
// How it works
//   1. A small sequential "double dabble" converts the 10-bit value to three
//      BCD digits in 12 cycles. It runs continuously, so the display follows
//      `value` within a few clock cycles, and it uses no divider (easy timing
//      at 100 MHz).
//   2. Only the 3 used digits are scanned, one after the other, so every
//      digit has a 1/3 duty cycle and the display stays bright.
//      Scan step = 2^SCAN_BITS clocks (14 -> 163 us per digit, one full
//      frame every ~0.5 ms = ~2 kHz, no visible flicker).
//
// Project conventions: single clock CLK100MHZ, rst active-high synchronous.
//==============================================================================
module sevenseg_driver #(
    parameter SCAN_BITS = 14,       // scan step = 2^SCAN_BITS clocks
    parameter SHOW_FORM = 0         // 1 = show `form` on the leftmost digit
) (
    input  wire        clk,         // CLK100MHZ
    input  wire        rst,         // active-high, synchronous
    input  wire [15:0] value,       // EP score (score_ctrl.score)
    input  wire [4:0]  form,        // current form (1..4), or 10 E / 11 n / 12 H (v18 difficulty on TITLE),
                                    // v20 grade: 16 A, 17 b, 18 C, 19 d, 20 F, 21 S, 22 - (cheat)
    output reg  [7:0]  an,          // digit enables, active low
    output reg  [6:0]  seg,         // segments {CG..CA}, active low
    output wire        dp           // decimal point, active low (off)
);

    assign dp = 1'b1;

    // ---- clamp to 3 decimal digits -----------------------------------------
    wire [9:0] v = (value > 16'd999) ? 10'd999 : value[9:0];

    // ---- binary -> BCD, sequential double dabble (10 bits) -----------------
    reg [3:0]  cnt;
    reg [9:0]  shift;
    reg [11:0] bcd;
    reg [11:0] bcd_out;

    // add 3 to every BCD nibble that is >= 5 (before the shift)
    wire [11:0] adj = {
        (bcd[11:8] >= 4'd5) ? bcd[11:8] + 4'd3 : bcd[11:8],
        (bcd[7:4]  >= 4'd5) ? bcd[7:4]  + 4'd3 : bcd[7:4],
        (bcd[3:0]  >= 4'd5) ? bcd[3:0]  + 4'd3 : bcd[3:0]
    };

    always @(posedge clk) begin
        if (rst) begin
            cnt     <= 4'd0;
            shift   <= 10'd0;
            bcd     <= 12'd0;
            bcd_out <= 12'd0;
        end else if (cnt == 4'd0) begin          // latch the value
            shift <= v;
            bcd   <= 12'd0;
            cnt   <= 4'd1;
        end else if (cnt <= 4'd10) begin         // 10 shift steps
            {bcd, shift} <= {adj, shift} << 1;
            cnt          <= cnt + 4'd1;
        end else begin                           // cnt == 11: publish result
            bcd_out <= bcd;
            cnt     <= 4'd0;
        end
    end

    // ---- digit scanner (3 digits: ones, tens, hundreds) --------------------
    reg [SCAN_BITS-1:0] scan_cnt;
    reg [1:0]           idx;                     // 0, 1, 2 (and 3 = form digit)
    wire [1:0]          idx_last = (SHOW_FORM != 0) ? 2'd3 : 2'd2;
    wire                strobe = &scan_cnt;

    always @(posedge clk) begin
        if (rst) begin
            scan_cnt <= {SCAN_BITS{1'b0}};
            idx      <= 2'd0;
        end else begin
            scan_cnt <= scan_cnt + 1'b1;
            if (strobe)
                idx <= (idx == idx_last) ? 2'd0 : idx + 2'd1;
        end
    end

    // ---- pick digit, blank leading zeros -----------------------------------
    reg [4:0] digit;
    reg       blank;
    always @* begin
        case (idx)
            2'd0:    begin digit = {1'b0, bcd_out[3:0]};   blank = 1'b0;                 end
            2'd1:    begin digit = {1'b0, bcd_out[7:4]};   blank = (bcd_out[11:4] == 8'd0); end
            2'd2:    begin digit = {1'b0, bcd_out[11:8]};  blank = (bcd_out[11:8] == 4'd0); end
            default: begin digit = form;           blank = 1'b0;                 end
        endcase
    end

    // active-high pattern {g,f,e,d,c,b,a}
    reg [6:0] pattern;
    always @* begin
        case (digit)
            5'd0:    pattern = 7'b0111111;
            5'd1:    pattern = 7'b0000110;
            5'd2:    pattern = 7'b1011011;
            5'd3:    pattern = 7'b1001111;
            5'd4:    pattern = 7'b1100110;
            5'd5:    pattern = 7'b1101101;
            5'd6:    pattern = 7'b1111101;
            5'd7:    pattern = 7'b0000111;
            5'd8:    pattern = 7'b1111111;
            5'd9:    pattern = 7'b1101111;
            5'd10:   pattern = 7'b1111001;     // E (easy)
            5'd11:   pattern = 7'b1010100;     // n (normal)
            5'd12:   pattern = 7'b1110110;     // H (hard)
            5'd16:   pattern = 7'b1110111;     // A (v20 grades)
            5'd17:   pattern = 7'b1111100;     // b
            5'd18:   pattern = 7'b0111001;     // C
            5'd19:   pattern = 7'b1011110;     // d
            5'd20:   pattern = 7'b1110001;     // F
            5'd21:   pattern = 7'b1101101;     // S
            5'd22:   pattern = 7'b1000000;     // - (cheat)
            default: pattern = 7'b0000000;
        endcase
    end

    // registered outputs: digit enable and segments change on the same edge
    always @(posedge clk) begin
        if (rst) begin
            an  <= 8'hFF;
            seg <= 7'h7F;
        end else begin
            an  <= blank ? 8'hFF : ~(8'b00000001 << ((idx == 2'd3) ? 3'd7 : {1'b0, idx}));
            seg <= blank ? 7'h7F : ~pattern;
        end
    end

endmodule
