// mus_voice: v27 one music voice (wavetable + level envelope + lead vibrato)
// Same integer model as the PC port (cpe_pc/src/music16.js); pulses from music_player:
//   stp  (sample clock 0) a new 16th-note step: note 0 = release, new = start a note
//   etk  (clock 1, every 256 samples = 5.24 ms) envelope / vibrato age step
//   smp  (clock 2, 48828 Hz) output one sample, advance the phase
// Instruments (inst): 0 lead, 1 low lead, 2 bell, 3 bass, 4 heavy bass, 5 arpeggio:
//   volume /64, decay shift (tau = 5.24 ms x 2^k), sustain level, vibrato.
// Every number is a PLACEHOLDER tuned by ear in tools/music16.
module mus_voice (
    input  wire              clk,
    input  wire              rst,
    input  wire              kill,             // track change: back to silence
    input  wire              stp,
    input  wire [6:0]        s_note,           // MIDI note, 0 = rest
    input  wire              s_new,
    input  wire              etk,
    input  wire              smp,
    input  wire [2:0]        inst,
    input  wire signed [4:0] lfo,              // -8..7
    output reg  signed [7:0] out
);
    reg [5:0] vol; reg [2:0] dk; reg [7:0] sus; reg vib;
    always @* begin
        case (inst)
            3'd0:    begin vol = 6'd24; dk = 3'd5; sus = 8'd179; vib = 1'b1; end
            3'd1:    begin vol = 6'd28; dk = 3'd4; sus = 8'd153; vib = 1'b0; end
            3'd2:    begin vol = 6'd21; dk = 3'd4; sus = 8'd38;  vib = 1'b0; end
            3'd3:    begin vol = 6'd36; dk = 3'd4; sus = 8'd140; vib = 1'b0; end
            3'd4:    begin vol = 6'd44; dk = 3'd3; sus = 8'd128; vib = 1'b0; end
            default: begin vol = 6'd12; dk = 3'd3; sus = 8'd64;  vib = 1'b0; end
        endcase
    end

    reg [23:0] ph;
    reg [7:0]  lvl;
    reg [5:0]  age;
    reg [6:0]  note;
    reg        gate;

    wire [19:0] inc0;
    mus_inc u_inc (.note(note), .inc(inc0));
    wire signed [15:0] vibd = $signed({1'b0, inc0[19:10]}) * lfo;          // +-7080
    wire [23:0] inc = (vib && age >= 6'd29) ? ({4'd0, inc0} + {{8{vibd[15]}}, vibd})
                                            : {4'd0, inc0};
    wire signed [7:0]  w;
    mus_wave u_wave (.tab(inst), .idx(ph[23:18]), .s(w));
    wire signed [16:0] p0 = w * $signed({1'b0, lvl});                      // x level / 256
    wire signed [8:0]  p  = p0[16:8];
    wire signed [15:0] q0 = p * $signed({1'b0, vol});                      // x volume / 64
    wire [7:0]  dec = (lvl - sus) >> dk;

    always @(posedge clk) begin
        if (rst || kill) begin
            ph <= 24'd0; lvl <= 8'd0; age <= 6'd0; note <= 7'd0; gate <= 1'b0; out <= 8'sd0;
        end else begin
            if (stp) begin
                if (s_note == 7'd0) gate <= 1'b0;
                else if (s_new) begin note <= s_note; lvl <= 8'd255; age <= 6'd0; gate <= 1'b1; end
            end
            if (etk) begin
                if (gate) begin
                    if (lvl > sus) lvl <= lvl - dec;
                    if (age != 6'd63) age <= age + 6'd1;
                end else begin
                    lvl <= (lvl[7:2] == 6'd0) ? 8'd0 : lvl - {2'b00, lvl[7:2]};   // release
                end
            end
            if (smp) begin
                out <= q0[13:6];
                ph  <= ph + inc;
            end
        end
    end
endmodule
