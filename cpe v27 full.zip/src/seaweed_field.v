// seaweed_field: hiding seaweed on the sea floor, drawn IN FRONT of the player
//
// NSPOT hiding spots at fixed world x (SPOT0..3), each made of 3 seaweed clumps side by
// side (61 px each, 183 px wide) so even form 4 (hitbox 91 px) fits. Bottom on the sea
// floor (world y 547..639). The middle clump is mirrored and every clump runs its
// 8-frame sway with a different phase, so the spot does not look copied.
// in_seaweed = the centre of the player hitbox is inside a spot (hidden from the shark).
// ROM: seaweed_0.mem frames 0..3, seaweed_1.mem frames 4..7, 61x93, 4-bit index.
// Timing as the other renderers (position registered, ROM, palette combinational).
module seaweed_field #(
    parameter WORLD_W = 1920,
    parameter SPOT0 = 260, parameter SPOT1 = 740, parameter SPOT2 = 1220, parameter SPOT3 = 1700,
    parameter TOP_Y = 547                 // world y of the seaweed top
)(
    input  wire        clk,
    input  wire [10:0] world_x,
    input  wire [9:0]  world_y,
    input  wire [2:0]  anim_frame,        // 0..7, sway frame
    input  wire [10:0] probe_x,           // player hitbox centre
    input  wire [9:0]  probe_y,
    output wire        pixel_on,
    output wire [11:0] rgb_out,
    output wire        in_seaweed
);
    localparam W = 61, H = 93, WH = W * H, SPAN = 3 * W;

    function [10:0] rel(input [10:0] x, input [10:0] s);
        rel = (x >= s) ? x - s : x + WORLD_W - s;
    endfunction

    wire [10:0] r0 = rel(world_x, SPOT0), r1 = rel(world_x, SPOT1);
    wire [10:0] r2 = rel(world_x, SPOT2), r3 = rel(world_x, SPOT3);
    reg  [10:0] r;
    reg  [1:0]  spot;
    reg         in_x;
    always @* begin
        in_x = 1'b1; spot = 2'd0; r = r0;
        if      (r0 < SPAN) begin spot = 2'd0; r = r0; end
        else if (r1 < SPAN) begin spot = 2'd1; r = r1; end
        else if (r2 < SPAN) begin spot = 2'd2; r = r2; end
        else if (r3 < SPAN) begin spot = 2'd3; r = r3; end
        else in_x = 1'b0;
    end
    wire        in_y  = (world_y >= TOP_Y) && (world_y < TOP_Y + H);
    wire [1:0]  clump = (r < W) ? 2'd0 : (r < 2 * W) ? 2'd1 : 2'd2;
    wire [7:0]  lx    = (clump == 2'd0) ? r[7:0] : (clump == 2'd1) ? r[7:0] - W : r[7:0] - 2 * W;
    wire [7:0]  sx    = (clump == 2'd1) ? (W - 1 - lx) : lx;
    wire [7:0]  sy    = world_y - TOP_Y;
    wire [2:0]  fr    = anim_frame + {clump, 1'b0} + clump + {1'b0, spot};

    reg        v_r, b_r;
    reg [14:0] a_r;
    always @(posedge clk) begin
        v_r <= in_x & in_y;
        b_r <= fr[2];
        a_r <= fr[1:0] * WH + sy * W + sx;
    end

    (* ram_style = "block" *) reg [3:0] rom0 [0:4*WH-1];
    (* ram_style = "block" *) reg [3:0] rom1 [0:4*WH-1];
    initial begin
        $readmemh("seaweed_0.mem", rom0);
        $readmemh("seaweed_1.mem", rom1);
    end
    reg [3:0] q0, q1;
    reg       v_d, b_d;
    always @(posedge clk) begin
        q0 <= rom0[a_r]; q1 <= rom1[a_r]; v_d <= v_r; b_d <= b_r;
    end

    reg [11:0] pal [0:15];
    initial $readmemh("seaweed_pal.mem", pal);
    wire [3:0] idx = b_d ? q1 : q0;
    assign pixel_on = v_d & (idx != 4'd0);
    assign rgb_out  = pal[idx];

    // hiding test on the player hitbox centre
    wire [10:0] p0 = rel(probe_x, SPOT0), p1 = rel(probe_x, SPOT1);
    wire [10:0] p2 = rel(probe_x, SPOT2), p3 = rel(probe_x, SPOT3);
    assign in_seaweed = ((p0 < SPAN) || (p1 < SPAN) || (p2 < SPAN) || (p3 < SPAN))
                        && (probe_y >= TOP_Y + 10);
endmodule
