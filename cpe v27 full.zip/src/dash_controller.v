// dash_controller: dash in the held direction (center button or Space)
// dash_req   : 1-cycle pulse from the button / Space key
// move_dx/dy : the player's movement this tick; the dash direction is latched from it.
//              No direction held = no dash (work plan row: center-button dash in the held direction).
// can_pay    : oxygen_ctrl has enough oxygen for one dash
// dash_start : 1-cycle pulse when a dash begins (oxygen_ctrl subtracts DASH_COST)
// dash_dx/dy : extra DASH_SPEED px/tick on each held axis for dash_len ticks
//              (DASH_TICKS is kept only as the default length used by older callers)
// cooling    : no new dash for COOLDOWN_TICKS ticks after a dash starts (keep >= DASH_TICKS)
// Per-form variants (Small dash, Super Dash, Dash Chain) will become parameters / inputs here.
// All numbers are placeholders until the team decides the real values.
module dash_controller #(
    parameter DASH_TICKS     = 8,
    parameter DASH_SPEED     = 8,
    parameter COOLDOWN_TICKS = 30,   // 0.5 s at 60 Hz
    parameter CHAIN_TICKS    = 30    // Dash Chain window after a dash (0.5 s)
)(
    input  wire              clk,
    input  wire              rst,
    input  wire              tick_60hz,
    input  wire              dash_req,
    input  wire signed [6:0] move_dx,
    input  wire signed [6:0] move_dy,
    input  wire              can_pay,
    input  wire [7:0]        dash_len,     // dash length in ticks (per form, form_skills)
    input  wire              chain_en,     // Dash Chain (form 2): dash again within
                                           // CHAIN_TICKS after a dash, ignoring cooldown
    output reg               dash_start,
    output wire              dashing,
    output wire              cooling,
    output reg  signed [6:0] dash_dx,
    output reg  signed [6:0] dash_dy
);
    reg [7:0] dcnt, ccnt, chain_t;
    reg [1:0] chained;                     // chain dashes used (max 2 after the first)
    reg       xp, xn, yp, yn;

    wire has_dir = (move_dx != 7'sd0) || (move_dy != 7'sd0);
    wire chain_ok = chain_en && (chain_t != 8'd0) && (chained != 2'd2);
    wire go      = dash_req && ((ccnt == 8'd0) || chain_ok) && can_pay && has_dir;

    always @(posedge clk) begin
        if (rst) begin
            dash_start <= 1'b0;
            dcnt <= 8'd0; ccnt <= 8'd0; chain_t <= 8'd0; chained <= 2'd0;
            xp <= 1'b0; xn <= 1'b0; yp <= 1'b0; yn <= 1'b0;
        end else begin
            dash_start <= 1'b0;
            if (go) begin
                dash_start <= 1'b1;
                dcnt <= dash_len;
                chain_t <= 8'd0;
                chained <= (ccnt != 8'd0) ? chained + 2'd1 : 2'd0;
                ccnt <= COOLDOWN_TICKS;
                xp <= (move_dx > 7'sd0);
                xn <= (move_dx < 7'sd0);
                yp <= (move_dy > 7'sd0);
                yn <= (move_dy < 7'sd0);
            end else if (tick_60hz) begin
                if (dcnt != 8'd0) dcnt <= dcnt - 8'd1;
                if (ccnt != 8'd0) ccnt <= ccnt - 8'd1;
                if (dcnt == 8'd1) chain_t <= CHAIN_TICKS;        // dash just ended
                else if (chain_t != 8'd0) chain_t <= chain_t - 8'd1;
            end
        end
    end

    assign dashing = (dcnt != 8'd0);
    assign cooling = (ccnt != 8'd0);

    always @* begin
        dash_dx = 7'sd0;
        dash_dy = 7'sd0;
        if (dashing && xp) dash_dx = DASH_SPEED;
        if (dashing && xn) dash_dx = -DASH_SPEED;
        if (dashing && yp) dash_dy = DASH_SPEED;
        if (dashing && yn) dash_dy = -DASH_SPEED;
    end
endmodule
