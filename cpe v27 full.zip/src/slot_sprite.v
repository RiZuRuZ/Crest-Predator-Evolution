// slot_sprite: draws up to N copies of one sprite sheet (one ROM read per pixel)
//
// Generic renderer for the props (mines, explosions, jellyfish, harpoons). Each slot k
// gives its top-left world position, frame and mirroring; the lowest active slot that
// covers the pixel is read. World coordinates like the other renderers (x wraps).
//   ROM: 4-bit palette index, index 0 transparent, address = frame*W*H + y*W + x.
//   A sheet with more than 32768 entries is split in two files: frames 0..FPB-1 in
//   FILE0, frames FPB.. in FILE1 (FPB = frames per bank). FILE1 = "" means one file.
// Timing (same as player_renderer / fish_renderer):
//   world_x / world_y registered by camera -> position registered here -> ROM read
//   -> palette (combinational).
// Slot y is 11 bits with an offset of 128 (y_obj = world y + 128) so a sprite can start
// above the top of the world (harpoons coming down from off screen).
module slot_sprite #(
    parameter N       = 1,
    parameter W       = 32,
    parameter H       = 32,
    parameter FRAMES  = 4,
    parameter FPB     = 4,             // frames per bank
    parameter FILE0   = "seamine.mem",
    parameter FILE1   = "",
    parameter PAL     = "seamine_pal.mem",
    parameter WORLD_W = 1920
)(
    input  wire           clk,
    input  wire [10:0]    world_x,
    input  wire [9:0]     world_y,
    input  wire [N-1:0]   active_vec,
    input  wire [11*N-1:0] x_vec,
    input  wire [11*N-1:0] y_vec,      // world y + 128
    input  wire [3*N-1:0]  frame_vec,
    input  wire [N-1:0]   mirx_vec,
    input  wire [N-1:0]   miry_vec,
    output wire           pixel_on,
    output wire [11:0]    rgb_out
);
    localparam WH    = W * H;
    localparam DEPTH0 = FPB * WH;
    localparam DEPTH1 = (FRAMES > FPB) ? (FRAMES - FPB) * WH : 1;

    // ---- stage 1: lowest slot covering the pixel --------------------------------
    wire [10:0] wy = {1'b0, world_y} + 11'd128;
    reg        v_c;
    reg [7:0]  sx_c, sy_c;
    reg [2:0]  fr_c;
    integer k;
    reg [10:0] ox, oy;
    reg [11:0] rx;
    reg [10:0] ry;
    always @* begin
        v_c = 1'b0; sx_c = 8'd0; sy_c = 8'd0; fr_c = 3'd0;
        for (k = N - 1; k >= 0; k = k - 1) begin
            ox = x_vec[11*k +: 11];
            oy = y_vec[11*k +: 11];
            rx = (world_x >= ox) ? (world_x - ox) : ({1'b0, world_x} + WORLD_W - ox);
            ry = wy - oy;
            if (active_vec[k] && rx < W && wy >= oy && ry < H) begin
                v_c  = 1'b1;
                sx_c = mirx_vec[k] ? (W - 1 - rx[7:0]) : rx[7:0];
                sy_c = miry_vec[k] ? (H - 1 - ry[7:0]) : ry[7:0];
                fr_c = frame_vec[3*k +: 3];
            end
        end
    end

    reg        v_r, b_r;
    reg [16:0] a_r;
    always @(posedge clk) begin
        v_r <= v_c;
        b_r <= (fr_c >= FPB);
        a_r <= ((fr_c >= FPB) ? (fr_c - FPB) : fr_c) * WH + sy_c * W + sx_c;
    end

    // ---- stage 2: ROM -------------------------------------------------------------
    (* ram_style = "block" *) reg [3:0] rom0 [0:DEPTH0-1];
    initial $readmemh(FILE0, rom0);
    reg [3:0] q0;
    wire [3:0] q1;
    reg       v_d, b_d;
    always @(posedge clk) begin
        q0  <= rom0[a_r[14:0]];
        v_d <= v_r;
        b_d <= b_r;
    end
    generate
        if (FRAMES > FPB) begin : g_bank1
            (* ram_style = "block" *) reg [3:0] rom1 [0:DEPTH1-1];
            initial $readmemh(FILE1, rom1);
            reg [3:0] q1_r;
            always @(posedge clk) q1_r <= rom1[a_r[14:0]];
            assign q1 = q1_r;
        end else begin : g_nobank1
            assign q1 = 4'd0;
        end
    endgenerate

    // ---- stage 3: palette ------------------------------------------------------------
    reg [11:0] pal [0:15];
    initial $readmemh(PAL, pal);
    wire [3:0] idx = b_d ? q1 : q0;
    assign pixel_on = v_d & (idx != 4'd0);
    assign rgb_out  = pal[idx];
endmodule
