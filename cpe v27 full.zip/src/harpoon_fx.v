// harpoon_fx: everything drawn around the harpoons except the harpoon sprites
//
//   warn   dashed warning line (3 px) along the path of every harpoon of the volley.
//          It blinks faster as the shot comes: slow while more than 60 ticks are left,
//          faster below 60, fastest in the last 30 ticks.
//   home   the same line in amber for the homing harpoon (lane 0 when `homing`)
//   aim    aim mark on the homing target (world aim_x / aim_y): a ring of radius 12..14
//          with four ticks, solid while it still follows the player, blinking once it
//          has locked
//   trail  bubbles behind every flying harpoon (up to 120 px back): small dots that
//          wobble around the line, thinner further back
//   sign   warning sign at the screen edge where each harpoon will come in (16x16
//          triangle with "!", yellow; red for the homing harpoon), blinking with the line
// World layers use world_x / world_y (x wraps); the edge signs use pixel_x / pixel_y.
// Timing: inputs -> stage 1 register (per-lane tests) -> stage 2 register (outputs),
// two clocks like shield_fx.
module harpoon_fx #(
    parameter N       = 5,
    parameter WORLD_W = 1920
)(
    input  wire            clk,
    input  wire [10:0]     world_x,
    input  wire [9:0]      world_y,
    input  wire [9:0]      pixel_x,
    input  wire [9:0]      pixel_y,
    input  wire [10:0]     cam_x,
    input  wire [9:0]      cam_y,
    input  wire [9:0]      anim_t,
    input  wire            warn_on,
    input  wire            fly_on,
    input  wire [6:0]      warn_t,
    input  wire            homing,
    input  wire            locked,
    input  wire [10:0]     aim_x,
    input  wire [9:0]      aim_y,
    input  wire [N-1:0]    lane_on,
    input  wire [N-1:0]    vert,
    input  wire [N-1:0]    back,
    input  wire [11*N-1:0] line_x_vec,
    input  wire [10*N-1:0] line_y_vec,
    input  wire [11*N-1:0] hx_vec,
    input  wire [11*N-1:0] hy_vec,        // world y + 128
    output reg             warn_px,
    output reg             home_px,
    output reg             aim_px,
    output reg             trail_px,
    output reg             sign_px,
    output reg  [11:0]     sign_rgb
);
    function [10:0] wrap(input [11:0] v);           // 0 .. 2*WORLD_W-1 -> 0 .. WORLD_W-1
        wrap = (v >= WORLD_W) ? v - WORLD_W : v[10:0];
    endfunction

    // blink of the warning: faster when the shot is near
    wire blink = (warn_t > 7'd60) ? anim_t[3] : (warn_t > 7'd30) ? anim_t[2] : anim_t[1];

    wire [10:0] wy128 = {1'b0, world_y} + 11'd128;

    // ---------------- stage 1: per-lane tests ----------------
    reg [N-1:0] line_c, trail_c, sign_c;
    reg [3:0]   sgx_c [0:N-1];
    reg [3:0]   sgy_c [0:N-1];
    integer k;
    reg [10:0] lx, hx, hx_end, d_raw, dxa;
    reg [9:0]  ly, lxd, lyd;
    reg [10:0] hy, d;
    reg        dvalid;
    reg signed [11:0] p;
    reg [4:0]  seg;
    reg [2:0]  u;
    reg signed [3:0] wob;
    reg [10:0] sxs;                 // lane x on the screen
    reg [10:0] sys;                 // lane y on the screen
    reg [9:0]  ex, ey;              // sign top-left (screen)
    reg        sv;
    always @* begin
        for (k = 0; k < N; k = k + 1) begin
            lx = line_x_vec[11*k +: 11];
            ly = line_y_vec[10*k +: 10];
            hx = hx_vec[11*k +: 11];
            hy = hy_vec[11*k +: 11];
            hx_end = 11'd0; d_raw = 11'd0; d = 11'd0; dvalid = 1'b0; p = 12'sd0;
            ex = 10'd0; ey = 10'd0; sv = 1'b0;

            // warning line (3 px wide, dashed every 8 px)
            dxa = (world_x >= lx) ? world_x - lx : lx - world_x;
            lxd = (dxa > WORLD_W / 2) ? WORLD_W - dxa : dxa;
            lyd = (world_y >= ly) ? world_y - ly : ly - world_y;
            line_c[k] = lane_on[k] && (vert[k] ? (lxd < 10'd2 && world_y[3])
                                                : (lyd < 10'd2 && world_x[3]));

            // bubble trail: d = distance behind the tail, p = offset across the line
            if (!vert[k]) begin
                hx_end = wrap({1'b0, hx} + 12'd88);
                d_raw  = back[k] ? wrap({1'b0, world_x} + WORLD_W - hx_end)   // flies left: tail on the right
                                 : wrap({1'b0, hx} + WORLD_W - world_x);       // flies right: tail on the left
                d      = d_raw;
                dvalid = 1'b1;
                p      = $signed({2'b00, world_y}) - $signed({2'b00, ly});
            end else begin
                // flies down: tail at the top (hy - 128); flies up: tail at the bottom (hy - 40)
                if (!back[k]) begin dvalid = (hy >= wy128);           d = hy - wy128; end
                else          begin dvalid = (wy128 >= hy + 11'd88);  d = wy128 - hy - 11'd88; end
                p = (world_x >= lx) ? $signed({1'b0, lxd}) : -$signed({1'b0, lxd});
            end
            seg = d[7:3];
            u    = d[2:0];
            wob  = $signed({1'b0, (seg * 3'd5 + k[2:0] + anim_t[4:2]) % 3'd7}) - 4'sd3;
            trail_c[k] = fly_on && lane_on[k] && dvalid && (d < 11'd120) &&
                         (u >= 3'd2) && (u < 3'd5) &&
                         (p >= wob - 1) && (p <= wob + 1) &&
                         !(seg > 5'd7 && seg[0]);

            // edge sign: where the harpoon comes in (screen coordinates)
            sxs = wrap({1'b0, lx} + WORLD_W - cam_x);
            sys = {1'b0, ly} - {1'b0, cam_y};
            if (!vert[k]) begin
                sv = (ly >= cam_y + 10'd8) && (ly < cam_y + 10'd472);
                ex = back[k] ? 10'd620 : 10'd4;
                ey = sys[9:0] - 10'd8;
            end else begin
                sv = (sxs >= 11'd8) && (sxs < 11'd632);
                ex = sxs[9:0] - 10'd8;
                ey = back[k] ? 10'd456 : 10'd56;
            end
            sign_c[k] = warn_on && lane_on[k] && sv &&
                        (pixel_x >= ex) && (pixel_x < ex + 10'd16) &&
                        (pixel_y >= ey) && (pixel_y < ey + 10'd16);
            sgx_c[k] = pixel_x[3:0] - ex[3:0];
            sgy_c[k] = pixel_y[3:0] - ey[3:0];
        end
    end

    // aim mark around (aim_x, aim_y)
    wire [10:0] adxa = (world_x >= aim_x) ? world_x - aim_x : aim_x - world_x;
    wire [10:0] adx  = (adxa > WORLD_W / 2) ? WORLD_W - adxa : adxa;
    wire [9:0]  ady  = (world_y >= aim_y) ? world_y - aim_y : aim_y - world_y;
    wire        anear = homing && warn_on && (adx < 11'd24) && (ady < 10'd24);

    wire [N-1:0] home_mask = {{(N-1){1'b0}}, homing};      // lane 0 drawn as `home`
    reg        line_r, home_r, trail_r, sign_r, sign_home_r, anear_r, blink_r, lock_r;
    reg [3:0]  sgx_r, sgy_r;
    reg [4:0]  adx_r, ady_r;
    integer j;
    always @(posedge clk) begin
        line_r  <= warn_on && |(line_c & ~home_mask);
        home_r  <= warn_on && homing && line_c[0];
        trail_r <= |trail_c;
        sign_r  <= |sign_c;
        sign_home_r <= 1'b0;
        sgx_r   <= 4'd0; sgy_r <= 4'd0;
        for (j = N - 1; j >= 0; j = j - 1)
            if (sign_c[j]) begin
                sgx_r <= sgx_c[j]; sgy_r <= sgy_c[j];
                sign_home_r <= homing && (j == 0);
            end
        anear_r <= anear;
        adx_r   <= adx[4:0];
        ady_r   <= ady[4:0];
        blink_r <= blink;
        lock_r  <= locked;
    end

    // ---------------- stage 2 ----------------
    // aim ring radius 12..14 (144 <= d2 < 225) + ticks 16..22 px out on both axes
    wire [10:0] ad2  = adx_r * adx_r + ady_r * ady_r;
    wire        aring = (ad2 >= 11'd144) && (ad2 < 11'd225);
    wire        atick = ((adx_r < 5'd2) && (ady_r >= 5'd16) && (ady_r < 5'd23)) ||
                        ((ady_r < 5'd2) && (adx_r >= 5'd16) && (adx_r < 5'd23));
    wire        adot  = (adx_r < 5'd2) && (ady_r < 5'd2);

    // warning sign: triangle (row r: |2x - 15| <= r), dark border and "!"
    wire [4:0] c2     = (sgx_r >= 4'd8) ? {sgx_r, 1'b0} - 5'd15 : 5'd15 - {sgx_r, 1'b0};
    wire       s_in   = (c2 <= {1'b0, sgy_r});
    wire       s_edge = s_in && ((c2 + 5'd2 > {1'b0, sgy_r}) || (sgy_r == 4'd15));
    wire       s_bang = ((sgx_r == 4'd7) || (sgx_r == 4'd8)) &&
                        (((sgy_r >= 4'd5) && (sgy_r <= 4'd10)) || (sgy_r == 4'd12) || (sgy_r == 4'd13));

    always @(posedge clk) begin
        warn_px  <= line_r & blink_r;
        home_px  <= home_r & (lock_r ? blink_r : 1'b1);
        aim_px   <= anear_r && (aring || atick || adot) && (!lock_r || blink_r);
        trail_px <= trail_r;
        sign_px  <= sign_r && s_in && blink_r;
        sign_rgb <= (s_edge || s_bang) ? 12'h210 : (sign_home_r ? 12'hF43 : 12'hFD2);
    end
endmodule
