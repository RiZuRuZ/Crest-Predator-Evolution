// ps2_receiver: receives bytes from the board's USB-HID host (PS/2 emulation)
// Frame (device -> host): start 0, 8 data bits LSB first, odd parity, stop 1.
// Data is sampled on the falling edge of PS2_CLK. Both lines are synchronized,
// PS2_CLK is glitch-filtered (must be stable for FILTER clocks).
// valid is a 1-cycle pulse with data; frames with a bad start/stop/parity are dropped.
// A partial frame is discarded after TIMEOUT clocks without a clock edge (resync).
module ps2_receiver #(
    parameter FILTER  = 8,
    parameter TIMEOUT = 200000      // 2 ms at 100 MHz
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       ps2_clk,
    input  wire       ps2_data,
    output reg  [7:0] data,
    output reg        valid
);
    reg [1:0]  cs, ds;
    reg        clk_f, clk_f_d;
    reg [3:0]  fcnt;
    reg [10:0] sh;
    reg [3:0]  bitcnt;
    reg [17:0] tcnt;

    wire        fall  = clk_f_d & ~clk_f;
    wire [10:0] frame = {ds[1], sh[10:1]};   // the 11th bit arrives now, first bit ends at [0]

    always @(posedge clk) begin
        if (rst) begin
            cs <= 2'b11; ds <= 2'b11;
            clk_f <= 1'b1; clk_f_d <= 1'b1;
            fcnt <= 4'd0; sh <= 11'd0; bitcnt <= 4'd0; tcnt <= 18'd0;
            data <= 8'd0; valid <= 1'b0;
        end else begin
            cs <= {cs[0], ps2_clk};
            ds <= {ds[0], ps2_data};
            valid <= 1'b0;

            // glitch filter on the clock line
            if (cs[1] == clk_f)            fcnt <= 4'd0;
            else if (fcnt == FILTER - 1) begin clk_f <= cs[1]; fcnt <= 4'd0; end
            else                           fcnt <= fcnt + 4'd1;
            clk_f_d <= clk_f;

            if (fall) begin
                tcnt <= 18'd0;
                sh   <= frame;
                if (bitcnt == 4'd10) begin
                    bitcnt <= 4'd0;
                    if (frame[0] == 1'b0 && frame[10] == 1'b1 && (^frame[9:1]) == 1'b1) begin
                        data  <= frame[8:1];
                        valid <= 1'b1;
                    end
                end else begin
                    bitcnt <= bitcnt + 4'd1;
                end
            end else if (bitcnt != 4'd0) begin
                if (tcnt == TIMEOUT - 1) begin
                    bitcnt <= 4'd0;
                    tcnt   <= 18'd0;
                end else begin
                    tcnt <= tcnt + 18'd1;
                end
            end
        end
    end
endmodule
