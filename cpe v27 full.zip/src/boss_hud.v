// boss_hud: boss fight words and the boss HP bar (v15, screen coordinates)
//
//   HP bar   top centre under the time: "BOSS" + 12 segments of 16 px (x 190..405, y 38..47),
//            white marks between the phases (after 4 and 8 segments)
//   words    BOSS! (intro), SHAKE! (held in the jaws), FLIP THE SWITCHES! / HIDDEN
//            (switch mini game), PERFECT ROAR!, SURVIVE (spear mini game),
//            FINISH! + PERFECT / GOOD / MISS + COMBO nn (arrow mini game),
//            shake meter under SHAKE!
// v20: also on during the mini game events (`show`), but the HP bar and FINISH! only in
//      the boss fight (`fight`)
// Alignment like hud.v: text gets the coordinates 1 clock late (font lookup 2 clocks),
// boxes 3 clocks late, so everything is ready at clock 3.
module boss_hud (
    input  wire        clk,
    input  wire        show,           // boss fight or event on
    input  wire        fight,          // v20: boss fight on
    input  wire [3:0]  hp,
    input  wire        blink,
    input  wire        intro,
    input  wire        grab,
    input  wire [7:0]  meter,          // shake meter 0..200 while held
    input  wire        sw_active,
    input  wire        sw_hidden,
    input  wire        parry_show,
    input  wire        spear_on,
    input  wire [1:0]  spear_pat,      // v21: soul game pattern 0 spears, 1 bars, 2 beams
    input  wire        arrow_on,
    input  wire [1:0]  rating,         // 1 PERFECT, 2 GOOD, 3 MISS
    input  wire        rating_show,
    input  wire [3:0]  combo,
    input  wire [9:0]  pixel_x,
    input  wire [9:0]  pixel_y,
    output wire        on,
    output wire [11:0] rgb
);
    reg [9:0] tx_x, tx_y, b2_x, b2_y, bx_x, bx_y;
    always @(posedge clk) begin
        tx_x <= pixel_x; tx_y <= pixel_y;
        b2_x <= tx_x;    b2_y <= tx_y;
        bx_x <= b2_x;    bx_y <= b2_y;
    end

    // ---- HP bar ----
    // (the right HUD box starts at x 428, so the bar stays left of it)
    wire       in_box = (bx_x >= 10'd146) && (bx_x < 10'd412) && (bx_y >= 10'd34) && (bx_y < 10'd52);
    wire [9:0] sx     = bx_x - 10'd190;
    wire [3:0] seg_i  = sx / 10'd18;                       // segment 0..11
    wire       in_seg = (bx_x >= 10'd190) && (bx_x < 10'd406) && (bx_y >= 10'd38) && (bx_y < 10'd48) &&
                        ((sx % 10'd18) < 10'd16);
    wire       mark   = (bx_y >= 10'd36) && (bx_y < 10'd50) && ((bx_x == 10'd261) || (bx_x == 10'd333));
    wire       seg_full = in_seg && (seg_i < hp);

    wire t_boss;
    text_line #(.X0(152), .Y0(39), .S(0), .N(4), .TEXT("BOSS")) u_lbl (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(t_boss));

    // ---- words ----
    wire w_intro, w_shake, w_flip, w_hid, w_roar, w_surv, w_fin, w_perf, w_good, w_miss, w_combo;
    text_line #(.X0(240), .Y0(190), .S(2), .N(5),  .TEXT("BOSS!")) u_w0 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_intro));
    text_line #(.X0(272), .Y0(120), .S(1), .N(6),  .TEXT("SHAKE!")) u_w1 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_shake));
    text_line #(.X0(176), .Y0(120), .S(1), .N(18), .TEXT("FLIP THE SWITCHES!")) u_w2 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_flip));
    text_line #(.X0(272), .Y0(120), .S(1), .N(6),  .TEXT("HIDDEN")) u_w3 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_hid));
    text_line #(.X0(216), .Y0(120), .S(1), .N(13), .TEXT("PERFECT ROAR!")) u_w4 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_roar));
    text_line #(.X0(264), .Y0(358), .S(1), .N(7),  .TEXT("SURVIVE")) u_w5 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_surv));
    // v21 soul game hints
    wire w_blue, w_orng, w_lines;
    text_line #(.X0(152), .Y0(358), .S(1), .N(9),  .TEXT("BLUE STOP")) u_w5b (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_blue));
    text_line #(.X0(320), .Y0(358), .S(1), .N(11), .TEXT("ORANGE MOVE")) u_w5o (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_orng));
    text_line #(.X0(200), .Y0(358), .S(1), .N(15), .TEXT("WATCH THE LINES")) u_w5l (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_lines));
    text_line #(.X0(264), .Y0(120), .S(1), .N(7),  .TEXT("FINISH!")) u_w6 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_fin));
    text_line #(.X0(190), .Y0(350), .S(1), .N(7),  .TEXT("PERFECT")) u_w7 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_perf));
    text_line #(.X0(190), .Y0(350), .S(1), .N(4),  .TEXT("GOOD")) u_w8 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_good));
    text_line #(.X0(190), .Y0(350), .S(1), .N(4),  .TEXT("MISS")) u_w9 (
        .clk(clk), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_miss));
    reg [63:0] combo_txt;
    always @(posedge clk)
        combo_txt <= {"COMBO ", 8'h30 + combo / 10, 8'h30 + combo % 10};
    text_dyn #(.X0(540), .Y0(366), .S(0), .N(8)) u_combo (
        .clk(clk), .chars(combo_txt), .pixel_x(tx_x), .pixel_y(tx_y), .pixel_on(w_combo));

    // shake meter under SHAKE!: 100 px = 200 (x 270..369, y 142..147)
    wire in_mtr  = grab && (bx_x >= 10'd270) && (bx_x < 10'd370) && (bx_y >= 10'd142) && (bx_y < 10'd148);
    wire mtr_on  = in_mtr && ((bx_x - 10'd270) < {3'd0, meter[7:1]});

    wire show_intro = intro && blink && w_intro;
    wire show_shake = grab && blink && w_shake;
    wire show_flip  = sw_active && !sw_hidden && w_flip;
    wire show_hid   = sw_hidden && w_hid;
    wire show_roar  = parry_show && w_roar;
    wire show_surv  = spear_on && (((spear_pat == 2'd0) && w_surv) || ((spear_pat == 2'd2) && w_lines));
    wire show_blue  = spear_on && (spear_pat == 2'd1) && w_blue;
    wire show_orng  = spear_on && (spear_pat == 2'd1) && w_orng;
    wire show_fin   = fight && arrow_on && w_fin;
    wire show_rate  = arrow_on && rating_show &&
                      (((rating == 2'd1) && w_perf) || ((rating == 2'd2) && w_good) ||
                       ((rating == 2'd3) && w_miss));
    wire show_combo = arrow_on && (combo != 4'd0) && w_combo;
    wire word = show_intro | show_shake | show_flip | show_hid | show_roar | show_surv | show_blue | show_orng |
                show_fin | show_rate | show_combo;

    assign on  = show && (word || (fight && in_box) || in_mtr);
    assign rgb = show_intro ? 12'hF43 :
                 show_shake ? 12'hFE5 :
                 show_flip  ? 12'hFE5 :
                 show_hid   ? 12'h8F8 :
                 show_roar  ? 12'h9EF :
                 show_fin   ? 12'hFD4 :
                 show_blue  ? 12'h3AF :
                 show_orng  ? 12'hF92 :
                 show_rate  ? ((rating == 2'd1) ? 12'h9EF : (rating == 2'd2) ? 12'h9F9 : 12'hF66) :
                 show_surv || show_combo ? 12'hFFF :
                 mtr_on     ? 12'hF93 :
                 in_mtr     ? 12'h234 :
                 t_boss     ? 12'hFFF :
                 mark       ? 12'hFFF :
                 seg_full   ? 12'hF55 :
                 in_seg     ? 12'h335 : 12'h013;
endmodule
