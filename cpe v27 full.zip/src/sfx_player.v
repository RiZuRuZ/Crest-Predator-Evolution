// sfx_player: short square-wave sound effects on the mono audio jack (AUD_PWM)
// Triggers are 1-cycle pulses. A new sound replaces the one playing; if several
// arrive together the most important wins: death > win > evolve > hit > bubble > eat.
// Each sound is up to 4 notes; a note is a frequency (as a half period in clocks)
// and a length in ms. mute = 1 silences everything.
// v14: the eat sound rises with eat_step (0..7, consecutive eats from top.v): every step
// is a whole tone higher (half period x 256/288 per step, table EAT_MUL).
// The tone is made by switching a fast PWM carrier (390 kHz) between two duty levels,
// 128 +/- VOL; silence is a steady 50 % duty (filtered to a flat level by the board).
// v27: the background music level (music_player, -100..100) is added to the duty:
// duty = 128 + effect (+-VOL) + mus, clamped to 0..255. mute silences everything.
module sfx_player #(
    parameter [7:0] VOL = 8'd40,
    // clock-rate dependent (defaults for 100 MHz; top.v runs at 25 MHz: 2 and 25000)
    parameter CLK_SHIFT = 0,          // half periods in the table are divided by 2^CLK_SHIFT
    parameter MS_CLKS   = 100000      // clocks per millisecond
)(
    input  wire clk,
    input  wire rst,
    input  wire mute,
    input  wire eat,
    input  wire [2:0] eat_step,  // 0 = first eat, 7 = 8th eat in a row (pitch up)
    input  wire bubble,
    input  wire evolve,
    input  wire hit,
    input  wire death,
    input  wire win,
    input  wire alarm,          // shark / harpoon warning (two-tone siren)
    input  wire signed [7:0] mus,   // v27 music level (-100..100, 0 = none)
    output reg  pwm_out
);
    localparam [2:0] NONE = 3'd0, S_EAT = 3'd1, S_BUB = 3'd2, S_EVO = 3'd3,
                     S_HIT = 3'd4, S_DEATH = 3'd5, S_WIN = 3'd6, S_ALARM = 3'd7;

    // half period in clocks = 100 MHz / (2 * f) (>> CLK_SHIFT for a slower clock). 0 = end of the sound.
    function [18:0] half_period(input [2:0] s, input [1:0] n);
        case ({s, n})
            {S_EAT,   2'd0}: half_period = 19'd31888;    // 1568 Hz
            {S_EAT,   2'd1}: half_period = 19'd23889;    // 2093 Hz
            {S_BUB,   2'd0}: half_period = 19'd63776;    //  784 Hz
            {S_BUB,   2'd1}: half_period = 19'd47755;    // 1047 Hz
            {S_BUB,   2'd2}: half_period = 19'd37907;    // 1319 Hz
            {S_EVO,   2'd0}: half_period = 19'd95602;    //  523 Hz
            {S_EVO,   2'd1}: half_period = 19'd75873;    //  659 Hz
            {S_EVO,   2'd2}: half_period = 19'd63776;    //  784 Hz
            {S_EVO,   2'd3}: half_period = 19'd47755;    // 1047 Hz
            {S_HIT,   2'd0}: half_period = 19'd255102;   //  196 Hz
            {S_HIT,   2'd1}: half_period = 19'd340136;   //  147 Hz
            {S_DEATH, 2'd0}: half_period = 19'd127551;   //  392 Hz
            {S_DEATH, 2'd1}: half_period = 19'd151515;   //  330 Hz
            {S_DEATH, 2'd2}: half_period = 19'd190840;   //  262 Hz
            {S_DEATH, 2'd3}: half_period = 19'd255102;   //  196 Hz
            {S_WIN,   2'd0}: half_period = 19'd63776;    //  784 Hz
            {S_WIN,   2'd1}: half_period = 19'd47755;    // 1047 Hz
            {S_WIN,   2'd2}: half_period = 19'd63776;    //  784 Hz
            {S_WIN,   2'd3}: half_period = 19'd47755;    // 1047 Hz
            {S_ALARM, 2'd0}: half_period = 19'd56818;    //  880 Hz
            {S_ALARM, 2'd1}: half_period = 19'd75758;    //  660 Hz
            {S_ALARM, 2'd2}: half_period = 19'd56818;    //  880 Hz
            {S_ALARM, 2'd3}: half_period = 19'd75758;    //  660 Hz
            default:         half_period = 19'd0;
        endcase
    endfunction

    function [9:0] note_ms(input [2:0] s, input [1:0] n);
        case ({s, n})
            {S_EAT,   2'd0}, {S_EAT,   2'd1}:                 note_ms = 10'd40;
            {S_BUB,   2'd0}, {S_BUB,   2'd1}, {S_BUB, 2'd2}:  note_ms = 10'd50;
            {S_EVO,   2'd0}, {S_EVO,   2'd1}, {S_EVO, 2'd2}:  note_ms = 10'd100;
            {S_EVO,   2'd3}:                                  note_ms = 10'd250;
            {S_HIT,   2'd0}, {S_HIT,   2'd1}:                 note_ms = 10'd120;
            {S_DEATH, 2'd0}, {S_DEATH, 2'd1}, {S_DEATH, 2'd2}: note_ms = 10'd200;
            {S_DEATH, 2'd3}:                                  note_ms = 10'd500;
            {S_WIN,   2'd0}, {S_WIN,   2'd1}, {S_WIN, 2'd2}:  note_ms = 10'd120;
            {S_WIN,   2'd3}:                                  note_ms = 10'd400;
            {S_ALARM, 2'd0}, {S_ALARM, 2'd1},
            {S_ALARM, 2'd2}, {S_ALARM, 2'd3}:                 note_ms = 10'd150;
            default:                                          note_ms = 10'd0;
        endcase
    endfunction

    wire [2:0] trig = death  ? S_DEATH :
                      win    ? S_WIN   :
                      alarm  ? S_ALARM :
                      evolve ? S_EVO   :
                      hit    ? S_HIT   :
                      bubble ? S_BUB   :
                      eat    ? S_EAT   : NONE;

    reg [16:0] ms_cnt;
    wire       ms_tick = (ms_cnt == MS_CLKS - 1);

    reg [2:0]  snd;
    reg [1:0]  note;
    reg [9:0]  ms_left;
    reg [18:0] tone_cnt;
    reg        phase;
    reg [7:0]  car;

    // whole-tone steps: 256 / 1.1225^k
    function [8:0] eat_mul(input [2:0] k);
        case (k)
            3'd0: eat_mul = 9'd256;
            3'd1: eat_mul = 9'd228;
            3'd2: eat_mul = 9'd203;
            3'd3: eat_mul = 9'd181;
            3'd4: eat_mul = 9'd161;
            3'd5: eat_mul = 9'd144;
            3'd6: eat_mul = 9'd128;
            default: eat_mul = 9'd114;
        endcase
    endfunction
    reg  [2:0]  step;                                   // eat_step latched at the trigger
    reg  [8:0]  mul;
    always @(posedge clk) mul <= (snd == S_EAT) ? eat_mul(step) : 9'd256;
    wire [18:0] hp0       = half_period(snd, note) >> CLK_SHIFT;
    wire [27:0] hp_m      = hp0 * mul;
    wire [18:0] hp        = hp_m[26:8];
    wire [9:0]  next_ms   = note_ms(snd, note + 2'd1);
    wire        last_note = (note == 2'd3) || (next_ms == 10'd0);

    // v27 mix: 128 + effect + music, clamped to 0..255
    wire signed [9:0] fx   = (snd == NONE) ? 10'sd0 : phase ? $signed({2'b00, VOL}) : -$signed({2'b00, VOL});
    wire signed [9:0] dsum = 10'sd128 + fx + mus;
    wire        [9:0] duty = dsum[9] ? 10'd0 : (dsum > 10'sd255) ? 10'd255 : dsum;

    always @(posedge clk) begin
        if (rst) begin
            ms_cnt <= 17'd0; snd <= NONE; note <= 2'd0; ms_left <= 10'd0;
            tone_cnt <= 19'd0; phase <= 1'b0; car <= 8'd0; pwm_out <= 1'b0;
            step <= 3'd0;
        end else begin
            ms_cnt <= ms_tick ? 17'd0 : ms_cnt + 17'd1;
            car    <= car + 8'd1;

            if (trig != NONE) begin
                snd      <= trig;
                step     <= eat_step;
                note     <= 2'd0;
                ms_left  <= note_ms(trig, 2'd0);
                tone_cnt <= 19'd0;
            end else if (snd != NONE && ms_tick) begin
                if (ms_left <= 10'd1) begin
                    if (last_note) snd <= NONE;
                    else begin
                        note    <= note + 2'd1;
                        ms_left <= next_ms;
                    end
                end else begin
                    ms_left <= ms_left - 10'd1;
                end
            end

            if (snd == NONE) begin
                tone_cnt <= 19'd0;
                phase    <= 1'b0;
            end else if (tone_cnt >= hp - 19'd1) begin
                tone_cnt <= 19'd0;
                phase    <= ~phase;
            end else begin
                tone_cnt <= tone_cnt + 19'd1;
            end

            if (mute) pwm_out <= car[7];                                       // 50 %: silence
            else      pwm_out <= {2'b00, car} < duty;
        end
    end
endmodule
