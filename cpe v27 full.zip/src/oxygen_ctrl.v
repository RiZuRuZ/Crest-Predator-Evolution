// oxygen_ctrl: oxygen level (rule 4.3: no surface, bubbles are the only refill)
// - drains 1 unit every DRAIN_TICKS ticks
// - dash_start  (pulse) costs DASH_COST
// - bubble_eat  (pulse) adds BUBBLE_REFILL, or 2x when double_refill = 1
//   (EVO1 Bubble Breath), clamped at OXY_MAX
// - empty goes high when oxygen reaches 0 and stays high until rst (out of oxygen = death)
// - can_dash = enough oxygen left for one dash without reaching 0
// All numbers are placeholders until the team decides the real values.
module oxygen_ctrl #(
    parameter OXY_MAX       = 960,   // 16 LEDs x 60
    parameter DRAIN_TICKS   = 4,     // 960 * 4 ticks = 64 s from full to empty
    parameter DASH_COST     = 60,
    parameter BUBBLE_REFILL = 240,
    parameter MINE_COST     = 120    // PLACEHOLDER
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       tick_60hz,
    input  wire [1:0] diff,      // v18: drain every 6 / 4 / 3 ticks (easy / normal / hard)
    input  wire       dash_start,
    input  wire       bubble_eat,
    input  wire       double_refill,
    input  wire       hold,           // Current Rider: no drain while riding a current
    input  wire       penalty,        // 1-clk pulse: form 4 ate a sea mine (-MINE_COST)
    output reg  [9:0] oxygen,
    output reg        empty,
    output wire       can_dash
);
    reg [7:0] dcnt;
    wire [7:0] drain_m1 = (diff == 2'd0) ? 8'd5 : (diff == 2'd2) ? 8'd2 : DRAIN_TICKS - 1;
    wire drain_now = tick_60hz && (dcnt == drain_m1);

    reg [11:0] nxt, sub;
    always @* begin
        nxt = {2'b00, oxygen};
        if (bubble_eat) nxt = nxt + (double_refill ? 2 * BUBBLE_REFILL : BUBBLE_REFILL);
        if (nxt > OXY_MAX) nxt = OXY_MAX;
        sub = (dash_start ? DASH_COST : 0) + ((drain_now && !hold) ? 1 : 0)
            + (penalty ? MINE_COST : 0);
        if (nxt <= sub) nxt = 12'd0;
        else            nxt = nxt - sub;
    end

    always @(posedge clk) begin
        if (rst) begin
            oxygen <= OXY_MAX;
            empty  <= 1'b0;
            dcnt   <= 8'd0;
        end else begin
            if (tick_60hz) dcnt <= (dcnt >= drain_m1) ? 8'd0 : dcnt + 8'd1;
            if (!empty) begin
                oxygen <= nxt[9:0];
                if (nxt == 12'd0) empty <= 1'b1;
            end
        end
    end

    assign can_dash = (oxygen > DASH_COST);
endmodule
