// player_anim_fsm.v
// Animation of the player sprite: which frame to draw, plus the eat / hit effects.
// The frame layout is the same for every evolution form:
//
//   frame 0,1  idle   (2-frame breathing loop, used when the player is still)
//   frame 2..5 swim   (4-frame loop, used while the player moves)
//   frame 6..9 bite   (swim frames 2..5 with the mouth open, made by split_sprite_roms.py)
//
// Eating and getting hit do NOT switch to another picture (the separate hurt / eat
// poses looked jarring, and the form 4 poses were smaller than its swim pose).
// The idle / swim loop keeps running and an effect is added on top:
//   near : an edible fish is close (fish_pool.near) - the mouth opens (swim frame + 4,
//          the wings keep flapping; when idle, bite frame 6)
//   eat  : the mouth stays open BITE_TICKS more ticks, then snaps shut;
//          lunge - the sprite is drawn up to 3 px forward and comes back
//          (lunge = 1,2,3,3,3,3,2,2,2,1,1,1 over EAT_TICKS = 12 ticks), and it
//          flashes brighter for the first FLASH_TICKS ticks
//   hurt : the same flash; no lunge, the knockback (hit_recovery) already moves the
//          player away from the fish
// A new pulse restarts its effect. The lunge only moves the drawing, not the player.
// Loops: IDLE <-> SWIM follows `moving` immediately; the loop restarts at its first frame.
// All timing counts tick_60hz pulses (conventions.md). rst is active-high, synchronous.
module player_anim_fsm #(
    parameter SWIM_TICKS  = 6,    // ticks per swim frame  (60/6  = 10 fps)
    parameter IDLE_TICKS  = 30,   // ticks per idle frame  (0.5 s)
    parameter EAT_TICKS   = 12,   // lunge duration        (0.2 s)
    parameter FLASH_TICKS = 4,    // flash duration
    parameter BITE_TICKS  = 6     // mouth open duration (0.1 s)
) (
    input  wire       clk,
    input  wire       rst,
    input  wire       tick_60hz,
    input  wire       moving,    // 1 while the player is moving (any direction)
    input  wire       hurt,      // 1-clk pulse
    input  wire       eat,       // 1-clk pulse
    input  wire       near,      // level: an edible fish is close
    output reg  [3:0] frame,     // sprite ROM frame index 0..9
    output reg  [1:0] lunge,     // forward drawing offset in pixels, 0..3
    output wire       flash,     // draw the sprite brighter
    output reg  [1:0] state      // 0 idle, 1 swim (for debug / LEDs)
);

    localparam [1:0] S_IDLE = 2'd0, S_SWIM = 2'd1;

    reg [7:0] timer;     // ticks left in the current idle / swim frame
    reg [1:0] fidx;      // frame counter inside the idle / swim loop
    reg [4:0] eat_t;     // ticks since the eat pulse, EAT_TICKS = done
    reg [4:0] flash_t;   // flash ticks left

    wire [1:0] free_state = moving ? S_SWIM : S_IDLE;
    wire [7:0] free_ticks = moving ? SWIM_TICKS : IDLE_TICKS;

    always @(posedge clk) begin
        if (rst) begin
            state <= S_IDLE;
            timer <= IDLE_TICKS;
            fidx  <= 2'd0;
        end else if (state != free_state) begin
            // movement started or stopped: switch loop, restart at its first frame
            state <= free_state;
            fidx  <= 2'd0;
            timer <= free_ticks;
        end else if (tick_60hz) begin
            if (timer <= 8'd1) begin
                timer <= free_ticks;
                fidx  <= fidx + 2'd1;
            end else begin
                timer <= timer - 8'd1;
            end
        end
    end

    // effects
    always @(posedge clk) begin
        if (rst) begin
            eat_t   <= EAT_TICKS;
            flash_t <= 5'd0;
        end else begin
            if (eat)
                eat_t <= 5'd0;
            else if (tick_60hz && eat_t < EAT_TICKS)
                eat_t <= eat_t + 5'd1;

            if (eat || hurt)
                flash_t <= FLASH_TICKS;
            else if (tick_60hz && flash_t != 5'd0)
                flash_t <= flash_t - 5'd1;
        end
    end
    assign flash = (flash_t != 5'd0);

    // lunge profile over the 12 eat ticks: out fast, back slowly
    always @(*) begin
        if (eat_t >= EAT_TICKS)  lunge = 2'd0;
        else if (eat_t == 5'd0)  lunge = 2'd1;
        else if (eat_t == 5'd1)  lunge = 2'd2;
        else if (eat_t < 5'd6)   lunge = 2'd3;
        else if (eat_t < 5'd9)   lunge = 2'd2;
        else                     lunge = 2'd1;
    end

    wire biting = near | (eat_t < BITE_TICKS);
    always @(*) begin
        case (state)
            S_SWIM:  frame = (biting ? 4'd6 : 4'd2) + {2'b00, fidx};   // 2..5, bite 6..9
            default: frame = biting ? 4'd6 : {3'b000, fidx[0]};        // 0, 1, bite 6
        endcase
    end

endmodule
