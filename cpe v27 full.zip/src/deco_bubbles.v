// deco_bubbles: decorative bubbles rising at random places in the background (no game effect)
// They replace the bubbles that were painted in the map (tools/clean_bubbles.py removed them).
// N bubbles, each with its own random:
//   - start position: x around the camera view (so they appear wherever the player goes),
//     y on the sea floor / rocks (Y_SPAWN .. Y_SPAWN + 255)
//   - size 5..13 px (small ones are more common), rise speed (15 / 30 / 45 px per second),
//     sideways wobble phase, and the height where it disappears (Y_TOP .. Y_TOP + 127)
// A bubble that reached its height, or is far from the camera, is "free". One bubble index
// is checked per frame (round robin) and respawned if free, so new bubbles appear one by one.
// Drawn as round rings (shine on 9 px and up), without fill, so they stay different from the
// real oxygen bubbles (16 px, filled). Works in world coordinates (world_x / world_y from
// camera). The output is registered (1 clock), safe because the pixel changes every 4 clocks.
module deco_bubbles #(
    parameter WORLD_W = 1920,
    parameter VIEW_W  = 640,
    parameter MARGIN  = 64,
    parameter Y_SPAWN = 380,
    parameter Y_TOP   = 90,
    parameter [11:0] RIM   = 12'hBEF,
    parameter [11:0] SHINE = 12'hFFF
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        frame_tick,
    input  wire [10:0] cam_x,
    input  wire [10:0] world_x,
    input  wire [9:0]  world_y,
    output reg         pixel_on,
    output reg  [11:0] rgb
);
    localparam N = 24;

    // ---- own random source (independent of the game, keeps running) ----
    reg [15:0] lfsr;
    always @(posedge clk) begin
        if (rst) lfsr <= 16'h7A3D;
        else     lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
    end
    reg [15:0] lfsr2;                       // a second, differently tapped value for more bits
    always @(posedge clk) begin
        if (rst) lfsr2 <= 16'hC0DE;
        else     lfsr2 <= {lfsr2[14:0], lfsr2[15] ^ lfsr2[14] ^ lfsr2[12] ^ lfsr2[3]};
    end

    function [3:0] size_of(input [2:0] code);   // small sizes twice as likely
        case (code)
            3'd0, 3'd1: size_of = 4'd5;
            3'd2, 3'd3: size_of = 4'd7;
            3'd4, 3'd5: size_of = 4'd9;
            3'd6:       size_of = 4'd11;
            default:    size_of = 4'd13;
        endcase
    endfunction

    // ---- bubble state ----
    reg        alive [0:N-1];
    reg [10:0] bx    [0:N-1];
    reg [9:0]  by    [0:N-1];
    reg [9:0]  btop  [0:N-1];
    reg [3:0]  bsz   [0:N-1];
    reg [1:0]  brate [0:N-1];               // 1..3 quarter pixels per frame
    reg [1:0]  bacc  [0:N-1];
    reg [2:0]  bph   [0:N-1];               // wobble phase
    reg [4:0]  rr;                          // round-robin index for respawning

    // random spawn values (from the current LFSR state)
    wire [9:0]  r_x     = lfsr[9:0] % 10'd768;                 // 0 .. 767
    wire [12:0] sx_raw  = {2'b00, cam_x} + WORLD_W - MARGIN + r_x;      // up to 4542
    wire [12:0] sx_m    = (sx_raw >= 2 * WORLD_W) ? sx_raw - 2 * WORLD_W :
                          (sx_raw >= WORLD_W)     ? sx_raw - WORLD_W : sx_raw;
    wire [10:0] spawn_x = sx_m[10:0];
    wire [9:0]  spawn_y = Y_SPAWN + lfsr2[7:0];
    wire [9:0]  spawn_t = Y_TOP + lfsr2[14:8];
    wire [3:0]  spawn_s = size_of(lfsr[12:10]);
    wire [1:0]  spawn_r = (lfsr[14:13] == 2'd0) ? 2'd2 : lfsr[14:13];   // 1, 2 (x2), 3
    wire [2:0]  spawn_p = lfsr2[2:0];

    integer i;
    reg [11:0] rel_raw, rel;
    reg [2:0]  sum;
    always @(posedge clk) begin
        if (rst) begin
            rr <= 5'd0;
            for (i = 0; i < N; i = i + 1) begin
                alive[i] <= 1'b0; bx[i] <= 11'd0; by[i] <= 10'd0; btop[i] <= 10'd0;
                bsz[i] <= 4'd5; brate[i] <= 2'd1; bacc[i] <= 2'd0; bph[i] <= 3'd0;
            end
        end else if (frame_tick) begin
            rr <= (rr == N - 1) ? 5'd0 : rr + 5'd1;
            for (i = 0; i < N; i = i + 1) begin
                // far from the camera -> free
                rel_raw = {1'b0, bx[i]} + WORLD_W - cam_x;
                rel     = (rel_raw >= WORLD_W) ? rel_raw - WORLD_W : rel_raw;
                if (i == rr && !alive[i]) begin
                    alive[i] <= 1'b1;
                    bx[i]    <= spawn_x;
                    by[i]    <= (spawn_y > 10'd620) ? 10'd620 : spawn_y;
                    btop[i]  <= spawn_t;
                    bsz[i]   <= spawn_s;
                    brate[i] <= spawn_r;
                    bacc[i]  <= 2'd0;
                    bph[i]   <= spawn_p;
                end else if (alive[i]) begin
                    if (by[i] <= btop[i] ||
                        (rel >= VIEW_W + MARGIN && rel < WORLD_W - 2 * MARGIN))
                        alive[i] <= 1'b0;
                    else begin
                        sum     = {1'b0, bacc[i]} + {1'b0, brate[i]};
                        bacc[i] <= sum[1:0];
                        if (sum[2]) by[i] <= by[i] - 10'd1;
                    end
                end
            end
        end
    end

    // ---- drawing: ring when size^2 >= d2 > (size-3)^2, with doubled coordinates ----
    integer n;
    reg [11:0] bxw, rx;
    reg [10:0] ry;
    reg [3:0]  sz;
    reg [2:0]  ph;
    reg [1:0]  wob;                     // 0..2, i.e. -1..+1 after the "- 1" below
    reg signed [6:0] X, Y, HX, HY;
    reg [13:0] d2, h2;
    reg        on_c;
    reg [11:0] rgb_c;
    always @* begin
        on_c  = 1'b0;
        rgb_c = RIM;
        for (n = 0; n < N; n = n + 1) begin
            sz = bsz[n];
            ph = by[n][5:3] + bph[n];
            case (ph[2:1])
                2'd0: wob = 2'd1;  2'd1: wob = 2'd2;  2'd2: wob = 2'd1;  default: wob = 2'd0;
            endcase
            bxw = {1'b0, bx[n]} + WORLD_W - 1 + wob;
            if (bxw >= WORLD_W) bxw = bxw - WORLD_W;
            rx = (world_x >= bxw) ? (world_x - bxw) : ({1'b0, world_x} + WORLD_W - bxw);
            ry = {1'b0, world_y} - {1'b0, by[n]};
            if (alive[n] && world_y >= by[n] && rx < sz && ry < sz) begin
                X  = $signed({2'b00, rx[4:0]} << 1) - $signed({3'b000, sz}) + 7'sd1;
                Y  = $signed({2'b00, ry[4:0]} << 1) - $signed({3'b000, sz}) + 7'sd1;
                d2 = X * X + Y * Y;
                HX = X + $signed({4'b0000, sz[3:1]});      // shine up-left of the center
                HY = Y + $signed({4'b0000, sz[3:1]});
                h2 = HX * HX + HY * HY;
                if (sz >= 4'd9 && h2 <= 14'd4) begin
                    on_c  = 1'b1;
                    rgb_c = SHINE;
                end else if (d2 <= sz * sz && d2 > (sz - 3) * (sz - 3)) begin
                    on_c  = 1'b1;
                    rgb_c = RIM;
                end
            end
        end
    end

    always @(posedge clk) begin
        pixel_on <= on_c;
        rgb      <= rgb_c;
    end
endmodule
