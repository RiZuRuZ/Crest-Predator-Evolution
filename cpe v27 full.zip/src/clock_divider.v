// clock_divider
// 100 MHz -> pix_ce (25 MHz clock enable) and tick_60hz (1-cycle pulse every 1/60 s)
// Uses clock enables instead of generating new clocks, so the whole design stays in one clock domain
module clock_divider #(
    parameter PIX_DIV  = 4,        // 100 MHz / 4 = 25 MHz
    parameter TICK_DIV = 1666667   // 100 MHz / 60 Hz
)(
    input  wire clk,
    input  wire rst,
    output reg  pix_ce,
    output reg  tick_60hz
);
    reg [7:0]  pix_cnt;
    reg [20:0] tick_cnt;

    always @(posedge clk) begin
        if (rst) begin
            pix_cnt   <= 8'd0;
            pix_ce    <= 1'b0;
            tick_cnt  <= 21'd0;
            tick_60hz <= 1'b0;
        end else begin
            if (pix_cnt == PIX_DIV - 1) begin
                pix_cnt <= 8'd0;
                pix_ce  <= 1'b1;
            end else begin
                pix_cnt <= pix_cnt + 8'd1;
                pix_ce  <= 1'b0;
            end

            if (tick_cnt == TICK_DIV - 1) begin
                tick_cnt  <= 21'd0;
                tick_60hz <= 1'b1;
            end else begin
                tick_cnt  <= tick_cnt + 21'd1;
                tick_60hz <= 1'b0;
            end
        end
    end
endmodule
