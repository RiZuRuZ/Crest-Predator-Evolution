// bubble_ctrl: air bubbles that rise from the sea floor; touching one refills oxygen
// World coordinates (camera update): x 11 bits, wraps at WORLD_W.
// - every SPAWN_TICKS ticks a bubble appears on the sea floor (y = WORLD_H - SIZE)
//   at a random x inside the current camera view, if a slot is free
// - it rises SPEED px per tick and disappears at the top of the world
// - it is also removed when it is far outside the camera view (frees the slot)
// - touching it gives a 1-cycle eat pulse (one per clock, lowest slot first) and removes it
// Per-slot outputs: slot i is at active_vec[i], x_vec[11i +: 11], y_vec[10i +: 10]
// All numbers are placeholders until the team decides the real values.
module bubble_ctrl #(
    parameter N           = 3,
    parameter SPAWN_TICKS = 150,     // 2.5 s
    parameter SIZE        = 16,
    parameter SPEED       = 1,
    parameter WORLD_W     = 1920,
    parameter WORLD_H     = 640,
    parameter VIEW_W      = 640,
    parameter MARGIN      = 64
)(
    input  wire            clk,
    input  wire            rst,
    input  wire            tick_60hz,
    input  wire [15:0]     rand,
    input  wire [10:0]     cam_x,
    input  wire [10:0]     player_x,
    input  wire [9:0]      player_y,
    input  wire [7:0]      player_w,       // player hitbox (head + body)
    input  wire [7:0]      player_h,
    output wire            eat,
    output wire [N-1:0]    active_vec,
    output wire [11*N-1:0] x_vec,
    output wire [10*N-1:0] y_vec
);
    // ---- spawn timer and random x inside the view -----------------------------
    reg  [15:0] t;
    wire        any_free  = ~(&active_vec);
    wire        spawn_now = tick_60hz && (t == SPAWN_TICKS - 1) && any_free;

    always @(posedge clk) begin
        if (rst)            t <= 16'd0;
        else if (tick_60hz) t <= (t == SPAWN_TICKS - 1) ? 16'd0 : t + 16'd1;
    end

    wire [10:0] rx_raw  = {2'b00, rand[8:0]} + {4'd0, rand[15:9]};   // 0 .. 638
    wire [10:0] x_max   = VIEW_W - SIZE;
    wire [10:0] rx_view = (rx_raw > x_max) ? (rx_raw - x_max) : rx_raw;
    wire [11:0] sx_w    = {1'b0, cam_x} + rx_view;
    wire [10:0] spawn_x = (sx_w >= WORLD_W) ? sx_w - WORLD_W : sx_w[10:0];

    // ---- slots ----------------------------------------------------------------
    wire [7:0]   sz   = SIZE;
    wire [N-1:0] free = ~active_vec;
    wire [N-1:0] eat_req;
    wire [N-1:0] eat_v;

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : g_bub
            wire [N-1:0] low_mask = (1 << i) - 1;
            wire         grant    = free[i] & ~(|(free & low_mask));
            wire         allow    = ~(|(eat_req & low_mask));

            reg        act;
            reg [10:0] bx;
            reg [9:0]  by;
            reg        hit_r;
            wire       hit_c;

            aabb_collision #(.SCREEN_W(WORLD_W), .CW(11)) u_hit (
                .ax(bx), .ay({1'b0, by}), .aw(sz), .ah(sz),
                .bx(player_x), .by({1'b0, player_y}), .bw(player_w), .bh(player_h),
                .hit(hit_c)
            );

            // position relative to the camera, to remove bubbles that are far away
            wire [11:0] rel_raw = {1'b0, bx} + WORLD_W - cam_x;
            wire [11:0] rel     = (rel_raw >= WORLD_W) ? rel_raw - WORLD_W : rel_raw;
            wire        far     = (rel >= VIEW_W + MARGIN) && (rel < WORLD_W - MARGIN - SIZE);

            assign eat_req[i] = act & hit_r;
            assign eat_v[i]   = eat_req[i] & allow;

            always @(posedge clk) begin
                if (rst) begin
                    act <= 1'b0; bx <= 11'd0; by <= 10'd0; hit_r <= 1'b0;
                end else begin
                    hit_r <= hit_c & act;              // gate: no stale hit after a reload
                    if (spawn_now && grant) begin
                        act <= 1'b1;
                        bx  <= spawn_x;
                        by  <= WORLD_H - SIZE;
                    end else if (eat_v[i]) begin
                        act <= 1'b0;
                    end else if (act && tick_60hz) begin
                        if (by <= SPEED || far) act <= 1'b0;   // reached the top / out of view
                        else                    by  <= by - SPEED;
                    end
                end
            end

            assign active_vec[i]     = act;
            assign x_vec[11*i +: 11] = bx;
            assign y_vec[10*i +: 10] = by;
        end
    endgenerate

    assign eat = |eat_v;
endmodule
