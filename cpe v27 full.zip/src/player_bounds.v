// player_bounds: x wraps around the world, y is clamped to the world top and bottom
// x,y is the top-left corner of the player in world coordinates
// y is clamped to 0 .. WORLD_H - size_h; x wraps around 0 .. WORLD_W-1
// (the camera keeps the player in the middle, so the map scrolls instead)
module player_bounds #(
    parameter WORLD_W = 1920,
    parameter WORLD_H = 640
)(
    input  wire [10:0]       x,
    input  wire [9:0]        y,
    input  wire signed [6:0] dx,
    input  wire signed [6:0] dy,
    input  wire [7:0]        size_h,     // sprite height (up to 255)
    output reg  [10:0]       next_x,
    output reg  [9:0]        next_y
);
    reg  signed [12:0] sx, sy;
    wire signed [12:0] max_y = WORLD_H - $signed({5'b00000, size_h});

    always @* begin
        sx = $signed({2'b00, x}) + dx;
        if (sx < 0)             sx = sx + WORLD_W;
        else if (sx >= WORLD_W) sx = sx - WORLD_W;
        next_x = sx[10:0];

        sy = $signed({3'b000, y}) + dy;
        if (sy < 0)          sy = 13'sd0;
        else if (sy > max_y) sy = max_y;
        next_y = sy[9:0];
    end
endmodule
