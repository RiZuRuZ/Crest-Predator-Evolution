// red_shark: one red shark that roams the whole map from form 2 on
//
// It appears once the player reaches form 2, on the far side of the world, and then
// stays in the map (the giant shark does not sweep it). Size 139 x 78 (the large-fish
// sprite drawn 1.5x by fish_renderer), hitbox = the large-fish hitbox x 1.5.
// States:
//   OFF    not there yet (form 1)
//   ROAM   swims in a random direction, a new direction every 2..4 s; stays away from
//          the world top / bottom; x wraps around the world
//   CHASE  forms 2, 3: when the player comes within SEE_X / SEE_Y it swims after him,
//          a little slower than the player (CHASE_Q quarter px per tick); it gives up
//          when he is LOSE_X away or after CHASE_MAX ticks, and does not look for him
//          again for COOL_TICKS
//   FLEE   form 4: when the player is close it swims away from him (FLEE_Q)
//   GONE   eaten (form 4) - it never comes back
// Touching it in forms 2, 3 costs a heart (`hurt`, once per contact, centre in hit_cx /
// hit_cy for the knockback). In form 4 touching it eats it (`eaten` -> +100 points).
// Tidal Roar (roar pulse within 240 px) stops it for STUN_TICKS: it cannot bite then
// (form 4 can still eat it, v21).
// `near`: form 4 and the player is within NEAR px (the dragon opens its mouth).
// Positions: x / y = sprite top-left (world). dir = 1: swims left (drawn mirrored).
// PLACEHOLDERS: every speed, distance and time below.
module red_shark #(
    parameter WORLD_W    = 1920,
    parameter WORLD_H    = 640,
    parameter SEE_X      = 230,     // v14: 180 -> 230
    parameter SEE_Y      = 160,     // v14: 130 -> 160
    parameter LOSE_X     = 330,     // v14: 280 -> 330
    parameter CHASE_MAX  = 330,     // 5.5 s
    parameter COOL_TICKS = 180,     // 3 s
    parameter ROAM_Q     = 7,       // quarter px per tick: 1.75 px (v14: was 6)
    parameter CHASE_Q    = 11,      // 2.75 px (v14: was 10; form 2 player 3.5, form 3 player 2.75)
    parameter FLEE_Q     = 8,       // 2.0 px (form 4 player 2.25)
    parameter STUN_TICKS = 180,
    parameter NEAR       = 24
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        tick_60hz,
    input  wire [15:0] rand,
    input  wire [2:0]  form,
    input  wire [1:0]  diff,           // v18: chase 2.25 / 2.75 / 3.0 px, hard sees +40 / +30
    input  wire [10:0] player_cx,      // player centre
    input  wire [9:0]  player_cy,
    input  wire [10:0] player_x,       // player hitbox
    input  wire [9:0]  player_y,
    input  wire [7:0]  player_w,
    input  wire [7:0]  player_h,
    input  wire        roar,
    output wire        active,
    output reg  [10:0] x,
    output reg  [9:0]  y,
    output reg         dir,
    output wire [1:0]  frame,
    output reg         hurt,           // 1-clk pulse
    output reg         eaten,          // 1-clk pulse
    output wire [10:0] hit_cx,
    output wire [9:0]  hit_cy,
    output wire        near
);
    localparam W = 139, H = 78;
    localparam HX = 28, HY = 10, HW = 108, HH = 58;        // large fish 19,7,72,39 x 1.5
    localparam S_OFF = 3'd0, S_ROAM = 3'd1, S_CHASE = 3'd2, S_FLEE = 3'd3, S_GONE = 3'd4;

    reg [2:0]  st;
    reg [8:0]  turn_t, chase_t;
    reg [7:0]  cool_t, stun_t;
    reg signed [1:0] mx, my;           // direction -1 / 0 / +1
    reg [1:0]  ax, ay;                 // quarter-pixel remainders
    reg [3:0]  anim;
    assign active = (st == S_ROAM) || (st == S_CHASE) || (st == S_FLEE);
    assign frame  = anim[3:2];
    wire stunned  = (stun_t != 8'd0);

    // centre and the signed shortest distance to the player (x wraps)
    wire [11:0] cx_r = {1'b0, x} + W / 2;
    wire [10:0] cx   = (cx_r >= WORLD_W) ? cx_r - WORLD_W : cx_r[10:0];
    wire [9:0]  cy   = y + H / 2;
    assign hit_cx = cx;
    assign hit_cy = cy;
    wire [11:0] dpx  = {1'b0, player_cx} + WORLD_W - cx;
    wire [10:0] dpw  = (dpx >= WORLD_W) ? dpx - WORLD_W : dpx[10:0];       // 0 .. W-1
    wire signed [11:0] ddx = (dpw > WORLD_W / 2) ? $signed({1'b0, dpw}) - WORLD_W : $signed({1'b0, dpw});
    wire signed [11:0] ddy = $signed({2'b00, player_cy}) - $signed({2'b00, cy});
    wire [10:0] adx = ddx[11] ? -ddx : ddx;
    wire [10:0] ady = ddy[11] ? -ddy : ddy;
    wire sees  = (diff == 2'd2) ? ((adx < SEE_X + 40) && (ady < SEE_Y + 30)) : ((adx < SEE_X) && (ady < SEE_Y));
    wire lost  = (adx > LOSE_X) || (ady > 11'd220);

    // hitbox (mirrored when swimming left) and contact
    wire [11:0] hbx_r = {1'b0, x} + (dir ? (W - HX - HW) : HX);
    wire [10:0] hbx   = (hbx_r >= WORLD_W) ? hbx_r - WORLD_W : hbx_r[10:0];
    wire touch_c, near_c;
    aabb_collision #(.SCREEN_W(WORLD_W), .CW(11)) u_hit (
        .ax(hbx), .ay({1'b0, y + 10'd10}), .aw(HW), .ah(HH),
        .bx(player_x), .by({1'b0, player_y}), .bw(player_w), .bh(player_h),
        .hit(touch_c)
    );
    wire [11:0] nx_r = {1'b0, player_x} + WORLD_W - NEAR;
    wire [10:0] nx   = (nx_r >= WORLD_W) ? nx_r - WORLD_W : nx_r[10:0];
    wire [9:0]  ny   = (player_y >= NEAR) ? player_y - NEAR : 10'd0;
    aabb_collision #(.SCREEN_W(WORLD_W), .CW(11)) u_near (
        .ax(hbx), .ay({1'b0, y + 10'd10}), .aw(HW), .ah(HH),
        .bx(nx), .by({1'b0, ny}), .bw(player_w + 2 * NEAR), .bh(player_h + 2 * NEAR),
        .hit(near_c)
    );
    reg touch_r, touch_d, near_r;
    always @(posedge clk) begin
        touch_r <= touch_c & active;
        near_r  <= near_c & active;
    end
    assign near = near_r && (form >= 3'd4);

    // speed of the current state
    wire [3:0] chase_q = (diff == 2'd0) ? 4'd9 : (diff == 2'd2) ? 4'd12 : CHASE_Q;
    wire [3:0] q = (st == S_CHASE) ? chase_q : (st == S_FLEE) ? FLEE_Q : ROAM_Q;
    wire [3:0] sumx = {2'b00, ax} + q;
    wire [3:0] sumy = {2'b00, ay} + q;
    wire [1:0] stepx = (mx == 2'sd0) ? 2'd0 : sumx[3:2];
    wire [1:0] stepy = (my == 2'sd0) ? 2'd0 : sumy[3:2];

    // roam direction from random bits: mostly sideways
    wire signed [1:0] rmx = rand[0] ? 2'sd1 : -2'sd1;
    wire signed [1:0] rmy = (rand[3:2] == 2'd0) ? -2'sd1 : (rand[3:2] == 2'd1) ? 2'sd1 : 2'sd0;
    wire roar_near = (adx < 11'd240) && (ady < 11'd240);      // v19: 160 -> 240

    always @(posedge clk) begin
        hurt  <= 1'b0;
        eaten <= 1'b0;
        if (rst) begin
            st <= S_OFF; x <= 11'd0; y <= 10'd200; dir <= 1'b0; mx <= 2'sd0; my <= 2'sd0;
            ax <= 2'd0; ay <= 2'd0; turn_t <= 9'd0; chase_t <= 9'd0; cool_t <= 8'd0;
            stun_t <= 8'd0; anim <= 4'd0; touch_d <= 1'b0;
        end else begin
            touch_d <= touch_r;
            // contact
            // v21: form 4 eats it on any touch, also while it is stunned by the roar (v20
            // needed a new touch edge and no stun, so a stunned shark could not be eaten)
            if (touch_r && active && form >= 3'd4) begin
                st <= S_GONE; eaten <= 1'b1;
            end else if (touch_r && !touch_d && !stunned && active)
                hurt <= 1'b1;
            if (roar && active && roar_near) stun_t <= STUN_TICKS;

            if (tick_60hz) begin
                anim <= anim + 4'd1;
                if (stun_t != 8'd0) stun_t <= stun_t - 8'd1;
                if (cool_t != 8'd0) cool_t <= cool_t - 8'd1;
                case (st)
                    S_OFF: if (form >= 3'd2) begin
                        // far side of the world from the player
                        x   <= (player_cx >= WORLD_W / 2) ? player_cx - WORLD_W / 2 : player_cx + WORLD_W / 2;
                        y   <= 10'd150 + {2'b00, rand[7:0]};
                        st  <= S_ROAM; mx <= rmx; my <= 2'sd0; turn_t <= 9'd180;
                    end
                    S_ROAM, S_CHASE, S_FLEE: begin
                        // --- choose the state and direction ---
                        if (form >= 3'd4) begin
                            if (sees) begin
                                st <= S_FLEE;
                                mx <= ddx[11] ? 2'sd1 : -2'sd1;
                                my <= (ady < 11'd8) ? 2'sd0 : (ddy[11] ? 2'sd1 : -2'sd1);
                            end else if (st != S_ROAM) begin st <= S_ROAM; turn_t <= 9'd0; end
                        end else if (st == S_CHASE) begin
                            chase_t <= chase_t + 9'd1;
                            if (lost || chase_t >= CHASE_MAX) begin
                                st <= S_ROAM; cool_t <= COOL_TICKS; turn_t <= 9'd0;
                            end else begin
                                mx <= ddx[11] ? -2'sd1 : 2'sd1;
                                my <= (ady < 11'd8) ? 2'sd0 : (ddy[11] ? -2'sd1 : 2'sd1);
                            end
                        end else if (sees && cool_t == 8'd0) begin
                            st <= S_CHASE; chase_t <= 9'd0;
                        end
                        if (st == S_ROAM) begin
                            if (turn_t == 9'd0) begin
                                mx <= rmx; my <= rmy;
                                turn_t <= 9'd120 + {1'b0, rand[11:4] % 8'd120};
                            end else turn_t <= turn_t - 9'd1;
                        end
                        // keep away from the world top and bottom
                        if (y < 10'd30 && my == -2'sd1)                 my <= 2'sd1;
                        if (y > WORLD_H - H - 30 && my == 2'sd1)        my <= -2'sd1;

                        // --- move (not while stunned) ---
                        if (!stunned) begin
                            ax <= (mx == 2'sd0) ? ax : sumx[1:0];
                            ay <= (my == 2'sd0) ? ay : sumy[1:0];
                            if (mx == 2'sd1)
                                x <= (x + stepx >= WORLD_W) ? x + stepx - WORLD_W : x + stepx;
                            else if (mx == -2'sd1)
                                x <= (x >= stepx) ? x - stepx : x + WORLD_W - stepx;
                            if (my == 2'sd1 && y < WORLD_H - H - 4)    y <= y + stepy;
                            else if (my == -2'sd1 && y > 10'd4)        y <= y - stepy;
                            if (mx != 2'sd0) dir <= (mx == -2'sd1);
                        end
                    end
                    default: ;
                endcase
            end
        end
    end
endmodule
