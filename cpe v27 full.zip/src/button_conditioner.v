// button_conditioner: 2-stage synchronizer + debounce
// btn_sync  = debounced (stable) button level
// btn_pulse = 1-cycle pulse when a press becomes stable (rising edge)
module button_conditioner #(
    parameter DEBOUNCE_CYCLES = 1000000   // ~10 ms at 100 MHz
)(
    input  wire clk,
    input  wire rst,
    input  wire raw_btn,
    output reg  btn_sync,
    output reg  btn_pulse
);
    reg        s0, s1;
    reg [24:0] cnt;

    always @(posedge clk) begin
        if (rst) begin
            s0        <= 1'b0;
            s1        <= 1'b0;
            cnt       <= 25'd0;
            btn_sync  <= 1'b0;
            btn_pulse <= 1'b0;
        end else begin
            s0 <= raw_btn;
            s1 <= s0;
            btn_pulse <= 1'b0;

            if (s1 != btn_sync) begin
                if (cnt == DEBOUNCE_CYCLES - 1) begin
                    cnt       <= 25'd0;
                    btn_sync  <= s1;
                    btn_pulse <= s1;
                end else begin
                    cnt <= cnt + 25'd1;
                end
            end else begin
                cnt <= 25'd0;
            end
        end
    end
endmodule
