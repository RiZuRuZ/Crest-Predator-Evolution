// player_health: 3 hearts, shield, death
// hurt      : 1-cycle pulse from a damaging collision (fish_pool.hurt, later harpoon/mine)
// invuln    : from hit_recovery; hits are ignored while it is high
// heart_up  : 1-cycle pulse from the heart power-up (+1, max MAX_HEARTS)
// shield    : level, a shield is available (power-up / Tough Scales); tied to 0 for now
// hit_taken : 1-cycle pulse for every accepted hit (heart lost OR shield used),
//             starts hit_recovery
// shield_used : 1-cycle pulse when the shield absorbed the hit (the shield owner clears it)
// dead      : goes high when the last heart is lost and stays high until rst
// If hurt and heart_up arrive in the same clock, the hit wins and the heart is not added.
// v15 boss fight: refill (1-cycle pulse) sets BOSS_HEARTS hearts; while big = 1 the
// maximum is BOSS_HEARTS. hearts is 3 bits wide (0..7).
module player_health #(
    parameter MAX_HEARTS  = 3,
    parameter BOSS_HEARTS = 5
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       hurt,
    input  wire       invuln,
    input  wire       heart_up,
    input  wire       shield,
    input  wire [1:0] diff,       // v18: start 4 / 3 / 2 hearts, max 4 / 3 / 3, boss 6 / 5 / 4
    input  wire       refill,
    input  wire       big,
    output reg  [2:0] hearts,
    output reg        dead,
    output reg        hit_taken,
    output reg        shield_used
);
    wire [2:0] start_h = (diff == 2'd0) ? 3'd4 : (diff == 2'd2) ? 3'd2 : MAX_HEARTS;
    wire [2:0] max_h   = (diff == 2'd0) ? 3'd4 : MAX_HEARTS;
    wire [2:0] boss_h  = (diff == 2'd0) ? 3'd6 : (diff == 2'd2) ? 3'd4 : BOSS_HEARTS;

    always @(posedge clk) begin
        if (rst) begin
            hearts      <= start_h;
            dead        <= 1'b0;
            hit_taken   <= 1'b0;
            shield_used <= 1'b0;
        end else begin
            hit_taken   <= 1'b0;
            shield_used <= 1'b0;
            if (refill && !dead) begin
                hearts <= boss_h;
            end else if (!dead) begin
                if (hurt && !invuln) begin
                    hit_taken <= 1'b1;
                    if (shield) begin
                        shield_used <= 1'b1;
                    end else if (hearts <= 3'd1) begin
                        hearts <= 3'd0;
                        dead   <= 1'b1;
                    end else begin
                        hearts <= hearts - 3'd1;
                    end
                end else if (heart_up && hearts < (big ? boss_h : max_h)) begin
                    hearts <= hearts + 3'd1;
                end
            end
        end
    end
endmodule
