"""Remove the bubbles painted in the map picture (the game draws moving ones instead)

usage: python tools/clean_bubbles.py <map.png> <map_clean.png>

Only the vertical bubble streams listed in STREAMS are touched, so rock edges and
coral highlights stay intact. Inside each stream band, small bright low-saturation
blobs (the bubble rings) are found with a top-hat filter and filled in from the
surrounding water with OpenCV inpainting.

STREAMS is in pixels of the ORIGINAL picture (2172 x 724). deco_bubbles.v uses the
same streams converted to world coordinates (world = original * 2040 / 2172).
Needs: numpy, opencv-python.
"""
import sys
import numpy as np
import cv2

# (x center, y top, y bottom) of each painted bubble stream
STREAMS = [(160, 110, 205), (479, 105, 440), (1059, 105, 450), (1385, 105, 205), (1544, 105, 465)]
HALF_W = 38

def main(src, dst):
    im = cv2.imread(src)
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)
    lum = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    tophat = cv2.morphologyEx(lum, cv2.MORPH_TOPHAT,
                              cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25)))
    bright = ((tophat > 10) & (hsv[:, :, 1] < 175) & (hsv[:, :, 2] > 135)).astype(np.uint8)

    band = np.zeros_like(bright)
    for x, y0, y1 in STREAMS:
        band[y0:y1, x - HALF_W:x + HALF_W] = 1
    cand = bright & band

    n, lab, st, _ = cv2.connectedComponentsWithStats(cand, 8)
    keep = np.zeros_like(cand)
    for i in range(1, n):
        _, _, w, h, area = st[i]
        if area <= 500 and w <= 44 and h <= 44:
            keep[lab == i] = 1
    keep = cv2.dilate(keep, np.ones((5, 5), np.uint8))
    out = cv2.inpaint(im, keep * 255, 5, cv2.INPAINT_TELEA)
    cv2.imwrite(dst, out)
    print(f"removed {int(keep.sum())} pixels in {len(STREAMS)} streams")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
