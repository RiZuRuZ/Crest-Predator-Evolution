"""Add a thin dark outline to the prop sprites (jellyfish, sea mine, seaweed).

The props were keyed out from their original background, so their soft edge pixels are
gone and the edges look see-through over the map. This adds a 1 px outline in the
sprite's own darkest palette color (index 1) around every frame. It uses the 4
neighbours only (no corners) so the outline stays thin.

The script always reads the untouched sprites from tools/props_orig/ (copied there the
first time it runs), so running it again gives the same result.

Usage:  python3 tools/outline_props.py            (from the project folder)
        python3 tools/outline_props.py --preview  (also writes PNG previews to tools/preview/)
"""
import os
import shutil
import sys

import numpy as np
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "src")
ORIG = os.path.join(HERE, "props_orig")
DARK = 1
CROSS = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)

# file, palette, width, height, frames in this file
PROPS = [
    ("jellyfish.mem", "jellyfish_pal.mem", 37, 52, 4),
    ("seamine.mem",   "seamine_pal.mem",   43, 44, 4),
    ("seaweed_0.mem", "seaweed_pal.mem",   61, 93, 4),
    ("seaweed_1.mem", "seaweed_pal.mem",   61, 93, 4),
]


def read(path):
    with open(path) as f:
        return [int(l, 16) for l in f if l.strip()]


def write(path, vals):
    with open(path, "w") as f:
        f.write("\n".join(f"{v:X}" for v in vals) + "\n")


def outline(frame, w, h):
    a = np.array(frame, dtype=np.int32).reshape(h, w)
    op = a != 0
    a[ndimage.binary_dilation(op, structure=CROSS) & ~op] = DARK
    return a.reshape(-1).tolist()


def preview(name, vals, pal, w, h, n):
    from PIL import Image
    cols = [tuple(int(c, 16) * 17 for c in p) for p in pal]
    img = Image.new("RGB", (w * n + 4 * (n - 1), h), (40, 90, 140))   # map-like blue
    for f in range(n):
        for y in range(h):
            for x in range(w):
                v = vals[f * w * h + y * w + x]
                if v:
                    img.putpixel((f * (w + 4) + x, y), cols[v])
    os.makedirs(os.path.join(HERE, "preview"), exist_ok=True)
    img.resize((img.width * 4, img.height * 4), Image.NEAREST).save(
        os.path.join(HERE, "preview", name.replace(".mem", ".png")))


def main():
    os.makedirs(ORIG, exist_ok=True)
    for name, palname, w, h, n in PROPS:
        orig = os.path.join(ORIG, name)
        if not os.path.exists(orig):
            shutil.copy(os.path.join(SRC, name), orig)
        vals = read(orig)
        assert len(vals) == w * h * n, name
        out = []
        for f in range(n):
            out += outline(vals[f * w * h:(f + 1) * w * h], w, h)
        write(os.path.join(SRC, name), out)
        if "--preview" in sys.argv:
            with open(os.path.join(SRC, palname)) as fp:
                pal = [l.strip() for l in fp if l.strip()]
            preview("before_" + name, vals, pal, w, h, n)
            preview("after_" + name, out, pal, w, h, n)
        print(f"{name}: {n} frames {w}x{h} outlined")


if __name__ == "__main__":
    main()
