"""Turn the sprite pack ROMs into the ROM files used by player_renderer and fish_renderer.

usage: python tools/split_sprite_roms.py <pack_mem_dir> <out_dir>
       pack_mem_dir = the mem/ folder made by build_sprites.py / build_fish.py
                      (evo1..4.mem, evo1..4_pal.mem, fish.mem, fish_pal.mem)
       out_dir      = src/

Clean-up applied to every frame (dragon and fish) before packing:
  - small transparent holes inside the sprite (at most MAX_HOLE pixels, not connected
    to the frame edge: eyes, gaps between scales) are filled with palette index 1, the
    darkest color. They were dark pixels that the conversion keyed out with the
    background, so the map showed through the eyes.
  - a 1-pixel outline of index 1 is added around the sprite (8 neighbours), like the
    art on its original dark navy background.

Every ROM has at most 32K entries: a deeper ROM makes Vivado cascade RAMB36 blocks,
which failed DRC REQP-1962 on this board (conventions.md).

Dragon (player_renderer.v) - row spans, all four forms in one address space
  About 65 % of the dragon pixels are transparent, so each sprite row stores only the
  span from its first to its last visible pixel. All forms and frames are packed one
  after another into banks of 32768 entries (4-bit palette indexes); a span never
  crosses a bank boundary.
    dragon_b0..bN.mem   packed spans
    dragon_rows.mem     one 34-bit entry per sprite row, {offset[17:0], x0[7:0], len[7:0]}
                        offset = address of the span's first pixel (bank = offset[17:15])
                        x0     = column of the first stored pixel, len = span length
                        (len 0 = empty row)
  Row index = ROW_BASE[form] + frame * H + y,  frame 0..9:
    0,1 idle | 2..5 swim | 6..9 bite = swim frames 2..5 with the mouth open
  The pack's hurt / eat poses (pack frames 6, 7) are not stored: they are a different
  pose (and smaller for form 4), so switching to them looked jarring. The bite frames
  are made here from the swim frames: the lower jaw (JAW table, found by hand on swim
  frame 2) is turned down around its hinge, up to `open` px at the snout tip, and the
  gap is filled with the dark color. For swim frames 3..5 the head position is found by
  matching the head area against frame 2 (the head bobs up to 6 px). Pixel (x, y) is visible only if x0 <= x < x0 + len, and its index is
  at offset + (x - x0).

Fish (fish_renderer.v): fish0..fish3.mem, one file per type,
  address = frame*W*H + y*W + x, 4 swim frames.

Palettes are copied unchanged (evoN_pal.mem 16 colors, fish_pal.mem 4 x 16).
The script prints the bank sizes and row bases; they must match player_renderer.v.
"""
import os
import shutil
import sys

FORMS = {1: (73, 41), 2: (96, 58), 3: (126, 74), 4: (171, 106)}
PACK_FRAMES = 8             # frames per form in the sprite pack
FRAMES = 10                 # frames stored: idle 0,1 + swim 2..5 + bite 6..9
MAX_HOLE = 12
DARK = 1                    # palette index used for holes and the outline
FISH = [(31, 27, 0), (52, 42, 3348), (93, 52, 12084), (44, 35, 31428)]  # w, h, base
FISH_FRAMES = 4
BANK = 32768

def read(path):
    with open(path) as f:
        return [int(l, 16) for l in f if l.strip()]

def write(path, vals, digits=1):
    with open(path, "w") as f:
        f.write("\n".join(f"{v:0{digits}X}" for v in vals) + "\n")

def clean(frame, w, h):
    """Fill small enclosed transparent holes and add a 1 px dark outline."""
    import numpy as np
    from scipy import ndimage
    a = np.array(frame, dtype=np.int32).reshape(h, w)
    t = a == 0
    lab, n = ndimage.label(t)
    edge = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]])))
    sizes = ndimage.sum(t, lab, range(n + 1))
    for k in range(1, n + 1):
        if k not in edge and sizes[k] <= MAX_HOLE:
            a[lab == k] = DARK
    op = a != 0
    a[ndimage.binary_dilation(op, structure=np.ones((3, 3))) & ~op] = DARK
    return a.reshape(-1).tolist()

# lower jaw on swim frame 2: mouth seam row, hinge x, snout tip x, jaw bottom row, open px
JAW = {1: (21, 57, 68, 26, 3), 2: (30, 76, 90, 35, 4), 3: (30, 100, 124, 34, 5),
       4: (48, 142, 167, 58, 6)}
HEAD = {1: (50, 5, 73, 30), 2: (65, 15, 96, 40), 3: (90, 10, 126, 40), 4: (125, 25, 171, 60)}

def head_shift(ref, a, box):
    """(dx, dy) that moves the head of frame a onto the head of the reference frame."""
    import numpy as np
    x0, y0, x1, y1 = box
    best = None
    for dy in range(-6, 7):
        for dx in range(-6, 7):
            b = np.roll(np.roll(a, -dy, 0), -dx, 1)[y0:y1, x0:x1]
            e = ((ref[y0:y1, x0:x1] != 0) != (b != 0)).sum()
            if best is None or e < best[0]:
                best = (e, dx, dy)
    return best[1], best[2]

# form 3 has almost no lower jaw in the pack, so shifting it leaves a flat dark slab.
# Instead draw a new lower jaw: seam row, hinge x, jaw tip x, open px at the tip
JAW3 = (30, 107, 121, 6)
MOUTH = 0xF                 # red mouth interior (evo3_pal index F = E34)
TOOTH = 7                   # light teeth along the upper jaw

def bite3(a, dx, dy):
    ym, xc, xt, op = JAW3
    ym += dy; xc += dx; xt += dx
    h, w = a.shape
    out = a.copy()
    for x in range(xc, min(xt + 1, w)):
        d = int(round(op * (x - xc) / (xt - xc)))
        for y in range(ym + 1, min(ym + 2 + op + 2, h)):
            out[y, x] = 0                      # clear the old one-row jaw
        if d == 0:
            continue
        for y in range(ym + 1, min(ym + 1 + d, h)):
            out[y, x] = MOUTH
        if (x - xc) % 3 == 1 and x > xc + 2:
            out[ym + 1, x] = TOOTH             # upper teeth
        yj = ym + 1 + d
        thick = 2 if x < xt - 1 else 1         # jaw tapers at the tip
        for i in range(thick):
            if yj + i < h:
                out[yj + i, x] = 7 if i == 0 else 5
        if x > xc + 3 and (x - xc) % 4 == 0 and yj - 1 > ym + 1:
            out[yj - 1, x] = TOOTH             # lower teeth
    return out

def bite(a, form, dx, dy):
    """Open the mouth: shift the lower jaw down, more towards the snout tip."""
    if form == 3:
        return bite3(a, dx, dy)
    ym, xc, xt, yb, op = JAW[form]
    ym += dy; xc += dx; xt += dx; yb += dy
    h, w = a.shape
    out = a.copy()
    for x in range(xc, min(xt + 1, w)):
        d = int(round(op * (x - xc) / (xt - xc)))
        if d == 0 or (a[ym, x] == 0 and a[ym - 1, x] == 0):
            continue
        jaw = a[ym:yb, x].copy()
        for y in range(ym, yb):
            if a[y, x] != 0:
                out[y, x] = 0
        for i, y in enumerate(range(ym, yb)):
            if jaw[i] and y + d < h:
                out[y + d, x] = jaw[i]
        for y in range(ym, min(ym + d, h)):
            out[y, x] = DARK
    return out

def load_dragon(src, form):
    import numpy as np
    w, h = FORMS[form]
    sheet = read(os.path.join(src, f"evo{form}.mem"))
    assert len(sheet) == w * h * PACK_FRAMES, (form, len(sheet))
    raw = np.array(sheet, dtype=np.int32).reshape(PACK_FRAMES, h, w)
    frames = [raw[i] for i in range(6)]
    for k in range(2, 6):
        dx, dy = head_shift(raw[2], raw[k], HEAD[form])
        frames.append(bite(raw[k], form, dx, dy))
    out = []
    for a in frames:
        out += clean(a.reshape(-1).tolist(), w, h)
    return out

def pack_dragon(src, out):
    pix = []          # packed spans, all banks back to back
    rows = []
    row_base = {}
    for form, (w, h) in FORMS.items():
        sheet = load_dragon(src, form)
        row_base[form] = len(rows)
        for fr in range(FRAMES):
            for y in range(h):
                row = sheet[fr * w * h + y * w:fr * w * h + (y + 1) * w]
                vis = [x for x, v in enumerate(row) if v]
                if not vis:
                    rows.append((0, 0, 0))
                    continue
                x0, x1 = vis[0], vis[-1]
                n = x1 - x0 + 1
                room = BANK - (len(pix) % BANK)
                if n > room:                       # do not cross a bank boundary
                    pix += [0] * room
                rows.append((len(pix), x0, n))
                pix += row[x0:x1 + 1]
        shutil.copy(os.path.join(src, f"evo{form}_pal.mem"), out)

    nb = (len(pix) + BANK - 1) // BANK
    sizes = []
    for b in range(nb):
        chunk = pix[b * BANK:(b + 1) * BANK]
        sizes.append(len(chunk))
        write(os.path.join(out, f"dragon_b{b}.mem"), chunk)
    with open(os.path.join(out, "dragon_rows.mem"), "w") as f:
        for off, x0, n in rows:
            f.write(f"{(off << 16) | (x0 << 8) | n:09X}\n")
    print("dragon banks:", sizes)
    print("row base per form:", row_base, "rows:", len(rows))
    return pix, rows, row_base

def check_dragon(src, pix, rows, row_base):
    """Rebuild every frame from the packed data the way player_renderer does."""
    for form, (w, h) in FORMS.items():
        sheet = load_dragon(src, form)
        for fr in range(FRAMES):
            for y in range(h):
                off, x0, n = rows[row_base[form] + fr * h + y]
                for x in range(w):
                    v = pix[off + x - x0] if x0 <= x < x0 + n else 0
                    assert v == sheet[fr * w * h + y * w + x], (form, fr, x, y)
    print("dragon check OK")

def split_fish(src, out):
    fish = read(os.path.join(src, "fish.mem"))
    for t, (w, h, base) in enumerate(FISH):
        n = w * h * FISH_FRAMES
        assert n <= BANK
        data = []
        for fr in range(FISH_FRAMES):
            data += clean(fish[base + fr * w * h:base + (fr + 1) * w * h], w, h)
        write(os.path.join(out, f"fish{t}.mem"), data)
    shutil.copy(os.path.join(src, "fish_pal.mem"), out)

def main(src, out):
    pix, rows, row_base = pack_dragon(src, out)
    check_dragon(src, pix, rows, row_base)
    split_fish(src, out)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
