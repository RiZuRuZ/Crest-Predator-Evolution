"""Boss (giant shark) sprite frames from the user's reference image.

Stored at HALF resolution and drawn as 2x2 blocks on screen (same trick as the map), because
BRAM is nearly full (130/135 at v13). On screen the boss is about 2*W x 2*H px.

Frames (art faces right):
  0..3  swim loop   - tail sweeps, body wave, lower jaw opens/closes a little, flame bits bob
  4     CHARGE      - wind-up: body pulled back and compressed, jaw nearly shut, tail cocked
  5     LUNGE       - stretched forward, jaw wide open, tail straight
Hit / stun flashes are meant to be done by palette swap in logic (no extra frames).

Output: mem/boss_0.mem (frames 0..FPB-1), mem/boss_1.mem (the rest) - each <= 32K entries
        mem/boss_spr_pal.mem (16 x 12-bit, entry 0 transparent)
        rtl/boss_params.vh, mem/boss_sheet.png, mem/boss_swim.gif, frames/boss/*.png
"""
import math, os
import numpy as np
import cv2
from PIL import Image
from scipy import ndimage as ndi

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REF = os.path.join(ROOT, "ref", "boss", "boss.png")
MEM, RTL = os.path.join(ROOT, "mem"), os.path.join(ROOT, "rtl")
BG = np.array([3, 9, 33])
STORE_W = 114             # stored width (screen width = 2 * STORE_W)
BANK = 32768
PAD = 4


EYE_REL = (0.813, 0.500)   # eye centre in the reference body box (measured from the red pixels)
HINGE_REL = (0.76, 0.64)   # mouth corner: the lower jaw rotates about this point


def build_indexed():
    """Crisp conversion: quantize the FULL-resolution art to 15 colours first, then shrink by
    majority vote per block (not by averaging), so purple/magenta/navy do not smear into mud.
    Thin bright details (teeth) and the red eye get extra vote weight so they survive."""
    rgb = np.array(Image.open(REF).convert("RGB")).astype(np.float32)
    m = np.abs(rgb - BG).sum(axis=2) > 20               # keep dark purple mouth/shadows
    lab, n = ndi.label(m)
    sz = ndi.sum(m, lab, range(1, n + 1))
    m = np.isin(lab, 1 + np.where(sz >= 150)[0])
    ys, xs = np.where(m)
    sl = (slice(ys.min(), ys.max() + 1), slice(xs.min(), xs.max() + 1))
    rgb, m = rgb[sl], m[sl]
    # palette from the full-res pixels
    pts = rgb[m]
    rng = np.random.default_rng(1)
    sub = pts[rng.choice(len(pts), min(60000, len(pts)), replace=False)].astype(np.float32)
    cv2.setRNGSeed(3)
    _, _, cen = cv2.kmeans(sub, 14, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 80, 0.2),
                           6, cv2.KMEANS_PP_CENTERS)
    eye_red = np.array([230, 20, 40], np.float32)
    cen = np.vstack([cen, eye_red])                      # 15th colour reserved for the eye
    cen12 = np.clip(np.round(cen / 17.0), 0, 15).astype(int)
    cen12 = np.unique(cen12, axis=0)
    cen12 = cen12[np.argsort(cen12.sum(axis=1))]
    pv = (cen12 * 17).astype(np.float32)
    full = np.zeros(m.shape, np.uint8)
    d = ((rgb[m][:, None, :] - pv[None]) ** 2).sum(axis=2)
    full[m] = d.argmin(axis=1) + 1
    K = len(cen12) + 1
    # vote weights: bright (teeth / highlights) and red count more
    lum = pv.sum(axis=1)
    wgt = np.ones(K, np.float32)
    wgt[1:][lum >= np.percentile(lum, 80)] = 1.5
    reds = (pv[:, 0] > 150) & (pv[:, 1] < 90)
    wgt[1:][reds] = 3.0
    s = STORE_W / m.shape[1]
    tw, th = STORE_W, max(1, round(m.shape[0] * s))
    votes = np.stack([cv2.resize((full == k).astype(np.float32), (tw, th), interpolation=cv2.INTER_AREA) * wgt[k]
                      for k in range(K)])
    opaque = votes[0] / wgt[0] < 0.55
    votes[0] = 0
    idx = votes.argmax(axis=0).astype(np.uint8)
    idx[~opaque] = 0
    # drop specks smaller than 4 px
    lab, n = ndi.label(idx > 0)
    if n > 1:
        sz = ndi.sum(np.ones_like(idx), lab, range(1, n + 1))
        idx[np.isin(lab, 1 + np.where(sz < 4)[0])] = 0
    # clean eye: 2x2 red with a 1-px light highlight
    H, W = idx.shape
    red_i = int(np.argmax(pv[:, 0] - pv[:, 1] - pv[:, 2]) + 1)
    light_i = int(np.argmax(lum) + 1)
    ex, ey = int(round(EYE_REL[0] * (W - 1))), int(round(EYE_REL[1] * (H - 1)))
    idx[(idx == red_i)] = idx[ey, ex - 3] if idx[ey, ex - 3] else 1   # remove smeared red first
    idx[ey - 1:ey + 1, ex - 1:ex + 1] = red_i
    idx[ey - 1, ex - 1] = light_i
    pal = [(0, 0, 0)] + [tuple(int(v) for v in c) for c in cen12]
    while len(pal) < 16: pal.append((0, 0, 0))
    return idx, pal


def pose(idx, pal, tail_deg, wave, jaw_deg, stretch, bob, flame_phase):
    """Backward-mapped pose. Landmarks are fractions of the body box (art faces right):
    tail base at 30% from the left, jaw hinge at 74% x / 50% y."""
    H, W = idx.shape
    ys, xs = np.where(idx > 0)
    xmin, xmax, ymin, ymax = xs.min(), xs.max(), ys.min(), ys.max()
    span, hh = xmax - xmin, ymax - ymin
    yc = ymin + 0.52 * hh
    X, Y = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
    qx, qy = X.copy(), Y - bob
    # stretch / compress the body behind the head only (head pixels stay 1:1)
    xh = xmax - 0.36 * span
    qx = np.where(qx < xh, xh - (xh - qx) / stretch, qx)
    u = np.clip((xmax - qx) / span, 0, 1)                  # 0 snout .. 1 tail end
    # lower jaw: shift it straight down by jaw_deg/3 px (rigid move keeps the teeth intact)
    hx, hy = xmin + HINGE_REL[0] * span, ymin + HINGE_REL[1] * hh
    drop = jaw_deg / 3.0
    t = np.clip((qx - hx) / (0.12 * span), 0, 1)          # ramp in from the hinge so the corner does not tear
    jaw = (qx > hx) & (qy > hy - 0.06 * (qx - hx) + drop * t)
    qy = np.where(jaw, qy - np.rint(drop * t), qy)
    # body wave (grows toward the tail)
    qy = qy - wave * hh * (u ** 2) * 1.0
    # tail: rotate the rear part about the tail base, smooth weight across the joint
    u0 = 0.68
    wgt = np.clip((u - u0) / 0.10, 0, 1)
    ang = math.radians(tail_deg) * wgt
    px_ = xmax - u0 * span
    ddx, ddy = qx - px_, qy - yc
    sx = px_ + ddx * np.cos(ang) - ddy * np.sin(ang)
    sy = yc + ddx * np.sin(ang) + ddy * np.cos(ang)
    sx = np.rint(sx).astype(int); sy = np.rint(sy).astype(int)
    ok = (sx >= 0) & (sx < W) & (sy >= 0) & (sy < H)
    out = np.zeros_like(idx); out[ok] = idx[sy[ok], sx[ok]]
    # mouth gap opened by the jaw: fill with the darkest body colour (mouth inside), not transparent
    P = np.array(pal, int)
    darkest = int(np.argmin(np.where(np.arange(16) == 0, 999, P.sum(1))))
    head = (X > hx) & (Y > hy - 0.15 * hh) & (Y < ymax)
    hull = ndi.binary_fill_holes(ndi.binary_closing(out > 0, iterations=3))
    gap = head & hull & (out == 0)
    out[gap] = darkest
    # flame bits (small loose pieces) bob up/down a pixel, each with its own phase
    lab, n = ndi.label(out > 0)
    if n > 1:
        sz = ndi.sum(np.ones_like(out), lab, range(1, n + 1))
        big = np.argmax(sz) + 1
        moved = out.copy()
        for i in range(1, n + 1):
            if i == big: continue
            sel = lab == i
            dyb = int(round(math.sin(flame_phase + 1.7 * i)))
            if dyb:
                moved[sel] = 0
                yy, xx = np.where(sel)
                yy2 = np.clip(yy - dyb, 0, H - 1)
                moved[yy2, xx] = out[yy, xx]
        out = moved
    return out


def main():
    idx, pal = build_indexed()
    idx = np.pad(idx, PAD)
    frames = []
    for k in range(4):                                     # swim loop
        phi = k * math.pi / 2
        frames.append(pose(idx, pal, tail_deg=9 * math.sin(phi), wave=0.02 * math.sin(phi - 1.2),
                           jaw_deg=3 + 3 * math.sin(phi), stretch=1.0, bob=round(math.sin(phi + 1.0)),
                           flame_phase=phi))
    frames.append(pose(idx, pal, tail_deg=-12, wave=-0.02, jaw_deg=-2, stretch=0.92, bob=0,
                       flame_phase=0.5))                  # CHARGE
    frames.append(pose(idx, pal, tail_deg=4, wave=0.0, jaw_deg=18, stretch=1.08, bob=0,
                       flame_phase=2.0))                  # LUNGE
    u = np.any(np.stack(frames) > 0, axis=0)
    ys, xs = np.where(u)
    frames = [f[ys.min():ys.max() + 1, xs.min():xs.max() + 1] for f in frames]
    H, W = frames[0].shape
    n = len(frames)
    nb = int(math.ceil(n * W * H / BANK)); fpb = int(math.ceil(n / nb))
    for b in range(nb):
        with open(os.path.join(MEM, f"boss_{b}.mem"), "w") as fh:
            fh.write("\n".join(f"{v:x}" for f in frames[b * fpb:(b + 1) * fpb] for v in f.flatten()) + "\n")
    with open(os.path.join(MEM, "boss_spr_pal.mem"), "w") as fh:
        fh.write("\n".join(f"{r:x}{g:x}{b:x}" for r, g, b in pal) + "\n")
    with open(os.path.join(RTL, "boss_params.vh"), "w") as fh:
        fh.write("// Generated by tools/build_boss.py - do not edit by hand\n")
        fh.write("// Stored at half resolution: draw each stored pixel as a 2x2 block (screen = 2*W x 2*H)\n")
        fh.write("// frames: 0..3 swim, 4 CHARGE, 5 LUNGE; addr = (frame % FPB)*(W*H) + y*W + x in boss_{frame/FPB}.mem\n")
        fh.write(f"localparam BOSS_W = {W};\nlocalparam BOSS_H = {H};\nlocalparam BOSS_FRAMES = {n};\n"
                 f"localparam BOSS_FPB = {fpb};\n")
    diffs = [int((frames[i] != frames[(i + 1) % n]).sum()) for i in range(n)]
    print(f"boss stored {W}x{H} (screen {2 * W}x{2 * H}), {n} frames = {n * W * H} entries "
          f"= {n * W * H * 4 / 1000:.0f} Kb, {nb} files x {fpb} frames, diffs {diffs}")
    # previews at screen scale (2x) and 4x for checking; separate frame PNGs
    p8 = np.array([(r * 17, g * 17, b * 17) for r, g, b in pal], np.uint8)
    bgc = (4, 6, 26)
    d = os.path.join(ROOT, "frames", "boss"); os.makedirs(d, exist_ok=True)
    for f in os.listdir(d): os.remove(os.path.join(d, f))
    labels = ["swim0", "swim1", "swim2", "swim3", "charge", "lunge"]
    ims = []
    for k, f in enumerate(frames):
        rgba = np.dstack([p8[f], np.where(f > 0, 255, 0).astype(np.uint8)])
        im = Image.fromarray(rgba, "RGBA")
        im.save(os.path.join(d, f"boss_{k}_{labels[k]}_stored.png"))
        im.resize((W * 2, H * 2), Image.NEAREST).save(os.path.join(d, f"boss_{k}_{labels[k]}_screen.png"))
        rgb = p8[f]; rgb[f == 0] = bgc
        ims.append(Image.fromarray(rgb).resize((W * 4, H * 4), Image.NEAREST))
    gap = 12
    sheet = Image.new("RGB", (ims[0].width * 2 + gap * 3, (ims[0].height + gap) * 3 + gap), bgc)
    for k, im in enumerate(ims):
        sheet.paste(im, (gap + (k % 2) * (im.width + gap), gap + (k // 2) * (im.height + gap)))
    sheet.save(os.path.join(MEM, "boss_sheet.png"))
    ims[0].save(os.path.join(MEM, "boss_swim.gif"), save_all=True, append_images=ims[1:4], duration=140, loop=0)
    seq = ims[:4] + [ims[4]] * 3 + [ims[5]] * 3
    seq[0].save(os.path.join(MEM, "boss_attack.gif"), save_all=True, append_images=seq[1:], duration=140, loop=0)


if __name__ == "__main__":
    main()

# ---------------------------------------------------------------------------------------
# v21 BRAM fix (board): the 6-frame ROM needed 137/135 RAMB36. The board uses 4 frames
# (swim 0, swim 2, CHARGE, LUNGE) cropped to 113 x 54 at stored (5, 1) in ONE file
# boss_0.mem (4 * 6102 = 24408 entries <= 24576 = 3 RAMB36 as 8K x 4). Re-make it with
# crop_board() after main().
def crop_board(src0='mem/boss_0.mem', src1='mem/boss_1.mem', dst='mem/boss_0_board.mem'):
    W, H = 118, 57
    d = [int(l, 16) for l in open(src0).read().split()] + [int(l, 16) for l in open(src1).read().split()]
    fr = [d[i * W * H:(i + 1) * W * H] for i in range(6)]
    X0, Y0, CW, CH = 5, 1, 113, 54
    out = ['%x' % fr[i][y * W + x] for i in (0, 2, 4, 5) for y in range(Y0, Y0 + CH) for x in range(X0, X0 + CW)]
    open(dst, 'w').write('\n'.join(out) + '\n')

# ---------------------------------------------------------------------------------------
# v22 (board): crop_board() above is no longer used. All 6 frames are stored as row spans
# with a dark inner outline (palette index 1 on every opaque pixel that touches a
# transparent pixel or the image edge):
#   boss_0.mem     23761 4-bit pixels (3 RAMB36)
#   boss_rows.mem  342 entries {offset[28:14], x0[13:7], len[6:0]}, row = frame * 57 + y
def rows_board(src0='mem/boss_0.mem', src1='mem/boss_1.mem', dst_pix='mem/boss_0_board.mem',
               dst_rows='mem/boss_rows.mem'):
    W, H = 118, 57
    d = [int(l, 16) for l in open(src0).read().split()] + [int(l, 16) for l in open(src1).read().split()]
    pix, rows = [], []
    for f in range(6):
        fr = d[f * W * H:(f + 1) * W * H]
        op = lambda x, y: 0 <= x < W and 0 <= y < H and fr[y * W + x] != 0
        g = [[fr[y * W + x] for x in range(W)] for y in range(H)]
        for y in range(H):
            for x in range(W):
                if fr[y * W + x] and not (op(x + 1, y) and op(x - 1, y) and op(x, y + 1) and op(x, y - 1)):
                    g[y][x] = 1
        for y in range(H):
            xs = [x for x in range(W) if g[y][x]]
            if xs:
                x0, x1 = xs[0], xs[-1]
                rows.append((len(pix), x0, x1 - x0 + 1)); pix += [g[y][x] for x in range(x0, x1 + 1)]
            else:
                rows.append((len(pix), 0, 0))
    open(dst_pix, 'w').write('\n'.join('%x' % v for v in pix) + '\n')
    open(dst_rows, 'w').write('\n'.join('%08x' % ((o << 14) | (x0 << 7) | n) for o, x0, n in rows) + '\n')
