"""Convert the prop frames from the sprite chat (props_frames.zip) into ROM files.

usage: python tools/build_prop_roms.py <frames_dir> <out_dir>
       frames_dir = the frames/ folder of props_frames.zip
                    (frames/<name>/<name>_<k>.png, RGBA, transparent background)
       out_dir    = src/

For each prop: every frame pixel with alpha >= 128 is kept, all frames of the prop
share one 16-color palette (index 0 = transparent, 15 colors chosen by k-means on
the 12-bit colors), so the colors do not flicker between frames.

ROM layout: address = frame*W*H + y*W + x (row-major), 4-bit index per entry, every
file at most 32768 entries (no BRAM cascade, conventions.md).
  jellyfish.mem      37x52  x 4 frames
  seamine.mem        43x44  x 4 frames
  seamine_boom.mem   64x64  x 6 frames (played once)
  seaweed_0.mem      61x93  frames 0..3
  seaweed_1.mem      61x93  frames 4..7
  harpoon_h.mem      88x23  x 4 frames, points right (pointing left = mirrored x)
  harpoon_v.mem      23x88  x 4 frames, the same art turned to point down
                     (pointing up = mirrored y)
  <name>_pal.mem     16 x 12-bit {R,G,B} (harpoon_h / harpoon_v share harpoon_pal.mem)
"""
import glob
import os
import sys
import numpy as np
from PIL import Image

LIMIT = 32768

def load_frames(d, name):
    fs = sorted(glob.glob(os.path.join(d, name, f"{name}_*.png")))
    fs = [f for f in fs if not f.endswith("_x4.png")]
    fs.sort(key=lambda f: int(os.path.basename(f).split("_")[-1].split(".")[0]))
    return [np.array(Image.open(f).convert("RGBA")) for f in fs]

def palette(frames):
    px = np.concatenate([f[f[..., 3] >= 128][:, :3] for f in frames]).astype(float)
    px = np.round(px / 17.0)
    uniq, cnt = np.unique(px, axis=0, return_counts=True)
    if len(uniq) <= 15:
        return uniq
    from scipy.cluster.vq import kmeans2
    pts = np.repeat(uniq, np.maximum(1, cnt // 4), axis=0)
    c, _ = kmeans2(pts, 15, minit="++", seed=3, iter=40)
    return np.clip(np.round(c), 0, 15)

def index(frames, pal):
    out = []
    for f in frames:
        rgb = np.round(f[..., :3].astype(float) / 17.0)
        d = ((rgb[..., None, :] - pal[None, None]) ** 2).sum(-1)
        idx = d.argmin(-1) + 1
        idx[f[..., 3] < 128] = 0
        out.append(idx)
    return out

def write_mem(path, frames):
    vals = np.concatenate([f.reshape(-1) for f in frames])
    assert len(vals) <= LIMIT, (path, len(vals))
    with open(path, "w") as fh:
        fh.write("\n".join(f"{v:X}" for v in vals) + "\n")

def write_pal(path, pal):
    with open(path, "w") as fh:
        fh.write("000\n")
        for r, g, b in pal.astype(int):
            fh.write(f"{r:X}{g:X}{b:X}\n")
        for _ in range(15 - len(pal)):
            fh.write("000\n")

def main(src, out):
    for name in ["jellyfish", "seamine", "seamine_boom", "seaweed", "harpoon"]:
        fr = load_frames(src, name)
        pal = palette(fr)
        idx = index(fr, pal)
        if name == "seaweed":
            write_mem(os.path.join(out, "seaweed_0.mem"), idx[:4])
            write_mem(os.path.join(out, "seaweed_1.mem"), idx[4:8])
        elif name == "harpoon":
            write_mem(os.path.join(out, "harpoon_h.mem"), idx)
            # turn 90 degrees clockwise: the tip (right) ends up at the bottom
            write_mem(os.path.join(out, "harpoon_v.mem"), [np.rot90(a, -1) for a in idx])
        else:
            write_mem(os.path.join(out, f"{name}.mem"), idx)
        write_pal(os.path.join(out, f"{name}_pal.mem"), pal)
        print(name, len(fr), fr[0].shape[1], "x", fr[0].shape[0], "colors", len(pal))

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
