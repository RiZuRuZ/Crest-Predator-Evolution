"""Convert the map picture into the background ROM files used by bg_rom.v

usage: python tools/clean_bubbles.py <map.png> <map_clean.png>   (remove painted bubbles first)
       python tools/gen_background.py <map_clean.png> <out_dir>

- The game world is 1920 x 640 pixels. The ROM stores it at half resolution
  (960 x 320) and bg_rom.v shows every stored pixel as a 2x2 block.
- The left and right edges are cross-faded over BLEND stored pixels so the map
  wraps around without a visible seam.
- Colors are reduced to the 12-bit VGA colors of the board and then to a
  256-color palette (8 bits per stored pixel).
- ROM rows are stored back to back, 960 entries each (address = y*960 + x, no padding).
- The ROM is split into banks of 32768 entries, one file per bank (bg_pix0..8 full,
  bg_pix9 = the last 12288 entries), so Vivado can build each bank from BRAMs without
  cascading them.

Outputs in <out_dir>:
  bg_pix0.mem .. bg_pix9.mem   32768 lines each, 2 hex digits (palette index)
  bg_palette.mem  256 lines, 3 hex digits each ({R,G,B} 4 bits each)
  bg_plant.mem    256 lines, 1 = this palette color belongs to seaweed or coral
                  (bg_rom sways those pixels; greens and pink/purple/orange colors)
  bg_preview.png  the result at full world size (1920 x 640), as the board shows it
"""
import sys
import colorsys
import numpy as np
from PIL import Image

STORE_W, STORE_H = 960, 320      # world 1920 x 640 at 2x
BANK = 32768                # entries per ROM bank
BLEND = 60

def is_plant(r, g, b):
    """Seaweed (greens) and coral (pink / purple / orange) colors; blue ruins and water are not."""
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    hue = h * 360
    green = 60 <= hue < 165 and s > 0.40 and v > 0.30
    coral = (hue >= 255 or hue < 45) and s > 0.25 and v > 0.45
    return green or coral

def main(src, out_dir):
    im = Image.open(src).convert("RGB")
    # resize to the stored width plus the blend zone, then cross-fade the edges
    wide = np.asarray(im.resize((STORE_W + BLEND, STORE_H), Image.LANCZOS)).astype(np.float32)
    out = wide[:, :STORE_W].copy()
    for x in range(BLEND):
        t = x / BLEND                          # 0 at the seam, 1 inside the picture
        out[:, x] = (1 - t) * wide[:, STORE_W + x] + t * wide[:, x]

    # 12-bit colors (4 bits per channel)
    q4 = np.clip(np.rint(out / 17.0), 0, 15).astype(np.uint8)
    img12 = Image.fromarray((q4 * 17).astype(np.uint8), "RGB")

    # 256-color palette, no dithering (keeps the pixel-art look)
    pimg = img12.quantize(colors=256, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    idx = np.asarray(pimg)
    pal = np.array(pimg.getpalette()[:256 * 3], dtype=np.int32).reshape(-1, 3)
    if pal.shape[0] < 256:
        pal = np.vstack([pal, np.zeros((256 - pal.shape[0], 3), dtype=np.int32)])
    pal4 = np.clip(np.rint(pal / 17.0), 0, 15).astype(np.int32)

    flat = [f"{v:02X}" for v in idx.reshape(-1)]
    for b in range((len(flat) + BANK - 1) // BANK):
        with open(f"{out_dir}/bg_pix{b}.mem", "w") as f:
            f.write("\n".join(flat[b * BANK:(b + 1) * BANK]) + "\n")
    with open(f"{out_dir}/bg_palette.mem", "w") as f:
        for r, g, b in pal4:
            f.write(f"{r:X}{g:X}{b:X}\n")
    with open(f"{out_dir}/bg_plant.mem", "w") as f:
        for r, g, b in pal4:
            f.write(("1" if is_plant(r / 15, g / 15, b / 15) else "0") + "\n")

    preview = (pal4[idx] * 17).astype(np.uint8)
    Image.fromarray(preview, "RGB").resize((STORE_W * 2, STORE_H * 2), Image.NEAREST) \
        .save(f"{out_dir}/bg_preview.png")
    seam = np.abs(preview[:, 0].astype(int) - preview[:, -1].astype(int)).mean()
    print(f"colors used: {len(np.unique(idx))}, seam difference: {seam:.1f}")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
