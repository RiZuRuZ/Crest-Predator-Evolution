"""Print the is_plant() function for bg_rom.v from bg_plant.mem.

usage: python tools/plant_table_to_verilog.py src/bg_plant.mem
Run it after gen_background.py makes a new map, and paste the output over the
is_plant() function in src/bg_rom.v. (The table is built into the Verilog because
Vivado did not load bg_plant.mem into a 1-bit array on the board.)
"""
import sys

def main(path):
    with open(path) as f:
        bits = [int(l) for l in f if l.strip()]
    idx = [i for i, b in enumerate(bits) if b]
    print("    // palette indexes that are plant colors (from bg_plant.mem, made by")
    print("    // tools/plant_table_to_verilog.py; regenerate after a new map)")
    print("    function is_plant(input [7:0] c);")
    print("        case (c)")
    for k in range(0, len(idx), 10):
        chunk = ", ".join(f"8'd{i}" for i in idx[k:k + 10])
        end = ":" if k + 10 >= len(idx) else ","
        print(f"            {chunk}{end}" + (" is_plant = 1'b1;" if end == ":" else ""))
    print("            default: is_plant = 1'b0;")
    print("        endcase")
    print("    endfunction")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1])
