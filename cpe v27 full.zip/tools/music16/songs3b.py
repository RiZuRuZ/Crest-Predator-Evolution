from songs3 import *
# ================= TITLE: "Coral Hop" intro (calm, same hook, 136 bpm) =================
T_bell = A1
T_lead = ('-:16 -:16 -:16 -:16 ' + ' '.join(A2.split()[:-4]) + ' C5:6')
TITLE = dict(ms=110)
TITLE['voices'] = {
    'lead': ('lead', bars(T_lead)),
    'call': ('bell', bars(T_bell) + rest(4)),
    'arp':  ('arp', arp(chA) + arp(chA[:3] + [['C4','E4','G4','C5']])),
    'bass': ('bass', bass(['C2','A1','D2','G1'] * 2, '0:4 -:2 7:2 12:4 -:4')),
}
TITLE['drum'] = ('....h.......h...' * 3 + '....h.......h.hh' + 'k...h...k...h...' * 3 + 'k...h...c.......')
# ================= EVENT / giant shark: "Fin Alert" (G minor, 176 bpm) =================
E_lead = ('G4:1 -:1 G4:1 -:1 A#4:1 -:1 D5:2 C5:2 A#4:2 A4:2 G4:2 '
          'D#5:1 -:1 D#5:1 -:1 G5:2 D#5:2 D5:2 C5:2 A#4:4 '
          'F4:1 -:1 A4:1 -:1 C5:2 F5:2 D#5:2 D5:2 C5:2 A4:2 '
          'F#4:2 A4:2 C5:2 D5:2 F#5:4 -:4 '
          'G3:2 A#3:2 D4:2 G4:2 -:8 '
          'D#4:2 G4:2 A#4:2 D#5:2 -:8 '
          'F4:2 A4:2 C5:2 F5:2 F#5:2 A5:2 C6:2 D6:2 '
          'D6:4 C6:2 A5:2 F#5:2 D5:2 A4:4')
E_bell = ('-:16 -:16 -:16 -:16 '
          '-:8 D6:1 -:1 A#5:1 -:1 G5:2 D5:2 '
          '-:8 D#6:1 -:1 A#5:1 -:1 G5:2 D#5:2 '
          '-:16 -:16')
cE = [['G3','A#3','D4'], ['D#3','G3','A#3'], ['F3','A3','C4'], ['D3','F#3','A3','C4']]
EVENT = dict(ms=85)
EVENT['voices'] = {
    'lead': ('lead', bars(E_lead)),
    'call': ('bell', bars(E_bell)),
    'arp':  ('arp', arp(cE, 1, 1) + rest(4)[:0] + arp(cE, 1, 1)),
    'bass': ('bass', bass(['G1','D#1','F1','D2'] * 2, '0:1 -:1 12:1 -:1 0:1 0:1 12:1 -:1 0:1 -:1 12:1 0:1 10:2 7:2')),
}
e1, ef = 'k.h.s.hkk.h.s.hk', 'k.s.s.s.ssssssss'
EVENT['drum'] = 'c' + e1[1:] + e1 + e1 + ef + 'k.h.s.hkk.h.s.hk' + e1 + e1 + 'kkkkssssppppssss'
# ================= BOSS phase 3: "Abyss Rush" faster (216 bpm) =================
BOSS3 = dict(BOSS, ms=70)
if __name__ == '__main__':
    gap = np.zeros(int(SR * .7)); parts = []; t = 0
    for nm, trk, n in [('TITLE', TITLE, 2), ('EVENT "Fin Alert"', EVENT, 3), ('BOSS phase 3', BOSS3, 1)]:
        L = len(trk['drum']); assert all(len(v[1]) == L for v in trk['voices'].values()), (nm, L, {k: len(v[1]) for k, v in trk['voices'].items()})
        a = render(trk, n); print(nm, '%d:%04.1f' % (t // 60, t % 60), L, 'steps', round(L * trk['ms'] / 1000, 1), 's/loop')
        parts += [a, gap]; t += (len(a) + len(gap)) / SR
    au = np.concatenate(parts); au = au / np.max(np.abs(au)) * .9
    with wave.open('music_16bit_rest.wav', 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((au * 32767).astype('<i2').tobytes())
