# BOSS phase 1-2: "Deep Rampage" - low, fast, relentless (E minor, 172 bpm), original
from fury import *
INST['lead_lo'] = dict(t=table([(n, 1 / n) for n in range(1, 13)]), v=.27, a=.003, d=.12, s=.6, vib=0)
INTRO = '-:16 -:16'
R1 = 'E4:1 E4:1 E4:1 -:1 G4:1 -:1 E4:1 E4:1 A#4:2 A4:2 G4:1 F#4:1 E4:1 D4:1'
R2 = 'E4:1 E4:1 E4:1 -:1 G4:1 -:1 E4:1 E4:1 B4:2 A4:2 G4:2 F#4:2'
R3 = 'C4:1 C4:1 C4:1 -:1 E4:1 -:1 C4:1 C4:1 G4:2 F#4:2 E4:1 D4:1 C4:1 B3:1'
R4 = 'B3:1 B3:1 B3:1 -:1 D#4:1 -:1 F#4:1 -:1 B4:4 A4:2 F#4:2'
R6 = 'E4:1 E4:1 E4:1 -:1 B4:1 -:1 E4:1 E4:1 D5:2 C5:2 B4:2 A4:2'
R7 = 'D4:1 D4:1 D4:1 -:1 F#4:1 -:1 D4:1 D4:1 A4:2 G4:2 F#4:1 E4:1 D4:1 C#4:1'
R8 = 'B3:1 C4:1 D#4:1 E4:1 F#4:1 G4:1 A4:1 B4:1 C5:1 B4:1 A4:1 G4:1 F#4:1 D#4:1 C4:1 B3:1'
RIFF = ' '.join([R1, R2, R3, R4, R1, R6, R7, R8])
STOMP = 'A4:6 C5:2 B4:4 A4:4 G4:6 B4:2 A4:4 G4:4 E4:6 G4:2 F#4:4 E4:4 D#4:4 F#4:4 B3:8'
BRK = ('E4:1 F4:1 E4:1 F#4:1 E4:1 G4:1 E4:1 G#4:1 E4:1 A4:1 E4:1 A#4:1 E4:1 B4:1 E4:1 C5:1 '
       'B4:1 A#4:1 A4:1 G#4:1 G4:1 F#4:1 F4:1 E4:1 D#4:4 -:4')
RIFF4 = ' '.join([R1, R2, R3, R4])
END = 'E4:1 E4:1 E4:1 -:1 G4:1 -:1 E4:1 E4:1 A#4:2 A4:2 G4:2 F#4:2 E4:4 -:4 B3:1 B3:1 B3:1 -:1 B3:1 -:3'
for nm, s, n in [('RIFF', RIFF, 128), ('STOMP', STOMP, 64), ('BRK', BRK, 32), ('RIFF4', RIFF4, 64), ('END', END, 32)]:
    assert sum(int(t.split(':')[1]) for t in s.split()) == n, (nm, sum(int(t.split(':')[1]) for t in s.split()))
pw = lambda r: C(r, [0, 7, 12, 7])                     # power chord tremolo
DEEP = dict(ms=87)
DEEP['voices'] = {
    'lead': ('lead_lo', bars(INTRO, RIFF, STOMP, BRK, RIFF4, END)),
    'call': ('bell', rest(2) + rest(8) + rest(4) + rest(2) + rest(4) + rest(2)),
    'arp':  ('arp', rest(2) + arp([pw('E3'), pw('E3'), pw('C3'), pw('B2'), pw('E3'), pw('E3'), pw('D3'), pw('B2')])
             + arp([pw('A2'), pw('E3'), pw('C3'), pw('B2')]) + rest(2)
             + arp([pw('E3'), pw('E3'), pw('C3'), pw('B2')]) + arp([pw('E3'), pw('B2')])),
    'bass': ('bass_hv', bass(['E2'] * 2, '0:2 0:1 0:1 0:2 0:1 0:1 0:2 0:1 0:1 0:1 0:1 0:1 0:1')
             + bars(tr(RIFF, -24)) + bass(['A1', 'E2', 'C2', 'B1'], '0:1 ' * 16)
             + bars(tr(BRK, -24)) + bars(tr(RIFF4, -24)) + bars(tr(END, -24))),
}
g, gf = 'kkhks.hkk.hks.hk', 'k.kks.kkk.kks.kk'
DEEP['drum'] = ('k.kkk.kkk.kkk.kk' + 'kkkkkkkkssssssss'
                + 'c' + g[1:] + g + gf + g + g + g + gf + 'k.s.s.s.ssssssss'
                + 'c.kkk.kks.kkk.kk' + 'k.kkk.kks.kkk.kk' + 'k.kkk.kks.kkk.kk' + 'k.kks.kkssssssss'
                + 'k.k.k.k.k.k.k.k.' + 'kkkkkkkkc.......'
                + 'c' + gf[1:] + gf + gf + 'k.s.s.s.sssskkkk' + g + 'c...............')
if __name__ == '__main__':
    L = len(DEEP['drum']); bad = {k: len(v[1]) for k, v in DEEP['voices'].items() if len(v[1]) != L}
    assert not bad, (L, bad)
    a = render(DEEP, 1)
    sub = dict(DEEP, voices={k: (i, s[32:160]) for k, (i, s) in DEEP['voices'].items()}, drum=DEEP['drum'][32:160])
    au = np.concatenate([a, render(sub, 1)]); au = au / np.max(np.abs(au)) * .9
    print(L, 'steps', round(L * .087, 1), 's/loop')
    with wave.open('deep_rampage_preview.wav', 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((au * 32767).astype('<i2').tobytes())
