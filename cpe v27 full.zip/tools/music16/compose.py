# Crest Predator Evolution - music v2 demo (original tunes).
# Model = what the board can do: lead (triangle or square + decay), triangle bass,
# 1 drum voice (kick = pitch drop, snare = noise, hat = short noise); 16th-note steps.
import numpy as np, wave, json
SR = 44100
NOTE = {'C':0,'C#':1,'Db':1,'D':2,'D#':3,'Eb':3,'E':4,'F':5,'F#':6,'Gb':6,'G':7,'G#':8,'Ab':8,'A':9,'A#':10,'Bb':10,'B':11}
def midi(n):
    nm, oc = (n[:-1], int(n[-1]))
    return 12 * (oc + 1) + NOTE[nm]
def seq(text):                       # "A4:2 -:2 C5:4" -> list of (midi or None, steps)
    out = []
    for tok in text.split():
        n, d = tok.split(':'); out.append((None if n == '-' else midi(n), int(d)))
    return out
def steps_of(s):                     # expand to per-step (note, new_note_flag)
    r = []
    for n, d in s:
        for k in range(d): r.append((n, k == 0))
    return r
def bass_line(chords, pat):          # chords: list of root names per bar; pat per bar
    s = []
    for c in chords:
        root = midi(c)
        for tok in pat.split():
            n, d = tok.split(':')
            s.append((None if n == '-' else root + int(n), int(d)))
    return s
DR = {'.': 0, 'k': 1, 's': 2, 'h': 3}
def drums(bars):                     # list of 16-char strings
    return [DR[c] for b in bars for c in b]

TRACKS = {}
# 1 TITLE - calm, floating arpeggios (D major 7 / G major 7), no drums
TRACKS['title'] = dict(ms=190, lead='tri', decay=(0.75, 0.9),
    mel=seq('D5:2 F#5:2 A5:2 C#6:2 E6:4 C#6:2 A5:2 '
            'B4:2 D5:2 F#5:2 A5:2 C#6:4 A5:2 F#5:2 '
            'G4:2 B4:2 D5:2 F#5:2 A5:4 F#5:2 D5:2 '
            'A4:2 C#5:2 E5:2 G5:2 F#5:4 E5:2 C#5:2'),
    bass=bass_line(['D3', 'B2', 'G2', 'A2'], '0:8 7:8'),
    drum=drums(['................'] * 4))
# 2 NORMAL - calm underwater with a soft beat, catchy hook (D major)
TRACKS['normal'] = dict(ms=150, lead='tri', decay=(0.65, 0.5),
    mel=seq('F#5:4 A5:2 C#6:2 B5:6 A5:2 '
            'F#5:4 D5:2 F#5:2 E5:8 '
            'D5:4 E5:2 F#5:2 G5:4 A5:4 '
            'B5:4 A5:4 E5:8 '
            'F#5:4 A5:2 C#6:2 D6:6 C#6:2 '
            'B5:4 A5:2 F#5:2 A5:8 '
            'G5:2 F#5:2 E5:2 D5:2 E5:4 G5:4 '
            'F#5:4 E5:4 D5:4 -:4'),
    bass=bass_line(['D3', 'B2', 'G2', 'A2', 'D3', 'B2', 'G2', 'A2'], '0:3 -:1 7:2 12:2 0:3 -:1 7:4'),
    drum=drums(['k...h.....k.h...', 'k...h.....k.h...', 'k...h.....k.h...', 'k...h...k...h.hh'] * 2))
# 3 BOSS - heroic, driving (A minor), 143 bpm
_boss_mel = ('A4:2 C5:2 E5:4 A5:6 G5:2 '
             'F5:4 E5:2 D5:2 C5:4 A4:4 '
             'B4:2 D5:2 G5:4 F5:4 D5:4 '
             'E5:6 G#5:2 B5:8 '
             'A5:2 B5:2 C6:4 B5:2 A5:2 E5:4 '
             'F5:2 G5:2 A5:4 C6:4 A5:4 '
             'G5:2 A5:2 B5:4 D6:4 B5:4 '
             'E6:8 D6:2 C6:2 B5:2 G#5:2')
TRACKS['boss'] = dict(ms=105, lead='sq', decay=(0.45, 0.3), mel=seq(_boss_mel),
    bass=bass_line(['A2', 'F2', 'G2', 'E2', 'A2', 'F2', 'G2', 'E2'], '0:2 12:2 0:2 12:2 0:2 12:2 0:2 12:2'),
    drum=drums(['k.h.s.h.k.h.s.h.', 'k.h.s.h.k.k.s.h.', 'k.h.s.h.k.h.s.h.', 'k.h.s.h.k.h.s.ss'] * 2))
# 4 BOSS phase 3 - the same theme, faster, four-on-the-floor
TRACKS['boss3'] = dict(ms=85, lead='sq', decay=(0.45, 0.3), mel=seq(_boss_mel),
    bass=bass_line(['A2', 'F2', 'G2', 'E2', 'A2', 'F2', 'G2', 'E2'], '0:1 12:1 0:1 12:1 0:1 12:1 0:1 12:1 0:1 12:1 0:1 12:1 0:1 12:1 0:1 12:1'),
    drum=drums(['k.h.s.h.k.h.s.h.', 'k.h.s.h.k.h.s.h.', 'k.h.s.h.k.h.s.h.', 'k.h.s.h.k.s.s.ss'] * 2))
# 5 EVENT / giant shark - tense and heroic (D minor), short loop
TRACKS['event'] = dict(ms=110, lead='sq', decay=(0.5, 0.3),
    mel=seq('D5:2 D5:2 F5:2 A5:2 G5:4 F5:4 '
            'Bb4:2 D5:2 F5:4 E5:4 D5:4 '
            'C5:2 E5:2 G5:4 A5:4 G5:4 '
            'A5:4 C#6:4 E6:4 C#6:4'),
    bass=bass_line(['D2', 'A#1', 'C2', 'A1'], '0:2 12:2 0:2 12:2 0:2 12:2 0:2 12:2'),
    drum=drums(['k.h.s.h.k.h.s.h.', 'k.h.s.h.k.h.s.h.', 'k.h.s.h.k.h.s.h.', 'k.s.s.s.k.s.ssss']))

def freq(m): return 440.0 * 2 ** ((m - 69) / 12)
def osc(kind, f, n, ph):
    t = (ph + f * np.arange(n) / SR) % 1.0
    if kind == 'sq':  w = np.where(t < 0.5, 1.0, -1.0)
    else:             w = 4 * np.abs(t - 0.5) - 1          # triangle
    return w, (ph + f * n / SR) % 1.0
rng = np.random.default_rng(1)
def render(tr, loops=2):
    m = steps_of(tr['mel']); b = steps_of(tr['bass']); d = tr['drum']
    L = len(m); assert len(b) == L == len(d), (len(m), len(b), len(d))
    ns = int(SR * tr['ms'] / 1000)
    out = []; pm = pb = 0.0; env_t = 0
    for lp in range(loops):
        for i in range(L):
            buf = np.zeros(ns)
            n, new = m[i]
            if new: env_t = 0
            if n is not None:
                w, pm = osc(tr['lead'], freq(n), ns, pm)
                lo, tau = tr['decay']                     # decay to `lo` with time constant tau (s)
                tt = (env_t + np.arange(ns)) / SR
                env = lo + (1 - lo) * np.exp(-tt / tau)
                buf += 0.26 * w * env
            env_t += ns
            bn, _ = b[i]
            if bn is not None:
                w, pb = osc('tri', freq(bn), ns, pb); buf += 0.34 * w
            dr = d[i]; k = np.arange(ns) / SR
            if dr == 1:   # kick: triangle 140 -> 45 Hz in 60 ms, decay
                fk = 45 + 95 * np.exp(-k / 0.03); ph = np.cumsum(fk) / SR
                buf += 0.55 * (4 * np.abs((ph % 1) - 0.5) - 1) * np.exp(-k / 0.09)
            elif dr == 2: # snare: noise, decay 70 ms
                buf += 0.22 * rng.uniform(-1, 1, ns) * np.exp(-k / 0.07)
            elif dr == 3: # hat: short noise, decay 15 ms, first difference = brighter
                nz = rng.uniform(-1, 1, ns + 1); buf += 0.12 * np.diff(nz) * np.exp(-k / 0.015)
            out.append(buf)
    return np.concatenate(out)
if __name__ == '__main__':
    order = [('title', 2), ('normal', 2), ('boss', 2), ('boss3', 1), ('event', 3)]
    gap = np.zeros(int(SR * 0.6))
    audio = np.concatenate([np.concatenate([render(TRACKS[k], n), gap]) for k, n in order])
    audio = audio / np.max(np.abs(audio)) * 0.85
    with wave.open('music_v2_preview.wav', 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((audio * 32767).astype('<i2').tobytes())
    for k, n in order:
        tr = TRACKS[k]; L = len(steps_of(tr['mel']))
        print(k, L, 'steps', round(L * tr['ms'] / 1000, 1), 's per loop x', n)
