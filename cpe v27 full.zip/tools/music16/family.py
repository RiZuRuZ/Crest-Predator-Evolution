# Coral Hop family: same style / instruments, different songs (original tunes)
from songs3 import *
def C(root, iv):
    names = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']; r = midi(root)
    return [f'{names[(r + i) % 12]}{(r + i) // 12 - 1}' for i in iv]
M7, D7, m7 = [0, 4, 7, 11], [0, 4, 7, 10], [0, 3, 7, 10]
# ================= EVENT: "Bubble Panic" (F major, jazzy, 176 bpm) =================
EV_A = ('C5:1 -:1 C5:1 -:1 F5:2 A5:2 G5:1 -:1 F5:1 -:1 D5:2 C5:2 '
        'D5:1 -:1 F#5:1 -:1 A5:2 C6:2 A5:2 F#5:2 D5:4 '
        'G5:2 A#5:2 D6:2 A#5:2 A5:2 G5:2 F5:2 D5:2 '
        'E5:2 G5:2 A#5:2 C6:2 -:2 C6:1 A#5:1 A5:2 G5:2 '
        'C5:1 -:1 C5:1 -:1 F5:2 A5:2 C6:4 A5:2 F5:2 '
        'F#5:2 A5:2 D6:2 C6:2 A5:4 F#5:4 '
        'A#5:2 A5:2 G5:2 F5:2 E5:2 G5:2 C6:2 E5:2 '
        'F5:4 -:12')
EV_T = ('D4:2 F4:2 A#4:2 D5:2 -:8 '
        'C#4:2 F4:2 A#4:2 C#5:2 -:8 '
        'C5:2 A4:2 F4:2 A4:2 C5:2 F5:2 A5:2 C6:2 '
        'C6:1 A#5:1 G5:1 E5:1 C5:1 A#4:1 G4:1 E4:1 -:4 C5:1 -:1 C5:1 -:1')
EV_BELL = ('-:16 ' * 7 + '-:8 A5:1 -:1 C6:1 -:1 F6:2 -:2 '
           '-:8 F5:1 -:1 A#5:1 -:1 D6:2 F6:2 '
           '-:8 F5:1 -:1 A#5:1 -:1 C#6:2 F6:2 '
           '-:16 -:16')
cEv = [C('F4', M7), C('D4', D7), C('G4', m7), C('C4', D7)] * 2 + [C('A#3', M7), C('A#3', m7), C('F4', M7), C('C4', D7)]
EVENT2 = dict(ms=85)
EVENT2['voices'] = {
    'lead': ('lead', bars(EV_A, EV_T)),
    'call': ('bell', bars(EV_BELL)),
    'arp':  ('arp', arp(cEv)),
    'bass': ('bass', bass(['F2','D2','G2','C2'] * 2, funk) + bass(['A#1','A#1','A1','C2'], '0:4 7:4 12:4 7:4')),
}
e1, e2, ef = 'k.h.s.hkk.h.s.h.', 'k.hks.h.k.h.s.ho', 'k.h.s.h.k.s.ssss'
EVENT2['drum'] = 'c' + e1[1:] + e2 + e1 + ef + e1 + e2 + e1 + 'k.s.s.s.kpkpssss' + 'k..k..s.k..k.s..' * 2 + e1 + 'ssssssss....s.s.'
# ================= BOSS: "Coral Clash" (C minor, jazzy funk, 168 bpm) =================
BA = ('C5:2 D#5:2 G5:2 A#5:1 -:1 A#5:2 G5:2 D#5:2 F5:2 '
      'G#5:2 -:1 G#5:1 F#5:2 D#5:2 C5:4 D#5:4 '
      'F5:2 G#5:2 C6:2 D#6:2 D6:2 C6:2 G#5:2 F5:2 '
      'G5:2 B5:2 D6:2 F6:2 D6:1 B5:1 G5:1 F5:1 D5:2 B4:2 '
      'C5:2 D#5:2 G5:2 C6:1 -:1 C6:2 A#5:2 G5:2 A#5:2 '
      'C6:2 G#5:2 D#5:2 C5:2 F#5:4 D#5:4 '
      'F5:2 G#5:2 C6:2 G#5:2 B5:2 D6:2 G6:2 F6:2 '
      'D#6:4 C6:4 -:2 G4:1 G#4:1 B4:2 C5:2')
BB = ('G#3:2 -:2 C4:2 D#4:2 G#4:4 G4:2 D#4:2 '
      'G3:2 -:2 B3:2 D4:2 G4:4 F4:2 D4:2 '
      'F4:2 G#4:2 C5:2 F5:2 D#5:2 C5:2 G#4:2 F4:2 '
      'G4:2 B4:2 D5:2 F5:2 G5:4 -:4')
BB_BELL = ('-:8 D#5:1 -:1 G#5:1 -:1 C6:2 A#5:2 '
           '-:8 D5:1 -:1 G5:1 -:1 B5:2 G5:2 '
           '-:8 F5:2 G#5:2 C6:2 G#5:2 '
           'B5:1 D6:1 F6:1 G6:1 -:12')
BRK3 = '-:16 -:8 G4:1 G#4:1 B4:1 C5:1 D5:1 D#5:1 F5:1 F#5:1'
BA4 = ' '.join(BA.split()[:34])
assert sum(int(t.split(':')[1]) for t in BA4.split()) == 64, sum(int(t.split(':')[1]) for t in BA4.split())
BEND = 'G5:4 F5:2 D5:2 B4:2 D5:2 F5:2 G5:2 C5:4 -:4 -:4 G4:1 G#4:1 B4:2'
cBA = [C('C4', m7), C('G#3', D7), C('F4', m7), C('G3', D7)] * 2
cBB = [C('G#3', M7), C('G3', [0, 4, 7]), C('F3', m7), C('G3', D7)]
cBL = [C('D4', m7), C('A#3', D7), C('G4', m7), C('A3', D7)]
mfunk = '0:2 -:1 0:1 12:2 0:2 10:2 -:1 7:1 12:2 7:2'
CLASH = dict(ms=89)
CLASH['voices'] = {
    'lead': ('lead', bars(BA, BB, BRK3, tr(BA4, 2), BEND)),
    'call': ('bell', rest(8) + bars(BB_BELL) + rest(2) + bars(dia_dummy := '-:16 -:16 -:16 -:16') + rest(2)),
    'arp':  ('arp', arp(cBA) + rest(4) + rest(1) + arp([C('G3', D7)]) + arp(cBL) + arp([C('G3', D7), C('C4', m7)])),
    'bass': ('bass', bass(['C2','G#1','F2','G1'] * 2, mfunk) + bass(['G#1','G1','F1','G1'], drv)
             + bass(['G1'], '0:3 0:1 -:2 0:2 -:2 7:2 10:2 12:2') + bass(['G1'], '0:2 1:2 2:2 3:2 4:2 5:2 6:2 7:2')
             + bass(['D2','A#1','G1','A1'], mfunk) + bass(['G1','C2'], mfunk)),
}
b1, b2, bf = 'k.h.s.hkk.hks.h.', 'k.hks.hkk.h.s.hk', 'k.s.s.s.sssskkkk'
CLASH['drum'] = ('c' + b1[1:] + b2 + b1 + bf + b1 + b2 + b1 + bf +
                 'k.h.s.h.k.h.s.h.' * 3 + 'k.s.s.s.kpkpssss' + 'k..k..s.k..k.sss' + 'kkkkssssppppssss' +
                 'c' + b2[1:] + b2 + b1 + bf + 'k.h.s.h.k.h.s.h.' + 'c...............')
CLASH3 = dict(CLASH, ms=74)
if __name__ == '__main__':
    gap = np.zeros(int(SR * .7)); parts = []; t = 0
    for nm, trk, n in [('EVENT "Bubble Panic"', EVENT2, 2), ('BOSS "Coral Clash"', CLASH, 1), ('BOSS phase 3', CLASH3, 1)]:
        L = len(trk['drum']); bad = {k: len(v[1]) for k, v in trk['voices'].items() if len(v[1]) != L}
        assert not bad, (nm, L, bad)
        a = render(trk, n); print(nm, '%d:%04.1f' % (t // 60, t % 60), L, 'steps', round(L * trk['ms'] / 1000, 1), 's/loop')
        parts += [a, gap]; t += (len(a) + len(gap)) / SR
    au = np.concatenate(parts); au = au / np.max(np.abs(au)) * .9
    with wave.open('coral_family_preview.wav', 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((au * 32767).astype('<i2').tobytes())
