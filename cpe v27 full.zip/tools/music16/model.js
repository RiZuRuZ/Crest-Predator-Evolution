// render the 5 tracks with the board model (../../../cpe_pc/src/music16.js) -> raw int8 files
const fs = require('fs'); const M16 = require(process.argv[2]);
const D = JSON.parse(fs.readFileSync(__dirname + '/music16.json'));
const loops = +(process.argv[3] || 1);
for (const t of D.tracks) {
  const n = t.len * t.step_smp * loops, out = new Int16Array(n), st = M16.state();
  M16.render(D, t, n, st, out);
  let pk = 0, rms = 0, clip = 0;
  for (const x of out) { pk = Math.max(pk, Math.abs(x)); rms += x * x; if (Math.abs(x) >= 100) clip++; }
  console.log(t.name, 'samples', n, 'peak', pk, 'rms', Math.sqrt(rms / n).toFixed(1), 'clipped', clip);
  fs.writeFileSync(`/tmp/m16_${t.name}.raw`, Buffer.from(Int8Array.from(out).buffer));
}
