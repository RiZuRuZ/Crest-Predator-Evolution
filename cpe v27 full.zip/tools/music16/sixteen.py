# Music v3 demo: "16-bit" style (wavetable instruments + sampled drums), original tunes.
# Hardware model: 4 tonal voices (256 x 8-bit single-cycle wavetables, nearest sample, ADSR,
# lead vibrato) + 1 drum voice (8-bit 16 kHz one-shot samples); 16th-note steps.
import numpy as np, wave
from compose import midi, seq, steps_of
SR = 44100
rng = np.random.default_rng(7)
def table(harm):                       # harmonics [(n, amp)] -> 256 x 8-bit table (-1..1)
    x = np.arange(256) / 256 * 2 * np.pi
    w = sum(a * np.sin(n * x) for n, a in harm); w = w / np.max(np.abs(w))
    return np.round(w * 127) / 127
INST = {   # wavetable, volume, attack s, decay tau s, sustain, vibrato
    'lead':    dict(t=table([(1, 1), (2, .5), (3, .33), (4, .25), (5, .2), (6, .12), (7, .08)]), v=.24, a=.004, d=.18, s=.7, vib=1),
    'bell':    dict(t=table([(1, 1), (3, .25), (4, .3), (6, .08)]),  v=.20, a=.002, d=.12, s=.15, vib=0),
    'bass':    dict(t=table([(1, 1), (2, .6), (3, .35), (4, .2), (5, .1)]), v=.36, a=.003, d=.12, s=.55, vib=0),
    'arp':     dict(t=table([(1, 1), (3, .3), (5, .12)]), v=.11, a=.002, d=.06, s=.25, vib=0),
}
def drum_samples():                    # 16 kHz 8-bit one-shots
    fs = 16000
    def env(n, tau): return np.exp(-np.arange(n) / fs / tau)
    k = np.arange(2400) / fs; f = 50 + 110 * np.exp(-k / .025)
    kick = np.sin(2 * np.pi * np.cumsum(f) / fs) * env(2400, .12)
    n = rng.uniform(-1, 1, 2800)
    snare = .65 * n * env(2800, .08) + .5 * np.sin(2 * np.pi * 190 * np.arange(2800) / fs) * env(2800, .05)
    h = np.diff(rng.uniform(-1, 1, 801)); hat = h * env(800, .02)
    o = np.diff(rng.uniform(-1, 1, 4001)); ohat = o * env(4000, .12)
    c = np.diff(rng.uniform(-1, 1, 12001)); crash = .8 * c * env(12000, .5)
    clap = n[:2400] * (env(2400, .03) + .6 * np.roll(env(2400, .03), 160) + .4 * np.roll(env(2400, .05), 320))
    out = {}
    for nm, s in dict(k=kick, s=snare, h=hat, o=ohat, c=crash, p=clap).items():
        s = np.round(s / np.max(np.abs(s)) * 127) / 127           # 8-bit
        out[nm] = np.repeat(s, 1)                                   # resampled at play time
    return out, fs
DRUMS, DFS = drum_samples()
DVOL = dict(k=.55, s=.38, h=.14, o=.14, c=.2, p=.3)
def freq(m): return 440.0 * 2 ** ((m - 69) / 12)

def render(track, loops=1):
    ms = track['ms']; ns = int(SR * ms / 1000)
    voices = track['voices']                     # name -> (inst, per-step [(note, new)])
    L = len(track['drum'])
    for nm, (inst, st) in voices.items(): assert len(st) == L, (nm, len(st), L)
    total = ns * L * loops
    mix = np.zeros(total + SR)
    for nm, (inst, st) in voices.items():
        I = INST[inst]; ph = 0.0; i = 0
        st = st * loops
        while i < len(st):
            n, new = st[i]
            if n is None: i += 1; continue
            j = i + 1
            while j < len(st) and st[j][0] == n and not st[j][1]: j += 1
            dur = (j - i) * ns; t = np.arange(dur + int(.03 * SR)) / SR
            f = freq(n) * (1 + (0.006 * np.sin(2 * np.pi * 5.5 * t) * (t > .15) if I['vib'] else 0 * t))
            phase = ph + np.cumsum(f) / SR
            w = I['t'][(np.floor(phase * 256) % 256).astype(int)]
            env = np.minimum(1, t / I['a']) * (I['s'] + (1 - I['s']) * np.exp(-t / I['d']))
            rel = np.clip(1 - (t - dur / SR) / .03, 0, 1); env *= rel
            mix[i * ns: i * ns + len(w)] += I['v'] * w * env
            ph = phase[-1] % 1; i = j
    dr = track['drum'] * loops
    for i, c in enumerate(dr):
        if c == '.': continue
        s = DRUMS[c]; idx = (np.arange(int(len(s) / DFS * SR)) * DFS / SR).astype(int)
        seg = s[idx] * DVOL[c]; mix[i * ns: i * ns + len(seg)] += seg[:len(mix) - i * ns]
    # board output: PWM + analogue low-pass (approximated, one pole ~9 kHz)
    a = np.exp(-2 * np.pi * 9000 / SR); y = np.zeros_like(mix); acc = 0.0
    for k in range(len(mix)): acc = a * acc + (1 - a) * mix[k]; y[k] = acc
    return y[:total]

# ---------- writing helpers ----------
def bars(*strs): return steps_of(seq(' '.join(strs)))
def tr(text, semi):                    # transpose a note string
    out = []
    for tok in text.split():
        n, d = tok.split(':')
        if n == '-': out.append(tok); continue
        m = midi(n) + semi; names = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
        out.append(f'{names[m % 12]}{m // 12 - 1}:{d}')
    return ' '.join(out)
def bass(roots, pat):                  # roots: note names per bar, pat: offsets string
    s = []
    for r in roots:
        for tok in pat.split():
            n, d = tok.split(':'); s.append((None if n == '-' else midi(r) + int(n), int(d)))
    return steps_of(s)
def arp(chords, rate=1, oct_=0):       # chords: list of note-name lists per bar, 16th arps
    out = []
    for ch in chords:
        ms = [midi(c) + 12 * oct_ for c in ch]; seqn = ms + ms[-2:0:-1]
        for k in range(16 // rate):
            out += [(seqn[k % len(seqn)], True)] + [(seqn[k % len(seqn)], False)] * (rate - 1)
    return out
def rest(nb): return [(None, False)] * (16 * nb)
