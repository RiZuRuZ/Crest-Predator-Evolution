from family import *
INST['bass_hv'] = dict(t=table([(1, 1), (2, .7), (3, .5), (4, .35), (5, .25), (6, .15), (7, .1)]), v=.42, a=.002, d=.07, s=.5, vib=0)
def p3(pat_a, pat_b, brk1, brk2):
    return (bass(['C2','G#1','F1','G1'] * 2, pat_a) + bass(['G#1','G1','F1','G1'], pat_b)
            + bass(['G1'], brk1) + bass(['G1'], brk2)
            + bass(['D2','A#1','G1','A1'], pat_a) + bass(['G1','C2'], pat_a))
# V1: 16th chug, octave jumps low / high
V1a = '0:1 12:1 0:1 12:1 0:1 12:1 7:1 12:1 0:1 12:1 0:1 12:1 10:1 12:1 7:1 12:1'
V1b = '0:1 0:1 12:1 0:1 0:1 12:1 0:1 12:1 0:1 0:1 12:1 0:1 7:1 12:1 10:1 12:1'
# V2: wide jumps (2 octaves) and fifths, slap style
V2a = '0:1 24:1 0:1 12:1 0:1 24:1 7:1 19:1 0:1 24:1 0:1 12:1 10:1 22:1 7:1 19:1'
V2b = '0:1 0:1 24:1 0:1 12:1 0:1 24:1 12:1 0:1 0:1 24:1 0:1 19:1 7:1 22:1 10:1'
brk1 = '0:1 0:1 0:1 0:1 -:2 0:1 0:1 -:2 7:1 7:1 10:1 10:1 12:1 12:1'
brk2 = '0:1 12:1 1:1 13:1 2:1 14:1 3:1 15:1 4:1 16:1 5:1 17:1 6:1 18:1 7:1 19:1'
dr3 = ('c' + 'k.hks.hkk.hks.hk'[1:] + 'kkhks.hkk.hks.hk' + 'k.hks.hkkkhks.hk' + 'k.s.s.s.sssskkkk') * 2
dr3 += 'k.h.s.hkk.h.s.hk' * 3 + 'k.s.s.s.kpkpssss' + 'k..k..s.k..k.sss' + 'kkkkssssppppssss'
dr3 += 'c' + 'kkhks.hkk.hks.hk'[1:] + 'kkhks.hkk.hks.hk' + 'k.hks.hkkkhks.hk' + 'k.s.s.s.sssskkkk' + 'kkhks.hkk.h.s.h.' + 'c...............'
def variant(pa, pb):
    v = dict(CLASH['voices']); v['bass'] = ('bass_hv', p3(pa, pb, brk1, brk2))
    return dict(CLASH, ms=74, voices=v, drum=dr3)
if __name__ == '__main__':
    gap = np.zeros(int(SR * .7)); parts = []; t = 0
    for nm, trk in [('phase 3 now', CLASH3), ('phase 3 V1 (octave chug)', variant(V1a, V1b)), ('phase 3 V2 (wide jumps)', variant(V2a, V2b))]:
        L = len(trk['drum']); assert all(len(v[1]) == L for v in trk['voices'].values()), nm
        a = render(trk, 1); print(nm, '%d:%04.1f' % (t // 60, t % 60)); parts += [a, gap]; t += (len(a) + len(gap)) / SR
    au = np.concatenate(parts); au = au / np.max(np.abs(au)) * .9
    with wave.open('boss3_bass_preview.wav', 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((au * 32767).astype('<i2').tobytes())
