# BOSS phase 3: "Coral Fury" - new song, D minor, ~197 bpm, heavy jumping bass (original)
from p3 import *
DM = ['D','E','F','G','A','A#','C']
def dia2(text, k, sc):
    names = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']; out = []
    for tok in text.split():
        n, d = tok.split(':')
        if n == '-': out.append(tok); continue
        nm = n[:-1]
        if nm not in sc: out.append(f'-:{d}'); continue
        i = sc.index(nm) + k; base = midi(n); m = midi(sc[i % 7] + n[-1])
        while m > base: m -= 12
        while m < base - 12: m += 12
        out.append(f'{names[m % 12]}{m // 12 - 1}:{d}')
    return ' '.join(out)
FA = ('D5:1 -:1 D5:1 -:1 F5:1 -:1 A5:2 G5:1 -:1 F5:1 -:1 E5:2 D5:2 '
      'D5:1 -:1 D5:1 -:1 F5:1 -:1 A#5:2 A5:2 F5:2 D5:4 '
      'G5:2 -:1 G5:1 A#5:2 D6:2 C6:2 A#5:2 A5:2 G5:2 '
      'A5:2 C#6:2 E6:2 G6:2 F6:1 E6:1 D6:1 C#6:1 A5:4 '
      'D6:1 -:1 D6:1 -:1 C6:1 -:1 A5:2 C6:1 -:1 A5:1 -:1 F5:2 D5:2 '
      'F5:2 A#5:2 D6:2 F6:2 E6:2 D6:2 A#5:4 '
      'G5:2 A#5:2 D6:2 G6:2 F6:2 D6:2 A#5:2 G5:2 '
      'A5:4 -:2 A4:1 A#4:1 C#5:1 D5:1 E5:1 F5:1 G5:1 A5:1 -:2')
FB = ('F6:4 D6:4 A#5:4 D6:4 '
      'E6:4 G6:4 E6:2 C6:2 G5:4 '
      'C#6:4 E6:4 A6:4 G6:2 E6:2 '
      'F6:2 E6:2 D6:2 A5:2 F5:2 A5:2 D6:4')
FBRK = '-:16 -:8 D5:1 E5:1 F5:1 G5:1 A5:1 A#5:1 C6:1 C#6:1'
FA4 = ' '.join(FA.split()[:41])
FEND = 'A5:2 G5:2 F5:2 E5:2 D5:2 C#5:2 D5:2 E5:2 D5:4 -:4 -:4 A4:1 -:1 A4:1 -:1'
FINTRO = '-:16 -:16'
for nm, s, n in [('FA', FA, 128), ('FB', FB, 64), ('FA4', FA4, 64), ('FEND', FEND, 32)]:
    assert sum(int(t.split(':')[1]) for t in s.split()) == n, (nm, sum(int(t.split(':')[1]) for t in s.split()))
cFA = [C('D4', m7), C('A#3', M7), C('G4', m7), C('A3', D7)] * 2
cFB = [C('A#4', M7), C('C5', [0, 4, 7, 12]), C('A4', D7), C('D5', m7)]
cFL = [C('D#4', m7), C('B3', M7), C('G#4', m7), C('A#3', D7)]
slap = '0:1 24:1 0:1 12:1 0:1 24:1 7:1 19:1 0:1 24:1 0:1 12:1 10:1 22:1 7:1 19:1'
chug = '0:1 0:1 12:1 0:1 0:1 12:1 0:1 12:1 0:1 0:1 12:1 0:1 7:1 12:1 10:1 12:1'
FURY = dict(ms=76)
FURY['voices'] = {
    'lead': ('lead', bars(FINTRO, FA, FB, FBRK, tr(FA4, 1), FEND)),
    'call': ('bell', rest(2) + rest(8) + bars(dia2(FB, -2, DM)) + rest(2) + rest(4) + rest(2)),
    'arp':  ('arp', rest(2) + arp(cFA, 1, 1) + arp(cFB) + rest(2) + arp(cFL, 1, 1) + arp([C('A3', D7), C('D4', m7)], 1, 1)),
    'bass': ('bass_hv', bass(['D2'], '0:1 0:1 12:1 0:1 24:1 0:1 12:1 0:1 0:1 0:1 12:1 0:1 22:1 19:1 15:1 12:1')
             + bass(['D2'], '0:1 0:1 12:1 0:1 24:1 0:1 12:1 0:1 0:1 12:1 3:1 15:1 5:1 17:1 7:1 19:1')
             + bass(['D2','A#1','G1','A1'] * 2, slap) + bass(['A#1','C2','A1','D2'], chug)
             + bass(['A1'], '0:1 -:1 0:1 -:1 0:1 12:1 -:2 1:1 13:1 2:1 14:1 3:1 15:1 4:1 16:1')
             + bass(['C#2'], '0:1 12:1 0:1 12:1 0:1 12:1 0:1 12:1 1:1 13:1 1:1 13:1 1:1 13:1 1:1 13:1')
             + bass(['D#2','B1','G#1','A#1'], slap) + bass(['A1','D2'], slap)),
}
k1, k2, kf = 'kkhks.hkk.hks.hk', 'k.hks.hkkkhks.hk', 'k.s.s.s.sssskkkk'
FURY['drum'] = ('k.k.k.k.k.k.k.k.' + 'kkkkkkkkssssssss'
                + 'c' + k1[1:] + k2 + k1 + kf + k1 + k2 + k1 + kf
                + 'c' + k2[1:] + k2 + k2 + 'k.s.s.s.kpkpssss'
                + '................' + 'kkkkssssppppssss'
                + 'c' + k1[1:] + k2 + k1 + kf + k1 + 'c...............')
if __name__ == '__main__':
    L = len(FURY['drum']); bad = {k: len(v[1]) for k, v in FURY['voices'].items() if len(v[1]) != L}
    assert not bad, (L, bad)
    a = render(FURY, 1)
    sub = dict(FURY, voices={k: (i, s[32:32 + 128]) for k, (i, s) in FURY['voices'].items()}, drum=FURY['drum'][32:160])
    au = np.concatenate([a, render(sub, 1)]); au = au / np.max(np.abs(au)) * .9
    print(L, 'steps', round(L * .076, 1), 's/loop')
    with wave.open('coral_fury_preview.wav', 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((au * 32767).astype('<i2').tobytes())
