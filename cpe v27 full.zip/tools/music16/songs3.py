from sixteen import *
# ================= NORMAL: "Coral Hop" (C major, jazzy fun, 165 bpm) =================
A1 = ('E4:2 G4:2 C5:2 E5:1 -:1 D5:2 C5:2 G4:2 A4:2 '
      'C#5:2 E5:2 A4:2 C#5:1 -:1 B4:2 A4:2 G4:4 '
      'F4:2 A4:2 D5:2 F5:2 E5:2 D5:2 C5:2 A4:2 '
      'B4:2 D5:2 G5:4 F5:1 E5:1 D5:1 C5:1 B4:2 G4:2')
A2 = ('E4:2 G4:2 C5:2 E5:1 -:1 G5:2 E5:2 C5:2 E5:2 '
      'G5:2 E5:2 C#5:2 A4:2 E5:4 C#5:4 '
      'D5:2 F5:2 A5:2 F5:2 B4:2 D5:2 G5:2 F5:2 '
      'E5:4 C5:4 -:2 G4:1 A4:1 B4:2 C5:2')
B_lead = ('A3:2 -:2 C4:2 E4:2 A4:4 G4:2 E4:2 '
          'F3:2 -:2 A3:2 C4:2 F4:4 E4:2 C4:2 '
          'D4:2 F4:2 A4:2 D5:2 C5:2 A4:2 F4:2 D4:2 '
          'E4:2 G#4:2 B4:2 D5:2 E5:4 -:4')
B_call = ('-:8 E5:1 -:1 A5:1 -:1 C6:2 B5:2 '
          '-:8 F5:1 -:1 A5:1 -:1 C6:2 A5:2 '
          '-:8 F5:2 A5:2 D6:2 A5:2 '
          'G#5:1 B5:1 D6:1 E6:1 -:12')
BRK_lead = '-:16 -:8 G4:1 A4:1 B4:1 C5:1 D5:1 E5:1 F5:1 F#5:1'
END_lead = 'G5:4 E5:2 C5:2 G4:2 A4:2 B4:2 D5:2 C5:2 -:2 E4:1 F4:1 G4:2 -:8'
chA = [['C4','E4','G4','B4'], ['C#4','E4','G4','A4'], ['D4','F4','A4','C5'], ['D4','F4','G4','B4']]
chB = [['A3','C4','E4'], ['F3','A3','C4'], ['D4','F4','A4'], ['E4','G#4','B4','D5']]
chD = [[n for n in tr(' '.join(x + ':1' for x in c), 2).replace(':1', '').split()] for c in chA]
funk = '0:2 -:1 0:1 12:2 0:2 7:2 -:1 7:1 12:2 7:2'
drv = '0:2 0:2 7:2 0:2 12:2 0:2 7:2 0:2'
NORMAL = dict(ms=91)
NORMAL['voices'] = {
    'lead': ('lead', bars(A1, A2, B_lead, BRK_lead, tr(A1, 2), END_lead)),
    'call': ('bell', rest(8) + bars(B_call) + rest(2) + rest(4) + rest(2)),
    'arp':  ('arp', arp(chA) + arp(chA) + rest(4) + arp(chA[:2]) + arp(chD) + arp([['G3','B3','D4','F4'], ['C4','E4','G4','C5']])),
    'bass': ('bass', bass(['C2','A1','D2','G1'] * 2, funk) + bass(['A1','F1','D2','E2'], drv)
             + bass(['G1'], '0:3 0:1 -:2 0:2 -:2 7:2 10:2 12:2') + bass(['G1'], '0:2 0:2 0:2 0:2 2:2 4:2 5:2 6:2')
             + bass(['D2','B1','E2','A1'], funk) + bass(['G1','C2'], funk)),
}
g1, g2, fill = 'k.h.s.h.k.hks.h.', 'k.h.s.hkk.h.s.ho', 'k.h.s.h.k.ssss.s'
NORMAL['drum'] = ('c' + g1[1:] + g2 + g1 + fill + g1 + g2 + g1 + fill +
                  'c.h.s.h.k.h.s.h.' + 'k.h.s.h.k.h.s.h.' + 'k.h.s.h.k.h.s.h.' + 'k.s.s.s.kpkpssss' +
                  'k..k..s.k..k.sss' + 'k.k.p.k.ssssssss' +
                  'c' + g1[1:] + g2 + g1 + fill + 'k.h.s.h.k.h.s.h.' + 'c...............')

# ================= BOSS: "Abyss Rush" (E minor, 180 bpm) =================
R1 = ('E4:1 -:1 E4:1 -:1 G4:2 E4:2 B4:2 A4:2 G4:2 F#4:2 '
      'G4:1 -:1 G4:1 -:1 C5:2 G4:2 E5:2 D5:2 C5:2 B4:2 '
      'A4:1 -:1 A4:1 -:1 D5:2 A4:2 F#5:2 E5:2 D5:2 C5:2 '
      'B4:2 D#5:2 F#5:2 A5:2 B5:4 A5:1 G5:1 F#5:1 D#5:1')
S1 = ('B5:4 G5:2 E5:2 B5:4 C6:2 B5:2 '
      'A5:4 G5:2 E5:2 C6:4 B5:2 A5:2 '
      'C6:2 B5:2 A5:2 E5:2 A5:2 B5:2 C6:2 D6:2 '
      'D#6:4 F#6:4 B5:2 A5:2 G5:2 F#5:2')
BRK2 = '-:16 -:8 B4:1 C5:1 D5:1 E5:1 F#5:1 G5:1 A5:1 B5:1'
FIN2 = 'E5:4 -:2 B4:2 E5:4 G5:4 B5:2 -:2 E6:4 -:8'
cR = [['E3','G3','B3'], ['C3','E3','G3'], ['D3','F#3','A3'], ['B2','D#3','F#3','A3']]
cS = [['E4','G4','B4'], ['C4','E4','G4'], ['A3','C4','E4'], ['B3','D#4','F#4','A4']]
cF = [[n for n in tr(' '.join(x + ':1' for x in c), 1).replace(':1', '').split()] for c in cR]
chug = '0:1 0:1 12:1 0:1 0:1 0:1 12:1 0:1 0:1 0:1 12:1 0:1 0:1 0:1 12:1 0:1'
BOSS = dict(ms=83)
BOSS['voices'] = {
    'lead': ('lead', rest(2) + bars(R1, S1, BRK2, tr(R1, 1), FIN2)),
    'harm': ('bell', rest(2) + rest(4) + bars(tr(S1, -12)) + rest(2) + rest(4) + rest(2)),
    'arp':  ('arp', rest(2) + rest(4) + arp(cS, 1, 1) + rest(2) + arp(cF, 1, 1) + rest(2)),
    'bass': ('bass', bass(['E2','E2'], '0:1 -:1 0:1 -:1 0:1 0:1 3:2 5:2 -:1 5:1 6:2 7:2')
             + bass(['E2','C2','D2','B1'], chug) + bass(['E2','C2','A1','B1'], chug)
             + bass(['E2'], '0:2 0:2 3:2 0:2 6:2 5:2 3:2 0:2') + bass(['E2'], '0:1 -:1 0:1 -:1 1:2 2:2 3:2 4:2 5:2 7:2')
             + bass(['F2','C#2','D#2','C2'], chug) + bass(['E2','E2'], '0:2 -:2 0:2 -:2 7:4 12:4')),
}
d1, d2, df = 'k.h.s.hkk.h.s.h.', 'k.k.s.k.k.k.s.kk', 'k.s.s.s.sssskkkk'
BOSS['drum'] = ('k..k..k.k.k.ssss' + 'k.k.k.k.sksksssss'[:16] +
                'c' + d1[1:] + d1 + d1 + df + 'c' + d2[1:] + d2 + d2 + df +
                'k..k..s.k..k.sss' + 'kkkkssssppppssss' + 'c' + d2[1:] + d2 + d2 + df + 'k.h.s.h.k.h.s.h.' + 'c...............')
if __name__ == '__main__':
    gap = np.zeros(int(SR * .7)); parts = []; t = 0
    for nm, trk, n in [('NORMAL "Coral Hop"', NORMAL, 2), ('BOSS "Abyss Rush"', BOSS, 2)]:
        a = render(trk, n); print(nm, '%d:%04.1f' % (t // 60, t % 60), len(trk['drum']), 'steps,',
                                  round(len(trk['drum']) * trk['ms'] / 1000, 1), 's per loop')
        parts += [a, gap]; t += (len(a) + len(gap)) / SR
    au = np.concatenate(parts); au = au / np.max(np.abs(au)) * .9
    with wave.open('music_16bit_preview.wav', 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((au * 32767).astype('<i2').tobytes())
