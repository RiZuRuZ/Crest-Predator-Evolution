`timescale 1ns/1ps
// Checks game_fsm: TITLE -> PLAY -> PAUSE -> PLAY -> OVER -> TITLE, and PLAY -> WIN -> TITLE,
// win beats dead in the same clock, start does nothing in PLAY / PAUSE
module tb_game_fsm;
    reg clk = 0, rst = 1, start = 0, pause_sw = 0, dead = 0, win = 0;
    wire [2:0] state;
    wire in_title, playing;
    always #5 clk = ~clk;

    game_fsm dut (.clk(clk), .rst(rst), .start(start), .pause_sw(pause_sw),
                  .dead(dead), .win(win), .state(state), .in_title(in_title), .playing(playing));

    localparam [2:0] TITLE = 3'd0, PLAY = 3'd1, PAUSE = 3'd2, OVER = 3'd3, WIN = 3'd4;
    integer errors = 0;

    task press;  begin @(negedge clk) start = 1; @(negedge clk) start = 0; @(negedge clk); end endtask
    task settle; begin @(negedge clk); @(negedge clk); end endtask
    task check(input [2:0] exp, input [255:0] name);
        begin
            if (state !== exp || in_title !== (exp == TITLE) || playing !== (exp == PLAY)) begin
                $display("FAIL %0s: state=%0d in_title=%b playing=%b, expected %0d",
                         name, state, in_title, playing, exp);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        #25 rst = 0;
        settle;          check(TITLE, "start");
        press;           check(PLAY,  "start pressed");
        press;           check(PLAY,  "start ignored in PLAY");
        pause_sw = 1; settle; check(PAUSE, "pause on");
        press;           check(PAUSE, "start ignored in PAUSE");
        pause_sw = 0; settle; check(PLAY,  "pause off");
        dead = 1; settle; check(OVER, "dead");
        dead = 0;
        press;           check(TITLE, "back to title");

        press;           check(PLAY,  "second game");
        dead = 1; win = 1; settle; check(WIN, "win beats dead");
        dead = 0; win = 0;
        pause_sw = 1; settle; check(WIN, "pause ignored in WIN");
        pause_sw = 0;
        press;           check(TITLE, "win -> title");

        if (errors == 0) $display("PASS tb_game_fsm");
        $finish;
    end
endmodule
