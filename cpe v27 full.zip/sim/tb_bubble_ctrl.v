`timescale 1ns/1ps
// Checks bubble_ctrl (world coordinates): spawn timing and position (inside the camera view),
// rising, full slots skip a spawn, eating removes the bubble, reaching the top removes it,
// random x clamp, and removal when the camera is far away
module tb_bubble_ctrl;
    reg clk = 0, rst = 1, tick = 0;
    reg [15:0] rnd = 0;
    reg [10:0] cam = 0;
    reg [10:0] px = 600;
    reg [9:0]  py = 0;
    wire eat;
    wire [1:0] act;
    wire [21:0] xv;
    wire [19:0] yv;
    always #5 clk = ~clk;

    bubble_ctrl #(.N(2), .SPAWN_TICKS(3), .SIZE(16), .SPEED(1), .WORLD_H(40)) dut (
        .clk(clk), .rst(rst), .tick_60hz(tick), .rand(rnd), .cam_x(cam),
        .player_x(px), .player_y(py), .player_w(8'd16), .player_h(8'd16),
        .eat(eat), .active_vec(act), .x_vec(xv), .y_vec(yv));

    integer errors = 0, eats = 0, i, gone;
    always @(posedge clk) if (eat) eats = eats + 1;

    task do_tick; begin @(negedge clk) tick = 1; @(negedge clk) tick = 0; @(negedge clk); end endtask

    initial begin
        #25 rst = 0;
        // random x clamp: 511 + 127 = 638 > 624 -> 14 (camera at 0)
        rnd = 16'hFFFF; #1;
        if (dut.spawn_x !== 14) begin $display("FAIL x clamp: %0d", dut.spawn_x); errors = errors + 1; end
        // spawn x is relative to the camera and wraps: camera 1910 + 14 -> 4
        cam = 1910; #1;
        if (dut.spawn_x !== 4) begin $display("FAIL x wrap: %0d", dut.spawn_x); errors = errors + 1; end
        cam = 0; rnd = 0;

        do_tick; do_tick;
        if (act !== 2'b00) begin $display("FAIL spawned too early"); errors = errors + 1; end
        do_tick;
        if (act !== 2'b01 || xv[10:0] !== 0 || yv[9:0] !== 24) begin
            $display("FAIL first spawn: act=%b x=%0d y=%0d", act, xv[10:0], yv[9:0]); errors = errors + 1;
        end
        rnd = 16'd100;
        do_tick;
        if (yv[9:0] !== 23) begin $display("FAIL rise: y=%0d", yv[9:0]); errors = errors + 1; end
        do_tick; do_tick;
        if (act !== 2'b11 || xv[21:11] !== 100) begin
            $display("FAIL second spawn: act=%b x=%0d", act, xv[21:11]); errors = errors + 1;
        end
        do_tick; do_tick; do_tick;                   // both slots full: this spawn is skipped
        if (act !== 2'b11) begin $display("FAIL full slots"); errors = errors + 1; end

        // touch the second bubble
        px = 100; py = yv[19:10];
        @(negedge clk); @(negedge clk); @(negedge clk);
        if (eats != 1 || act[1] !== 0) begin
            $display("FAIL eat: eats=%0d act=%b", eats, act); errors = errors + 1;
        end
        px = 600; py = 0;

        // first bubble must leave at the top
        gone = 0;
        for (i = 0; i < 30 && !gone; i = i + 1) begin
            do_tick;
            if (act[0] === 0) gone = 1;
        end
        if (!gone) begin $display("FAIL bubble never left the top"); errors = errors + 1; end
        if (eats != 1) begin $display("FAIL extra eats: %0d", eats); errors = errors + 1; end

        // camera moves far away: an active bubble is removed on the next tick
        gone = 0;
        // wait for a bubble, and for a tick that does not also spawn a new one (timer != 2)
        for (i = 0; i < 12 && !((act != 2'b00) && (dut.t != 2)); i = i + 1) do_tick;
        if (!(act[0] || act[1])) begin $display("FAIL no bubble for the far test"); errors = errors + 1; end
        cam = 1000;
        do_tick;
        if (act !== 2'b00) begin $display("FAIL far bubble not removed: act=%b", act); errors = errors + 1; end

        if (errors == 0) $display("PASS tb_bubble_ctrl");
        $finish;
    end
endmodule
