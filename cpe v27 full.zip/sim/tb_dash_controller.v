`timescale 1ns/1ps
// Checks dash_controller: no dash without a direction, dash speed and length,
// cooldown, no dash without oxygen, diagonal direction
module tb_dash_controller;
    reg clk = 0, rst = 1, tick = 0, req = 0, can_pay = 1;
    reg signed [6:0] mdx = 0, mdy = 0;
    wire start, dashing, cooling;
    wire signed [6:0] ddx, ddy;
    always #5 clk = ~clk;

    dash_controller #(.DASH_TICKS(3), .DASH_SPEED(8), .COOLDOWN_TICKS(5)) dut (
        .clk(clk), .rst(rst), .tick_60hz(tick), .dash_req(req),
        .move_dx(mdx), .move_dy(mdy), .can_pay(can_pay), .dash_len(8'd3), .chain_en(1'b0),
        .dash_start(start), .dashing(dashing), .cooling(cooling),
        .dash_dx(ddx), .dash_dy(ddy));

    integer errors = 0, starts = 0, i;
    always @(posedge clk) if (start) starts = starts + 1;

    task do_tick;
        begin @(negedge clk) tick = 1; @(negedge clk) tick = 0; end
    endtask
    task do_req;
        begin @(negedge clk) req = 1; @(negedge clk) req = 0; @(negedge clk); end
    endtask
    task check(input signed [6:0] ex, input signed [6:0] ey, input [255:0] name);
        begin
            if (ddx !== ex || ddy !== ey) begin
                $display("FAIL %0s: dash=(%0d,%0d) expected (%0d,%0d)", name, ddx, ddy, ex, ey);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        #25 rst = 0;
        do_req; check(0, 0, "no direction");
        if (starts != 0) begin $display("FAIL dashed without direction"); errors = errors + 1; end

        mdx = 4;
        do_req; check(8, 0, "dash right");
        if (starts != 1) begin $display("FAIL dash_start count %0d", starts); errors = errors + 1; end
        mdx = 0;                                   // direction is latched
        do_tick; do_tick; check(8, 0, "still dashing");
        do_tick;          check(0, 0, "dash over after 3 ticks");

        mdx = -4;
        do_req; check(0, 0, "during cooldown");
        if (starts != 1) begin $display("FAIL dashed during cooldown"); errors = errors + 1; end
        do_tick; do_tick;
        if (cooling !== 0) begin $display("FAIL cooldown too long"); errors = errors + 1; end

        can_pay = 0;
        do_req; check(0, 0, "no oxygen");
        can_pay = 1;

        mdx = -4; mdy = -4;
        do_req; check(-8, -8, "dash left-up");
        if (starts != 2) begin $display("FAIL dash_start count %0d, expected 2", starts); errors = errors + 1; end

        if (errors == 0) $display("PASS tb_dash_controller");
        $finish;
    end
endmodule
