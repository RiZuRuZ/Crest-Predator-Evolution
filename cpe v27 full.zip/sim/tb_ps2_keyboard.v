`timescale 1ns/1ps
// Checks ps2_receiver + ps2_keys together: decodes frames, drops a bad-parity frame,
// resyncs after a cut-off frame, and tracks W / Space press and release.
// Extended codes (E0 xx) must not change the keys.
// This test takes ~120 us of simulated time: type "run all" if PASS is not shown yet.
module tb_ps2_keyboard;
    reg clk = 0, rst = 1;
    reg ps2_clk = 1, ps2_data = 1;
    wire [7:0] code;
    wire valid;
    wire kw, ka, ks, kd, ksp;
    always #5 clk = ~clk;

    ps2_receiver #(.FILTER(4), .TIMEOUT(100)) u_rx (
        .clk(clk), .rst(rst), .ps2_clk(ps2_clk), .ps2_data(ps2_data),
        .data(code), .valid(valid));
    ps2_keys u_keys (
        .clk(clk), .rst(rst), .code(code), .valid(valid),
        .key_w(kw), .key_a(ka), .key_s(ks), .key_d(kd), .key_space(ksp));

    integer errors = 0, nbytes = 0;
    reg [7:0] last = 0;
    always @(posedge clk) if (valid) begin nbytes = nbytes + 1; last = code; end

    // one frame: data changes while the clock is high, the host samples on the falling edge
    task send_frame(input [7:0] b, input bad_parity);
        reg [10:0] f;
        integer j;
        begin
            f = {1'b1, (~(^b)) ^ bad_parity, b, 1'b0};
            for (j = 0; j < 11; j = j + 1) begin
                ps2_data = f[j];
                #200 ps2_clk = 0;
                #200 ps2_clk = 1;
            end
            ps2_data = 1;
            #600;
        end
    endtask

    task expect_byte(input [7:0] b, input integer count, input [255:0] name);
        begin
            if (nbytes != count || last !== b) begin
                $display("FAIL %0s: bytes=%0d last=%h, expected bytes=%0d last=%h",
                         name, nbytes, last, count, b);
                errors = errors + 1;
            end
        end
    endtask

    task expect_keys(input w, input sp, input [255:0] name);
        begin
            if (kw !== w || ksp !== sp || ka !== 0 || ks !== 0 || kd !== 0) begin
                $display("FAIL %0s: w=%b space=%b a=%b s=%b d=%b", name, kw, ksp, ka, ks, kd);
                errors = errors + 1;
            end
        end
    endtask

    integer j;
    initial begin
        #100 rst = 0;
        #200;
        send_frame(8'h1D, 0); expect_byte(8'h1D, 1, "W make");  expect_keys(1, 0, "W pressed");
        send_frame(8'h29, 0); expect_byte(8'h29, 2, "Space");   expect_keys(1, 1, "W + Space");
        send_frame(8'h55, 1);
        if (nbytes != 2) begin $display("FAIL bad parity frame was accepted"); errors = errors + 1; end
        send_frame(8'hF0, 0); send_frame(8'h1D, 0);
        expect_byte(8'h1D, 4, "W break"); expect_keys(0, 1, "W released");

        // cut-off frame: 4 bits only, then a long gap -> receiver must resync
        for (j = 0; j < 4; j = j + 1) begin
            ps2_data = j[0];
            #200 ps2_clk = 0;
            #200 ps2_clk = 1;
        end
        ps2_data = 1;
        #3000;
        send_frame(8'hE0, 0); send_frame(8'h1D, 0);   // extended code: must be ignored
        expect_byte(8'h1D, 6, "after resync"); expect_keys(0, 1, "extended ignored");
        send_frame(8'hF0, 0); send_frame(8'h29, 0);
        expect_keys(0, 0, "Space released");

        if (errors == 0) $display("PASS tb_ps2_keyboard");
        $finish;
    end
endmodule
