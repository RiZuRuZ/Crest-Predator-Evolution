`timescale 1ns / 1ps
//==============================================================================
// tb_aabb_collision - self-checking testbench for aabb_collision
//
// 1. Directed cases (overlap, edge touch, x wrap-around, zero size)
// 2. Random cases compared against a pixel-by-pixel reference model that does
//    not use the same arithmetic as the DUT.
//==============================================================================
module tb_aabb_collision;

    reg  [9:0] ax, ay, bx, by;
    reg  [7:0] aw, ah, bw, bh;
    wire       hit;

    aabb_collision dut (
        .ax(ax), .ay(ay), .aw(aw), .ah(ah),
        .bx(bx), .by(by), .bw(bw), .bh(bh),
        .hit(hit)
    );

    integer errors = 0;
    integer n;

    // Reference: walk every pixel column/row of A and test membership in B.
    function ref_hit;
        input [9:0] fax, fay, fbx, fby;
        input [7:0] faw, fah, fbw, fbh;
        integer i, j, xa, ya, dxx, dyy;
        reg xo, yo;
        begin
            xo = 1'b0;
            yo = 1'b0;
            for (i = 0; i < faw; i = i + 1) begin
                xa  = (fax + i) % 640;
                dxx = (xa - fbx + 640) % 640;
                if (dxx < fbw) xo = 1'b1;
            end
            for (j = 0; j < fah; j = j + 1) begin
                ya  = fay + j;
                dyy = ya - fby;
                if (dyy >= 0 && dyy < fbh) yo = 1'b1;
            end
            ref_hit = xo & yo;
        end
    endfunction

    task check;
        input [255:0] name;
        input         expected;
        begin
            #1;
            if (hit !== expected) begin
                $display("FAIL [%0s]: hit=%b expected=%b  A(%0d,%0d,%0dx%0d) B(%0d,%0d,%0dx%0d)",
                         name, hit, expected, ax, ay, aw, ah, bx, by, bw, bh);
                errors = errors + 1;
            end
        end
    endtask

    task setbox;
        input [9:0] tax, tay; input [7:0] taw, tah;
        input [9:0] tbx, tby; input [7:0] tbw, tbh;
        begin
            ax = tax; ay = tay; aw = taw; ah = tah;
            bx = tbx; by = tby; bw = tbw; bh = tbh;
        end
    endtask

    initial begin
        // ---- directed ------------------------------------------------------
        setbox(100,100,16,16, 108,108,16,16); check("overlap",        1'b1);
        setbox(100,100,16,16, 116,100,16,16); check("touch right",    1'b0);
        setbox(100,100,16,16, 100,116,16,16); check("touch bottom",   1'b0);
        setbox(100,100,16,16, 115,115,16,16); check("1px corner",     1'b1);
        setbox(100,100,16,16, 300,300,16,16); check("far apart",      1'b0);
        setbox(100,100,32,32, 110,110, 8, 8); check("B inside A",     1'b1);
        setbox(110,110, 8, 8, 100,100,32,32); check("A inside B",     1'b1);
        setbox(100,100,16,16, 100,200,16,16); check("same x diff y",  1'b0);

        // x wrap-around (rule 4.4)
        setbox(632,100,16,16,   4,100,16,16); check("wrap overlap",   1'b1);
        setbox(  4,100,16,16, 632,100,16,16); check("wrap overlap sw",1'b1);
        setbox(632,100,16,16,   8,100,16,16); check("wrap just miss", 1'b0);
        setbox(624,100,16,16,   0,100,16,16); check("wrap touch",     1'b0);
        setbox(639,100,16,16,   0,100,16,16); check("wrap 1px",       1'b1);

        // zero size never collides
        setbox(100,100, 0,16, 100,100,16,16); check("zero width",     1'b0);
        setbox(100,100,16, 0, 100,100,16,16); check("zero height",    1'b0);

        // y is not wrapped: bottom of screen must not meet the top
        setbox(100,470,16,10, 100,  0,16,10); check("no y wrap",      1'b0);

        // ---- random vs reference -----------------------------------------
        for (n = 0; n < 20000; n = n + 1) begin
            // NOTE: $random is signed, so "$random % N" can be negative.
            // {$random} (concatenation) is unsigned, which keeps every
            // coordinate inside the range the DUT requires.
            ax = {$random} % 640;  bx = {$random} % 640;
            // bias half of the cases toward the wrap seam
            if (n[0]) begin ax = 620 + ({$random} % 20); bx = {$random} % 30; end
            ay = {$random} % 400;  by = {$random} % 400;
            // bias some cases to be vertically close, but never below 0
            if (n[1]) by = ay + ({$random} % 40) - ((ay >= 20) ? 20 : ay);
            aw = 1 + ({$random} % 64);  bw = 1 + ({$random} % 64);
            ah = 1 + ({$random} % 64);  bh = 1 + ({$random} % 64);
            check("random", ref_hit(ax, ay, bx, by, aw, ah, bw, bh));
        end

        if (errors == 0) $display("PASS: aabb_collision, all checks OK");
        else             $display("DONE with %0d error(s)", errors);
        $finish;
    end

endmodule
