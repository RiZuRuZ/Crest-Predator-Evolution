// tb_popup_text: a "-1 heart" popup appears above the anchor in red with a dark shadow,
// a second event stacks above it, and both are gone after LIFE ticks.
// Prints PASS or FAIL lines, then "DONE". Run with: run all
`timescale 1ns / 1ps
module tb_popup_text;
    reg clk = 0;
    always #5 clk = ~clk;

    reg       rst = 1;
    reg       tick = 0;
    reg       ev_heart = 0, ev_o2 = 0;
    reg [9:0] px = 0, py = 0;
    wire        on;
    wire [11:0] rgb;

    popup_text #(.LIFE(48)) dut (
        .clk(clk), .rst(rst), .tick_60hz(tick), .show(1'b1),
        .anchor_x(10'd320), .anchor_y(10'd200),
        .ev_score(1'b0), .score_val(8'd0), .ev_gold(1'b0), .ev_o2(ev_o2), .ev_mine(1'b0),
        .ev_stun(1'b0), .ev_heart(ev_heart), .ev_block(1'b0), .ev_roar(1'b0),
        .ev_roar_rdy(1'b0), .ev_shield_rdy(1'b0), .ev_fever(1'b0), .ev_evolve(1'b0),
        .ev_stealth(1'b0), .ev_pu_heart(1'b0), .ev_pu_shield(1'b0), .ev_pu_speed(1'b0),
        .pixel_x(px), .pixel_y(py), .pixel_on(on), .rgb_out(rgb)
    );

    integer errors = 0;
    task check(input cond, input [255:0] msg);
        begin
            if (cond) $display("PASS: %0s", msg);
            else begin $display("FAIL: %0s", msg); errors = errors + 1; end
        end
    endtask

    // scan a screen area; count text pixels of one color and shadow pixels
    integer x, y, n_col, n_shd, n_any;
    task scan(input [9:0] x0, input [9:0] y0, input [9:0] w, input [9:0] h, input [11:0] col);
        begin
            n_col = 0; n_shd = 0; n_any = 0;
            for (y = y0; y < y0 + h; y = y + 1)
                for (x = x0; x < x0 + w; x = x + 1) begin
                    px = x; py = y;
                    repeat (3) @(posedge clk);       // 2-clock latency
                    if (on) begin
                        n_any = n_any + 1;
                        if (rgb == col)     n_col = n_col + 1;
                        if (rgb == 12'h112) n_shd = n_shd + 1;
                    end
                end
        end
    endtask

    integer k;
    initial begin
        repeat (4) @(posedge clk);
        rst = 0;
        @(posedge clk);

        // nothing at first
        scan(10'd290, 10'd195, 10'd60, 10'd25, 12'hF44);
        check(n_any == 0, "no popup before any event");

        // "-1 heart": 3 characters, 48 px wide, centred on x 320 -> x 296..343, y 200..215
        @(posedge clk) ev_heart <= 1'b1;
        @(posedge clk) ev_heart <= 1'b0;
        repeat (3) @(posedge clk);
        scan(10'd290, 10'd195, 10'd60, 10'd25, 12'hF44);
        check(n_col > 20, "red -1 heart text above the dragon");
        check(n_shd > 10, "dark drop shadow");

        // a second event right away stacks 18 px higher (y 182)
        @(posedge clk) ev_o2 <= 1'b1;
        @(posedge clk) ev_o2 <= 1'b0;
        repeat (3) @(posedge clk);
        scan(10'd290, 10'd178, 10'd60, 10'd18, 12'h5EF);
        check(n_col > 20, "+O2 popup stacked above the first one, in cyan");

        // after LIFE ticks both are gone
        for (k = 0; k < 50; k = k + 1) begin
            @(posedge clk) tick <= 1'b1;
            @(posedge clk) tick <= 1'b0;
        end
        scan(10'd290, 10'd150, 10'd60, 10'd70, 12'hF44);
        check(n_any == 0, "popups gone after LIFE ticks");

        if (errors == 0) $display("ALL PASS");
        $display("DONE");
        $finish;
    end
endmodule
