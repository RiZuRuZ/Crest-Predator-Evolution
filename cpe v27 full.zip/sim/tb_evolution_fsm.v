`timescale 1ns/1ps
// Checks evolution_fsm: thresholds 25/75/200, one pulse per form change, no regression, reset to FORM1
module tb_evolution_fsm;
    reg clk = 0, rst = 1;
    reg [15:0] score = 0;
    wire [2:0] form;
    wire pulse;
    always #5 clk = ~clk;

    evolution_fsm dut (.clk(clk), .rst(rst), .score(score), .form_state(form), .evolve_pulse(pulse));

    integer errors = 0, pulses = 0;
    always @(posedge clk) if (pulse) pulses = pulses + 1;

    task expect_form(input [2:0] exp, input [255:0] name);
        begin
            repeat (3) @(posedge clk);
            #1;
            if (form !== exp) begin
                $display("FAIL %0s: form = %0d, expected %0d", name, form, exp);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        #25 rst = 0;
        expect_form(1, "start");
        score = 24;  expect_form(1, "EP 24");
        score = 25;  expect_form(2, "EP 25");
        score = 74;  expect_form(2, "EP 74");
        score = 75;  expect_form(3, "EP 75");
        score = 199; expect_form(3, "EP 199");
        score = 200; expect_form(4, "EP 200");
        if (pulses != 3) begin $display("FAIL pulses = %0d, expected 3", pulses); errors = errors + 1; end
        score = 0;   expect_form(4, "no regression when score drops");
        score = 500; expect_form(4, "EP 500 stays FORM4");
        if (pulses != 3) begin $display("FAIL extra pulses at FORM4 (%0d)", pulses); errors = errors + 1; end

        rst = 1; score = 0; repeat (2) @(posedge clk); rst = 0;
        expect_form(1, "reset");

        // jump straight past all thresholds: one form per clock, ends at FORM4
        pulses = 0;
        score = 300; expect_form(4, "jump to 300");
        // the last evolve_pulse is registered together with the last form change,
        // so wait 2 more clocks before counting it
        repeat (2) @(posedge clk);
        #1;
        if (pulses != 3) begin $display("FAIL jump pulses = %0d, expected 3", pulses); errors = errors + 1; end

        if (errors == 0) $display("PASS tb_evolution_fsm");
        $finish;
    end
endmodule
