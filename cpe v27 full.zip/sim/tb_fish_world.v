`timescale 1ns/1ps
// Checks the fish modules in world coordinates (camera update):
//   fish_spawner : fish appears just outside the camera view (both sides, with wrap),
//                  y inside the view
//   fish_slot    : swims across the map seam, is removed when far from the camera,
//                  eat / hurt across the seam using the head + body hitbox,
//                  the hitbox is mirrored when the fish swims left
// Sprite sizes (fish-sprites.md): small 31x27, hitbox 7,3,23,21; medium 52x42, hitbox 12,4,40,34.
// (fish_renderer reads ROM files and is checked on the board instead.)
module tb_fish_world;
    reg clk = 0, rst = 1;
    always #5 clk = ~clk;
    integer errors = 0;

    // ---------------- fish_spawner ----------------
    reg         sp_tick = 0;
    reg  [15:0] sp_rand = 0;
    reg  [10:0] sp_cam_x = 100;
    reg  [9:0]  sp_cam_y = 50;
    wire        sp_valid, sp_dir;
    wire [1:0]  sp_type;
    wire [10:0] sp_x;
    wire [9:0]  sp_y;
    fish_spawner u_sp (.clk(clk), .rst(rst), .spawn_tick(sp_tick), .rand(sp_rand),
                       .cam_x(sp_cam_x), .cam_y(sp_cam_y),
                       .spawn_valid(sp_valid), .fish_type(sp_type),
                       .spawn_x(sp_x), .spawn_y(sp_y), .spawn_dir(sp_dir));

    task spawn(input [15:0] r, input [10:0] cx, input [10:0] ex, input [255:0] name);
        begin
            @(negedge clk) begin sp_rand = r; sp_cam_x = cx; sp_tick = 1; end
            @(negedge clk) sp_tick = 0;
            if (sp_x !== ex) begin
                $display("FAIL spawner %0s: x=%0d expected %0d", name, sp_x, ex); errors = errors + 1;
            end
            if (sp_y < sp_cam_y || sp_y > sp_cam_y + 480 - 27) begin
                $display("FAIL spawner %0s: y=%0d outside the view", name, sp_y); errors = errors + 1;
            end
        end
    endtask

    // ---------------- fish_slot ----------------
    reg         load = 0, tick = 0, ldir = 0;
    reg  [1:0]  ltype = 0;
    reg  [10:0] lx = 0, plx = 1000, cam = 0;
    reg  [9:0]  ly = 100, ply = 400;
    reg  [2:0]  form = 1;
    wire        active, fdir, eat_req, eat, hurt;
    wire [1:0]  ftype;
    wire [10:0] fx;
    wire [9:0]  fy;
    fish_slot u_slot (.clk(clk), .rst(rst), .tick_60hz(tick),
                      .load(load), .load_type(ltype), .load_x(lx), .load_y(ly), .load_dir(ldir), .load_school(1'b0),
                      .player_x(plx), .player_y(ply), .player_w(8'd16), .player_h(8'd16), .form(form), .cam_x(cam),
                      .clear(1'b0), .roar(1'b0), .roar_cx(11'd0), .roar_cy(10'd0),
                      .active(active), .fish_type_o(ftype), .fish_x(fx), .fish_y(fy), .fish_dir(fdir),
                      .eat_req(eat_req), .eat_allow(1'b1), .eat(eat), .hurt(hurt));

    integer eats = 0, hurts = 0;
    always @(posedge clk) begin
        if (eat)  eats  = eats + 1;
        if (hurt) hurts = hurts + 1;
    end
    task load_fish(input [1:0] t, input [10:0] x, input [9:0] y, input d);
        begin
            @(negedge clk) begin load = 1; ltype = t; lx = x; ly = y; ldir = d; end
            @(negedge clk) load = 0;
            @(negedge clk);
        end
    endtask
    task do_tick; begin @(negedge clk) tick = 1; @(negedge clk) tick = 0; @(negedge clk); end endtask


    initial begin
        #25 rst = 0;

        // spawner: rand[1:0] = 00 small (31 px wide), rand[2] = direction
        spawn(16'h0000, 100, 69,   "dir 0 enters left of the view");     // 100 - 31
        spawn(16'h0004, 100, 740,  "dir 1 enters right of the view");    // 100 + 640
        spawn(16'h0000, 10,  1899, "dir 0 wraps around the seam");       // 10 - 31 + 1920
        spawn(16'h0004, 1500, 220, "dir 1 wraps around the seam");       // 1500 + 640 - 1920

        // slot: swims right across the seam
        cam = 1600;
        load_fish(2'd0, 11'd1916, 10'd100, 1'b0);
        do_tick;
        if (!active || fx !== 1918) begin $display("FAIL move 1: active=%b x=%0d", active, fx); errors = errors + 1; end
        do_tick;
        if (!active || fx !== 0)    begin $display("FAIL wrap: active=%b x=%0d", active, fx); errors = errors + 1; end
        // swims left across the seam
        rst = 1; @(negedge clk); rst = 0;
        load_fish(2'd0, 11'd1, 10'd100, 1'b1);
        do_tick;
        if (!active || fx !== 1919) begin $display("FAIL left wrap: active=%b x=%0d", active, fx); errors = errors + 1; end
        // camera far away -> removed on the next tick
        cam = 900;
        do_tick;
        if (active) begin $display("FAIL far fish not removed"); errors = errors + 1; end

        // hitbox mirror: player box 1910..1925 (wraps to 0..5), small fish sprite at x = 2.
        // Facing right its box is x 9..31: no contact. Facing left (dir 1) the box is
        // mirrored to x 3..25: contact, so the fish is eaten.
        cam = 1600; plx = 1910; ply = 100;
        load_fish(2'd0, 11'd2, 10'd100, 1'b0);
        @(negedge clk); @(negedge clk);
        if (eats != 0 || !active) begin $display("FAIL tail is not hitbox: eats=%0d active=%b", eats, active); errors = errors + 1; end
        rst = 1; @(negedge clk); rst = 0;
        load_fish(2'd0, 11'd2, 10'd100, 1'b1);
        @(negedge clk); @(negedge clk);
        if (eats != 1 || active) begin $display("FAIL mirrored hitbox: eats=%0d active=%b", eats, active); errors = errors + 1; end

        // eat across the seam: player box 1919..1934 (wraps to 0..14), small fish box 9..31
        plx = 1919;
        load_fish(2'd0, 11'd2, 10'd100, 1'b0);
        @(negedge clk); @(negedge clk);
        if (eats != 2 || active) begin $display("FAIL eat across seam: eats=%0d active=%b", eats, active); errors = errors + 1; end
        // hurt: form 1 touches a medium fish (box x 14..53, y 104..137)
        load_fish(2'd1, 11'd2, 10'd100, 1'b0);
        @(negedge clk); @(negedge clk);
        if (hurts != 1 || !active) begin $display("FAIL hurt: hurts=%0d active=%b", hurts, active); errors = errors + 1; end

        if (errors == 0) $display("PASS tb_fish_world");
        $finish;
    end
endmodule
