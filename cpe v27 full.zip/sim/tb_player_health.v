`timescale 1ns/1ps
// Checks player_health: -1 heart per hit, invuln blocks hits, heart_up max 3,
// shield absorbs a hit, death at 0 hearts stays until reset
module tb_player_health;
    reg clk = 0, rst = 1;
    reg hurt = 0, invuln = 0, heart_up = 0, shield = 0;
    wire [2:0] hearts;
    wire dead, hit_taken, shield_used;
    always #5 clk = ~clk;

    player_health dut (.clk(clk), .rst(rst), .hurt(hurt), .invuln(invuln),
                       .heart_up(heart_up), .shield(shield), .diff(2'd1), .refill(1'b0), .big(1'b0),
                       .hearts(hearts),
                       .dead(dead), .hit_taken(hit_taken), .shield_used(shield_used));

    integer errors = 0, hits = 0, shields = 0;
    always @(posedge clk) begin
        if (hit_taken)   hits    = hits + 1;
        if (shield_used) shields = shields + 1;
    end

    task pulse_hurt;
        begin @(negedge clk) hurt = 1; @(negedge clk) hurt = 0; @(negedge clk); end
    endtask
    task pulse_heart;
        begin @(negedge clk) heart_up = 1; @(negedge clk) heart_up = 0; @(negedge clk); end
    endtask
    task check(input [1:0] exp_h, input exp_dead, input [255:0] name);
        begin
            if (hearts !== exp_h || dead !== exp_dead) begin
                $display("FAIL %0s: hearts=%0d dead=%b, expected hearts=%0d dead=%b",
                         name, hearts, dead, exp_h, exp_dead);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        #25 rst = 0;
        @(negedge clk); check(3, 0, "start");
        pulse_hurt;  check(2, 0, "first hit");
        invuln = 1;
        pulse_hurt;  check(2, 0, "hit while invuln");
        invuln = 0;
        pulse_heart; check(3, 0, "heart up");
        pulse_heart; check(3, 0, "heart up at max");
        shield = 1;
        pulse_hurt;  check(3, 0, "shield hit");
        shield = 0;
        if (shields != 1) begin $display("FAIL shield_used count = %0d", shields); errors = errors + 1; end
        pulse_hurt;  check(2, 0, "hit 3->2");
        pulse_hurt;  check(1, 0, "hit 2->1");
        pulse_hurt;  check(0, 1, "last heart");
        pulse_heart; check(0, 1, "no heal when dead");
        pulse_hurt;  check(0, 1, "no hit when dead");
        if (hits != 5) begin $display("FAIL hit_taken count = %0d, expected 5", hits); errors = errors + 1; end

        @(negedge clk) rst = 1; @(negedge clk) rst = 0; @(negedge clk);
        check(3, 0, "reset");

        if (errors == 0) $display("PASS tb_player_health");
        $finish;
    end
endmodule
