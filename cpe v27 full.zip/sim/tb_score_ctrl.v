`timescale 1ns / 1ps
//==============================================================================
// tb_score_ctrl - self-checking testbench for score_ctrl
//
// Checks: reset, EP per fish type (1/3/5), golden = +10, no change without eat,
// saturation at 500, win flag, eats ignored after win, score never above 500,
// reset clears score and win.
//==============================================================================
module tb_score_ctrl;

    reg         clk = 1'b0;
    reg         rst = 1'b1;
    reg         eat = 1'b0;
    reg  [1:0]  fish_type = 2'd0;
    wire [15:0] score;
    wire        win;

    score_ctrl dut (
        .clk(clk), .rst(rst), .eat(eat), .fish_type(fish_type), .bonus(1'b0), .double(1'b0), .cheat(1'b0), .jump(1'b0),
        .score(score), .win(win)
    );

    always #5 clk = ~clk;

    integer errors = 0;
    integer k;

    // one-cycle eat pulse; after it returns, the score has been updated
    task do_eat;
        input [1:0] t;
        begin
            @(negedge clk);
            eat = 1'b1;
            fish_type = t;
            @(negedge clk);
            eat = 1'b0;
        end
    endtask

    task expect_score;
        input [15:0] exp_score;
        input        exp_win;
        begin
            if (score !== exp_score || win !== exp_win) begin
                $display("FAIL: score=%0d win=%b, expected score=%0d win=%b",
                         score, win, exp_score, exp_win);
                errors = errors + 1;
            end
        end
    endtask

    // the score must never exceed 500 at any time
    always @(posedge clk)
        if (score > 16'd500) begin
            $display("FAIL: score above 500 (%0d)", score);
            errors = errors + 1;
        end

    initial begin
        repeat (3) @(negedge clk);
        rst = 1'b0;
        @(negedge clk);
        expect_score(0, 1'b0);

        do_eat(2'd0); expect_score(1, 1'b0);     // small  +1
        do_eat(2'd1); expect_score(4, 1'b0);     // medium +3
        do_eat(2'd2); expect_score(9, 1'b0);     // large  +5
        do_eat(2'd3); expect_score(19, 1'b0);    // golden +10

        // no eat -> no change
        repeat (10) @(negedge clk);
        expect_score(19, 1'b0);

        // 96 large fish: 19 + 96*5 = 499
        for (k = 0; k < 96; k = k + 1) do_eat(2'd2);
        expect_score(499, 1'b0);

        // one more large fish would be 504 -> saturate at 500 and win
        do_eat(2'd2);
        expect_score(500, 1'b1);

        // eats after the win are ignored
        do_eat(2'd2); expect_score(500, 1'b1);
        do_eat(2'd0); expect_score(500, 1'b1);

        // reset clears everything
        @(negedge clk); rst = 1'b1;
        @(negedge clk); @(negedge clk);
        rst = 1'b0;
        expect_score(0, 1'b0);

        // exact landing on 500: 499 via small fish then +1
        for (k = 0; k < 499; k = k + 1) do_eat(2'd0);
        expect_score(499, 1'b0);
        do_eat(2'd0);
        expect_score(500, 1'b1);

        if (errors == 0) $display("PASS: score_ctrl, all checks OK");
        else             $display("DONE with %0d error(s)", errors);
        $finish;
    end

endmodule
