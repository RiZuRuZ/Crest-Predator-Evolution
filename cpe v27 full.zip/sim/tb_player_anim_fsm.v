`timescale 1ns/1ps
// Testbench for player_anim_fsm (short loop timings so it finishes quickly).
// Checks: idle loop 0,1; swim loop 2..5; eating opens the mouth (bite frames 6..9,
// still flapping) for BITE_TICKS, then back to 2..5, with the lunge 1,2,3,...,1,0 and
// a flash; getting hit gives a flash without a lunge or bite.
// Prints "PASS" at the end when every check holds. Use "run all".
module tb_player_anim_fsm;
    reg  clk = 0, rst = 1, tick = 0, moving = 0, hurt = 0, eat = 0, near = 0;
    wire [3:0] frame;
    wire [1:0] lunge;
    wire       flash;
    wire [1:0] state;
    integer errors = 0;

    player_anim_fsm #(.SWIM_TICKS(2), .IDLE_TICKS(3), .EAT_TICKS(12), .FLASH_TICKS(4),
                     .BITE_TICKS(6)) dut (
        .clk(clk), .rst(rst), .tick_60hz(tick), .moving(moving),
        .hurt(hurt), .eat(eat), .near(near), .frame(frame), .lunge(lunge), .flash(flash), .state(state));

    always #5 clk = ~clk;

    // tick_60hz stand-in: a 1-clk pulse every 4 clk
    reg [1:0] div = 0;
    always @(posedge clk) begin
        div  <= div + 2'd1;
        tick <= (div == 2'd3);
    end

    task check(input ok, input [255:0] what);
        begin
            if (!ok) begin
                errors = errors + 1;
                $display("FAIL: %0s (frame=%0d lunge=%0d flash=%b t=%0t)", what, frame, lunge, flash, $time);
            end
        end
    endtask

    task clk_n(input integer n);
        integer i;
        begin for (i = 0; i < n; i = i + 1) @(posedge clk); #1; end
    endtask

    task wait_tick;
        begin @(posedge tick); @(posedge clk); #1; end
    endtask

    task pulse_hurt; begin hurt = 1; clk_n(1); hurt = 0; end endtask
    task pulse_eat;  begin eat  = 1; clk_n(1); eat  = 0; end endtask

    // wait (max_ticks game ticks) until frame == want
    task wait_frame(input [3:0] want, input integer max_ticks);
        integer i;
        begin
            i = 0;
            while (frame != want && i < max_ticks * 4) begin clk_n(1); i = i + 1; end
            check(frame == want, "frame reached");
        end
    endtask

    integer k, seen_max, lsum, bad;
    reg [1:0] prev;
    initial begin
        clk_n(4); rst = 0; clk_n(1);
        check(state == 0 && frame == 0, "starts idle frame 0");
        pulse_eat;
        check(frame == 4'd6, "eat while idle -> bite frame 6");
        for (k = 0; k < 14; k = k + 1) wait_tick;
        check(frame <= 4'd1, "idle again after the bite");
        check(lunge == 0 && !flash, "no effect at start");
        wait_frame(3'd1, 4);                       // idle alternates 0 -> 1
        wait_frame(3'd0, 4);

        moving = 1; clk_n(2);
        check(state == 1 && frame == 3'd2, "moving -> swim frame 2");
        wait_frame(3'd3, 3);                       // swim loop 2,3,4,5
        wait_frame(3'd4, 3);
        wait_frame(3'd5, 3);
        wait_frame(3'd2, 3);

        // eat: lunge rises to 3 and comes back to 0, steps of at most 1,
        // the swim loop keeps running, flash at the start
        pulse_eat;
        check(frame >= 4'd6 && frame <= 4'd9, "eat -> bite frame");
        check(lunge == 1, "eat -> lunge starts at 1");
        check(flash, "eat -> flash");
        seen_max = 0; bad = 0; prev = lunge;
        for (k = 0; k < 14; k = k + 1) begin
            wait_tick;
            if (lunge > seen_max) seen_max = lunge;
            if ((lunge > prev + 1) || (prev > lunge + 1)) bad = bad + 1;
            if (k <= 4 && (frame < 4'd6 || frame > 4'd9)) bad = bad + 1;   // mouth open
            if (k >= 5 && (frame < 4'd2 || frame > 4'd5)) bad = bad + 1;   // mouth shut
            prev = lunge;
        end
        check(seen_max == 3, "lunge reaches 3");
        check(bad == 0, "lunge smooth, bite then swim loop");
        check(lunge == 0, "lunge back to 0");
        check(!flash, "flash over");

        // hurt: flash, no lunge
        pulse_hurt;
        check(flash, "hurt -> flash");
        lsum = 0;
        for (k = 0; k < 6; k = k + 1) begin
            wait_tick; lsum = lsum + lunge;
            if (frame > 4'd5) lsum = lsum + 1;
        end
        check(lsum == 0, "hurt -> no lunge, no bite");
        check(!flash, "hurt flash over");

        // near: the mouth opens while an edible fish is close, shuts when it leaves
        near = 1; clk_n(2);
        check(frame >= 4'd6 && frame <= 4'd9, "near -> mouth open");
        near = 0; clk_n(2);
        check(frame >= 4'd2 && frame <= 4'd5, "fish gone -> mouth shut");

        moving = 0;
        for (k = 0; k < 8; k = k + 1) clk_n(1);
        check(state == 0 && frame <= 4'd1, "stopped -> idle");

        if (errors == 0) $display("PASS");
        else             $display("FAILED: %0d errors", errors);
        $finish;
    end
endmodule
