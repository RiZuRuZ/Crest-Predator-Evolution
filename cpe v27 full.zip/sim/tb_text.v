`timescale 1ns/1ps
// Checks text_line and text_number against font_rom pixel by pixel:
// "A1" at (8,4) and the number 407 at (40,4), both at 1x scale.
// Also checks that something is actually drawn (not an all-blank match).
// This test takes ~40 us of simulated time: type "run all" if PASS is not shown yet.
module tb_text;
    reg clk = 0;
    reg [9:0] px = 0, py = 0;
    wire tl_on, tn_on;
    always #5 clk = ~clk;

    text_line #(.X0(8), .Y0(4), .S(0), .N(2), .TEXT("A1")) u_line (
        .clk(clk), .pixel_x(px), .pixel_y(py), .pixel_on(tl_on));
    text_number #(.X0(40), .Y0(4), .S(0)) u_num (
        .clk(clk), .value(10'd407), .pixel_x(px), .pixel_y(py), .pixel_on(tn_on));

    reg  [7:0] ref_ch;
    reg  [2:0] ref_row;
    wire [4:0] ref_bits;
    font_rom u_ref (.ch(ref_ch), .row(ref_row), .bits(ref_bits));

    integer errors = 0, x, y, gx, gy, col, lit = 0;
    reg exp_l, exp_n;

    initial begin
        repeat (4) @(posedge clk);                 // let text_number register its digits
        for (y = 0; y < 16; y = y + 1) begin
            for (x = 0; x < 72; x = x + 1) begin
                @(negedge clk) begin px = x; py = y; end
                // expected for text_line
                exp_l = 0;
                if (x >= 8 && x < 24 && y >= 4 && y < 12) begin
                    col = (x - 8) / 8; gx = (x - 8) % 8; gy = y - 4;
                    ref_ch = (col == 0) ? "A" : "1"; ref_row = gy; #1;
                    exp_l = (gx < 5) && (gy < 7) && ref_bits[4 - gx];
                end
                // expected for text_number
                exp_n = 0;
                if (x >= 40 && x < 64 && y >= 4 && y < 12) begin
                    col = (x - 40) / 8; gx = (x - 40) % 8; gy = y - 4;
                    ref_ch = (col == 0) ? "4" : (col == 1) ? "0" : "7"; ref_row = gy; #1;
                    exp_n = (gx < 5) && (gy < 7) && ref_bits[4 - gx];
                end
                repeat (3) @(posedge clk);
                #1;
                if (tl_on !== exp_l || tn_on !== exp_n) begin
                    if (errors < 10)
                        $display("FAIL pixel (%0d,%0d): line=%b exp %b, number=%b exp %b",
                                 x, y, tl_on, exp_l, tn_on, exp_n);
                    errors = errors + 1;
                end
                if (exp_l || exp_n) lit = lit + 1;
            end
        end
        if (lit < 20) begin $display("FAIL only %0d lit pixels expected, font looks empty", lit); errors = errors + 1; end
        if (errors == 0) $display("PASS tb_text (%0d lit pixels)", lit);
        $finish;
    end
endmodule
