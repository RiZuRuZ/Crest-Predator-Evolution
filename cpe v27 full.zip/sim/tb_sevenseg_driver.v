`timescale 1ns / 1ps
//==============================================================================
// tb_sevenseg_driver - self-checking testbench for sevenseg_driver
//
// For several values it watches the outputs for a few scan frames, decodes
// the lit segments of each enabled digit and compares with the expected
// decimal digits, including leading-zero blanking and the 999 clamp.
// Uses SCAN_BITS = 4 so the scan is fast in simulation.
//==============================================================================
module tb_sevenseg_driver;

    reg         clk = 1'b0;
    reg         rst = 1'b1;
    reg  [15:0] value = 16'd0;
    wire [7:0]  an;
    wire [6:0]  seg;
    wire        dp;

    sevenseg_driver #(.SCAN_BITS(4)) dut (
        .clk(clk), .rst(rst), .value(value), .an(an), .seg(seg), .dp(dp)
    );

    always #5 clk = ~clk;

    integer errors = 0;
    integer k, p;

    reg [3:0] got  [0:7];
    reg [7:0] seen;

    // decode an active-low segment pattern back to a digit (15 = invalid)
    function [3:0] decode;
        input [6:0] s;
        reg [6:0] a;                       // active-high {g..a}
        begin
            a = ~s;
            case (a)
                7'b0111111: decode = 4'd0;
                7'b0000110: decode = 4'd1;
                7'b1011011: decode = 4'd2;
                7'b1001111: decode = 4'd3;
                7'b1100110: decode = 4'd4;
                7'b1101101: decode = 4'd5;
                7'b1111101: decode = 4'd6;
                7'b0000111: decode = 4'd7;
                7'b1111111: decode = 4'd8;
                7'b1101111: decode = 4'd9;
                default:    decode = 4'd15;
            endcase
        end
    endfunction

    task show_and_check;
        input [15:0] val;
        integer v, h, t, o;
        reg exp_h, exp_t;
        begin
            value = val;
            repeat (80) @(posedge clk);          // let conversion settle
            seen = 8'd0;
            for (k = 0; k < 300; k = k + 1) begin
                @(negedge clk);
                if (dp !== 1'b1) begin
                    $display("FAIL: dp not off");
                    errors = errors + 1;
                end
                for (p = 0; p < 8; p = p + 1) begin
                    if (an === ~(8'b1 << p)) begin
                        seen[p] = 1'b1;
                        got[p]  = decode(seg);
                    end
                end
                if (an !== 8'hFF && !(an === ~(8'b1 << 0) || an === ~(8'b1 << 1) ||
                                      an === ~(8'b1 << 2))) begin
                    $display("FAIL: unexpected digit enable %b for value %0d", an, val);
                    errors = errors + 1;
                end
            end

            v = (val > 999) ? 999 : val;
            h = v / 100;  t = (v / 10) % 10;  o = v % 10;
            exp_h = (h != 0);
            exp_t = (h != 0) || (t != 0);

            if (!seen[0] || got[0] !== o) begin
                $display("FAIL: value %0d ones digit got %0d expected %0d", val, got[0], o);
                errors = errors + 1;
            end
            if (seen[1] !== exp_t || (exp_t && got[1] !== t)) begin
                $display("FAIL: value %0d tens digit (seen=%b got=%0d, expected %s %0d)",
                         val, seen[1], got[1], exp_t ? "shown" : "blank", t);
                errors = errors + 1;
            end
            if (seen[2] !== exp_h || (exp_h && got[2] !== h)) begin
                $display("FAIL: value %0d hundreds digit (seen=%b got=%0d, expected %s %0d)",
                         val, seen[2], got[2], exp_h ? "shown" : "blank", h);
                errors = errors + 1;
            end
            if (seen[7:3] !== 5'd0) begin
                $display("FAIL: value %0d lit an unused digit (%b)", val, seen);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        repeat (3) @(posedge clk);
        #1 rst = 1'b0;

        show_and_check(16'd0);
        show_and_check(16'd7);
        show_and_check(16'd10);
        show_and_check(16'd42);
        show_and_check(16'd100);
        show_and_check(16'd205);
        show_and_check(16'd499);
        show_and_check(16'd500);
        show_and_check(16'd999);
        show_and_check(16'd1234);     // clamped to 999
        show_and_check(16'd5);        // back to a short number: blanks again

        if (errors == 0) $display("PASS: sevenseg_driver, all checks OK");
        else             $display("DONE with %0d error(s)", errors);
        $finish;
    end

endmodule
