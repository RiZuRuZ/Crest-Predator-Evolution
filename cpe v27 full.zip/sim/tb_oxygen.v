`timescale 1ns/1ps
// Checks oxygen_ctrl + oxygen_led_bar: drain, dash cost, bubble refill (normal and
// double), clamp at max, can_dash, empty is sticky, LED bar levels, reset
// This test takes ~25 us of simulated time: type "run all" if PASS is not shown yet.
module tb_oxygen;
    reg clk = 0, rst = 1, tick = 0, dash = 0, bubble = 0, dbl = 0;
    wire [9:0] oxy;
    wire empty, can_dash;
    wire [15:0] led;
    always #5 clk = ~clk;

    oxygen_ctrl #(.OXY_MAX(960), .DRAIN_TICKS(2), .DASH_COST(60), .BUBBLE_REFILL(240)) dut (
        .clk(clk), .rst(rst), .tick_60hz(tick), .diff(2'd1), .dash_start(dash),
        .bubble_eat(bubble), .double_refill(dbl), .hold(1'b0), .penalty(1'b0),
        .oxygen(oxy), .empty(empty), .can_dash(can_dash));
    oxygen_led_bar #(.OXY_MAX(960)) u_led (.oxygen(oxy), .led(led));

    integer errors = 0, i;

    task do_tick;   begin @(negedge clk) tick = 1;   @(negedge clk) tick = 0;   end endtask
    task do_dash;   begin @(negedge clk) dash = 1;   @(negedge clk) dash = 0;   end endtask
    task do_bubble; begin @(negedge clk) bubble = 1; @(negedge clk) bubble = 0; end endtask
    task check(input [9:0] exp, input [15:0] exp_led, input [255:0] name);
        begin
            if (oxy !== exp || led !== exp_led) begin
                $display("FAIL %0s: oxygen=%0d led=%h, expected %0d %h", name, oxy, led, exp, exp_led);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        #25 rst = 0;
        @(negedge clk); check(960, 16'hFFFF, "start");
        for (i = 0; i < 4; i = i + 1) do_tick;
        check(958, 16'hFFFF, "drain 1 per 2 ticks");
        do_dash;   check(898, 16'h7FFF, "dash cost");
        do_bubble; check(960, 16'hFFFF, "refill clamped");
        for (i = 0; i < 15; i = i + 1) do_dash;
        check(60, 16'h0001, "after 15 dashes");
        if (can_dash !== 0) begin $display("FAIL can_dash at 60"); errors = errors + 1; end
        dbl = 1;
        do_bubble; check(540, 16'h01FF, "double refill");
        dbl = 0;
        if (can_dash !== 1) begin $display("FAIL can_dash at 540"); errors = errors + 1; end

        for (i = 0; i < 1200 && !empty; i = i + 1) do_tick;
        if (empty !== 1) begin $display("FAIL never empty"); errors = errors + 1; end
        check(0, 16'h0000, "empty");
        do_bubble; check(0, 16'h0000, "no refill after empty");
        if (empty !== 1) begin $display("FAIL empty not sticky"); errors = errors + 1; end

        @(negedge clk) rst = 1; @(negedge clk) rst = 0; @(negedge clk);
        check(960, 16'hFFFF, "reset");
        if (empty !== 0) begin $display("FAIL empty after reset"); errors = errors + 1; end

        if (errors == 0) $display("PASS tb_oxygen");
        $finish;
    end
endmodule
