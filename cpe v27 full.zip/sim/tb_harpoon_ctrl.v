// tb_harpoon_ctrl: volley size, spread of the lanes, homing (follows, then locks),
// and the speed-up after the shot. Prints PASS or FAIL lines, then "DONE".
// Run with: run all
`timescale 1ns / 1ps
module tb_harpoon_ctrl;
    reg clk = 0;
    always #5 clk = ~clk;

    reg        rst = 1;
    reg        tick = 0;
    reg [15:0] rand = 16'h0000;    // 0: homing on, every lane horizontal, flying right
    reg [2:0]  form = 3'd2;
    reg [10:0] pcx = 11'd960;
    reg [9:0]  pcy = 10'd320;

    wire        hurt, warn_on, fly_on, homing, locked;
    wire [10:0] hit_cx, aim_x;
    wire [9:0]  hit_cy, aim_y;
    wire [6:0]  warn_t;
    wire [4:0]  lane_on, vert, back;
    wire [54:0] lx_v, hx_v, hy_v;
    wire [49:0] ly_v;
    wire [2:0]  frame;

    harpoon_ctrl #(.N(5)) dut (
        .clk(clk), .rst(rst), .tick_60hz(tick), .rand(rand), .form(form), .diff(2'd1), .pause(1'b0), .clear(1'b0), .wide(1'b0),
        .cam_x(11'd640), .cam_y(10'd80), .player_cx(pcx), .player_cy(pcy),
        // hitbox far away from every lane: no hits
        .player_x(11'd100), .player_y(10'd600), .player_w(8'd4), .player_h(8'd4),
        .hurt(hurt), .hit_cx(hit_cx), .hit_cy(hit_cy),
        .warn_on(warn_on), .fly_on(fly_on), .warn_t(warn_t),
        .homing(homing), .locked(locked), .aim_x(aim_x), .aim_y(aim_y),
        .lane_on(lane_on), .vert(vert), .back(back),
        .line_x_vec(lx_v), .line_y_vec(ly_v), .hx_vec(hx_v), .hy_vec(hy_v), .frame(frame)
    );

    // one game tick every 4 clocks
    integer c = 0;
    always @(posedge clk) begin
        c    <= c + 1;
        tick <= (c % 4 == 3);
    end

    integer errors = 0;
    task check(input cond, input [255:0] msg);
        begin
            if (cond) $display("PASS: %0s", msg);
            else begin $display("FAIL: %0s", msg); errors = errors + 1; end
        end
    endtask

    reg [10:0] h0, h1, h2;
    initial begin
        repeat (5) @(posedge clk);
        rst = 0;

        wait (warn_on);
        @(posedge clk);
        check(lane_on == 5'b00111, "form 2 -> volley of 3 harpoons");
        check(homing == 1'b1,      "rand = 0 -> homing volley");
        check(ly_v[19:10] == 10'd400 && ly_v[29:20] == 10'd240,
              "lanes 1 and 2 spread 80 px to both sides of the player");

        // homing line follows the player while not locked
        pcy = 10'd300;
        repeat (12) @(posedge clk);
        check(ly_v[9:0] == 10'd300 && aim_y == 10'd300, "homing line follows the player");

        // after the lock it stays
        wait (locked);
        repeat (2) @(posedge clk);
        pcy = 10'd250;
        repeat (40) @(posedge clk);
        check(ly_v[9:0] == 10'd300, "homing line stays after the lock");

        // speed-up after the shot
        wait (fly_on);
        @(posedge tick); @(posedge clk); h0 = hx_v[10:0];
        @(posedge tick); @(posedge clk); h1 = hx_v[10:0];
        @(posedge tick); @(posedge clk); h2 = hx_v[10:0];
        check((h2 - h1) == (h1 - h0) + 11'd1, "harpoon speeds up by 1 px per tick");

        wait (!fly_on);
        check(lane_on == 5'b00000, "volley ends");

        if (errors == 0) $display("ALL PASS");
        $display("DONE");
        $finish;
    end
endmodule
