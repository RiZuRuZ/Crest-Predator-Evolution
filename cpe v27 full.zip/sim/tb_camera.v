`timescale 1ns/1ps
// Checks camera: player kept in the middle, x wraps around the 1920 world, y stops at the
// world top/bottom, the camera only moves on `update`, world_x/world_y of a screen pixel
module tb_camera;
    reg clk = 0, rst = 1, upd = 0;
    reg [10:0] plx = 952;
    reg [9:0]  ply = 312;
    reg [9:0]  pxs = 0, pys = 0;
    wire [10:0] cam_x, wx;
    wire [9:0]  cam_y, wy;
    always #5 clk = ~clk;

    camera dut (.clk(clk), .rst(rst), .update(upd),
                .player_x(plx), .player_y(ply), .player_w(8'd16), .player_h(8'd16), .zoom(5'd16),
                .pixel_x(pxs), .pixel_y(pys), .shake_x(4'sd0), .shake_y(4'sd0),
                .cam_x(cam_x), .cam_y(cam_y), .world_x(wx), .world_y(wy));

    integer errors = 0;
    task do_update; begin @(negedge clk) upd = 1; @(negedge clk) upd = 0; @(negedge clk); end endtask
    task check_cam(input [10:0] ex, input [9:0] ey, input [255:0] name);
        begin
            if (cam_x !== ex || cam_y !== ey) begin
                $display("FAIL %0s: cam=(%0d,%0d) expected (%0d,%0d)", name, cam_x, cam_y, ex, ey);
                errors = errors + 1;
            end
        end
    endtask
    task check_world(input [9:0] sx, input [9:0] sy, input [10:0] ex, input [9:0] ey, input [255:0] name);
        begin
            @(negedge clk) begin pxs = sx; pys = sy; end
            @(negedge clk);
            if (wx !== ex || wy !== ey) begin
                $display("FAIL %0s: world=(%0d,%0d) expected (%0d,%0d)", name, wx, wy, ex, ey);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        #25 rst = 0;
        do_update;  check_cam(640, 80, "start in the middle");      // center (960,320) - (320,240)
        check_world(320, 240, 960, 320, "screen center = player center");

        plx = 100;  check_cam(640, 80, "no move without update");
        do_update;  check_cam(1708, 80, "x wraps left");             // 108 - 320 + 1920
        check_world(300, 10, 88, 90, "pixel across the seam");       // 1708 + 300 - 1920

        plx = 1900; do_update; check_cam(1588, 80, "near the right end");
        ply = 0;    do_update; check_cam(1588, 0,   "stops at the top");
        ply = 624;  do_update; check_cam(1588, 160, "stops at the bottom");
        ply = 300;  do_update; check_cam(1588, 68,  "free in between");

        if (errors == 0) $display("PASS tb_camera");
        $finish;
    end
endmodule
