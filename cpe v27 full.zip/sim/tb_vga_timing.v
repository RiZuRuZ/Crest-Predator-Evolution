`timescale 1ns/1ps
// Checks: 1 line = 800 pixels, 1 frame = 420000 pixels, 640 visible pixels per line and 480 visible lines
module tb_vga_timing;
    reg clk = 0, rst = 1;
    wire hsync, vsync, active_video;
    wire [9:0] x, y;
    always #5 clk = ~clk;

    vga_timing dut (.clk(clk), .rst(rst), .pix_ce(1'b1),
                    .hsync(hsync), .vsync(vsync), .x(x), .y(y),
                    .active_video(active_video));

    integer cyc = 0, last_h = -1, last_v = -1, errors = 0;
    integer active_in_line = 0, active_lines = 0;
    reg hs_d = 1, vs_d = 1;

    always @(posedge clk) if (!rst) begin
        cyc <= cyc + 1;
        hs_d <= hsync; vs_d <= vsync;
        if (hs_d && !hsync) begin
            if (last_h >= 0 && (cyc - last_h) != 800) begin
                $display("FAIL hsync period = %0d", cyc - last_h); errors = errors + 1;
            end
            last_h <= cyc;
        end
        if (vs_d && !vsync) begin
            if (last_v >= 0 && (cyc - last_v) != 420000) begin
                $display("FAIL vsync period = %0d", cyc - last_v); errors = errors + 1;
            end
            last_v <= cyc;
        end
        if (active_video) active_in_line = active_in_line + 1;
        if (x == 799) begin
            if (active_in_line != 0 && active_in_line != 640) begin
                $display("FAIL active pixels per line = %0d", active_in_line); errors = errors + 1;
            end
            if (active_in_line == 640) active_lines = active_lines + 1;
            active_in_line = 0;
        end
    end

    initial begin
        #50 rst = 0;
        #(10 * 900000);
        if (active_lines < 480) begin
            $display("FAIL active lines = %0d", active_lines); errors = errors + 1;
        end
        if (errors == 0) $display("PASS tb_vga_timing");
        else             $display("tb_vga_timing: %0d errors", errors);
        $finish;
    end
endmodule
