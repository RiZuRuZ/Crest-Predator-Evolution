`timescale 1ns/1ps
// Checks player_bounds (world top/bottom clamp, left/right wrap at 1920), player_move and
// player_geom (sprite box and mirrored hitbox per form, wrap across the map seam)
module tb_player;
    reg  [10:0] x;
    reg  [9:0]  y;
    reg  signed [6:0] dx, dy;
    wire [10:0] nx;
    wire [9:0]  ny;
    player_bounds b (.x(x), .y(y), .dx(dx), .dy(dy), .size_h(8'd16), .next_x(nx), .next_y(ny));

    reg bu, bd, bl, br;
    wire signed [6:0] mdx, mdy;
    player_move m (.btn_u(bu), .btn_d(bd), .btn_l(bl), .btn_r(br),
                   .speed(4'd4), .current_dx(6'sd0), .dx(mdx), .dy(mdy));

    reg  [10:0] gcx;
    reg  [9:0]  gcy;
    reg  [2:0]  gform;
    reg         gleft;
    wire [7:0]  gsw, gsh, ghw, ghh;
    wire [10:0] gsx, ghx;
    wire [9:0]  gsy, ghy;
    player_geom g (.cx(gcx), .cy(gcy), .form(gform), .facing_left(gleft), .shrink(1'b0),
                   .spr_w(gsw), .spr_h(gsh), .spr_x(gsx), .spr_y(gsy),
                   .hb_x(ghx), .hb_y(ghy), .hb_w(ghw), .hb_h(ghh));

    integer errors = 0;
    task chk_b(input [10:0] ex, input [9:0] ey, input [255:0] name);
        begin #1;
            if (nx !== ex || ny !== ey) begin
                $display("FAIL %0s: got (%0d,%0d) want (%0d,%0d)", name, nx, ny, ex, ey);
                errors = errors + 1;
            end
        end
    endtask
    task chk_g(input [10:0] esx, input [9:0] esy, input [10:0] ehx, input [9:0] ehy, input [255:0] name);
        begin #1;
            if (gsx !== esx || gsy !== esy || ghx !== ehx || ghy !== ehy) begin
                $display("FAIL geom %0s: spr (%0d,%0d) hb (%0d,%0d)", name, gsx, gsy, ghx, ghy);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        x = 100; y = 100; dx = 4; dy = -4;   chk_b(104, 96, "normal");
        x = 1916; y = 100; dx = 10; dy = 0;  chk_b(6,    100, "wrap right");
        x = 3;    y = 100; dx = -10; dy = 0; chk_b(1913, 100, "wrap left");
        x = 700;  y = 100; dx = 8; dy = 0;   chk_b(708,  100, "past 640 is fine now");
        x = 100;  y = 2;   dx = 0; dy = -10; chk_b(100,  0,   "clamp top");
        x = 100;  y = 620; dx = 0; dy = 10;  chk_b(100,  624, "clamp bottom");
        x = 100;  y = 470; dx = 0; dy = 10;  chk_b(100,  480, "below 480 is fine now");

        bu = 0; bd = 0; bl = 0; br = 1; #1;
        if (mdx !== 4 || mdy !== 0) begin $display("FAIL move right"); errors = errors + 1; end
        br = 0; bl = 1; bu = 1; #1;
        if (mdx !== -4 || mdy !== -4) begin $display("FAIL move left+up"); errors = errors + 1; end
        bl = 1; br = 1; bu = 0; bd = 1; #1;
        if (mdx !== 0 || mdy !== 4) begin $display("FAIL opposite cancel"); errors = errors + 1; end

        // player_geom: centre (960,320), form 1 (73x41, hitbox 32,12,35,22)
        gcx = 960; gcy = 320; gform = 1; gleft = 0;
        chk_g(924, 300, 956, 312, "form 1 facing right");
        gleft = 1;
        chk_g(924, 300, 930, 312, "form 1 facing left (mirrored hitbox)");
        gleft = 0; gcx = 10;
        chk_g(1894, 300, 6, 312, "x wraps around the seam");
        gcx = 960; gcy = 40; gform = 4;                   // 171x106, hitbox 78,34,91,42
        chk_g(875, 0, 953, 34, "form 4 near the top: sprite clamped at y 0");

        if (errors == 0) $display("PASS tb_player");
        $finish;
    end
endmodule
