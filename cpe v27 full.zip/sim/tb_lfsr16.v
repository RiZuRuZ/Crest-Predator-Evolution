`timescale 1ns / 1ps
//==============================================================================
// tb_lfsr16 - self-checking testbench for lfsr16
//
// Checks:
//   1. reset loads SEED
//   2. the state holds while en = 0
//   3. the state never becomes zero
//   4. the sequence is maximal length: it returns to SEED after exactly
//      65535 enabled steps, and never hits SEED earlier
//==============================================================================
module tb_lfsr16;

    reg         clk = 1'b0;
    reg         rst = 1'b1;
    reg         en  = 1'b0;
    wire [15:0] rnd;

    localparam [15:0] SEED = 16'hACE1;

    lfsr16 #(.SEED(SEED)) dut (
        .clk(clk),
        .rst(rst),
        .en (en),
        .rnd(rnd)
    );

    always #5 clk = ~clk;   // 100 MHz

    integer i;
    integer errors = 0;
    reg [15:0] held;

    initial begin
        // 1. reset loads SEED
        repeat (3) @(posedge clk);
        #1;
        if (rnd !== SEED) begin
            $display("FAIL: reset value %h, expected %h", rnd, SEED);
            errors = errors + 1;
        end
        rst = 1'b0;

        // 2. hold while en = 0
        held = rnd;
        repeat (10) @(posedge clk);
        #1;
        if (rnd !== held) begin
            $display("FAIL: state changed while en = 0");
            errors = errors + 1;
        end

        // 3 + 4. full period walk
        en = 1'b1;
        for (i = 1; i <= 65535; i = i + 1) begin
            @(posedge clk);
            #1;
            if (rnd === 16'h0000) begin
                $display("FAIL: zero state at step %0d", i);
                errors = errors + 1;
            end
            if (rnd === SEED && i != 65535) begin
                $display("FAIL: returned to SEED early at step %0d", i);
                errors = errors + 1;
            end
            if (i == 65535 && rnd !== SEED) begin
                $display("FAIL: not back at SEED after 65535 steps (got %h)", rnd);
                errors = errors + 1;
            end
        end
        en = 1'b0;

        if (errors == 0) $display("PASS: lfsr16 maximal length (65535), all checks OK");
        else             $display("DONE with %0d error(s)", errors);
        $finish;
    end

endmodule
