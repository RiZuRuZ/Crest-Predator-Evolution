`timescale 1ns/1ps
// Testbench for switch_puzzle: start -> LEDs show the switches to flip, flipping them
// clears the LEDs and gives solved, flipping one back makes it blink again.
// Prints "PASS" at the end. "run 1000ns" is enough.
module tb_switch_puzzle;
    reg         clk = 0, rst = 1, start = 0, active = 0, blink = 1;
    reg  [11:0] sw = 12'b0000_1010_0000;
    reg  [15:0] rnd = 16'h2153;          // first switch 3, extra = 2 -> switches 5 and 1
    wire [11:0] led;
    wire        solved, running;
    integer errors = 0;

    switch_puzzle dut (.clk(clk), .rst(rst), .start(start), .active(active), .sw(sw),
                       .rand(rnd), .blink(blink), .led(led), .solved(solved), .running(running));

    always #5 clk = ~clk;

    task check(input ok, input [255:0] what);
        begin
            if (!ok) begin errors = errors + 1; $display("FAIL: %0s (led=%b)", what, led); end
        end
    endtask

    reg [11:0] todo;
    initial begin
        #20 rst = 0; active = 1;
        #10 check(!running && led == 12'd0, "idle: no LEDs");
        start = 1; #10 start = 0; #1;
        check(running, "running after start");
        todo = led;
        check(todo != 12'd0, "some switches to flip");
        check(!solved, "not solved yet");
        blink = 0; #1 check(led == 12'd0, "LEDs blink (off phase)");
        blink = 1; #1;
        sw = sw ^ todo; #10;
        check(solved && led == 12'd0, "flipping the blinking switches solves it");
        sw[0] = ~sw[0]; #10;
        check(!solved && led[0], "wrong switch blinks");
        sw[0] = ~sw[0]; #10;
        check(solved, "flipped back: solved again");
        active = 0; #10;
        check(!running && !solved, "event over: puzzle cleared");
        if (errors == 0) $display("PASS");
        else             $display("FAILED: %0d errors", errors);
        $finish;
    end
endmodule
