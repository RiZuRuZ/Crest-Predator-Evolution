`timescale 1ns/1ps
// Checks hit_recovery with short timings: invuln length, blinking, knockback away
// from the hitter's center (including the map seam at 1920) and knockback length
module tb_hit_recovery;
    reg clk = 0, rst = 1, tick = 0, hit = 0;
    reg [10:0] px = 100, hcx = 0;
    reg [9:0]  py = 100, hcy = 0;
    wire invuln, blink_hide;
    wire signed [6:0] kdx, kdy;
    always #5 clk = ~clk;

    hit_recovery #(.INVULN_TICKS(6), .BLINK_TICKS(2), .KNOCK_TICKS(3), .KNOCK_SPEED(3)) dut (
        .clk(clk), .rst(rst), .tick_60hz(tick), .hit(hit),
        .player_x(px), .player_y(py), .player_w(8'd16), .player_h(8'd16),
        .hit_cx(hcx), .hit_cy(hcy),
        .invuln(invuln), .blink_hide(blink_hide),
        .knock_dx(kdx), .knock_dy(kdy));

    integer errors = 0, i, seen_show, seen_hide;

    task do_tick;
        begin @(negedge clk) tick = 1; @(negedge clk) tick = 0; end
    endtask
    task do_hit;
        begin @(negedge clk) hit = 1; @(negedge clk) hit = 0; end
    endtask
    task wait_out;
        begin for (i = 0; i < 6; i = i + 1) do_tick; end
    endtask
    task check_knock(input signed [6:0] ex, input signed [6:0] ey, input [255:0] name);
        begin
            if (kdx !== ex || kdy !== ey) begin
                $display("FAIL %0s: knock=(%0d,%0d) expected (%0d,%0d)", name, kdx, kdy, ex, ey);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        #25 rst = 0;
        @(negedge clk);
        if (invuln !== 0 || blink_hide !== 0) begin $display("FAIL idle"); errors = errors + 1; end
        check_knock(0, 0, "idle");

        // player center (108,108), fish to the left at the same height: push right only
        hcx = 90; hcy = 108;
        do_hit;
        hcx = 200;                                   // later changes must not matter (latched)
        if (invuln !== 1) begin $display("FAIL invuln not set"); errors = errors + 1; end
        check_knock(3, 0, "fish on the left");
        seen_show = 0; seen_hide = 0;
        for (i = 0; i < 3; i = i + 1) begin
            if (blink_hide) seen_hide = 1; else seen_show = 1;
            do_tick;
        end
        check_knock(0, 0, "knock over after 3 ticks");
        if (invuln !== 1) begin $display("FAIL invuln ended too early"); errors = errors + 1; end
        for (i = 0; i < 3; i = i + 1) begin
            if (blink_hide) seen_hide = 1; else seen_show = 1;
            do_tick;
        end
        if (!(seen_show && seen_hide)) begin $display("FAIL no blinking"); errors = errors + 1; end
        if (invuln !== 0 || blink_hide !== 0) begin $display("FAIL invuln not over after 6 ticks"); errors = errors + 1; end

        // fish below-right of the player: push left and up
        hcx = 120; hcy = 120;
        do_hit;
        check_knock(-3, -3, "fish below-right");
        wait_out;

        // across the map seam: player center 1918, fish center 5 is just to the right -> push left
        px = 1910; hcx = 5; hcy = 108;
        do_hit;
        check_knock(-3, 0, "fish across right edge");
        wait_out;

        // same center: no push, still invulnerable
        px = 100; hcx = 108; hcy = 108;
        do_hit;
        check_knock(0, 0, "same center");
        if (invuln !== 1) begin $display("FAIL same-center invuln"); errors = errors + 1; end

        if (errors == 0) $display("PASS tb_hit_recovery");
        $finish;
    end
endmodule
