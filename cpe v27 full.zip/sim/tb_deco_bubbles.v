`timescale 1ns/1ps
// Checks deco_bubbles (random bubbles):
//   - after reset bubbles appear one per frame, around the camera view, from the sea floor
//   - alive bubbles rise
//   - when the camera jumps far away, the old bubbles are freed (and respawn near it later)
//   - a bubble is drawn as a ring: top middle lit, center empty (output 1 clock late)
// This test takes ~20 us of simulated time: type "run all" if PASS is not shown yet.
module tb_deco_bubbles;
    reg clk = 0, rst = 1, ft = 0;
    reg [10:0] cam = 11'd0;
    reg [10:0] wx = 0;
    reg [9:0]  wy = 0;
    wire on;
    wire [11:0] rgb;
    always #5 clk = ~clk;

    deco_bubbles dut (.clk(clk), .rst(rst), .frame_tick(ft), .cam_x(cam),
                      .world_x(wx), .world_y(wy), .pixel_on(on), .rgb(rgb));

    integer errors = 0, i, alive_n, bad_pos;
    reg [9:0]  y_before;
    reg [11:0] rel;
    reg [3:0]  sz;
    task tick; begin @(negedge clk) ft = 1; @(negedge clk) ft = 0; repeat (5) @(negedge clk); end endtask
    task px(input [10:0] x, input [9:0] y, input exp, input [255:0] name);
        begin
            @(negedge clk) begin wx = x; wy = y; end
            @(posedge clk); #1;
            if (on !== exp) begin $display("FAIL %0s: on=%b at (%0d,%0d)", name, on, x, y); errors = errors + 1; end
        end
    endtask

    initial begin
        #25 rst = 0;
        repeat (24) tick;
        alive_n = 0; bad_pos = 0;
        for (i = 0; i < 24; i = i + 1) if (dut.alive[i]) begin
            alive_n = alive_n + 1;
            rel = (dut.bx[i] + 1920 - cam) % 1920;
            if (!(rel < 704 || rel >= 1856)) bad_pos = bad_pos + 1;      // camera view +- 64
            if (dut.by[i] < 360 || dut.by[i] > 620) bad_pos = bad_pos + 1;  // near the sea floor
        end
        if (alive_n < 20) begin $display("FAIL only %0d bubbles alive after 24 frames", alive_n); errors = errors + 1; end
        if (bad_pos != 0) begin $display("FAIL %0d bubbles spawned in a wrong place", bad_pos); errors = errors + 1; end

        // they rise
        y_before = dut.by[0];
        repeat (8) tick;
        if (!(dut.by[0] < y_before)) begin $display("FAIL bubble 0 did not rise (%0d -> %0d)", y_before, dut.by[0]); errors = errors + 1; end

        // ring drawing for bubble 0 (no wobble check: look for the lit top row near its x)
        sz = dut.bsz[0];
        px(dut.bx[0] + sz / 2, dut.by[0] + sz / 2, 1'b0, "center is empty");

        // camera far away: everything near the old camera is freed on the next frame
        cam = 11'd1000;
        tick;
        alive_n = 0;
        for (i = 0; i < 24; i = i + 1) if (dut.alive[i]) alive_n = alive_n + 1;
        if (alive_n > 1) begin $display("FAIL %0d far bubbles still alive", alive_n); errors = errors + 1; end
        repeat (24) tick;
        bad_pos = 0;
        for (i = 0; i < 24; i = i + 1) if (dut.alive[i]) begin
            rel = (dut.bx[i] + 1920 - cam) % 1920;
            if (!(rel < 704 || rel >= 1856)) bad_pos = bad_pos + 1;
        end
        if (bad_pos != 0) begin $display("FAIL %0d bubbles respawned away from the camera", bad_pos); errors = errors + 1; end

        if (errors == 0) $display("PASS tb_deco_bubbles");
        $finish;
    end
endmodule
