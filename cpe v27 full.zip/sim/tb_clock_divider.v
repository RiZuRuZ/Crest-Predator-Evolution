`timescale 1ns/1ps
// Checks pix_ce every 4 clk and tick every TICK_DIV clk (value reduced to keep simulation short)
module tb_clock_divider;
    reg clk = 0, rst = 1;
    wire pix_ce, tick_60hz;
    always #5 clk = ~clk;

    clock_divider #(.PIX_DIV(4), .TICK_DIV(100)) dut (
        .clk(clk), .rst(rst), .pix_ce(pix_ce), .tick_60hz(tick_60hz));

    integer cyc = 0, lp = -1, lt = -1, errors = 0;
    always @(posedge clk) if (!rst) begin
        cyc <= cyc + 1;
    end
    reg pce_d = 0, t_d = 0;
    always @(posedge clk) begin
        pce_d <= pix_ce; t_d <= tick_60hz;
        if (pix_ce && !pce_d) begin
            if (lp >= 0 && (cyc - lp) != 4) begin $display("FAIL pix period %0d", cyc - lp); errors = errors + 1; end
            lp <= cyc;
        end
        if (tick_60hz && !t_d) begin
            if (lt >= 0 && (cyc - lt) != 100) begin $display("FAIL tick period %0d", cyc - lt); errors = errors + 1; end
            lt <= cyc;
        end
    end

    initial begin
        #30 rst = 0;
        #5000;
        if (lp < 0 || lt < 0) begin $display("FAIL no pulses"); errors = errors + 1; end
        if (errors == 0) $display("PASS tb_clock_divider");
        $finish;
    end
endmodule
