`timescale 1ns/1ps
// Simulates a bouncing button, then checks that btn_pulse fires exactly once and btn_sync settles at 1, returning to 0 on release
module tb_button_conditioner;
    reg clk = 0, rst = 1, raw = 0;
    wire sync, pulse;
    always #5 clk = ~clk;

    button_conditioner #(.DEBOUNCE_CYCLES(8)) dut (
        .clk(clk), .rst(rst), .raw_btn(raw), .btn_sync(sync), .btn_pulse(pulse));

    integer pulses = 0, errors = 0;
    always @(posedge clk) if (pulse) pulses = pulses + 1;

    initial begin
        #30 rst = 0;
        // bounce
        repeat (3) begin raw = 1; #20; raw = 0; #20; end
        #200;
        if (sync !== 0 || pulses != 0) begin $display("FAIL bounce leaked"); errors = errors + 1; end
        // real press
        raw = 1; #300;
        if (sync !== 1) begin $display("FAIL sync not 1"); errors = errors + 1; end
        if (pulses != 1) begin $display("FAIL pulses = %0d", pulses); errors = errors + 1; end
        // release
        raw = 0; #300;
        if (sync !== 0) begin $display("FAIL sync not 0"); errors = errors + 1; end
        if (pulses != 1) begin $display("FAIL extra pulse on release"); errors = errors + 1; end
        if (errors == 0) $display("PASS tb_button_conditioner");
        $finish;
    end
endmodule
